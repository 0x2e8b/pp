"""The official Sycope 3.3 template names of rules the catalog already had under a shorter name.

The catalog (rules.py) was written from the lab, where alert_cluster's short names arrive ("SYN Flood"); a customer
with the stock Sycope 3.3 templates gets the official ones ("SYN Flood Attack", Impact_040). Both are the same rule
and mean the same thing, so the catalog lists the official name beside the short one with the same classification.
Every table that is keyed by a rule name (the catalog, the ATT&CK map, the legacy cluster map, the short wordings, the
C2 threat-intel set) takes its alias rows from this one dict instead of repeating them.
"""

from __future__ import annotations

# official template name -> the catalog's short name of the same rule
ALIASES: dict[str, str] = {
    "SYN Flood Attack": "SYN Flood",
    "DDoS Protocol Flood": "Protocol Flood",
    "DDoS DNS Amplification Attack": "DNS Amplification",
    "DoS Attack": "DoS",
    "Possible DNS Reflection Attack": "DNS Reflection",
    "Excessive ICMP Requests": "Excessive ICMP",
    "FTP Data Exfiltration": "FTP Exfil",
    "High IP Count on Device": "High IP Count",
    "IRC Traffic Detected": "IRC Traffic",
    "Kerberos Traffic to External": "Kerberos External",
    "LDAP to External": "LDAP External",
    "Multiple Protocols Same Destination": "Multiple Protocols Same Dest",
    "Proxy/SOCKS Traffic Detected": "Proxy/SOCKS",
    "RDP Brute Force (Slow)": "RDP Brute Force Slow",
    "SSH Brute Force (Slow)": "SSH Brute Force Slow",
    "Repeated Connection (C2 Polling)": "Repeated Connection",
    "Suspicious Domain - Malware via DNS": "Suspicious Domain - DNS",
    "Suspicious Domain - Malware via HTTP": "Suspicious Domain - HTTP",
    "Suspicious JA3 Fingerprint": "Suspicious JA3",
    "Suspicious Small Payload Beaconing": "Small Payload Beaconing",
    "Unknown Device Detected": "Unknown Device",
    "Watch Device Detected": "Watch Device",
}


def extend(table: dict, aliases: dict[str, str] = ALIASES) -> dict:
    """`table` (keyed by rule name) with a row for every official name whose short name has one: the same value."""
    for official, short in aliases.items():
        if short in table and official not in table:
            table[official] = table[short]
    return table
