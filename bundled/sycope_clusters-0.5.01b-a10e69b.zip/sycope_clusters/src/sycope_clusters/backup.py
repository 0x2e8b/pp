"""A daily copy of the state database, and the way back when the file is damaged.

    daily(db, out_dir, keep, now)   one consistent copy per UTC day (sqlite's online backup, safe while the service
                                    writes) as `clusters-YYYY-MM-DD.db`, the newest `keep` kept
    restore_if_corrupt(db, out_dir) at start, before the Store opens: a file that fails PRAGMA quick_check is set
                                    aside as `<name>.corrupt-<unix time>` (never deleted, with its -wal and -shm) and
                                    the newest good backup takes its place; a file that merely cannot be read now
                                    (locked) is left alone

A backup is written under a temporary name and renamed, so a crash never leaves a half copy that looks complete.
"""

from __future__ import annotations

import logging
import os
import shutil
import sqlite3
import time
from pathlib import Path

log = logging.getLogger("sycope_clusters.backup")
PREFIX, SUFFIX = "clusters-", ".db"
CORRUPT_TEXT = "The state database was corrupt"
CHECK_TIMEOUT_S = 2.0      # how long the start-up check waits for a lock


def name_for(now: float) -> str:
    """The file name of the backup of the UTC day of `now`."""
    return PREFIX + time.strftime("%Y-%m-%d", time.gmtime(now)) + SUFFIX


def backups(out_dir: Path) -> list[Path]:
    """The backup files, oldest first (the date is in the name)."""
    try:
        return sorted(p for p in Path(out_dir).iterdir() if p.name.startswith(PREFIX) and p.name.endswith(SUFFIX))
    except OSError:
        return []


def latest(out_dir: Path) -> Path | None:
    got = backups(out_dir)
    return got[-1] if got else None


def daily(db_path: Path, out_dir: Path, keep: int = 7, now: float | None = None) -> Path:
    """Copy the database into `out_dir` as the backup of the UTC day of `now` (replacing that day's earlier copy)
    and delete the oldest copies beyond `keep`. Returns the file. Raises OSError or sqlite3.Error; a half-written
    copy never stays behind."""
    now = time.time() if now is None else now
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / name_for(now)
    tmp = target.with_name(target.name + ".tmp")
    tmp.unlink(missing_ok=True)
    try:
        src = sqlite3.connect(_uri(db_path, "ro"), uri=True, timeout=30)
        try:
            dst = sqlite3.connect(tmp)
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
        os.replace(tmp, target)
    finally:
        tmp.unlink(missing_ok=True)
    for old in backups(out_dir)[:-max(1, keep)]:
        old.unlink(missing_ok=True)
    return target


def _uri(path: Path, mode: str) -> str:
    """A sqlite file: URI for the path (percent-encoded: a path may hold % or ?)."""
    return f"{Path(path).resolve().as_uri()}?mode={mode}"


OK, CORRUPT, UNKNOWN = "ok", "corrupt", "unknown"


def check(path: Path) -> tuple[str, str]:
    """(OK | CORRUPT | UNKNOWN, detail). CORRUPT only on a wrong header, a failed quick_check or a sqlite error that
    says the file is not a database (DatabaseError that is not an OperationalError). A file that cannot be read now
    (locked, permissions, busy) is UNKNOWN: it is not touched. The header is read first: a leftover -wal can hold a
    good first page and hide a damaged file from the check."""
    try:
        with open(path, "rb") as f:
            if f.read(16) != b"SQLite format 3\x00":
                return CORRUPT, "not a sqlite file"
        db = sqlite3.connect(_uri(path, "ro"), uri=True, timeout=CHECK_TIMEOUT_S)
        try:
            got = db.execute("PRAGMA quick_check").fetchone()[0]
        finally:
            db.close()
    except (OSError, sqlite3.OperationalError) as exc:
        return UNKNOWN, f"{type(exc).__name__}: {exc}"
    except sqlite3.DatabaseError as exc:
        return CORRUPT, f"{type(exc).__name__}: {exc}"
    return (OK, "") if got == "ok" else (CORRUPT, str(got))


def ok(path: Path) -> bool:
    """Whether the file is a sqlite database that passes its quick check (a file that cannot be read now is not)."""
    return check(path)[0] == OK


def restore_if_corrupt(db_path: Path, out_dir: Path, now: float | None = None) -> str | None:
    """Check the database before it is opened. None when it is fine or there is no file yet. When it cannot be
    checked (locked, unreadable) it is left alone and the answer says so. When it is corrupt the file (and its -wal
    and -shm) are renamed to `<name>.corrupt-<unix time>` and the newest backup that passes the check is copied in
    its place; the answer (it starts with CORRUPT_TEXT) says what happened. With no good backup the service starts
    on an empty database (the history is read from Sycope again) and the answer says so."""
    db_path = Path(db_path)
    if not db_path.is_file():
        return None
    state, detail = check(db_path)
    if state == OK:
        return None
    if state == UNKNOWN:
        log.warning("state database %s could not be checked: %s", db_path, detail)
        return f"The state database could not be checked and was left as it is ({detail})."
    stamp = int(time.time() if now is None else now)
    kept = db_path.with_name(f"{db_path.name}.corrupt-{stamp}")
    for suffix in ("-wal", "-shm"):     # a stale journal would damage whatever database takes the name
        side = db_path.with_name(db_path.name + suffix)
        if side.exists():
            side.rename(kept.with_name(kept.name + suffix))
    db_path.rename(kept)
    log.error("state database %s is corrupt (%s), kept as %s", db_path, detail, kept.name)
    for good in reversed(backups(out_dir)):
        if ok(good):
            tmp = db_path.with_name(db_path.name + ".restoring")
            shutil.copyfile(good, tmp)
            os.replace(tmp, db_path)
            return (f"{CORRUPT_TEXT}: kept as {kept.name} and restored from the backup "
                    f"{good.name} (changes since that backup are lost).")
    return (f"{CORRUPT_TEXT}: kept as {kept.name}. There is no backup to restore, so the service "
            f"started on an empty database; history is read from Sycope again.")
