"""The live part: a background thread keeps the last SC_RETENTION_HOURS of alerts in memory (as hourly finding
buckets and a ring of raw alerts per host, ingest.py) and rebuilds the boards after every poll. Pages only ever read
`Live.cboard` (Clusters) and `Live.board` (Triage), which are replaced whole (no locking in readers).

First poll: the whole retention window. Later polls: from the newest alert seen minus SC_OVERLAP_SECONDS (Sycope
writes an alert a little after its bucket ends, so the newest minutes are asked again); alerts are counted by id, so
the overlap never double counts.
"""

from __future__ import annotations

import concurrent.futures
import contextlib
import copy
import csv
import ipaddress
import itertools
import logging
import re
import socket
import threading
import time
import urllib.parse
from collections.abc import Callable
from dataclasses import dataclass, field, replace
from pathlib import Path

from sycope_clusters import (
    alertdefs,
    backup,
    cluster_work,
    clusters,
    crown,
    entities,
    evidence,
    flowagg,
    health,
    history,
    identity,
    ingest,
    lookups,
    notify,
    pipeline,
    playbook,
    rules,
    scoring,
    silence,
    sla,
    ticket,
    triage,
)
from sycope_clusters import confplane as cfg
from sycope_clusters import memory as memory_mod
from sycope_clusters import priors as priors_mod
from sycope_clusters import profile as prof_mod
from sycope_clusters.addresses import AddressBook
from sycope_clusters.config import Settings
from sycope_clusters.params import Params, env_layer
from sycope_clusters.store import Store
from sycope_clusters.sycope import FIELDS, Sycope, SycopeError

log = logging.getLogger("sycope_clusters.live")
_TS = FIELDS.index("timestamp")
_C, _S, _CL, _SL = (FIELDS.index(k) for k in ("clientIp", "serverIp", "clientLocation", "serverLocation"))
# stored days kept for the profile and novelty, whatever SC_HISTORY_DAYS backfills: 7-14 usable days survive a
# two-week holiday (spec 5.4 calendar)
KEEP_DAYS = 35
BACKUP_KEEP = 7            # daily copies of the state database kept (backup.py)
MAX_WAIT_S = 900           # the longest the poller waits between polls while Sycope keeps failing
FILL_SAMPLE = 20_000       # rows looked at for the field fill rates: a window is thinned to about this many
# what the scoring holds besides the window, per item (tracemalloc, CPython 3.12, 2026-10-21, rounded up): a row of
# Window.rows(), a finding of the board with its trace, a stored row read into the History
ROW_B, FINDING_B, HIST_ROW_B = 360, 950, 60
PAST_RETRY_MAX_S = 3600    # the longest wait between two tries to learn the past after failures
HIST_GUESS_DAYS = 21       # stored days a History reads at most (comparable days, the week, two weeks of shares)
# a preview after a failed rebuild compares the board on show with the draft on the newer alerts
STALE_NOTE = ("The last rebuild failed: the board on show is older than the alerts in memory, so the list also holds "
              "what changed since it was scored.")
WORK_BUCKET_B = 360        # before the first board: rows and board per hourly bucket (2M alerts, 50k hosts)
# a preview's board per finding of the board on show, with its private copy of the profile (traced at 2M alerts,
# 50k hosts, 2026-10-21: 319 MB for 283k findings)
PREVIEW_FINDING_B = 1200
HIST_PARAMS = ("confirm_bits", "exfil_floor_bytes", "week_share")   # what evidence.History reads of the parameters
# the status an analyst sets -> what incident.status calls it; most incidents one bulk action reports
STATUS_WORDS = {"investigating": "taken", "escalated": "escalated", "ack": "seen", "tp": "closed", "benign": "closed",
                "fp": "closed", "resolved": "closed"}
STATUS_MAX = 200
WEBHOOK_ON = "webhook_on"      # meta: "1" while the webhook is on (the SLA events that passed before are not sent)
PREVIEW_BUSY = "a preview is running (one preview or replay at a time): try again when it has finished"


class PreviewBusy(Exception):
    """Another preview or replay is running (a 409 for the route)."""


class PreviewTooBig(Exception):
    """A preview or replay would not fit SC_MEMORY_MB now (a 503 for the route)."""


@dataclass
class Backfill:
    """Progress of reading past days from Sycope into the state database (the System page shows it)."""
    running: bool = False
    day: str = ""
    done: list = field(default_factory=list)
    failed: dict = field(default_factory=dict)
    last_run: float = 0.0
    message: str = "not started"


@dataclass
class PollInfo:
    at: float = 0.0
    ok: bool = False
    message: str = "not polled yet"
    fetched: int = 0
    new: int = 0
    took_s: float = 0.0
    window: tuple[float, float] = (0.0, 0.0)


@dataclass(frozen=True)
class Scored:
    """What the last successful rebuild scored and with what: references only, never changed afterwards, so a
    preview can re-score it on another thread without taking the build lock."""
    rows: list
    now: float
    crit: crown.CrownSet
    exceptions: list
    names: dict
    prof: prof_mod.Profile
    days: list
    today: str
    priors: priors_mod.Priors
    book: AddressBook
    window_s: float
    board: evidence.Board
    disabled: frozenset = frozenset()    # the terms missing fields had turned off (health.disabled_terms)
    failed: bool = False    # the rebuild after it failed: rows are the window's newer ones, the rest is the board's
    hist: evidence.History | None = None   # the History it was scored on, when it was the one in force (not stale)
    config: dict | None = None             # the configuration body in use then
    memory: evidence.Memory | None = None  # what the store remembered about the hosts then (memory.py)


@dataclass
class Live:
    settings: Settings
    window: ingest.Window | None = None
    cboard: clusters.ClusterBoard | None = None     # the Clusters board, built from the window's buckets
    last: PollInfo = field(default_factory=PollInfo)
    history: list[PollInfo] = field(default_factory=list)
    started: float = field(default_factory=time.time)
    _client: Sycope | None = None
    _stop: threading.Event = field(default_factory=threading.Event)
    _thread: threading.Thread | None = None
    _newest: float = 0.0
    model: scoring.Model = field(default_factory=scoring.Model)
    names: dict[str, str] = field(default_factory=dict)
    name_src: dict[str, str] = field(default_factory=dict)   # host -> where its name comes from
    _ptr: dict[str, tuple[str, float]] = field(default_factory=dict)
    _file_names: dict[str, str] = field(default_factory=dict)
    _file_mtime: float = -1.0
    _ui: Sycope | None = None
    _ui_lock: threading.Lock = field(default_factory=threading.Lock)
    _rec_cache: dict[str, tuple[float, dict]] = field(default_factory=dict)
    _flow_cache: dict[tuple, tuple[float, list]] = field(default_factory=dict)
    _buffer: tuple[float, dict] | None = None
    _names_thread: threading.Thread | None = None
    store: Store | None = None
    catalog: rules.Catalog | None = None
    board: evidence.Board | None = None
    backfill: Backfill = field(default_factory=Backfill)
    _hist: evidence.History | None = None
    _hist_key: tuple = ()
    _cold_hist: evidence.History | None = None
    _work_b: int = 0           # the last board and its rows (estimate, ROW_B / FINDING_B)
    _cl_b: int = 0             # the last full Clusters board's frames (polars' own count)
    _lean: bool = False        # Clusters leaves hygiene findings out: the rest of the service is near the budget
    _hist_b: int = 0           # the History in use (estimate, HIST_ROW_B)
    _past_thread: threading.Thread | None = None
    past_async: bool = False   # learn the past on its own thread (start() turns it on)
    provisional: bool = False  # the board is scored on the cold (or previous) past while the service learns it
    _stale: bool = False       # the last past() answered with the previous History (a new one is being learned)
    past_error: str = ""       # why the last learning of the past failed ("" = fine); Health shows it
    _past_fails: int = 0
    _past_retry_at: float = 0.0
    _past_gen: int = 0         # bumped by every invalidation (freeze): a job started before it never swaps in
    _since_set: bool = False
    _bf_thread: threading.Thread | None = None
    _flow_thread: threading.Thread | None = None
    flow_error: str = ""       # why the last netflow aggregate failed ("" = fine); Health shows it
    flow_at: float = 0.0       # when the netflow aggregate last ran
    _build_lock: threading.Lock = field(default_factory=threading.Lock)
    _cl_lock: threading.Lock = field(default_factory=threading.Lock)      # one Clusters build at a time
    _cfg_lock: threading.Lock = field(default_factory=threading.Lock)     # one configuration write at a time
    _preview_lock: threading.Lock = field(default_factory=threading.Lock)  # one preview or replay at a time
    _rescore_pending: threading.Event = field(default_factory=threading.Event)
    _rescore_thread: threading.Thread | None = None
    _located: set = field(default_factory=set)
    _lookups: lookups.LookupCache | None = None
    _lookups_logged: str = field(default_factory=lambda: lookups.digest([]))   # what the audit already has
    _silenced: lookups.LookupCache | None = None    # the silenced-hosts lookup (D45), read-only
    _silenced_logged: str = field(default_factory=lambda: lookups.digest([]))
    alert_defs: alertdefs.AlertDefCache | None = None   # Sycope's alert definitions, for the silence dialog's picker
    unknown_privacy: int = 0   # lookup rows with a privacy value that is neither internal nor external (Health)
    _last_verdict: dict | None = None
    _held: dict = field(default_factory=dict)    # host -> the verdict a hold keeps it at (logged once per hold)
    pcap_by_alert: dict = field(default_factory=dict)
    pcap_by_ip: dict = field(default_factory=dict)
    _pcap_at: float = 0.0
    _pcap_thread: threading.Thread | None = None
    _reopened: set | None = None
    params: Params = field(default_factory=Params.factory)
    profile: prof_mod.Profile | None = None    # the environment profile in use (learned daily, or the frozen one)
    priors: priors_mod.Priors | None = None
    _prof_key: tuple = ()
    confplane: cfg.ConfPlane | None = None
    config_version: int | None = None          # the published configuration in use (None: factory and SC_* only)
    config: dict = field(default_factory=cfg.empty_body)
    file_error: str = ""                       # why the break-glass file was refused ("" = fine)
    stored_error: str = ""                     # why the stored active configuration is not used ("" = fine)
    _scored: Scored | None = None
    fill: dict = field(default_factory=dict)         # field -> fill rate of the window at the last rebuild (Health)
    disabled: list = field(default_factory=list)     # [{term, needs, text}] the scoring terms turned off for them
    silence_spikes: dict = field(default_factory=dict)   # rule id -> {"alerts", "usual", "text"}: rules hiding a spike
    silenced_alerts: int = 0                         # alerts of the window some rule took (the Simple footer)
    wait_s: float = 0.0        # seconds until the next poll: poll_seconds, doubled after each Sycope error up to 900
    last_ok_at: float = 0.0    # when the last poll succeeded
    restore_note: str = ""     # what the start-up database check did ("" = nothing was wrong)
    backup_error: str = ""     # why the last daily backup failed ("" = fine)
    notifier: notify.Notifier | None = None    # the outbound webhook (notify.py), always there, off without SC_WEBHOOK_URL
    ticket_fn: Callable | None = None          # (record, ctx) -> ticket text of the live page payloads; the app sets it
    _backup_day: str = ""
    _backup_failed_at: float = 0.0
    _backup_thread: threading.Thread | None = None

    @property
    def backup_dir(self) -> Path | None:
        return Path(self.settings.state_dir) / "backups" if self.settings.state_dir else None

    @property
    def config_error(self) -> str:
        """Everything wrong with the configuration, for Health: the break-glass file and the stored version."""
        return " | ".join(e for e in (self.file_error, self.stored_error) if e)

    @property
    def playbook_overlay(self) -> list[dict]:
        """The administrator's playbook overlay of the configuration in use (playbook.apply)."""
        return self.config.get("playbook") or []

    def __post_init__(self) -> None:
        self.priors = priors_mod.load()
        self._lookups = lookups.LookupCache(self.settings.lookup_refresh_seconds,
                                            lookups.names(self.settings.lookup_names))
        self._silenced = lookups.LookupCache(self.settings.lookup_refresh_seconds,
                                             lookups.names(self.settings.silenced_lookup)[:1], ("subnet", "csvFile"))
        self.alert_defs = alertdefs.AlertDefCache(self.settings.lookup_refresh_seconds)
        self.model = scoring.load(self.model_path)
        s = self.settings
        self.wait_s = float(s.poll_seconds)
        if s.db_path is not None:     # a damaged file is set aside and the newest good backup put back, before opening
            try:
                self.restore_note = backup.restore_if_corrupt(s.db_path, self.backup_dir) or ""
            except Exception as exc:
                log.exception("checking the state database failed")
                self.restore_note = f"The state database could not be checked: {type(exc).__name__}: {exc}"
        try:
            self.store = Store(self.settings.db_path)
        except Exception:  # an unwritable state directory must not stop the board: memory only, said on /system
            log.exception("state database unavailable, triage state kept in memory only")
            self.store = Store(None)
        self.notifier = notify.Notifier.from_settings(self.settings, self.store)
        if self.restore_note:
            corrupt = self.restore_note.startswith(backup.CORRUPT_TEXT)
            self.store.log("service", "backup:restored" if corrupt else "backup:unchecked", str(s.db_path),
                           note=self.restore_note)
        self.confplane = cfg.ConfPlane(self.store)
        try:   # the critical hosts file is imported once; afterwards the admin edits the crown jewels in the DB
            crown.import_file(self.store, s.critical_hosts_path)
        except Exception:
            log.exception("importing the critical hosts file failed")
        if s.state_dir:   # break-glass (D52): a file in the state directory is applied before the first board
            try:
                self.file_error = self.confplane.break_glass(Path(s.state_dir), time.time()) or ""
            except Exception as exc:
                log.exception("the break-glass configuration file failed")
                self.file_error = f"{type(exc).__name__}: {exc}"
        try:
            self.reload_config()
        except Exception as exc:   # validation should make this impossible; the service starts on the shipped setup
            log.exception("loading the configuration in force failed")
            self.stored_error = (f"the configuration in force could not be loaded ({type(exc).__name__}: {exc}); "
                                 "the shipped one is used")
            body = cfg.empty_body()
            self.config_version, self.config, self.params = None, body, Params(env=env_layer(s))
            try:
                self.catalog = self._catalog(body)
            except Exception:
                log.exception("the rule catalog file failed")
                self.catalog = rules.Catalog()
        self._migrate_model()
        # classic_max=0: the window keeps no list of every raw alert; Clusters reads the buckets like Triage does
        self.window = ingest.Window(s.retention_hours * 3600, s.raw_per_host, 0,
                                    classify=self._degrade_class)

    def _degrade_class(self, name, tactic, rid) -> str:
        """The class the window's degrading sees: a rule with direction variants is never hygiene there, its server
        and port decide the direction (an exposed service, an outbound protocol) and must be kept."""
        rule = self.catalog.get(name, tactic, rid)
        return "B" if rule.variants and rule.cls == "D" else rule.cls

    @property
    def snapshot(self) -> pipeline.Snapshot | None:
        """The engine's snapshot of the Clusters board. Read-only in practice: assigning one (tests do) wraps it in
        a board of its own."""
        return self.cboard.snapshot if self.cboard else None

    @snapshot.setter
    def snapshot(self, snap: pipeline.Snapshot | None) -> None:
        self.cboard = None if snap is None else clusters.ClusterBoard(snap.built_at, snap.now, snap.took_s, snap)

    @property
    def model_path(self) -> Path | None:
        return Path(self.settings.state_dir) / "scoring.json" if self.settings.state_dir else None

    def _migrate_model(self) -> None:
        """Once per state directory: a saved alert_cluster model becomes maciej_note, other edits kept. Needs the
        store (the guard is a meta key, the trace an audit line), so it cannot run inside scoring.load."""
        if self.store.meta("clusters_scoring_migrated"):
            return
        new = scoring.migrate(self.model)
        if new is not None:
            self.model = new          # in force for this run even when the file cannot be rewritten
            if self.model_path:
                try:
                    scoring.save(self.model_path, new)
                except OSError:       # a read-only state directory must not stop the board; retried at the next start
                    log.exception("saving the migrated scoring model failed")
                    return
            self.store.log("system", "scoring:migrate", "scoring", detail={"from": scoring.wire("alert_cluster"),
                                                                     "to": scoring.wire("maciej_note")})
        self.store.meta("clusters_scoring_migrated", "1")

    # ---- the administrator's configuration (confplane.py) ---------------------------------------------------

    def _catalog(self, body: dict) -> rules.Catalog:
        """The rule catalog: SC_RULES_FILE is the env layer, the configuration's entries the admin layer (they win)."""
        return rules.Catalog(rules.read_overrides(self.settings.rules_file), admin=body.get("catalog") or {})

    def reload_config(self) -> None:
        """Take the published configuration into use: parameters, rule catalog, addresses the admin called
        internal. A stored version that no longer validates never loads: the newest good one is used and
        `config_error` says why. The next rebuild scores with it (the profile is learned again)."""
        vid, body = self.confplane.active()
        errs = cfg.validate(body) if vid is not None else []
        self.stored_error = ""
        if errs:
            log.error("the active configuration (version %s) is not valid: %s", vid, "; ".join(errs))
            self.stored_error = f"version {vid} is not valid and is not used: {'; '.join(errs)}"
            vid, body = self.confplane.last_good()
        p = Params(env=env_layer(self.settings), admin=body.get("params"))
        cat = self._catalog(body)
        with self._build_lock:
            self.config_version, self.config = vid, body
            self.params, self.catalog = p, cat
        self.store.stamp = (vid, self.store.stamp[1])

    def preview_config(self, body: dict) -> dict:
        """What a draft would change on the board now: the window of the last rebuild scored again with the draft's
        parameters, rule catalog and internal addresses, on private copies of the profile and the address book.
        Reads only what the last rebuild left behind (no build lock), never writes to the store, never changes the
        live state. {"changed": [{key, label, from, to, why}] (the first 500), "n": how many, "version_from",
        "scored": False before the first rebuild, "reused_past": the History of the board was used, "notes"}.
        One preview or replay at a time, within SC_MEMORY_MB (preview_slot).
        The learned profile is the one in use; a parameter that changes how the profile is learned shows after the
        next daily learning. Raises ConfigError for a body that is not allowed."""
        body = cfg.migrate(body)
        errs = cfg.validate(body)
        if errs:
            raise cfg.ConfigError(errs)
        out = {"changed": [], "n": 0, "version_from": self.config_version, "scored": False}
        src = self._scored
        if src is None and self._build_lock.locked():    # a rebuild let the last rows go: wait for its new ones
            with self._build_lock:
                src = self._scored
        if src is None:   # nothing scored yet: "no changes" would be a wrong answer
            return out
        out["scored"] = True
        if src.failed:
            out["notes"] = [STALE_NOTE]
        p = Params(env=env_layer(self.settings), learned=src.prof.values, admin=body.get("params"))
        cat = self._catalog(body)
        # a draft that changes nothing the History reads (the common case: scoring numbers) is scored on the
        # History of the board: no third History next to the two of mem_bytes
        reuse = (src.hist is not None and src.config is not None
                 and all((body.get(k) or {}) == (src.config.get(k) or {}) for k in ("catalog", "internal"))
                 and all(p[k] == src.board.params[k] for k in HIST_PARAMS))
        wanted = evidence.History.wanted(src.days, src.today, src.prof.calendar)
        extra = src.board.findings * PREVIEW_FINDING_B + (0 if reuse else self._hist_bytes(wanted))
        with self.preview_slot(extra):
            snap = src.book.snapshot()
            snap["admin_internal"] = dict(body.get("internal") or {})
            book = AddressBook.from_snapshot(snap)
            prof = copy.deepcopy(src.prof)
            hist = src.hist if reuse else evidence.History(self.store.iter_day_rows(wanted), src.days, src.today,
                                                           cat, book, p, profile=prof, priors=src.priors)
            if not reuse and src.memory is not None:
                hist.set_memory(src.memory)      # the same remembered decisions as the board it is compared with
            board = evidence.build(src.rows, src.now, cat, hist, exceptions=src.exceptions, crown=src.crit,
                                   nets=book, names=dict(src.names), window_s=src.window_s, params=p, profile=prof,
                                   priors=src.priors, disabled=src.disabled)
        out["reused_past"] = reuse
        changes = _verdict_changes(src.board, board)
        out["n"], out["changed"] = len(changes), changes[:500]
        return out

    @contextlib.contextmanager
    def preview_slot(self, extra_b: int):
        """One preview or replay at a time, and only when it fits SC_MEMORY_MB. Either holds a third board (and
        maybe a third History) next to what mem_bytes counts (the board on show, the one a rebuild may be making,
        their Histories): refused (PreviewBusy, PreviewTooBig) rather than risking the service being killed."""
        if not self._preview_lock.acquire(blocking=False):
            raise PreviewBusy(PREVIEW_BUSY)
        try:
            have, limit = self.mem_bytes(), self.settings.memory_mb * 2**20
            if have + extra_b > limit:
                raise PreviewTooBig(
                    f"not enough memory for this now: the service holds about {have / 2**20:,.0f} MB of its "
                    f"{self.settings.memory_mb:,} MB (SC_MEMORY_MB) and this needs about {extra_b / 2**20:,.0f} MB "
                    "more. A change of scoring numbers alone needs less (the past days are reused); otherwise raise "
                    "SC_MEMORY_MB and the container's memory with it.")
            yield
        finally:
            self._preview_lock.release()

    def set_model(self, model: scoring.Model) -> None:
        """Save the model (when a state directory is set) and re-rank the current Clusters board with it."""
        if self.model_path:
            scoring.save(self.model_path, model)
        self.model = model
        if self.cboard is not None:
            self.cboard = replace(self.cboard, snapshot=pipeline.rescore(self.cboard.snapshot, model))

    def start(self) -> None:
        self.past_async = True
        if self._thread is None:
            self._thread = threading.Thread(target=self._loop, name="poller", daemon=True)
            self._thread.start()
        if self._bf_thread is None and self.settings.history_days > 0:
            self._bf_thread = threading.Thread(target=self._backfill_loop, name="backfill", daemon=True)
            self._bf_thread.start()
        if self._flow_thread is None and self.settings.flow_aggregate and self.settings.sycope_url:
            self._flow_thread = threading.Thread(target=self._flow_loop, name="flowagg", daemon=True)
            self._flow_thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self.notifier is not None:
            self.notifier.stop()

    def _loop(self) -> None:
        while not self._stop.is_set():
            self.poll()
            self._stop.wait(self.wait_s)

    def poll(self, now: float | None = None) -> PollInfo:
        s = self.settings
        now = now or time.time()
        keep_from = now - s.retention_hours * 3600
        start = keep_from if not self._newest else max(keep_from, self._newest - s.overlap_seconds)
        info = PollInfo(at=now, window=(start, now))
        t0 = time.monotonic()
        try:
            if self._client is None:
                self._client = Sycope(s.sycope_url, s.sycope_user, s.sycope_password, s.sycope_verify_tls)
            fetched = new = 0
            newest = self._newest
            for page in _pages(self._client, start, now, s.nql, s.fetch_chunk_seconds):
                new += self.window.add(page)        # a page at a time: the first poll never holds the whole day
                fetched += len(page)
                if page:
                    newest = max(newest, max((r[_TS] or 0) for r in page) / 1000)
                    self._budget()                  # a level applies to the pages still to come
            self._newest = newest                   # only after every page: a failed poll is asked again whole
            self.window.trim(now)
            self.window.forget_ids((self._newest - s.overlap_seconds - 3600) * 1000)   # an hour of slack
            self._budget()
            info.fetched, info.new = fetched, new
            self.read_lookups(now)
            self.rebuild(now)
            snap = self.rebuild_clusters(now)       # after Triage, which never waits for Clusters
            if self.settings.recorder_passthrough and (self._pcap_thread is None or not self._pcap_thread.is_alive()) \
                    and time.time() - self._pcap_at > 300:
                self._pcap_thread = threading.Thread(target=self.pcap_index, name="pcap", daemon=True)
                self._pcap_thread.start()
            if self._names_thread is None or not self._names_thread.is_alive():
                # PTR lookups can sit on resolver timeouts: never in the poll's way
                self._names_thread = threading.Thread(target=self._refresh_names, args=(snap,), daemon=True)
                self._names_thread.start()
            info.ok = True
            self.wait_s, self.last_ok_at = float(s.poll_seconds), now
            self._backup_soon(now)
            b = self.board
            info.message = (f"{fetched} alerts read, {self.window.alerts} kept, "
                            f"{len(snap.clusters) if snap else 0} clusters "
                            f"(engine {snap.took_s if snap else 0:.1f} s), triage {b.findings if b else 0} findings "
                            f"({b.took_s if b else 0:.1f} s)")
        except SycopeError as exc:   # Sycope is down or refuses: wait twice as long each time, up to MAX_WAIT_S
            info.message = str(exc)
            self._client = None if "login" in str(exc) else self._client
            self.wait_s = min(max(MAX_WAIT_S, s.poll_seconds), self.wait_s * 2)
        except Exception as exc:  # the thread must survive anything; the System page shows it
            log.exception("poll failed")
            info.message = f"{type(exc).__name__}: {exc}"
        info.took_s = time.monotonic() - t0
        self.last = info
        self.history = [info, *self.history][:30]
        log.info("poll %s: %s (%.1f s)", "ok" if info.ok else "FAILED", info.message, info.took_s)
        return info

    def rebuild_clusters(self, now: float | None = None) -> pipeline.Snapshot | None:
        """The Clusters board from the window's buckets, then its work records. A failure leaves Triage and the last
        board alone. Returns the board's snapshot (the last one when this build fails)."""
        s = self.settings
        with self._cl_lock:
            now = now or (self.cboard.now if self.cboard else time.time())
            try:
                book = self._nets()
                buckets = itertools.chain.from_iterable(self.window.iter_hours())   # an hour of rows at a time
                self.cboard = clusters.build(buckets, now, self.catalog, book, self.crown_set(book), self.model,
                                             store=self.store, delta_s=s.delta_seconds, min_alerts=s.min_alerts,
                                             lean=self._lean_now(), exceptions=self.exceptions())
                if not self.cboard.lean:      # the size of a full board is what the switch weighs; a lean one is smaller
                    snap = self.cboard.snapshot
                    self._cl_b = int(snap.alerts.estimated_size() + snap.cluster_alerts.estimated_size())
            except Exception:
                log.exception("clusters failed")
                return self.cboard.snapshot if self.cboard else None
        self.record_clusters(now)
        return self.cboard.snapshot

    def record_clusters(self, now: float | None = None) -> dict | None:
        """The Clusters records brought up to date with the board (after every build and every Clusters action)."""
        cb = self.cboard
        if cb is None:
            return None
        try:
            with history._LOCK:
                return cluster_work.record(cb, self.store.cluster_triage(), self.store, now or time.time(),
                                           catalog=self.catalog, names=dict(self.names),
                                           overlay=self.playbook_overlay)
        except Exception:
            log.exception("cluster history failed")
            return None

    def mem_bytes(self) -> int:
        """What the service holds, estimated: the window, and twice the last board with its rows and twice the
        History (the old one stays in use while the next is built). Before the first board and History they are
        guessed from the window's buckets and the stored days, so the first poll thins in time. Triage's share
        only: Clusters has its own switch (_lean_now) and never makes the window thin."""
        if self.window is None:
            return 0
        w = self.window.mem_bytes()
        work = self._work_b or self.window.stats()["buckets"] * WORK_BUCKET_B     # no board yet: a guess
        if self._hist_b:
            hist = self._hist_b
        else:   # no History yet: the stored days it will read
            stored = self.store.days() if self.store is not None else {}
            hist = sum(v["findings"] or 0 for d, v in sorted(stored.items())[-HIST_GUESS_DAYS:]) * HIST_ROW_B
        return w + 2 * (work + hist)

    def _lean_now(self) -> bool:
        """Whether Clusters builds without hygiene findings: yes while Triage's share (mem_bytes) plus three times the
        frames of a full Clusters board (building needs about that much working memory) is above 55 % of the memory
        budget; it stays lean until that is back under 40 %. The page says so. Clusters is not part of mem_bytes, so
        its size never thins the window."""
        rest, limit = self.mem_bytes() + 3 * self._cl_b, self.settings.memory_mb * 2**20
        self._lean = rest > 0.55 * limit or (self._lean and rest > 0.4 * limit)
        return self._lean

    def _budget(self) -> None:
        """Keep the service inside SC_MEMORY_MB: thin the window one level more while the whole (mem_bytes) is above
        80 % of it, one less below 60 %. Only the window can be thinned; the scoring's share is the last rebuild's."""
        w, limit = self.window, self.settings.memory_mb * 2**20
        while w.level < 3 and self.mem_bytes() > 0.8 * limit:
            w.degrade(w.level + 1)
            log.warning("over the memory budget: the alert window is thinned to level %d", w.level)
        if w.level and self.mem_bytes() < 0.6 * limit:
            w.degrade(w.level - 1)

    # ---- the triage board -------------------------------------------------------------------------------------

    def read_lookups(self, now: float) -> None:
        """Read the Sycope Lookups when due (the last good read stays when Sycope fails); a change goes to the audit."""
        lk = self._lookups
        lk.get(self._client, now)
        if lk.digest != self._lookups_logged:
            c = lk.change
            try:
                self.store.log("sycope-lookup", "lookup:changed", ", ".join(lk.wanted),
                               note=f"{c['now']} entries (was {c['was']})",
                               detail={"digest": c["digest"], "added": c["added"], "removed": c["removed"]})
            except Exception:
                log.exception("lookup audit line failed")
            self._lookups_logged = lk.digest
        sl = self._silenced
        sl.get(self._client, now)
        if sl.digest != self._silenced_logged:
            try:
                self.store.log("sycope-lookup", "lookup:changed", ", ".join(sl.wanted),
                               note=f"{sl.change['now']} silenced entries (was {sl.change['was']})",
                               detail={"digest": sl.digest, "added": sl.change["added"],
                                       "removed": sl.change["removed"]})
            except Exception:
                log.exception("silenced lookup audit line failed")
            self._silenced_logged = sl.digest
        self.alert_defs.get(self._client, now)      # same cadence; a failure only shows in the picker

    def exceptions(self) -> silence.ExceptionSet:
        """The active exceptions (silence rules among them): the stored ones, then the read-only ones of the
        silenced-hosts lookup, as the index the scoring matches with."""
        return silence.ExceptionSet.of([*self.store.exceptions(), *crown.silenced_from_lookup(self._silenced.entries)],
                                       self.params["calendar.utc_offset_min"])

    def silence_scan(self, fields: dict) -> list[tuple]:
        """The window's buckets a silence rule with these fields would take (the dialog's preview, the guard rails)."""
        s = silence.Silencer([{**fields, "id": -1, "kind": "silence"}], self.params["calendar.utc_offset_min"])
        return self.window.scan(s)

    FIRST_HIT_LINES = 8        # audit lines "first silenced <host>" per rule and pass; the rest in one line

    def _silence_after(self, sl: silence.Silencer, now: float) -> None:
        """After a board: write the pass's hit counters (idempotent), the audit lines for first hits, expiries and
        spikes, and the spike list Health and the bell read. Never raises: the board matters more than the log."""
        try:
            st = self.store
            first: dict[int, list[str]] = {}
            for rid, host in st.silence_record(sl.hits, now):
                first.setdefault(rid, []).append(host)
            for rid, hosts in first.items():
                for h in hosts[:self.FIRST_HIT_LINES]:
                    st.log("system", "silence:first-hit", h, f"rule #{rid} first silenced {h}", {"id": rid, "host": h})
                if len(hosts) > self.FIRST_HIT_LINES:
                    n = len(hosts) - self.FIRST_HIT_LINES
                    st.log("system", "silence:first-hit", f"rule #{rid}", f"rule #{rid} first silenced {n} more hosts",
                           {"id": rid, "more": n})
            p = self.params
            day = evidence.day_key(now * 1000)
            hour = int(now // 3600)
            spikes: dict[int, dict] = {}
            for x in st.exceptions(active_only=False):
                if x["kind"] != "silence":
                    continue
                if x["expired"] and x["active"] and not x.get("pending") and st.meta(f"silence_expired:{x['id']}") is None:
                    st.meta(f"silence_expired:{x['id']}", day)
                    st.log("system", "silence:expired", str(x["id"]), f"rule #{x['id']} expired",
                           {"id": x["id"], "rule": silence.describe(x)})
                if x["expired"] or not x["active"]:
                    continue
                got = silence.spike(st.silence_hourly(x["id"], hour - 170), hour, p["silence.spike_x"],
                                    p["silence.spike_min"])
                if got is None:
                    continue
                n, usual = got
                text = f"Silence rule #{x['id']} hides a spike: {n:,} alerts in the last hour (usual {usual:,.0f})"
                spikes[x["id"]] = {"id": x["id"], "alerts": n, "usual": round(usual, 1), "text": text, "day": day}
                if st.meta(f"silence_spike:{x['id']}:{day}") is None:     # once per rule per day
                    st.meta(f"silence_spike:{x['id']}:{day}", "1")
                    st.log("system", "silence:spike", str(x["id"]), text, {"id": x["id"], "alerts": n, "usual": usual})
            self.silence_spikes = spikes
        except Exception:
            log.exception("silence hit log failed")

    def silenced_rows(self) -> list[dict]:
        """The read-only exceptions of the silenced-hosts lookup."""
        return crown.silenced_from_lookup(self._silenced.entries) if self._silenced is not None else []

    def crown_set(self, book: AddressBook) -> crown.CrownSet:
        """The crown jewels the board is scored with: the table (admin, accepted, imported file) and the lookup."""
        return crown.CrownSet(crown.effective(self.store, book), book)

    def freeze_profile(self, frozen: bool, who: str) -> str | None:
        """Freeze or unfreeze the profile in use (learning goes on either way); the next board uses the one in force.
        The day it concerned, None when there was no snapshot to freeze."""
        day = prof_mod.freeze(self.store, frozen)
        if day is not None:
            self.store.log(who, "profile:freeze" if frozen else "profile:unfreeze", day)
        with self._build_lock:
            self._prof_key = self._hist_key = ()
            self._past_gen += 1
        return day

    def _nets(self, rows: list[tuple] | None = None) -> AddressBook:
        """Which IPs are ours: Sycope Lookups, the networks file, SC_INTERNAL_NETS, and with rows also every IP
        Sycope gives a location (kept for the calls without rows)."""
        if rows is not None and self.settings.location_internal:
            located: set[str] = set()
            for r in rows:
                if r[_CL] and r[_C]:
                    located.add(r[_C])
                if r[_SL] and r[_S]:
                    located.add(r[_S])
            self._located = located
        book = AddressBook([*self._lookups.entries, *self._networks().entries()], self.settings.internal_nets,
                           self._located if self.settings.location_internal else set(),
                           admin_internal=self.config.get("internal"))
        self.unknown_privacy = book.unknown_privacy
        return book

    def _learn_key(self, today: str, days: list[str]) -> tuple:
        flows = tuple(d for d in self.store.flow_days() if d < today)
        return (today, tuple(days), flows, self._lookups.digest, self.config_version, self.store.answers_stamp())

    def _learn(self, today: str, days: list[str]) -> prof_mod.Profile:
        """Learn (and store) today's profile and return the one in force; changes nothing on the Live."""
        book = self._nets()
        try:
            if self._prof_key or self.store.profile(today) is None:
                older = [d for d, _ in self.store.profile_days() if d < today]
                body = self.store.profile(older[-1]) if older else None
                prev = prof_mod.from_json(body) if body else None
                prof_mod.save(self.store, prof_mod.learn(self.store, today, self.priors, self.params, book,
                                                         self.catalog, prev))
            body = self.store.profile()
            prof = prof_mod.from_json(body) if body else evidence.empty_profile(
                today, self.params, self.priors, self.catalog, book)
        except Exception:   # a failed learner must not stop the board: the last profile (or the priors) scores
            log.exception("learning the environment profile failed")
            return self.profile or evidence.empty_profile(today, self.params, self.priors, self.catalog, book)
        try:
            # the one place both paths (inline learned() and the past thread) go through: date the suggestions (a failure
            # here costs the dates, never the freshly learned profile)
            health.stamp_suggestions(self.store, prof.suggestions, today)
        except Exception:
            log.exception("dating the profile suggestions failed")
        return prof

    def learned(self, today: str, days: list[str]) -> prof_mod.Profile:
        """The environment profile in use today. Learned (and stored) at the day rollover and again whenever the
        stored past changes (a backfilled day, a day of netflow, a lookup change); after a restart today's stored
        profile is used as it is. A frozen snapshot stays in use while learning goes on (Store.profile)."""
        key = self._learn_key(today, days)
        if self.profile is not None and key == self._prof_key:
            return self.profile
        self.profile, self._prof_key = self._learn(today, days), key
        return self.profile

    def scoring_params(self) -> Params:
        """The parameters the board is scored with: the deployment's, plus the profile's learned values."""
        return self.params.with_learned(self.profile.values) if self.profile is not None else self.params

    def _past_days(self, today: str) -> list[str]:
        stored = self.store.days()
        # a day Sycope had no alerts for (beyond its retention) is not a day of normal behaviour
        days = sorted(d for d, v in stored.items() if d < today and (v["alerts"] or 0) > 0)
        return days[-max(KEEP_DAYS, self.settings.history_days):]

    def _hist_bytes(self, wanted: list[str]) -> int:
        """What a History of these stored days holds, estimated (HIST_ROW_B per stored row)."""
        stored = self.store.days()
        return sum(stored[d]["findings"] or 0 for d in wanted if d in stored) * HIST_ROW_B

    def _history(self, today: str, days: list[str], prof: prof_mod.Profile) -> tuple[evidence.History, int]:
        """The History of these days and its size estimate."""
        wanted = evidence.History.wanted(days, today, prof.calendar)
        size = self._hist_bytes(wanted)
        hist = evidence.History(self.store.iter_day_rows(wanted), days, today, self.catalog, self._nets(),
                                self.params.with_learned(prof.values), profile=prof, priors=self.priors)
        return hist, size

    def past(self, now: float) -> evidence.History:
        """The past days from the store, rebuilt when a day is added, the day rolls over or the profile changes.
        Reads the rows of the comparable days (which may lie beyond two weeks after a holiday), the week and the two
        weeks behind the known-service shares.

        In the service (start()) the learning and the History run on their own thread, never under the build lock
        (at 50k hosts and 14 stored days they take about 20 s): until the first is ready the board scores on the
        priors alone, afterwards on the previous profile and History; a finished one asks for a rebuild. Called
        directly (tests, tools) both run inline."""
        today = evidence.day_key(now * 1000)
        days = self._past_days(today)
        key = self._learn_key(today, days)
        self._stale = False
        if self._hist is not None and self.profile is not None and key == self._hist_key == self._prof_key:
            return self._hist
        if self.past_async:
            t = self._past_thread
            if (t is None or not t.is_alive()) and time.monotonic() >= self._past_retry_at:
                self._past_thread = threading.Thread(target=self._past_job, args=(today, days, key, self._past_gen),
                                                     name="past", daemon=True)
                self._past_thread.start()
            self._stale = self._hist is not None     # the previous past, until the job swaps the new one in
            return self._hist if self._hist is not None else self._cold(today)
        prof = self.learned(today, days)
        (self._hist, self._hist_b), self._hist_key = self._history(today, days, prof), key
        return self._hist

    def _past_job(self, today: str, days: list[str], key: tuple, gen: int = 0) -> None:
        """Learn the past for `key` and swap it in, unless something invalidated it meanwhile (then the next rebuild
        starts another job). A failure is kept for Health, the retry backs off (1 min doubling up to 1 h) and the
        board stops being provisional: it scores on the priors (or the last good past) as a normal board."""
        try:
            prof = self._learn(today, days)
            hist, size = self._history(today, days, prof)
        except Exception as exc:
            log.exception("learning the past failed")
            with self._build_lock:
                self._past_fails += 1
                self.past_error = f"{type(exc).__name__}: {exc}"
                self._past_retry_at = time.monotonic() + min(PAST_RETRY_MAX_S, 60 * 2 ** (self._past_fails - 1))
            self.rescore_async()
            return
        with self._build_lock:
            if gen == self._past_gen:
                self.profile, self._prof_key = prof, key
                self._hist, self._hist_key, self._hist_b = hist, key, size
                self.past_error, self._past_fails, self._past_retry_at = "", 0, 0.0
        self.rescore_async()

    def _cold(self, today: str) -> evidence.History:
        """No past yet: the priors alone (an empty History on a cold-start profile)."""
        if self._cold_hist is None or self._cold_hist.today != today:
            self._cold_hist = evidence.History([], [], today, self.catalog, self._nets(), self.params,
                                               priors=self.priors)
        return self._cold_hist

    def rebuild(self, now: float | None = None) -> None:
        """Score the alerts in memory again (after a poll, a new history day or an analyst's exception)."""
        with self._build_lock:
            now = now or (self.cboard.now if self.cboard else time.time())
            # its rows go before the new ones are made (a preview waits for this build); the rest is kept for a
            # failed build: the board on show stays what a preview compares with and what Health reads
            prev, self._scored = (replace(self._scored, rows=[]) if self._scored is not None else None), None
            rows: list = []
            try:
                exceptions = self.exceptions()
                stored = [x for x in exceptions if isinstance(x.get("id"), int)]
                silencer = silence.Silencer(stored, self.params["calendar.utc_offset_min"],
                                            self._nets().internal if stored else None)
                rows = self.window.rows(silencer)
                hist = self.past(now)
                memory = self._remember(now)
                hist.set_memory(memory)
                self._fill(rows)
                book = self._nets(rows)
                crit = self.crown_set(book)
                window_s = self.settings.retention_hours * 3600
                off = frozenset(t["term"] for t in self.disabled)
                self.board = evidence.build(rows, now, self.catalog, hist, exceptions=exceptions, crown=crit,
                                            nets=book, names=dict(self.names), window_s=window_s,
                                            params=self.scoring_params(), profile=hist.profile, priors=self.priors,
                                            disabled=off)
                self.board.config_version = self.config_version
                self.silenced_alerts = silencer.silenced
                self._silence_after(silencer, now)
                self._work_b = len(rows) * ROW_B + self.board.findings * FINDING_B
                self.store.stamp = (self.config_version, self.board.profile_day)
                if not self._since_set:     # the days before the first board were never scored (profile base rate)
                    if self.store.meta("triage_since") is None:
                        self.store.meta("triage_since", repr(float(now)))
                    self._since_set = True
            except Exception:  # the classic page keeps working whatever happens here
                log.exception("triage board failed")
                # the alerts in memory now, with what the board on show was scored with (preview says so)
                self._scored = replace(prev, rows=rows, failed=True) if prev is not None and rows else None
                return
            self.board.name_src = {ip: self.name_src[ip] for ip in self.board.names if ip in self.name_src}
            try:
                nets = self._networks()
                self.board.netnames = {ip: n for ip in (*self.board.entities, *self.board.target_f)
                                       if (n := nets.name(ip))} if nets.rows else {}
            except Exception:
                log.exception("network names failed")
                self.board.netnames = {}
            fresh = hist is not self._cold_hist and not self._stale
            self._scored = Scored(rows, now, crit, exceptions, dict(self.names), hist.profile, list(hist.days),
                                  hist.today, self.priors, book, window_s, self.board, off,
                                  hist=hist if fresh else None, config=self.config, memory=memory)
            # a board on the cold past (the service is still learning it), or on the previous one after a change of
            # the configuration, a lookup or the stored days, never writes verdicts or incidents: they would open
            # and then close incidents a few seconds later, when the past in force is ready
            self.provisional = (hist is self._cold_hist or self._stale) and not self.past_error
            if self.provisional:
                return
            try:
                memory_mod.update_clock(self.store, self.board, memory, now, self.scoring_params())
            except Exception:
                log.exception("hold clock failed")
            try:
                self._log_transitions(self.board)
            except Exception:
                log.exception("verdict log failed")
            try:
                # the board's time, as for the verdict log: the incident clocks (sla.py) read it back
                res = history.record(self.board, self.store.triage(), self.store, now=self.board.now,
                                     overlay=self.playbook_overlay)
            except Exception:
                log.exception("incident history failed")
            else:
                try:
                    self._notify_record(res)
                except Exception:
                    log.exception("webhook for new incidents failed")
            try:
                self._sla_pass(self.board.now)
            except Exception:
                log.exception("SLA check failed")

    def _remember(self, now: float) -> evidence.Memory:
        """What the store remembers about the hosts (memory.py). A failure never stops the board: it is scored on the
        alerts and the past days alone."""
        try:
            return memory_mod.build(self.store, now, self.scoring_params())
        except Exception:
            log.exception("reading the remembered decisions failed")
            return evidence.Memory()

    def _fill(self, rows: list[tuple]) -> None:
        """The fill rate of each field the scoring reads, over the window (a sample of it when it is large), and the
        terms a missing field turns off. Too few rows say nothing: no rates, nothing turned off."""
        if len(rows) < health.MIN_ROWS:
            self.fill, self.disabled = {}, []
            return
        try:
            sample = rows[::max(1, len(rows) // FILL_SAMPLE)]
            self.fill = health.fill_rates(sample, self.catalog)
            self.disabled = health.disabled_terms(self.fill)
            if self.window is not None and self.window.level >= 3:   # target lists were thinned away on purpose
                self.disabled = [t for t in self.disabled if t["term"] != "same_host"]
        except Exception:   # Health must never stop the board
            log.exception("field fill rates failed")
            self.fill, self.disabled = {}, []

    def backup_once(self, now: float | None = None) -> bool:
        """Copy the state database once per UTC day (backup.py), keeping BACKUP_KEEP copies. True when a copy was
        made. Nothing to do without a state directory, or when today's copy exists (a restart later the same day).
        An error is kept in `backup_error` for Health, never raised."""
        db = self.settings.db_path
        if db is None or self.store is None or self.store.path == ":memory:" or not db.is_file():
            return False
        now = time.time() if now is None else now
        day = evidence.day_key(now * 1000)
        if self._backup_day == day or (self._backup_failed_at and now - self._backup_failed_at < 3600):
            return False      # done today, or failed less than an hour ago: not again at every poll
        try:
            if (self.backup_dir / backup.name_for(now)).exists():
                self._backup_day = day
                return False
            backup.daily(db, self.backup_dir, BACKUP_KEEP, now)
        except Exception as exc:
            log.exception("daily backup failed")
            self.backup_error = f"{type(exc).__name__}: {exc}"
            self._backup_failed_at = now
            return False
        self._backup_day, self.backup_error, self._backup_failed_at = day, "", 0.0
        return True

    def _backup_soon(self, now: float) -> None:
        """Start today's backup on its own thread when it is due: a large database must not hold up the poll."""
        if self._backup_day == evidence.day_key(now * 1000) or (self._backup_thread and self._backup_thread.is_alive()):
            return
        self._backup_thread = threading.Thread(target=self.backup_once, args=(now,), name="backup", daemon=True)
        self._backup_thread.start()

    def _log_transitions(self, b: evidence.Board) -> None:
        """Write the system's decisions to the hosts' history: entering the queue, escalating, de-escalating
        (only moves that touch Act now or Investigate: Review and Watch swap all day as alerts age), coming back
        after being handled, and leaving the window."""
        if self._last_verdict is None:
            self._last_verdict = self.store.last_verdicts()
            self._reopened = self.store.reopened_keys()
            self._held = self.store.held_verdicts()
        now, rows, last = b.now, [], self._last_verdict     # the board's time: the hysteresis reads these rows back
        tri = self.store.triage()
        for ip, e in b.entities.items():
            prev, v = last.get(ip), e.verdict
            if e.held:
                # a verdict kept above what the evidence says: written once when the hold starts (and again when
                # it moves to another level), with its reason; the host's history shows it as "held"
                if self._held.get(ip) != v:
                    rows.append((now, ip, "held", v, prev, e.held, round(e.conf, 4),
                                 {"raw": e.raw_verdict, "raw_reason": e.raw_reason[:200]}))
                self._held[ip] = v
            else:
                self._held.pop(ip, None)
                if v != prev and {v, prev} & {"act", "investigate"}:
                    kind = ("entered" if prev in (None, "gone") else
                            "escalated" if evidence.VRANK[v] > evidence.VRANK.get(prev, -1) else "de-escalated")
                    rows.append((now, ip, kind, v, prev, e.reason, round(e.conf, 4),
                                 {"first": e.first, "chains": [c for c, _, _ in e.chains],
                                  "headline": e.headline[:200]}))
            last[ip] = v
            t = tri.get(ip)
            if t and t["status"] in evidence.HANDLED:
                o = evidence.overlay(e, t)
                if o["changed"] and (ip, t["at"]) not in self._reopened:
                    what = ", ".join(rules.FAMILIES.get(x, (x,))[0] if x in rules.FAMILIES else x
                                     for x in o["new_parts"]) or "a higher verdict"
                    rows.append((now, ip, "reopened", v, None, f"shows {what} since {t['status']} by {t['who']}",
                                 round(e.conf, 4), {"handled_at": t["at"], "new_parts": o["new_parts"],
                                                    "status": t["status"], "who": t["who"]}))
                    self._reopened.add((ip, t["at"]))
        for ip, prev in list(last.items()):
            if ip not in b.entities and prev in ("act", "investigate"):
                rows.append((now, ip, "left", "gone", prev, "no alerts in the last 24 hours", None, {}))
                last[ip] = "gone"
                self._held.pop(ip, None)       # back within the hold: a new `held` row, restart or not
        self.store.log_verdicts(rows)

    def _networks(self) -> entities.Networks:
        """The operator's network names (SC_NETWORKS_FILE), read again when the file changes."""
        path = self.settings.networks_file
        try:
            mtime = Path(path).stat().st_mtime if path else None
        except OSError:
            mtime = None
        if getattr(self, "_nets_key", ("", 0)) != (path, mtime):
            self._nets_names = entities.Networks.load(path if mtime else None)
            self._nets_key = (path, mtime)
        return self._nets_names

    def rescore_async(self) -> None:
        """Ask for a rebuild off the request thread. One worker lives for the whole process: a request that comes
        while it is busy is picked up by its next round, never lost."""
        self._rescore_pending.set()
        if self._rescore_thread is None:
            def run() -> None:
                while not self._stop.is_set():
                    if self._rescore_pending.wait(5):
                        self._rescore_pending.clear()
                        self.rebuild()
                        self.rebuild_clusters()      # exceptions are shared: the Clusters board drops them too
            self._rescore_thread = threading.Thread(target=run, name="rescore", daemon=True)
            self._rescore_thread.start()

    def act(self, body: dict) -> dict:
        if isinstance(body, dict) and body.get("product") == "clusters" and body.get("op") in cluster_work.OPS:
            ans = cluster_work.act(body, self.cboard, self.store, self.catalog)
            self.record_clusters()       # the records show who has what at once, not after the next poll
            return ans
        ans = triage.act(body, self.board, self.store, self.catalog, approval=self.settings.exception_approval,
                         scan=self.silence_scan if self.window is not None else None)
        if ans.pop("rescore", False):
            self.rescore_async()
        elif self.board is not None:  # the history shows who handled what at once, not after the next poll
            try:
                who = triage._clean_text(body.get("who"), 40) or "analyst"
                if ans.get("op") == "comment":
                    history.note(self.store, ans["target"], who, triage._clean_text(body.get("text"), 1000))
                elif ans.get("op") == "record":
                    pass   # the record itself was written by the action
                elif ans.get("op") == "step":
                    history.event(self.store, ans["rec"], "step",
                                  f"{who} {'checked' if ans['done'] else 'unchecked'}: {ans['title']}")
                elif not self.provisional:   # a cold board writes no incidents; notes and steps go on
                    res = history.record(self.board, self.store.triage(), self.store, overlay=self.playbook_overlay)
                    self._notify_record(res)
            except Exception:
                log.exception("incident history failed")
        try:
            self._notify_status(body, ans)
        except Exception:
            log.exception("webhook for an action failed")
        return ans

    # ---- the outbound webhook (notify.py) and the SLA (sla.py) ---------------------------------------------------

    def ticket_ctx(self) -> ticket.Ctx:
        s = self.settings
        return ticket.Ctx(now=self.board.now if self.board is not None else time.time(),
                          offset_min=int(self.params["calendar.utc_offset_min"]),
                          sycope_ui=(s.sycope_ui_url or s.sycope_url).rstrip("/"), base=s.base_href)

    def incident_block(self, o: dict) -> dict:
        """An incident record as the webhook describes it."""
        ctx = self.ticket_ctx()
        p = self.scoring_params()
        pri = playbook.priority(o["verdict_last"], bool((o.get("snapshot") or {}).get("crown")), o.get("chains") or [], p)
        key = o.get("ui_key") or ""
        rel = (ticket.host_rel(key[2:]) if key.startswith("h:") else ticket.story_rel(key[2:]) if key.startswith("s:")
               else ticket.campaign_rel(key[2:]) if key.startswith("c:") else ticket.history_rel(o["id"]))
        return {"id": o["id"], "kind": o["kind"], "subject": o["subject"], "label": o["label"],
                "headline": o.get("headline"), "verdict": o["verdict_last"],
                "verdict_label": evidence.VERDICT_NAMES.get(o["verdict_last"], o["verdict_last"]),
                "peak": o["verdict_peak"], "priority": pri[0], "priority_reason": pri[1],
                "owner": o["outcome_by"] if o["outcome"] in history.OWNED else None,
                "status": o["status"], "outcome": o["outcome"], "outcome_by": o["outcome_by"],
                "outcome_at": o["outcome_at"], "opened_at": o["opened_at"], "last_seen": o["last_seen"],
                "closed_at": o["closed_at"], "first_alert_ms": o["first_ms"], "last_alert_ms": o["last_ms"],
                "members": o["members_n"], "link": ctx.link(rel), "record_link": ctx.link(ticket.history_rel(o["id"]))}

    def ticket_text(self, o: dict) -> str:
        """The "Copy as ticket" text of an incident record: from the live page payloads while the board shows it (the
        app's ticket_fn), else from what was kept at its peak."""
        ctx = self.ticket_ctx()
        text = None
        if self.ticket_fn is not None:
            try:
                text = self.ticket_fn(o, ctx)
            except Exception:
                log.exception("the ticket of incident %s failed", o.get("id"))
        if not text:
            pri = playbook.priority(o["verdict_last"], bool((o.get("snapshot") or {}).get("crown")),
                                    o.get("chains") or [], self.scoring_params())
            text = ticket.record_text(o, ctx, pri)
        return text

    def _emit_incident(self, event: str, iid: int, key: str, extra: dict) -> None:
        o = self.store.incident(iid, "triage")
        if o is None:
            return
        self.notifier.emit(event, lambda: {"incident": self.incident_block(o), **extra, "ticket": self.ticket_text(o)},
                           key=key, incident=iid)

    def _notify_record(self, res: dict | None) -> None:
        """incident.new and incident.raised from what history.record just wrote, and incident.status for a record an exception
        closed."""
        if not res or self.notifier is None or not self.notifier.enabled:
            return
        for e in res.get("events") or ():
            if e["transition"] == "entered":
                self._emit_incident("incident.new", e["id"], f"{e['id']}:new", {"verdict": e["verdict"]})
            else:
                tag = f"{e['verdict']}" if e["transition"] == "escalated" else f"{int(self.ticket_ctx().now)}"
                self._emit_incident("incident.raised", e["id"], f"{e['id']}:{e['transition']}:{tag}",
                                    {"transition": e["transition"], "verdict": e["verdict"], "previous": e["prev"]})
        for x in res.get("excepted") or ():
            # a record an exception took out of the queue: closed, outcome excepted, once (the marker survives a restart)
            if self.notifier.once(f"incident.status:{x['id']}:excepted", x["at"]):
                self._emit_incident("incident.status", x["id"], f"{x['id']}:status:excepted",
                                    {"status": "closed", "outcome": "excepted", "who": f"exception {x['exception']}",
                                     "owner": None, "note": None, "at": x["at"]})

    def _notify_status(self, body: dict, ans: dict) -> None:
        """incident.status for an analyst's action on an incident: one event per incident it touched (a bulk action on
        hosts of one incident is one event)."""
        if self.notifier is None or not self.notifier.enabled or not isinstance(body, dict) or not ans.get("ok"):
            return
        status = body.get("status")
        if body.get("op") not in ("triage", "story", "hosts", "record") or status not in STATUS_WORDS:
            return
        who = triage._clean_text(body.get("who"), 40) or "analyst"
        ids: list[int] = []
        st = self.store
        if body.get("op") == "record":
            ids = [int(ans["rec"])]
        elif body.get("op") == "story":
            o = st.open_incident_by_key("s:" + str(body.get("key") or ""))
            ids = [o["id"]] if o else []
        else:
            scope = str(body.get("scope") or "")
            o = st.open_incident_by_key(scope) if scope[:2] in ("s:", "c:") else None
            if o:
                ids = [o["id"]]
            else:
                for ip in ([body.get("ip")] if body.get("op") == "triage" else list(body.get("ips") or [])):
                    ip = str(ip or "")
                    o = st.open_incident_by_key("h:" + ip) or next(
                        (x for x in st.incidents_of(entities.key("ip", ip), 10) if x["status"] == "open"), None)
                    if o and o["id"] not in ids:
                        ids.append(o["id"])
                    if len(ids) >= STATUS_MAX:
                        log.warning("a bulk action touched more incidents than the webhook reports (%d)", STATUS_MAX)
                        break
        at = time.time()
        extra = {"status": STATUS_WORDS[status], "outcome": status, "who": who,
                 "owner": triage._clean_text(body.get("owner"), 40) or None, "note": triage._clean_text(body.get("note"), 500),
                 "at": at}
        for iid in ids:
            self._emit_incident("incident.status", iid, f"{iid}:status:{status}:{int(at)}", extra)

    def _sla_pass(self, now: float) -> None:
        """sla.breached and actnow.unowned for the open incidents, each once (the notifier keeps the markers)."""
        if self.notifier is None:
            return
        if not self.notifier.enabled:
            if self.store.meta(WEBHOOK_ON) == "1":      # off now: the next time it is on starts afresh
                self.store.meta(WEBHOOK_ON, "0")
            return
        p = self.scoring_params()
        due = sla.due_events(self.store.sla_rows(now), p, now)
        try:
            if self.store.meta(WEBHOOK_ON) != "1":
                # the webhook was just turned on: deadlines that already passed are old news, not sent (only those that
                # pass from now on); the markers keep them from firing later
                for d in due:
                    self.notifier.once(f"{d['event']}:{d['key']}", now, persist=False)
                self.store.meta(WEBHOOK_ON, "1")
                return
            for d in due:
                if not self.notifier.once(f"{d['event']}:{d['key']}", now, persist=False):
                    continue
                kind = d.get("sla") or "unowned"
                self._emit_incident(d["event"], d["incident"]["id"], d["key"],
                                    {"sla": {"kind": kind, "start": d["start"], "due": d["due"], "limit_s": d["limit_s"],
                                             "overdue_s": round(d["overdue_s"], 1)}})
        finally:
            self.notifier.flush()      # one write for all the markers of this pass


    def _backfill_loop(self) -> None:
        self._stop.wait(20)  # let the first poll fill the board first
        while not self._stop.is_set():
            try:
                self.backfill_once()
            except Exception as exc:
                log.exception("backfill failed")
                self.backfill.message = f"{type(exc).__name__}: {exc}"
            self._stop.wait(600)

    def backfill_once(self, now: float | None = None) -> int:
        """Read every missing past day (newest first) from Sycope, one hour at a time, into the store. A day read
        before it was over plus an hour (late alerts) is read again. Returns the number of days stored."""
        s, bf = self.settings, self.backfill
        now = now or time.time()
        today = evidence.day_key(now * 1000)
        have = self.store.days()
        wanted = [evidence.prev_day(today, k) for k in range(1, s.history_days + 1)]
        todo = []
        for d in wanted:
            end = datetime_end(d)
            info = have.get(d)
            if info is None or (info["fetched_at"] or 0) < end + 3600 <= now:
                todo.append(d)
        bf.running, bf.last_run = bool(todo), now
        try:
            return self._backfill_days(todo, today)
        finally:
            bf.running, bf.day = False, ""

    def _backfill_days(self, todo: list[str], today: str) -> int:
        s, bf = self.settings, self.backfill
        stored = 0
        client = Sycope(s.sycope_url, s.sycope_user, s.sycope_password, s.sycope_verify_tls)
        for d in todo:
            if self._stop.is_set():
                break
            bf.day = d
            bf.message = f"reading {d} from Sycope"
            start = datetime_end(d) - 86400
            try:
                big = self._big_day(client, start, start + 86400)
                if big:   # call 10: Sycope folds the day itself; no severity, threshold, ASN or targets
                    agg, alerts = ingest.aggregated_day(client, start, start + 86400, s.nql)
                else:
                    day = ingest.DayFold()    # an hour at a time into the day's findings: outside the window's budget
                    hours = 0
                    for h in range(24):
                        rows = client.alerts(start + h * 3600, start + (h + 1) * 3600, s.nql, 3600)
                        day.add_hour(rows)
                        hours += 1
                        if self._stop.wait(0.2):
                            break
                    if hours < 24:  # stopped half way: a partial day must never pass for a whole one
                        break
                    agg, alerts = day.rows(), day.alerts
            except SycopeError as exc:
                bf.failed[d] = str(exc)
                bf.message = f"{d}: {exc}"
                continue
            self.store.put_day(d, agg, alerts)
            bf.failed.pop(d, None)
            bf.done = sorted({*bf.done, d})[-60:]
            stored += 1
            bf.message = f"{d}: {alerts:,} alerts, {len(agg):,} findings stored{' (aggregated)' if big else ''}"
            self.rescore_async()
        self.store.prune(evidence.prev_day(today, max(s.history_days, KEEP_DAYS) + 2))
        self.store.prune_verdicts(time.time() - 90 * 86400, product=None)
        self.store.prune_incidents(time.time() - s.incident_days * 86400, product=None)
        self.store.prune_episodes(int((time.time() - 35 * 86400) * 1000))
        self.store.silence_prune(time.time() - 90 * 86400)
        if not todo:
            bf.message = f"history complete: {len(self.store.days())} alert days stored"
        return stored

    def _big_day(self, client: Sycope, start: float, end: float) -> bool:
        """Over SC_CLASSIC_MAX_ALERTS alerts: backfilled as Sycope's aggregate (ingest.aggregated_day). When the
        count cannot be asked (or the client is a test double without aggregates), alert by alert as before."""
        if not hasattr(client, "query_rows"):
            return False
        try:
            return ingest.day_count(client, start, end, self.settings.nql) > self.settings.classic_max_alerts
        except SycopeError as exc:
            log.warning("counting the alerts of a backfill day failed, reading it alert by alert: %s", exc)
            return False

    def _flow_loop(self) -> None:
        self._stop.wait(30)  # after the first poll
        while not self._stop.is_set():
            self.flow_once()
            self._stop.wait(300)

    def flow_once(self, client: Sycope | None = None, now: float | None = None) -> int:
        """Aggregate the complete netflow hours not aggregated yet (flowagg.py), two queries each, on its own thread
        so the poll never waits for it. An error is kept in `flow_error` and never raised; the hour is tried again
        on the next call. Returns the number of hours asked."""
        s = self.settings
        if not s.flow_aggregate:
            return 0
        now = time.time() if now is None else now
        try:
            hours = flowagg.pending_hours(self.store, now)
            if not hours:
                return 0
            client = client or Sycope(s.sycope_url, s.sycope_user, s.sycope_password, s.sycope_verify_tls)
            probe = flowagg.probing(self.store, now)
            book, min_clients = self._nets(), self.params["own_public_min_clients"]
            n = flowagg.run(self.store, client, book, hours, min_clients, pause=0.2, stop=self._stop)
            if probe and n and not flowagg.probing(self.store, now):   # the first hour with flows: catch up at once
                more = flowagg.pending_hours(self.store, now)
                n += flowagg.run(self.store, client, book, more, min_clients, pause=0.2, stop=self._stop)
            self.flow_error = ""
            return n
        except Exception as exc:   # Sycope down, an NQL it refuses, a full disk: the poller must not care
            log.exception("netflow aggregate failed")
            self.flow_error = f"{type(exc).__name__}: {exc}"
            return 0
        finally:
            self.flow_at = now

    # ---- host names: the operator's file first, then reverse DNS (cached a day) ----------------------------

    def _refresh_names(self, snap: pipeline.Snapshot, budget: int = 300) -> None:
        p = Path(self.settings.hostnames_file) if self.settings.hostnames_file else None
        try:
            mtime = p.stat().st_mtime if p else -1.0
            if mtime != self._file_mtime:
                self._file_names = read_hostnames(p) if p else {}
                self._file_mtime = mtime
        except OSError:
            self._file_names = {}
        names = dict(self._file_names)
        src = dict.fromkeys(names, "admin: the hostnames file")
        try:   # a name the Sycope lookup gives one host (a /32 or /128 entry) comes before a reverse DNS name
            for e in list(self._lookups.entries if self._lookups is not None else ()):
                if e.name and e.net.prefixlen == e.net.max_prefixlen and str(e.net.network_address) not in names:
                    names[str(e.net.network_address)] = e.name[:80]
                    src[str(e.net.network_address)] = "Sycope lookup"
        except Exception:
            log.exception("lookup host names failed")
        b = self.board
        if self.settings.reverse_dns and (b is not None or (snap is not None and not snap.empty)):
            now = time.time()
            if b is not None:  # the hosts the analyst sees first get their names first
                order = [e.ip for e in sorted(b.entities.values(), key=lambda e: -e.risk)]
                order += [t["ip"] for t in b.targets]
            else:
                order = snap.clusters.sort("score", descending=True)["anchor_ip"].unique(maintain_order=True).to_list()
            seen: set[str] = set()
            ips = [ip for ip in order if ip not in names and not (ip in seen or seen.add(ip))]
            todo = [ip for ip in ips if ip not in self._ptr or now - self._ptr[ip][1] > 86400][:budget]
            if todo:
                with concurrent.futures.ThreadPoolExecutor(16) as ex:
                    for ip, name in zip(todo, ex.map(_ptr, todo)):
                        self._ptr[ip] = (name, now)
            for ip, (n, _t) in self._ptr.items():
                if n and ip not in names:
                    names[ip], src[ip] = n, "reverse DNS"
        self.name_src = src
        self.names = names

    # ---- the recorder, through Sycope (its Passthrough and the alert's REST destination) ----------------

    def _ui_client(self) -> Sycope:
        s = self.settings
        if self._ui is None:
            self._ui = Sycope(s.sycope_url, s.sycope_user, s.sycope_password, s.sycope_verify_tls, timeout=30)
        return self._ui

    def flows(self, client: str | None, server: str | None, port: int | None, start: float, end: float,
              mode: str = "raw", limit: int = 40) -> list[dict]:
        """Flows from Sycope's netflow stream on demand: the newest records of a pair (raw), or a host's
        counterparts summed (client: whom it reached, server: who reached it). The addresses and the port come
        validated from the route; answers are cached for a minute."""
        key = (client, server, port, int(start // 60), int(end // 60), mode, limit)
        hit = self._flow_cache.get(key)
        if hit and time.time() - hit[0] < 60:
            return hit[1]
        where = [f'clientIp = "{client}"' if client else "", f'serverIp = "{server}"' if server else "",
                 f"serverPort = {int(port)}" if port else ""]
        cond = " and ".join(w for w in where if w)
        agg = ("aggr up=sum(clientBytes), down=sum(serverBytes), n=count(timestamp), first=min(firstTimestamp), "
               "last=max(lastTimestamp)")
        if mode == "client":
            nql = f'src stream="netflow" | where {cond} | {agg} by serverIp, serverPort | sort up desc | limit {limit}'
        elif mode == "server":
            nql = (f'src stream="netflow" | where {cond} | {agg} by clientIp, serverPort | sort down desc '
                   f'| limit {limit}')
        else:
            nql = f'src stream="netflow" | where {cond} | sort timestamp desc | limit {limit}'
        with self._ui_lock:
            rows = self._ui_client().rows(start, end, nql, limit)
        if mode in ("client", "server"):
            out = [{"peer": (r.get("_id") or [None, None])[0], "port": (r.get("_id") or [None, None])[1],
                    "up": r.get("up"), "down": r.get("down"), "n": r.get("n"), "first": r.get("first"),
                    "last": r.get("last")} for r in rows]
        else:
            out = [{"t": r.get("firstTimestamp") or r.get("timestamp"), "end": r.get("lastTimestamp"),
                    "c": r.get("clientIp"), "cp": r.get("clientPort"), "s": r.get("serverIp"),
                    "sp": r.get("serverPort"),
                    "proto": r.get("protocol"), "up": r.get("clientBytes"), "down": r.get("serverBytes"),
                    "pkc": r.get("clientPackets"), "pks": r.get("serverPackets"), "fc": r.get("clientTcpFlags"),
                    "fs": r.get("serverTcpFlags"), "asn": r.get("serverAsNumber"), "cc": r.get("serverCountry")}
                   for r in rows]
        if len(self._flow_cache) > 200:
            self._flow_cache.clear()
        self._flow_cache[key] = (time.time(), out)
        return out

    # ---- who acts, confirmed by Sycope (identity.py) --------------------------------------------------------------

    def identity_audit(self, start: float, end: float) -> list[dict]:
        """Sycope's audit lines of preference changes in [start, end), newest first (the service's own login needs
        to read the audit log)."""
        if not self.settings.sycope_url:
            raise SycopeError("Sycope is not configured here")
        with self._ui_lock:
            return self._ui_client().rows(start, end, identity.AUDIT_NQL, 500)

    def identity_user(self, name: str) -> dict:
        """Sycope's record of one user: roles, names, enabled."""
        with self._ui_lock:
            ans = self._ui_client().get_json("user/" + urllib.parse.quote(name, safe=""))
        return ans if isinstance(ans, dict) else {}

    def recorder_buffer(self) -> dict:
        """How far back the recorder's rolling buffer reaches (its /system JSON through the Passthrough), cached
        5 minutes: {"minutes", "stale"}, or {} when unknown. An alert older than that has no packets left."""
        name = self.settings.recorder_passthrough
        if not name or not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            return {}
        if self._buffer and time.time() - self._buffer[0] < 300:
            return self._buffer[1]
        out: dict = {}
        try:
            with self._ui_lock:
                ans = self._ui_client().get_json(f"passthrough/{name}/system?format=json")
            r = (ans or {}).get("rolling") or {}
            if r.get("reported") and r.get("retention_minutes") is not None:
                out = {"minutes": int(r["retention_minutes"]), "stale": bool(r.get("stale"))}
        except (SycopeError, AttributeError, TypeError, ValueError) as exc:
            log.info("recorder buffer: %s", exc)
        self._buffer = (time.time(), out)
        return out

    def recorder_jobs(self, ip: str) -> dict[str, dict]:
        """alert id -> {state, file} of the recorder's jobs that name this IP (cached 30 s); {} when off."""
        name = self.settings.recorder_passthrough
        if not name or not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            return {}
        hit = self._rec_cache.get(ip)
        if hit and time.time() - hit[0] < 30:
            return hit[1]
        # q narrows the queue on recorder v0.4+ (older ones ignore it and send the whole queue; "state=all"
        # would match nothing there). Jobs are matched by alert id below either way.
        q = urllib.parse.urlencode({"format": "json", "q": ip, "size": 1000})
        try:
            with self._ui_lock:
                ans = self._ui_client().get_json(f"passthrough/{name}/queue?{q}")
        except SycopeError as exc:
            log.warning("recorder queue: %s", exc)
            return {}
        jobs = {}
        for j in (ans or {}).get("jobs") or []:
            key = str(j.get("alert_key") or "")
            if key and key not in jobs:  # newest first: keep the newest job of an alert
                jobs[key] = {"state": j.get("state"), "file": j.get("id")}
        self._rec_cache[ip] = (time.time(), jobs)
        return jobs

    def pcap_index(self) -> None:
        """Which alerts of the window the recorder has packets for (done) or is getting (queued, running), and
        per IP how many: one read of the recorder's queue every five minutes, newest jobs first, pages until the
        jobs are older than the window."""
        name = self.settings.recorder_passthrough
        if not name or not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            return
        since = time.time() - self.settings.retention_hours * 3600
        by_alert: dict[str, dict] = {}
        by_ip: dict[str, dict] = {}
        try:
            for state in ("queued", "running", "done"):
                for page in range(1, 6):
                    q = urllib.parse.urlencode({"format": "json", "size": 1000, "state": state, "page": page})
                    with self._ui_lock:
                        ans = self._ui_client().get_json(f"passthrough/{name}/queue?{q}") or {}
                    jobs = ans.get("jobs") or []
                    oldest = None
                    for j in jobs:
                        info = j.get("alert_info") or {}
                        at = float(info.get("alertTime") or 0)
                        oldest = at if oldest is None else min(oldest, at)
                        key = str(j.get("alert_key") or "")
                        if not key or key in by_alert or (at and at < since):
                            continue
                        by_alert[key] = {"state": j.get("state"), "file": j.get("id"), "t": at * 1000,
                                         "name": info.get("name"), "bytes": j.get("pcap_bytes"),
                                         "client": info.get("clientIp"), "server": info.get("serverIp")}
                        for ip in {info.get("clientIp"), info.get("serverIp")} - {None, ""}:
                            c = by_ip.setdefault(ip, {"done": 0, "queued": 0})
                            c["done" if state == "done" else "queued"] += 1
                    if not jobs or page >= int(ans.get("pages") or 1) or (oldest and oldest < since):
                        break
        except SycopeError as exc:
            log.warning("recorder index: %s", exc)
            return
        self.pcap_by_alert, self.pcap_by_ip, self._pcap_at = by_alert, by_ip, time.time()

    def request_pcap(self, alert: dict) -> dict:
        """Ask Sycope to send this alert to the recorder destination. Raises SycopeError."""
        dest = self.settings.recorder_destination
        if not dest:
            raise SycopeError("no recorder destination set (SC_RECORDER_DESTINATION)")
        with self._ui_lock:
            ans = self._ui_client().call_action(dest, alert["def_id"], alert["id"], int(alert["t"]))
        self._rec_cache.clear()
        if isinstance(ans, dict) and ans.get("status") not in (None, 200):
            raise SycopeError(f"Sycope refused: {ans.get('message') or ans.get('code')}")
        return ans if isinstance(ans, dict) else {"answer": str(ans)[:300]}


def _verdict_changes(old: evidence.Board, new: evidence.Board) -> list[dict]:
    """The hosts whose verdict differs between two boards (a host absent from one has none there), the highest new
    verdict first, then by address."""
    def verdicts(b: evidence.Board) -> dict[str, tuple[str, str]]:
        out = {ip: (e.verdict, e.reason) for ip, e in b.entities.items()}
        for ip, t in b.target_inc.items():   # a host attacked from outside is also an incident
            if ip not in out or evidence.VRANK[t.verdict] > evidence.VRANK[out[ip][0]]:
                out[ip] = (t.verdict, t.reason)
        return out

    before, after = verdicts(old), verdicts(new)
    rows = []
    for ip in sorted({*before, *after}):
        was, now = before.get(ip), after.get(ip)
        if (was or ("none",))[0] == (now or ("none",))[0]:
            continue
        why = now[1] if now else f"no longer on the board (was: {was[1]})"
        name = new.names.get(ip) or old.names.get(ip)
        rows.append({"key": entities.key("ip", ip), "label": f"{ip} ({name})" if name else ip,
                     "from": was[0] if was else "none", "to": now[0] if now else "none", "why": why})
    rows.sort(key=lambda r: (-evidence.VRANK.get(r["to"], -1), r["key"]))
    return rows


def _pages(client, start: float, end: float, nql: str, chunk: int):
    """The alerts of a poll in Sycope pages; a client that only answers alerts() (a test double) as one page."""
    if hasattr(client, "pages"):
        return client.pages(start, end, nql, chunk)
    return [client.alerts(start, end, nql, chunk)]


def datetime_end(day: str) -> float:
    """Epoch seconds of the end of a UTC day 'YYYY-MM-DD'."""
    import calendar
    y, m, d = (int(x) for x in day.split("-"))
    return calendar.timegm((y, m, d, 0, 0, 0)) + 86400.0


def read_hostnames(path: Path) -> dict[str, str]:
    out = {}
    with path.open(encoding="utf-8", newline="") as f:
        for row in csv.reader(f):
            if len(row) >= 2:
                try:
                    out[str(ipaddress.ip_address(row[0].strip()))] = row[1].strip()[:80]
                except ValueError:
                    continue
    return out


def _ptr(ip: str) -> str:
    try:
        name = socket.gethostbyaddr(ip)[0]
    except (OSError, UnicodeError):
        return ""
    return name[:80] if re.fullmatch(r"[A-Za-z0-9._-]+", name or "") else ""
