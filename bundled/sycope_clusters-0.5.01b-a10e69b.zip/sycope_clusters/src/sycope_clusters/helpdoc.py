"""Help for every view, the way Sycope shows it: the ? in the top bar opens a side panel with the part for the view on
screen (the queue, one host, a group...), with screenshots whose numbered boxes the text explains. /help puts every
part on one page.

The figures name the elements their numbers mark (CSS selectors), and tools/help_shots.py draws the boxes on fresh
screenshots from those same lists, so the pictures and the words stay in step. The reference parts (the decision table,
families, chain rules, reasons, priorities) are built from the model's own tables.
"""

from __future__ import annotations

import html

from sycope_clusters import evidence as ev
from sycope_clusters import triage
from sycope_clusters.params import FACTORY, Params
from sycope_clusters.profile import WANT_DAYS
from sycope_clusters.rules import FAMILIES, STAGES


def _days_text() -> str:
    """The exception expiry options the way the dialog offers them: "1, 7, 30 or 90 days"."""
    d = triage.EXC_DAYS
    return ", ".join(str(x) for x in d[:-1]) + f" or {d[-1]} days"


def _e(x: object) -> str:
    return html.escape(str(x), quote=True)


def _pc(x: float) -> str:
    return f"{x * 100:.0f}%"


def _bytes(n: float) -> str:
    """10_000_000 as "10 MB" (decimal units, as the pages show bytes)."""
    for unit, size in (("GB", 1e9), ("MB", 1e6), ("KB", 1e3)):
        if n >= size:
            return f"{n / size:g} {unit}"
    return f"{n:g} B"


# ---- the screenshots: what each numbered box marks ------------------------------------------------------------------
# figure id -> {"caption", "marks": [(number, CSS selector, label, what it means)]}; tools/help_shots.py makes the image.
# A selector marks its first visible match ("a, b": the first of each, boxed together); "*" in front: every match.

FIGURES: dict[str, dict] = {
    "queue": {"caption": "The queue", "marks": [
        (1, "#headline", "The day in numbers",
         ("In the toolbar above the list: incidents (and the hosts in them), how many are at Act now and Investigate, "
         "and how many changed since they were handled. Hover it for the whole funnel: alerts in 24 hours, findings, "
         "the share that is busy services doing their job, handled hosts and what is new since your last visit. It "
         "gives way to the selection note when you tick incidents.")),
        (2, "#tabs", "Views",
         ("Three groups: the work (Queue, Under attack, External), the tuning (Noise & tuning, Hygiene) and the "
         "records (History, Audit) on the right. A number only where it means something: on Queue, red or orange is "
         "what to act on or investigate and grey what to review; on Under attack and External, the serious ones.")),
        (3, "*.qbar .vch", "Verdicts",
         "Show or hide Act now, Investigate, Review. Each chip counts incidents, the hosts in them in brackets."),
        (4, ".wfs", "Who has it",
         "Mine: what you took or were given. Unassigned: what nobody has. Escalated: what went to L2 or a team."),
        (5, "tr.qsec", "A section",
         "One per verdict, with its counts and what to do with it: Act now first, Review when the rest is done."),
        (6, "tr.qr td.c-i", "The incident",
         ("What it is (Host, Target, Group · hosts, Campaign · hosts), what happened in one line, and under it why it "
         "got this verdict.")),
        (7, "tr.qr td.c-k, tr.qr td.c-c", "How far, how sure",
         ("The kill-chain stages it reached, in the Kill chain column as R F L O (Recon, Foothold, Lateral, Objectives; "
          "filled: confirmed, dashed: only suggested), and the confidence. Scope, the hosts in it, sits between them.")),
        (8, "tr.qr[data-k^='h:'] td.c-a", "Actions",
         ("Open › opens the incident on its own page in a new tab. ⋯ (or a right click on the row) has the rest; Take, "
         "Seen and Close… appear in this column when the mouse is on the row, and stay out of the text beside it.")),
        (9, ".psw", "Triage | Episodes",
         ("The same alerts, seen two ways: Triage (this page) by evidence into incidents with a verdict, Episodes as "
          "the timeline of each host's activity. The verdict and the status of a host live here, in Triage.")),
    ]},
    "queue-bar": {"caption": "Filters, sorting and ticking", "marks": [
        (1, "*.qbar label", "Filters",
         ("Changed only: incidents that show something new since they were handled. Show handled: the closed and "
         "seen ones too. Watch: hosts with weak or background signals only (not incidents).")),
        (2, ".qtb [data-pause]", "Pause updates",
         "Holds the list as it is while you work; new data waits behind the pill at the bottom right."),
        (3, ".qtb .srch", "Find in the list",
         ("Filters this list by IP, alert, family or network. To find anything anywhere, use the search in the top "
         "bar.")),
        (4, "*th.srt", "Sort",
         ("Click Kill chain, Scope, Confidence or Last activity to sort inside each verdict; click again to reverse, "
         "a third time for the recommended order.")),
        (5, "input.qx", "Tick",
         "Tick several incidents, then Action ▾ above the table: one action on all their hosts."),
        (6, ".qtb label", "Compact", "One line per incident, as in Sycope's tables; this browser remembers it."),
    ]},
    "queue-campaign": {"caption": "A campaign with its incidents inside", "marks": [
        (1, "tr.qr[data-k^='c:']", "The campaign",
         "Many hosts of one network at Investigate or above: one row, with the incidents it is made of inside."),
        (2, "[data-exp]", "Open or fold",
         "Shows or hides its incidents here. A campaign with something at Act now inside opens by itself."),
        (3, "tr.qr[data-k^='c:'] td.c-s", "What is inside",
         "Its hosts, its incidents and how many of them are at each verdict (1 Act now · 15 Investigate)."),
        (4, "tr.child", "Its incidents",
         "Groups and single hosts that mostly sit in this network. Each one is worked like any incident."),
    ]},
    "queue-held": {"caption": "Taken, now quiet", "marks": [
        (1, "tr.held td.c-i", "Taken work",
         "A host, or an ended incident, that someone took or escalated and the board no longer shows: no alerts in 24 hours, or below Review."),
        (2, "tr.held td.c-st", "Who has it", "The status and the owner, as when it was taken."),
        (3, "tr.held td.c-a", "Finish it",
         "Close it with a classification, or Release it (back to New, off this list). Open › shows its record."),
    ]},
    "queue-unreviewed": {"caption": "Ended, not reviewed", "marks": [
        (1, "tr.unrev td.c-v", "At its peak",
         "The verdict it reached while it was on the board: only Act now and Investigate end up here."),
        (2, "tr.unrev td.c-i", "What it was",
         ("Its headline and when it ended. The section header says once why it is here: its strong alerts left the 24 h "
          "window before anyone looked (a night, a weekend). Back now means the same host is in the queue again.")),
        (3, "tr.unrev td.c-a", "Review it",
         ("Take it (in progress, yours), Seen (with why there is nothing to do) or Close… with a classification; "
          "Escalate… is in the ⋯ menu. Open › shows its record, with the next steps from its peak.")),
    ]},
    "queue-select": {"caption": "Several incidents at once", "marks": [
        (1, "*input.qx:checked", "Ticked", "The incidents you picked: hosts and groups."),
        (2, "#qact, #qsn", "Action",
         ("Blue once something is ticked; next to it how many incidents and hosts, and clear. The dialog repeats the "
         "scope before anything changes.")),
        (3, ".cm", "One action for all", "Take, Assign, Escalate, Seen or Close for all their hosts."),
    ]},
    "quicklook": {"caption": "Quick look", "marks": [
        (1, ".drw-h", "Quick look", "The incident you clicked, without leaving the list. Open incident › opens its page."),
        (2, "#drwg", "Width", "Drag the left edge to make it wider or narrower; the width is remembered."),
        (3, "#drwb .bulk", "Actions on the group", "For all its hosts, or for the ones ticked in its host list."),
        (4, "#drwb .nxs", "Next steps", "What to check, in order, from its evidence."),
    ]},
    "host-top": {"caption": "One host: the summary and what to do", "marks": [
        (1, "#crumbs", "Where you are",
         "Back to the queue or to the group and campaign around it; Previous and Next walk the list you came from."),
        (2, ".hsum .dh", "Who",
         "The verdict, the ticket priority (P1 to P4), the address, its name and tags; Copy IP and Copy as ticket."),
        (3, ".hsum .dsum, .hsum .rsn2", "What and why",
         "What happened in one line, and the line of the decision table that set the verdict."),
        (4, ".hsum .facts", "The facts",
         "Kill-chain stages, confidence, new behaviour, active now, the alerts and findings and their time."),
        (5, ".pcl", "Recorded packets", "Alerts the recorder has packets for, and how far back its buffer reaches."),
        (6, ".hact", "Act on it", ("Take it, assign, escalate, mark seen, close with a classification, add a note; "
                                  "under them its alerts and flows in Sycope.")),
    ]},
    "host-steps": {"caption": "Next steps", "marks": [
        (1, ".nx.ok", "A checked step", "Ticked by an analyst: name and time are kept with the incident."),
        (2, "*.nx .nxk", "Check, ask, action",
         "Check: a look in Sycope. Ask: outside it (EDR, auth logs, the owner). Action: containment, after a check."),
        (3, ".nx .nxl", "The links", "Flows or alerts of exactly this pair and time in Sycope, or the next host to see."),
        (4, ".flx", "Show here", "The pair's newest flows, read from Sycope: ports, bytes, packets, duration, flags."),
    ]},
    "host-path": {"caption": "The attack path and what happened", "marks": [
        (1, ".ap svg", "Attack path",
         ("Each family on its kill-chain stage, in time, from its first alert in What happened. Solid = confirmed, "
          "dashed = suspected. Labels stay inside the plot (a long one wraps or sits left of its dot; hover for the "
          "full name). Arrows show the order; orange ones a step against a host the previous step touched.")),
        (2, "ol.steps", "What happened", "The same evidence in words: one line per family, with its stage and bits."),
    ]},
    "host-alerts": {"caption": "The host's alerts", "marks": [
        (1, "tr.ag", "One line per repeat",
         "Alerts of one rule between the same pair are one line: how many, from when to when. Click to open."),
        (2, "[data-aflat]", "Each alert", "Shows every alert on its own, newest first."),
        (3, "tr.ag td a", "Into Sycope", "The alert in Sycope's alert list, or the flows of the pair at that time."),
    ]},
    "host-context": {"caption": "Context: the days before and the incident's history", "marks": [
        (1, ".heat", "Last days", "Its families per day: what is new today and what it does every day."),
        (2, "ol.hist", "History of this incident", "The system's decisions and every analyst action, newest first."),
        (3, "[data-sec='why'] > h3", "Why this verdict",
         "Folded: click it for the evidence term by term, the math of the confidence, and what Act now would need."),
    ]},
    "host-talk": {"caption": "Where it talked", "marks": [
        (1, ".flb .flh", "As client and as server",
         "Its flows in Sycope summed by counterpart: whom it reached, and who reached it, by bytes."),
        (2, ".flb [data-fl]", "The flows of one pair", "Opens the newest flows of that counterpart and port here."),
    ]},
    "dialog-close": {"caption": "Closing an incident", "marks": [
        (1, ".dlg .scope-box", "What it applies to", "The host, or how many hosts and how many of them at Act now."),
        (2, "#dlg-cls", "Classification", "True positive, benign or false positive."),
        (3, "#dlg-reason", "Reason", "A short list for each classification, so the numbers in History mean something."),
        (4, ".dlg textarea", "What you checked", "Required at Act now and Investigate: it goes into the history."),
    ]},
    "dialog-exception": {"caption": "An exception, before it is saved", "marks": [
        (1, ".dlg .scope-box", "What it does", "Allowed on this host, or a known service for every host."),
        (2, ".dlg-b > p", "What it would hide", "On the board now: findings, hosts, alerts, and how many at Act now."),
        (3, ".dlg textarea", "Why", "Kept in the audit log with your name."),
        (4, ".dlg select", "For how long", f"{_days_text()} (30 is offered); it ends by itself and Sycope keeps every alert either way."),
    ]},
    "group": {"caption": "A group of hosts", "marks": [
        (1, ".hsum .dh", "The group", "Its verdict, its pattern as a title (and the counterpart that ties it), its size."),
        (2, ".bulk", "Actions on the group", "For all its hosts, the hosts the filter shows, or the ones you tick."),
        (3, ".nxs", "Next steps", "Start with the host with the most evidence; one host's checks explain most of the rest."),
        (4, ".hfb", "Filter its hosts", "By text, /24 or status; the actions above then apply to what is shown."),
        (5, "table.ht thead, table.ht tbody tr", "Its hosts", "Each with its verdict, path, last activity and status; click for a quick look."),
    ]},
    "campaign": {"caption": "A campaign", "marks": [
        (1, ".hsum .dh", "The campaign", "Its network, its verdict, how many hosts in how many incidents."),
        (2, ".hsum .rsn2", "Why", "Act now when most hosts do something new, or some are at Act now already."),
        (3, ".nxs", "Next steps", "The most urgent incident inside first, then what drives the wave."),
        (4, ".sec table.qt thead, .sec table.qt tbody tr", "Its incidents", "The groups and hosts it is made of, worked like any incident."),
    ]},
    "target": {"caption": "A host attacked from outside", "marks": [
        (1, ".hsum .dh", "The target", ("Its verdict and priority: Review, Investigate when it answered a lot, is a crown jewel, "
                                       "or the source is on a threat list.")),
        (2, ".hsum .facts", "The attack", "Outside addresses, threat lists, how much it answered."),
        (3, ".nxs", "Next steps", "Did it let them in, should the service be open at all, whom it reached after."),
    ]},
    "targets": {"caption": "Under attack", "marks": [
        (1, "td .hb", "How exposed", ("Exposure high: a threat-listed attacker, an attack across the edge, a crown jewel "
                                     "under real attack or three attack families. It is not a verdict: the verdict "
                                     "is the only severity scale. Busy service: mostly a busy service.")),
        (2, "td .tg", "In the queue", "Attacked from outside and it answered: an incident of its own."),
        (3, "tbody tr td:nth-child(3)", "Attackers", "How many, internal and external."),
    ]},
    "external": {"caption": "Outside addresses", "marks": [
        (1, "td .hb", "Rating", "Hostile: on a threat list (not a shared cloud address) or attacking inward."),
        (2, "td .tg.ch", "Wave", "Several of your hosts contacted the same listed address."),
        (3, "#cpy", "Copy hostile IPs", "For a block list or a ticket."),
    ]},
    "tuning": {"caption": "Noise & tuning", "marks": [
        (1, ".sec:first-of-type table", "Busy services", "One server:port most hosts reach with the same rule every day."),
        (2, "[data-svc]", "Accept as known service", "Takes the weight of those alerts off the triage, after a preview."),
        (3, ".sec table.lt", "Rules and their value", ("Volume against what the triage kept: high volume, low value is "
                                                      "the rule to tune in Sycope.")),
    ]},
    "hygiene": {"caption": "Hygiene", "marks": [
        (1, "table.lt", "Findings", "Policy and hygiene: cleartext, unauthorized services, odd ports. Not threats."),
    ]},
    "history": {"caption": "History", "marks": [
        (1, ".afl", "Filters", "Period (8 hours for a shift up to all time), kind, peak verdict, outcome, and a search."),
        (2, ".hstat", "The numbers", "Incidents as the queue counts them, per verdict: active, handled how fast, how closed."),
        (3, "[data-handover]", "Copy as handover", "What happened in the shift, as text for the next one."),
        (4, ".qt tbody tr", "One record", "An incident as it was at its peak; click to open it."),
    ]},
    "record": {"caption": "A record of the history", "marks": [
        (1, ".hsum .dh", "The record", "What it was about, still open or closed, and a link to its current state."),
        (2, ".partof", "Outcome", "What the team did, who, when, why, with the note."),
        (3, "ol.hist", "What happened to it", "Opened, escalated, handled, closed: every event with its time."),
    ]},
    "audit": {"caption": "Audit", "marks": [
        (1, ".afl", "Filters", "Who, which action, the period, a search; Export CSV for the auditors."),
        (2, ".qt tbody tr", "One action", ("When, who (with a ✓ when Sycope confirmed the name), what, on which host, "
                                            "and the note.")),
    ]},
    "menu": {"caption": "A right click on an outside address", "marks": [
        (1, ".cm .cm-h", "What it is about", "The address (or the incident) under the mouse, and whether it is outside your networks."),
        (2, ".cm button.cm-i", "Here", "Quick look, a new tab, the search for it everywhere."),
        (3, ".cm a.cm-i[href*='raw-data']", "In Sycope", "Its flows (raw data) and its alerts, for the time of the incident."),
        (4, ".cm a.cm-i[href*='virustotal'], .cm a.cm-i[href*='abuseipdb']", "Look it up",
         ("Only for outside addresses, and only the services your admin set (SC_TI_PIVOTS): the address leaves your "
         "network.")),
    ]},
    "config": {"caption": "The Configuration tab (admins)", "marks": [
        (1, "[data-tab='config']", "The tab",
         ("Only an admin sees it: Sycope has to confirm who you are and that you are an admin, the page cannot claim "
          "it. Analysts never see the editors.")),
        (2, "#cfbar", "Changes not published yet",
         "Everything you change waits here. Nothing counts until you preview and publish it."),
        (3, ".cfg .sec[data-sec='cf-profile'] > h3", "Cards",
         ("Health, Profile, Crown jewels, Silenced, Scoring, Playbooks, Rule catalog and Versions. A header folds a "
          "card; the browser remembers which are open.")),
    ]},
    "config-preview": {"caption": "Preview before publishing", "marks": [
        (1, ".dlg.wide .dlg-b > p", "What would change", "How many incidents change verdict on today's data."),
        (2, ".dlg.wide thead", "From, to and why",
         "Each incident with its verdict now, its verdict with your change, and the reason the board gives."),
        (3, ".dlg.wide [data-dlg='1']", "Publish",
         "Makes it a new version and scores the board again. The toast after it has Undo."),
        (4, ".dlg.wide [data-dlg='0']", "Cancel", "Your changes stay in the page: nothing was published."),
    ]},
    "config-playbooks": {"caption": "Editing a playbook", "marks": [
        (1, "#cfpq", "Find a step", "Type a word of the step or its chain rule or family."),
        (2, ".cfpg[open] summary", "A section",
         "One per chain rule or family, with how many steps you changed. Add a step here adds one of your own."),
        (3, ".cfpg[open] .cfpb td.stp", "The step",
         ("Check, ask or act, the wording and why. {ip}, {cp} and the others fill in per incident. A step you edited "
          "says so, and says when the shipped wording changed under it.")),
        (4, ".cfpg[open] .cfpb .btns", "Edit, hide, move",
         "Hide takes the step off every incident. Move puts it after another step. Undo brings the shipped step back."),
    ]},
    "trace-sources": {"caption": "Where each number comes from", "marks": [
        (1, ".tr .srcl", "Source",
         ("Under each finding: learned from your network, shipped with the product, set by an admin, or from a "
          "setting of the deployment. Low norm confidence means few observations stand behind a learned norm.")),
    ]},
    "search": {"caption": "One search for everything", "marks": [
        (1, "#gsq", "Search", "An IP, a network (10.88.1.0/24), a host name, a rule or an outside network."),
        (2, ".gsh", "What it found", ("This host, what it is part of, hosts with alerts, targets, outside addresses, "
                                     "the history.")),
        (3, ".gsi", "Open it", "Click, or Enter for the first one: a quick look opens."),
    ]},
}


# ---- the parts ------------------------------------------------------------------------------------------------------
# blocks: ("p", html), ("fig", figure id), ("h", text), ("ul" | "ol", [html]), ("dl", [(term, html)]),
# ("table", [head], [[cell html]])

def _decision(p: Params = FACTORY) -> list:
    chain = lambda c: ev.CHAINS[c][0]
    lines = [
        ("Act now", "act", [
            "a chain rule that already means a compromise (" + ", ".join(chain(c) for c in sorted(p["act_chains"]))
            + f") with confidence {_pc(p['verdict.act_chain_conf'])} or more",
            (f"{chain('CR-08')} or {chain('CR-09')} where the second step hits a host the first one "
             f"touched, with confidence {_pc(p['verdict.linked_conf'])} or more"),
            f"a command channel or Objectives with evidence, and confidence {_pc(p['verdict.impact_conf'])} or more",
            ("a crown jewel with a command channel or at Objectives (any confidence), or at Lateral with confidence "
             f"{_pc(p['verdict.crown_stage_conf'])} or more")]),
        ("Investigate", "investigate", [
            "a command channel or Objectives with evidence at any confidence: an exfiltration or a command channel is never left in Review",
            ("a confirmed stage with enough risk (confidence times the weight of the stage, "
             f"{p['verdict.investigate_risk']:g} or more)"),
            f"the chain rules {chain('CR-03')}, {chain('CR-06')}, {chain('CR-08')}, {chain('CR-09')} or {chain('CR-10')}",
            "a new contact with an address on a threat list"]),
        ("Review", "review", ["a confirmed stage or some risk, below the lines above",
                              "a threat-list contact the host already had before"]),
        ("Watch", "watch", ["weak or background signals only: not an incident"]),
    ]
    out: list = [("p", "The first line that matches decides; the line under each incident says which one it was.")]
    for label, key, items in lines:
        out.append(("h", f'<span class="vdot" data-v="{key}"></span>{label}'))
        out.append(("ul", [_e(x) for x in items]))
    out.append(("h", "What the service remembers about a host"))
    out.append(("p", ("Three rules read the decisions already on record, not only today's alerts. A host nobody "
                      "decided on does not become normal, and a verdict does not fall just because a window moved.")))
    out.append(("ul", [
        ("<b>Habit only from decided days.</b> A day when the host was in an incident that peaked at Investigate or "
         "Act now and ended with nobody deciding does not count as a day it \"always does this\". The background "
         "line says so: \"Brute Force Attack on 3 of 7 days (2 days not counted: incidents nobody decided)\". Days of incidents "
         "closed as a true positive, benign, a false positive or resolved, and a known service, still teach. Marking an ended "
         "incident seen is not a decision."),
        (f"<b>Recurrence.</b> When a host's incidents (Review or above) have ended without a decision "
         f"{p['recurrence.min1']:g} times in the last {p['recurrence.days']:g} days, its evidence gets "
         f"{p['recurrence.bits1']:g} bit; from {p['recurrence.min2']:g} times, {p['recurrence.bits2']:g} bits. The "
         "Why table shows \"recurring N× without decision: +K bits\"."),
        (f"<b>Hysteresis.</b> Without an analyst's action on the host (a status, closing an incident it was in, or an "
         f"exception that covers its evidence) "
         f"a verdict falls at most one level in {p['hysteresis.step_h']:g} hours. A host that was Act now stays at "
         f"least Investigate until an analyst acts on it, or {p['hysteresis.act_hold_h']:g} hours pass with nothing "
         "above Watch; evidence at Review or above starts that count again. The Why table and the host's history "
         "say \"held at Investigate: Act now on &lt;time&gt;, no analyst decision\", with what the evidence alone says. "
         "Any analyst action, or an exception covering the host's evidence, ends the hold at once, however long ago it was "
         "taken; only what the service showed after it counts.")]))
    return out


STAGE_WORDS = {
    "Recon": ("someone maps you from outside", "Reconnaissance, Resource Development"),
    "Foothold": ("holds a host: first access, a command channel (beacon, covert channel, listed C2 address)",
                 "Initial Access, Execution, Persistence, Privilege Escalation, Command and Control"),
    "Lateral": ("moves inside: discovery, credentials, lateral movement, collecting data",
                "Discovery, Credential Access, Lateral Movement, Collection, Defense Evasion"),
    "Objectives": ("reaches its goal: data out, floods", "Exfiltration, Impact"),
}

def _glossary(p: Params = FACTORY) -> list:
    return [
        ("✓ after a name", ("Sycope confirmed who that was: the page proved the signed-in user once a shift (a code written "
                           "into the user's own Sycope preferences, found by the service in Sycope's audit log). Admin "
                           "rights come from that check too, never from the page.")),
        ("Alert", ("One row Sycope raised: a rule that fired on one flow or one window. The unit of the raw data; "
                  "\"Alerts naming this host\" counts every alert with the host on either side, while \"alerts it sent\" "
                  "counts those where it was the source.")),
        ("Finding", ("The alerts of one rule between the same pair of addresses (and port) in the 24 hours: one piece of "
                    "evidence, however many alerts it has.")),
        ("Family", ("Rules that mean the same kind of behaviour (scanning, a credential attack, a beacon). A host counts "
                   "each family once, with its strongest finding; weak signals do not add up, and a weak signal (class C) "
                   "is suspected only: its bits count, but it is never a step of a chain rule and never makes a "
                   "command channel.")),
        ("Bits", ("The strength of the evidence. Each bit doubles the odds that the host is under an attacker's control, "
                 "so 10 bits is four times as strong as 8. An indicator match can carry up to "
                 f"{p['class_bits.A']:g} bits, attack behaviour {p['class_bits.B']:g}, a weak signal "
                 f"{p['class_bits.C']:g}; a rule "
                 "that fires on most hosts, or every day, carries less (rarity and novelty).")),
        ("Prior", (f"The starting assumption before any evidence: about 1 host in {2 ** int(p['prior_bits'])} is under "
                  f"attack. Evidence has to beat it: {int(p['prior_bits'])} bits make a host a coin toss (50%), more bits "
                  "make it likelier than not. The Why table shows the sum with the prior in it (hover \"bits\" and \"prior\" there).")),
        ("Confidence", (f"The bits turned into a percentage, shown in lists as a word: low below {_pc(p['wording.conf_low'])}, "
                       f"medium below {_pc(p['wording.conf_high'])}, high from there (hover for the percentage). A stage is "
                       "called confirmed in a reason only at high confidence; below it the reason says \"stage signal\". "
                       "The verdict weighs the stage too, so a command channel or an Objectives finding at low confidence "
                       "is still Investigate (the row then says: low, but a command channel).")),
        ("Stage", ("How far an attacker got, in the four steps of the Unified Kill Chain: Recon, Foothold, Lateral, "
                  "Objectives (letters R F L O). A command channel is a Foothold: a beacon proves the attacker holds a "
                  "host, not that the goal is reached; it still weighs and ranks like Objectives, because a missed one "
                  "costs as much. A finding of "
                  f"{p['confirm_bits']:g} bits or more is strong evidence of its stage; weaker evidence only suggests it "
                  f"(dashed). A host's stage is called confirmed only when its confidence is also high "
                  f"({_pc(p['wording.conf_high'])} or more); below that the header says \"<Stage>-stage evidence\". "
                  "Incident records stored before 1.2 keep their original reason wording.")),
        ("Chain rule", ("Families in an attacker's order on one host (scanning, then a credential attack): extra bits, "
                       "and some of them decide Act now on their own.")),
        ("New", "At least one finding the host never had in the stored days before (needs 3 days of history)."),
        ("Crown jewel", ("A host your team marked critical (SC_CRITICAL_HOSTS_FILE, or the Configuration tab): its "
                         f"stages weigh {p['crown_mult']:g} times.")),
        ("Times and numbers", ("The top bar has a UTC | Local switch. Every time on these pages is in the zone you pick: Local "
                              "is your browser's own zone (the bar shows it, for example Local (UTC+01:00); daylight saving "
                              "time is applied per time), UTC is UTC. The choice is yours alone, kept in this browser, and "
                              "Local is the default. Times show as HH:MM for today and YYYY-MM-DD HH:MM for any other day (days "
                              "are cut in the zone you picked). Hover a time for the seconds and, in lists, how long ago. "
                              "Numbers use a comma for thousands. Text the service writes (the ticket, the digest, the "
                              "webhook) is in the time zone set in Configuration and always has the date; CSV exports are "
                              "always UTC and say so in the column name.")),
        ("Name and role tags", ("The host name comes from the hostnames file (admin), else a one-address entry of the "
                               "Sycope lookup, else reverse DNS; no source, no name. A role tag is the admin's (networks "
                               "file, or a confirmed suggestion), the lookup's, or learned from the netflow "
                               f"(\"learned role from 9 of {WANT_DAYS} days\"); the admin's wins. Hover a tag for its source. "
                               "The playbook stops asking whether a host is an admin workstation or a jump host once "
                               "an admin gave it a role or the profile learned one; a role that only the lookup "
                               "names, a role kept for a held host and a location do not stop it. There is no user "
                               "name until AD logons are connected.")),
        ("Busy service", ("A server most hosts use every day: its alerts are the service doing its job. They go to Noise "
                         "& tuning and weigh nothing until you decide.")),
        ("Host", "One internal address. As an incident: what that host did, with its verdict."),
        ("Incident", ("What the queue shows and an analyst works: a host, a group of hosts or a campaign, with one "
                     "verdict. Counted in incidents, not in alerts and not in hosts.")),
        ("Cluster", ("The Clusters view's unit (shown only in the compare mode): alerts chained in time on one host. "
                    "A host can have several clusters, so there are more clusters than hosts. It is not an incident of "
                    "the queue.")),
        ("Episode", ("Alerts chained in time on one host: the unit of the Episodes view. A host can have several "
                    "episodes, so there are more episodes than hosts. It is not an incident of the queue and has no "
                    "verdict of its own: the host's verdict is Triage's.")),
        ("Target", ("An incident about a host attacked from outside that answered (or whose attacker is on a threat "
                   "list). It has no confidence of its own: it is the victim, not the actor.")),
        ("Group", ("Hosts with the same verdict and pattern (families and chain rules): one incident, one decision for "
                  "all of them or for the ones you tick. When its hosts went after different targets it splits, and its "
                  "title names the counterpart that ties each part (around 10.88.100.10).")),
        ("Campaign", ("More hosts of one network segment at Investigate or above, with the same families, than chance "
                     "explains for its size: one wave, not separate incidents. Its groups and hosts sit inside it.")),
        ("Quiet", (f"No alerts for {p['quiet_h']:g} hours or more: lower in its section, still open. A compromise does "
                  "not end with silence.")),
    ]


def _words(p: Params = FACTORY) -> list:
    stages = [[f"<b>{_e(s)}</b>", _e(STAGE_WORDS[s][0]), _e(STAGE_WORDS[s][1])] for s in STAGES]
    return [("dl", [(t, _e(d)) for t, d in _glossary(p)]), ("h", "Kill-chain stages"),
            ("p", ("The stage a rule can confirm comes from the rule table, not from the template's MITRE tag: the tag "
                  "says what an alert could mean, the table what it proves.")),
            ("table", ["Stage", "Here it means", "MITRE ATT&CK tactics"], stages),
            ("h", "ATT&CK techniques"),
            ("p", ("The technique and tactic shown on a finding come from the product's own table, by rule and by "
                  "direction across the internet edge, and only where the flow signal (ports, volume, interval, "
                  "number of hosts) shows the technique. The same port reads differently: remote desktop from the "
                  "internet is External Remote Services (T1133, Initial Access), between internal hosts Remote "
                  "Desktop Protocol (T1021.001, Lateral Movement), and going out it is a policy finding with no "
                  "technique. A scan from outside is Reconnaissance (T1595), inside it is Discovery (T1046).")),
            ("p", ("A rule without a defensible network-level technique reads \"no ATT&CK mapping\" with the reason: "
                  "behavioural anomaly, policy or indicator match. Where the flow shows the tactic but not "
                  "the technique (a listed command-and-control address, whose protocol the list does not give; a large "
                  "upload out, whose channel is unknown; an exposed SMB, NFS or LDAP service) only the tactic is shown. The Sycope template's own "
                  "MITRE tag is kept for coverage reports and appears only in detail views, labelled template tag. "
                  "An admin can set the technique, the tactic and the command-and-control mark of a rule in the "
                  "Rule catalog of the Configuration tab."))]


def _families(p: Params = FACTORY) -> list:
    fams = [[f'<span class="fdot" style="color:{c}">●</span> <b>{_e(lbl)}</b>', _e(why)]
            for k, (lbl, why, c) in FAMILIES.items() if k != "UNK"]
    chains = [[f"<b>{_e(t)}</b>", _e(w), f"{p[f'chain.{k}.bonus']:g}"] for k, (t, _b, w) in ev.CHAINS.items()]
    return [("table", ["Family", "What it means"], fams), ("h", "Chain rules"),
            ("table", ["Chain rule", "When", "Extra bits"], chains)]


def _actions() -> list:
    reasons = [["<b>True positive</b>", "A real attack (or a real policy breach) that was dealt with.",
                _e("; ".join(triage.REASONS["tp"]))],
               ["<b>Benign</b>", "The alerts were right, but it is allowed or expected.",
                _e("; ".join(triage.REASONS["benign"]))],
               ["<b>False positive</b>", "The detection is wrong: it fires on traffic that is not what it says.",
                _e("; ".join(triage.REASONS["fp"]))]]
    return [
        ("p", ("Every change of state is one click and a short dialog when it matters; the toast that follows has "
              "<b>Undo</b> for a few seconds. Every action goes into the audit log and the incident's history with "
              "your name. Inside Sycope that is the name Sycope confirmed: once a shift the page proves who is signed "
              "in (it writes a code into your own Sycope preferences and the service finds that line in Sycope's audit "
              "log), and the top bar shows your name with a ✓. Without the check the name is what the browser says, "
              "and the audit log shows it without the ✓.")),
        ("dl", [("Take it", "In progress, assigned to you. It stays in the queue; Mine shows it."),
                ("Assign…", "In progress, assigned to the person you name (the list comes from Sycope's users)."),
                ("Escalate…", "To L2 or a named team, with what they should look at. It stays in the queue."),
                ("Seen", ("Looked at, nothing to do now. It leaves the queue and comes back when it shows something "
                         "new (a new family, a higher verdict).")),
                ("Close…", ("With a classification and a reason; at Act now and Investigate also a note on what you "
                           "checked. It comes back only if it shows something new.")),
                ("Add note", "A note in the incident's history; the state does not change."),
                ("Reopen", "Back to New.")]),
        ("fig", "dialog-close"),
        ("h", "Closing: classifications and reasons"),
        ("table", ["Closed as", "Means", "Reasons to pick from"], reasons),
        ("h", "Groups, campaigns, several incidents"),
        ("p", ("An action on a group applies to all its hosts, to the ones its filter shows, or to the ones you tick; "
              "the dialog always says how many hosts and how many of them are at Act now. Each host keeps its own "
              "line in the audit log. In the queue, tick the incidents and choose from Action ▾ above the table.")),
        ("fig", "queue-select"),
    ]


def _webhook(p: Params = FACTORY) -> list:
    """The webhook payload, the SLA numbers in force and where they change."""
    def h(v: float) -> str:
        return f"{v:g} h"

    return [
        ("h", "Webhook"),
        ("p", ("Set <code>SC_WEBHOOK_URL</code> (and <code>SC_WEBHOOK_SECRET</code>, <code>SC_WEBHOOK_VERIFY_TLS</code>). "
              "Each event is one JSON POST. With a secret every body is signed: header <code>X-SC-Signature</code> is "
              "<code>sha256=</code> and the HMAC-SHA256 of the body as hex. <code>X-SC-Event</code> and "
              "<code>X-SC-Delivery</code> (the event id: the same transition has the same id, drop a repeat) come with it. "
              "The signature carries no timestamp: a receiver that must refuse replays checks <code>event_id</code> and "
              "<code>at</code> in the body.")),
        ("dl", [
            ("incident.new", "A top-level incident (a host, a group or a campaign) first shows Investigate or Act now."),
            ("incident.raised", ("An incident rises above the peak it showed (<code>transition: escalated</code>), or comes "
                                "back after an analyst handled it (<code>reopened</code>). A verdict the hysteresis holds, "
                                "a fall and an incident leaving the board send nothing (an exception that closes it is "
                                "<code>incident.status</code>).")),
            ("incident.status", ("An analyst took it, escalated it, marked it seen or closed it: <code>status</code> "
                                "(taken, escalated, seen, closed), <code>outcome</code>, <code>who</code>, "
                                "<code>owner</code>, <code>note</code>. One event per incident, also for an action on "
                                "several hosts. The same event, once, when an exception covers all of an incident's "
                                "evidence and closes it: <code>status</code> closed, <code>outcome</code> excepted, "
                                "<code>who</code> \"exception &lt;id&gt;\".")),
            ("sla.breached", ("A deadline passed with nobody having acted: <code>sla.kind</code> is <code>ack</code> or "
                             "<code>handle</code>. Once per incident and kind; deadlines that passed before the webhook was turned on are not sent.")),
            ("actnow.unowned", "An Act now incident that nobody took or escalated after " + f"{p['sla.unowned_min']:g}"
                               + " min. Once per incident.")]),
        ("p", ("The body holds <code>event</code>, <code>event_id</code>, <code>at</code> (epoch seconds) and "
              "<code>at_iso</code>, <code>incident</code> (id, kind, subject, label, verdict, peak, priority, owner, "
              "status, outcome, opened_at, last_seen, <code>link</code>), the event's own fields (<code>transition</code>, "
              "<code>status</code>, <code>sla</code>) and <code>ticket</code>: the same text as Copy as ticket. "
              "<code>link</code> is relative to the address the pages are opened at; it is absolute when "
              "<code>SC_BASE_HREF</code> is set.")),
        ("p", ("Sending never waits for the receiver: events go on a queue (500; the oldest is dropped when it is full) and "
              "one background thread posts them. A failed post is tried three more times, with a growing pause (not after "
              "a redirect or a 4xx answer other than 408 and 429). The last failure is in the audit log (event, incident, HTTP status "
              "or error; never the body or the secret) and in Health on the System page: <i>the last delivery failed "
              "at ...</i>.")),
        ("h", "SLA"),
        ("p", ("An incident has an SLA by the highest verdict it reached. The clock starts when it first showed that verdict. "
              "<b>First action</b> is the first thing an analyst does with it: any status (seen too), a note or a next step "
              "checked. "
              "<b>Closed or escalated</b> is a close with an outcome (true positive, benign, false positive) or an "
              "escalation; seen is an action, not handling. Review has no SLA. An incident an analyst marked seen or closed, "
              "while that still covers its evidence, is out of the queue: no timer and no SLA event. A status set before "
              "the clock started counts as met.")),
        ("table", ["Verdict", "First action within", "Closed or escalated within"], [
            ["<b>Act now</b>", f"{p['sla.act.ack_min']:g} min", h(p["sla.act.handle_h"])],
            ["<b>Investigate</b>", h(p["sla.investigate.ack_h"]), h(p["sla.investigate.handle_h"])]]),
        ("p", "The queue's <b>SLA</b> column counts down to the next deadline (<i>ack 25 min</i>, then <i>close 3 h</i>) "
              "and says <b>breached</b> once it has passed; hover for the due time. An Act now incident that stays "
              "unowned for " + f"{p['sla.unowned_min']:g}" + " min also raises <code>actnow.unowned</code>. The Security "
              "digest shows incidents per verdict against the week before, the median time to first action and to close, "
              "the breaches of the last 24 hours and 7 days, and the Act now incidents per day."),
        ("p", ("Where to change the limits: Configuration, <b>parameters</b>, <code>sla.act.ack_min</code>, "
              "<code>sla.act.handle_h</code>, <code>sla.investigate.ack_h</code>, <code>sla.investigate.handle_h</code> "
              "and <code>sla.unowned_min</code>. They go through the same draft and publish as every other number.")),
    ]


def sections(p: Params = FACTORY) -> list[dict]:
    """The parts of the help, with the numbers of the parameters `p` (the board's, not the shipped ones)."""
    return [
        {"id": "queue", "title": "Queue", "intro":
            "The work list: every incident the last 24 hours of Sycope alerts produced, most urgent first. An incident is "
            "one host, a host attacked from outside, a group of hosts with the same pattern, or a campaign in one network. "
            "Work Act now first, then Investigate; Review when those are empty. The shift is clear when Act now and "
            "Investigate are.",
         "blocks": [
             ("fig", "queue"),
             ("p", (f"The blue line above the tabs (Profile: 4/{WANT_DAYS} days) shows while the triage is still learning what is "
                   "normal on this network. Verdicts work from the first day; until the profile fills they lean on "
                   "norms shipped with the product.")),
             ("h", "What happens when you…"),
             ("dl", [("click a row", "A quick look opens on the right: the whole incident without leaving the list."),
                     ("press Take", "It becomes yours (In progress), stays in the queue, and Mine counts it."),
                     ("press Seen", "It leaves the queue until it shows something new."),
                     ("press Close…", ("A dialog asks how you close it: true positive, benign or false positive, with a "
                                      "reason (and a note at Act now and Investigate).")),
                     ("wait a minute", ("The board reads Sycope every 60 seconds. While your mouse is on the list or a panel "
                                       "is open the list holds still, and a pill at the bottom right says how many changes "
                                       "wait (show now).")),
                     ("open Open ›", "The incident on its own page, in a new tab; Previous and Next there follow this list.")]),
             ("p", ("The <b>SLA</b> column counts down to the next deadline of an Act now or Investigate incident (first "
                   "action, then close or escalate) and says <b>breached</b> when it has passed; the limits and the "
                   "events are under Webhook and SLA.")),
             ("fig", "queue-bar"),
             ("fig", "queue-campaign"),
             ("fig", "queue-held"),
             ("p", ("A host you took that goes quiet does not disappear: it stays at the end of the queue until someone "
                   "closes or releases it.")),
             ("fig", "queue-unreviewed"),
             ("p", ("Neither does an incident nobody looked at. When an Act now or Investigate goes quiet (its alerts leave "
                   "the 24 h window, say over a weekend) it moves to Ended, not reviewed, after Review, and stays there until "
                   f"someone marks it seen or closes it, for at most {p['unreviewed_days']:g} days (the parameter unreviewed_days, "
                   "SC_UNREVIEWED_DAYS). The section has a count and folds: open by default, shut while the "
                   "queue has Review items, and this browser remembers your choice. It can also be taken or "
                   "escalated: it then waits under Taken, now quiet until someone closes or releases it, and its record "
                   "page has the next steps from its peak, which can be checked. Above the list, since … "
                   f"counts what is new since the team was last here (the last action before a pause of "
                   f"{p['shift_gap_h']:g} hours or more) and how many ended unreviewed.")),
         ], "see": ["quicklook", "actions", "verdicts", "words"]},
        {"id": "quicklook", "title": "Quick look", "intro":
            "Clicking a row, a host or a counterpart opens it in the panel on the right. It is the same content as the "
            "incident's own page; Back returns to what you looked at before.",
         "blocks": [("fig", "quicklook"),
                    ("ul", ["Open incident › opens the page in a new tab (⌘ or Ctrl click on a row does the same).",
                            "Close or Esc closes the panel; a click outside it does too.",
                            "The panel refreshes with the board but never eats what you are typing."])],
         "see": ["host", "group", "campaign"]},
        {"id": "host", "title": "Incident: one host", "intro":
            "Everything about one internal host and what it did: the verdict and why, what to do next, the attack path, "
            "its alerts, the days before and what the team did. Under the header, three lines say why (the three biggest "
            "terms of the math, with a link to all of it). From the top: summary, actions, next steps, evidence, "
            "context, and the math folded at the bottom. What a section means sits behind the (i) next to its heading.",
         "blocks": [("fig", "host-top"),
                    ("p", ("Each part of the page is a card: click its header to fold it or open it again, and this browser "
                          "remembers it. The math, the flows, the alerts and earlier incidents start folded.")),
                    ("fig", "host-steps"), ("fig", "host-path"), ("fig", "host-alerts"),
                    ("fig", "host-talk"), ("fig", "host-context"),
                    ("h", "Where the numbers come from"),
                ("p", ("In the math at the bottom, each finding says what its rarity and other terms rest on: learned from "
                      "this network, shipped with the product, set by an admin, or from a deployment setting. "
                      "<b>Low norm confidence</b> means the learned norm rests on few observations.")),
                ("fig", "trace-sources"),
                ("h", "Copy as ticket"),
                    ("p", ("A text for IT: the priority (P1 to P4), the recommended actions, what to check (with what was "
                          "checked), the indicators, outside addresses, notes and links; the bits go into an appendix at "
                          "the end. The service writes it (the webhook sends the same text), in the time zone of the "
                          "configuration."))],
         "see": ["steps", "actions", "verdicts", "priorities"]},
        {"id": "target", "title": "Incident: a host attacked from outside", "intro":
            "A host attacked across the internet edge (RDP, brute force, a credential attack, a scan) or by a threat-listed "
            "address, that answered. It does not act itself, so it has no confidence of its own: the question is whether "
            "the attack got in. Victims of internal attackers are not incidents of their own: their attackers are.",
         "blocks": [("fig", "target"),
                    ("ul", [(f"Review by default; Investigate when it answered {_bytes(p['answer_floor_bytes'])} or more, is a "
                             "crown jewel, or the source is listed and it answered."),
                            "Seen or Close work as for any host; it comes back with a new family or a listed source.",
                            "Under attack lists every target; the ones in the queue say so."])],
         "see": ["targets", "steps", "actions"]},
        {"id": "group", "title": "Incident: a group of hosts", "intro":
            "Hosts with the same verdict and the same pattern are one incident: one look, one decision. When the hosts "
            "went after different targets the group splits, and each part is named by the counterpart that ties it.",
         "blocks": [("fig", "group"),
                    ("ul", ["What connects these hosts: the families most of them confirmed, in their usual order.",
                            "Scope: their networks, crown jewels, the counterparts most of them hit, outside addresses.",
                            "Its history: the actions taken on the group as a whole."])],
         "see": ["actions", "steps", "campaign"]},
        {"id": "campaign", "title": "Incident: a campaign", "intro":
            "More hosts of one network segment at Investigate or above, with the same families, than chance explains for "
            "its size: one wave (a worm, a red team, an attacker spreading), not dozens of separate incidents. Its groups "
            "and single hosts sit inside it.",
         "blocks": [("fig", "campaign"),
                    ("p", ("A campaign is Act now when most of its hosts do something they never did before, or some of them "
                          "are at Act now already. The reason names the condition that fired with its numbers (\"2 of 41 hosts at Act now\", "
                          "\"28 of 41 hosts (68%) do something new\"). Its numbers are the sums of its incidents, so no host counts twice."))],
         "see": ["group", "actions"]},
        {"id": "steps", "title": "Next steps", "intro":
            "Each incident lists what to check, in order, built from its own evidence: its chain rules first (they say what "
            "kind of attack it is), then its strongest families, then the context (a crown jewel, recorded packets). The "
            "same evidence gives everyone the same list.",
         "blocks": [("fig", "host-steps"),
                    ("dl", [("Check", ("A look in Sycope: the link opens the flows or alerts of exactly this pair and time; "
                                      "show here reads the flows into the page.")),
                            ("Ask", "Outside Sycope: EDR, the auth logs of a server, the host's owner."),
                            ("Action", ("Containment (isolate, block, reset a password, escalate) once a check confirms the "
                                       "attack. These are the recommended actions of the ticket."))]),
                    ("p", ("Ticking a step keeps it on the incident with your name and the time, and adds a line to its "
                          "history. A step stays ticked while its evidence stays; new evidence brings new steps."))],
         "see": ["host", "priorities"]},
        {"id": "actions", "title": "Statuses and actions", "intro":
            "New, In progress (with an owner), Escalated, Seen, Closed (true positive, benign or false positive, with a "
            "reason).", "blocks": _actions(), "see": ["queue", "menu", "history"]},
        {"id": "menu", "title": "Right click and ⋯", "intro":
            "A right click on an address, a row or an alert line opens a menu with what you can do with it, as in Sycope, "
            "and only what works there. The ⋯ at the end of a row opens the same menu; Shift and a right click give the "
            "browser's own menu.",
         "blocks": [("fig", "menu"),
                    ("dl", [("an address", ("Quick look, a new tab, the search for it everywhere; its flows and alerts in Sycope "
                                           "for the time of the incident; for an outside address the lookups your admin set "
                                           "(VirusTotal, AbuseIPDB…); copy it.")),
                            ("a row", ("Quick look, a new tab; for a host Take, Assign, Escalate, Seen, Close and a note; its "
                                      "flows and alerts in Sycope; copy the link.")),
                            ("an alert line", "These alerts and the flows of the pair in Sycope; copy the alert name."),
                            ("Action ▾", "Above the queue: the same actions for the incidents you ticked.")])],
         "see": ["queue", "actions"]},
        {"id": "targets", "title": "Under attack", "intro":
            "Internal hosts that are the target of attacks, from the internet or from other internal hosts. A target is not "
            "a compromised host: it moves to the queue as a Host when it starts acting itself, or as a Target when it was "
            "attacked from outside and answered.",
         "blocks": [("fig", "targets")], "see": ["target", "external"]},
        {"id": "external", "title": "External", "intro":
            "Addresses outside your networks that touched your hosts, rated by threat lists and by what they did.",
         "blocks": [("fig", "external"),
                    ("p", ("An outside address on a shared cloud (Microsoft, Amazon, Cloudflare…) is only Suspicious even when "
                          "listed: lists carry stale cloud addresses. When the alerts carry no ASN, a shipped list of shared networks "
                          "(Cloudflare, Fastly, public DNS, Microsoft) does the same by address; an admin can add networks "
                          "(shared_infra_extra). The Check externally ▾ button (VirusTotal and the like) appears only "
                          "when the operator turned them on (SC_TI_PIVOTS), because each sends the address out."))],
         "see": ["targets"]},
        {"id": "tuning", "title": "Noise & tuning", "intro":
            "Where the noise is and what to do about it, without touching Sycope's rules.",
         "blocks": [("fig", "tuning"),
                    ("dl", [("Busy services", ("Accept one as a known service: its alerts stay in Sycope, their weight leaves "
                                              "the triage, with your name, a reason and an expiry.")),
                            ("Suggested by your team's closures", ("Where hosts keep being closed as false positive or benign "
                                                                  "for the same rule and server, the exception is offered.")),
                            ("Waiting for approval", ("When exceptions need an admin (SC_EXCEPTION_APPROVAL), analysts "
                                                     "propose and an admin approves or rejects.")),
                            ("Silence rules", ("One table for every exception: the alert name, source, destination, port, protocol and a time window "
                                             "of a rule as chips, how many alerts it took today, in 7 days and in total, its last hit, "
                                             "the hosts and 14 days as bars (click a count for the hit log, per hour, with sample alerts). "
                                             "Open an alert line on a host page and choose Silence to start one from it: tick the fields "
                                             "that must match, and the dialog shows what it would hide. A rule needs an alert name and "
                                             "a source, destination or port (a name alone: tune the rule in Sycope), a time window only "
                                             "with a source or destination, and ends within 90 days. A network wider than /24 (IPv6 /64) "
                                             "needs a second person. A rule that suddenly silences ten times its usual hour is reported "
                                             "in Health and the bell, and keeps silencing. The older service and host exceptions are "
                                             "rules in the same table. An exception is a "
                           "decision on the hosts whose evidence it covers: it ends the hold on them, and an open "
                           "incident whose evidence it covers entirely closes at once as Excepted and leaves the "
                           "SLA queue.")),
                            ("Who may add one", (f"A reason and an expiry ({_days_text()}; 30 is offered) are required. Until Sycope has "
                                                "confirmed who you are, what you add is only a proposal: a user Sycope has "
                                                "confirmed approves it (an admin when SC_EXCEPTION_APPROVAL is on), never the "
                                                "one who proposed it. Credential attack, exfiltration and C2 channel findings, "
                                                "every threat-list match (TOR, proxies and botnet domains too), whole-host "
                                                "exceptions and the rules that read as one of those when they cross the "
                                                "internet edge (LDAP, NFS or SMB going out) need two people Sycope has "
                                                "confirmed: an admin other than the one who proposes it approves it, whatever "
                                                "SC_EXCEPTION_APPROVAL says. One that would hide more than "
                                                f"{p['exception.big_alerts']:,.0f} alerts in the last 24 hours, or more than "
                                                f"{p['exception.big_hosts']:,.0f} hosts, needs an admin (the parameters "
                                                "exception.big_alerts and exception.big_hosts). The dialog shows those "
                                                "numbers; the service enforces them."))]),
                    ("fig", "dialog-exception")],
         "see": ["external", "hygiene"]},
        {"id": "hygiene", "title": "Hygiene", "intro":
            "Policy and hygiene findings: cleartext protocols, unauthorized services, ports outside the allowlist, asset "
            "changes. Worth fixing, never a threat on their own: they do not add to any verdict. Hygiene and policy findings "
            "never add threat weight; a rule that crosses the internet edge in a dangerous direction is reclassified "
            "and says so: LDAP going out is a credential attack, NFS and SMB going out are exfiltration (whatever the "
            "volume), and LDAP, NFS, SMB, a Docker daemon or RDP reached from the internet and answered is an exposed "
            "service, reviewed as a target. Inside your networks the same rules stay hygiene.",
         "blocks": [("fig", "hygiene")], "see": ["tuning"]},
        {"id": "configuration", "title": "Configuration (admins)", "intro":
        "For admins confirmed by Sycope. Change what the team may change: how the triage learns, which hosts are crown "
        "jewels, the exceptions, the numbers behind every verdict, the next steps of each incident and what each Sycope "
        "rule means. Analysts do not see this tab; they see the numbers a verdict used in its decision trace.",
     "blocks": [("fig", "config"),
                ("ol", ["Change something in a card. It shows as a row on the yellow bar.",
                        ("Preview and publish… asks what the change is for, then shows which incidents would change "
                         "verdict on today's data."),
                        ("Publish makes it a new version in the Versions card and scores the board again. Undo in the "
                         "toast goes back to the version before.")]),
                ("fig", "config-preview"),
                ("dl", [("Health", ("Which version is in force and whether it differs from the shipped setup, a "
                                   "configuration that failed to load, playbook edits whose step no longer exists, and "
                                   "suggestions waiting, and whether your browser's time zone differs from the calendar offset "
                                   "(the weekday learning). What Sycope sends, memory and polling are on the System page: "
                                   "there a field Sycope sends too rarely (under half the alerts), a netflow day with "
                                   "under 90 % of its hours, a time zone mismatch (an admin has a Use button that "
                                   "publishes the offset) or suggestions waiting over 7 days each raise a warning with "
                                   "what it costs; the card says Nothing needs attention only when there is none.")),
                        ("Profile", ("The numbers that steer how the triage learns what is normal, the addresses you "
                                    "declared as inside or outside your network, and suggestions waiting for your answer "
                                    "(accept or reject). Freeze keeps today's profile while learning goes on. A value "
                                    "that changes how the profile learns shows after the next learning, not in the "
                                    "preview.")),
                        ("Crown jewels", "Hosts and networks that weigh more. Add one, remove one with a reason, or accept a candidate."),
                        ("Silenced", "Every exception with filters. Tick the active ones to expire several at once."),
                        ("Scoring", ("The numbers behind every verdict, each next to the value the product ships with. "
                                    "Reset takes your value away.")),
                        ("Playbooks", "The steps of every incident: edit, hide, move or add your own, with a link into your tools."),
                        ("Rule catalog", ("What each alert rule means: family, class, stage. Rules the triage does not know "
                                         "wait to be classified.")),
                        ("Versions", ("Every published setup. View one, export it as a file for another instance, roll "
                                     "back, or import a file. An import goes through the same preview."))]),
                ("fig", "config-playbooks"),
                ("p", ("The orange <b>modified</b> mark in the top bar tells an admin that something differs from the "
                       "shipped setup.")),
                ("p", ("If no admin can sign in, whoever runs the service can place a configuration file in its state "
                       "directory: it is checked like an import at the next start and published as a version by "
                       "\"file\"."))],
     "see": ["tuning", "verdicts"]},
    {"id": "history", "title": "History", "intro":
            "Every incident the queue showed, kept as it was at its peak: the verdict and why, the evidence, what the team "
            "did and when. Each record is about an entity (an IP, a group, a network today; host names and users once those "
            "sources are connected).",
         "blocks": [("fig", "history"),
                    ("ul", [("The numbers count incidents as the queue does: a group inside a campaign is part of the campaign "
                            "(+N inside campaigns)."),
                            "Ended without action counts only Act now and Investigate: Review often needs none.",
                            ("Copy as handover: new incidents, what the team did, what is still open and who has it, what "
                            "ended unreviewed, notes. The period here when it is in hours, else since the team was last "
                            f"here: the last action before a pause of {p['shift_gap_h']:g} hours or more, so on Monday it "
                            f"covers the weekend (a team that never pauses gets the last {p['shift_h']:g} hours).")])],
         "see": ["record", "audit"]},
        {"id": "record", "title": "A record of the history", "intro":
            "One incident as it was: its peak, the evidence at that moment, the outcome and every event. Still open "
            "records keep the actions; Current state › opens it as it is now. A record that ended without a review can "
            "still be taken, escalated, marked seen or closed, and it has the next steps from its peak, which can be "
            "checked; they go into its history.",
         "blocks": [("fig", "record")], "see": ["history"]},
        {"id": "audit", "title": "Audit", "intro":
            "Every analyst action, kept in the state database of this service: who, what, on which host, when, with the "
            "note. A ✓ after a name means Sycope confirmed who that was; a name without it is what the browser said.",
         "blocks": [("fig", "audit")], "see": ["history", "actions"]},
        {"id": "episodes", "title": "Episodes", "intro":
            "The timeline of a host's activity: every stretch of alerts chained in time on one host (an episode), with "
            "when it began and ended, the kill-chain stages it reached and the alert types it holds. It is for reading "
            "how an activity unfolded. The verdict and the status of a host live in Triage: each row shows them and "
            "opens the Triage incident.",
         "blocks": [("dl", [("Host row", ("The host, its Triage verdict and status (No incident when Triage has none for "
                                        "it), how many episodes and alerts it has, and its latest alert. Open in Triage "
                                        "goes to its incident.")),
                            ("Episode", ("Start, end and duration, the stages it reached (filled when seen) and whether "
                                        "they came in the attack's order, and the alert types with how many alerts each.")),
                            ("Order", "By the Triage verdict (Act now first), then by the latest alert."),
                            ("Filters", ("The stage chips keep the hosts with an episode that reached one of the chosen "
                                        "stages; search matches an address, a name or an alert type."))]),
                    ("p", ("Nothing here is worked: take, close and note a host in Triage, where its handover and "
                           "history are."))],
         "see": ["queue", "host", "words"]},
        {"id": "search", "title": "Search", "intro":
            "The field in the top bar searches everything: the incidents now, every host with alerts (also by rule name), "
            "targets, outside addresses (also by network name) and the history.",
         "blocks": [("fig", "search")], "see": ["queue"]},
        {"id": "verdicts", "title": "Verdicts", "intro": "The decision table: how an incident gets its verdict.",
         "blocks": _decision(p), "see": ["words"]},
        {"id": "words", "title": "Words", "intro": "What the words on these pages mean.", "blocks": _words(p),
         "see": ["families", "verdicts"]},
        {"id": "families", "title": "Families and chain rules", "intro":
            "The kinds of behaviour the rules mean, and the orders of them that make an attack.", "blocks": _families(p),
         "see": ["words"]},
        {"id": "priorities", "title": "Ticket priorities", "intro":
            "Copy as ticket starts with a priority for IT:", "blocks": [
                ("table", ["Priority", "When"], [
                    ["<b>P1</b>", "Act now on a crown jewel, or Act now with " + _e(", ".join(ev.CHAINS[c][0]
                                                                                         for c in sorted(p["p1_chains"])))],
                    ["<b>P2</b>", "Act now; or Investigate on a crown jewel"], ["<b>P3</b>", "Investigate"],
                    ["<b>P4</b>", "Review"]])], "see": ["host", "steps"]},
        {"id": "webhook", "title": "Webhook and SLA", "intro":
            "Incident events sent to your ticketing or chat system, and the time limits the queue and the Security digest "
            "measure.", "blocks": _webhook(p), "see": ["queue", "actions", "priorities"]},
    ]


SECTIONS: list[dict] = sections()      # with the shipped numbers: titles, order and links
BY_ID = {s["id"]: s for s in SECTIONS}


# ---- rendering ------------------------------------------------------------------------------------------------------

def _fig(fid: str, img: str) -> str:
    f = FIGURES[fid]
    legend = "".join(f'<li><span class="hn">{n}</span><span><b>{_e(label)}</b> {_e(text)}</span></li>'
                     for n, _sel, label, text in f["marks"])
    return (f'<figure class="hf"><img src="{_e(img)}{_e(fid)}" alt="{_e(f["caption"])}" loading="lazy" '
            f'data-zoom="1"><figcaption>{_e(f["caption"])}</figcaption></figure><ol class="hlg">{legend}</ol>')


def render(sid: str, img: str = "helpimg?n=", p: Params | None = None, by: dict | None = None) -> str:
    """One part as HTML; `img` is the address prefix of the screenshots, `p` the parameters whose numbers it states
    (the board's; the shipped ones when none), `by` the sections of those parameters when the caller built them."""
    by = by or (BY_ID if p is None else {x["id"]: x for x in sections(p)})
    s = by[sid]
    out = [f'<p class="hin">{_e(s["intro"])}</p>']
    for b in s["blocks"]:
        kind = b[0]
        if kind == "p":
            out.append(f"<p>{b[1]}</p>")
        elif kind == "fig":
            out.append(_fig(b[1], img))
        elif kind == "h":
            out.append(f"<h3>{b[1]}</h3>")
        elif kind in ("ul", "ol"):
            out.append(f"<{kind}>" + "".join(f"<li>{x}</li>" for x in b[1]) + f"</{kind}>")
        elif kind == "dl":
            out.append('<dl class="hdl">' + "".join(f"<dt>{_e(t)}</dt><dd>{d}</dd>" for t, d in b[1]) + "</dl>")
        elif kind == "table":
            out.append('<table class="htb"><tr>' + "".join(f"<th>{_e(h)}</th>" for h in b[1]) + "</tr>"
                       + "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in b[2]) + "</table>")
    if s.get("see"):
        out.append('<p class="hsee">See also: ' + " · ".join(
            f'<a href="help#{_e(x)}" data-help="{_e(x)}">{_e(BY_ID[x]["title"])}</a>' for x in s["see"]) + "</p>")
    return "".join(out)


def all_parts(img: str = "helpimg?n=", p: Params | None = None) -> dict:
    secs = SECTIONS if p is None else sections(p)
    by = {s["id"]: s for s in secs}
    return {"order": [s["id"] for s in secs],
            "parts": {s["id"]: {"title": s["title"], "html": render(s["id"], img, p, by)} for s in secs}}
