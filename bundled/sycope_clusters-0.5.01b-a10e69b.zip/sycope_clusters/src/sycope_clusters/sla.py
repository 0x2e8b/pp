"""SLA of an incident (W-6) and the trends of the Digest (S-8).

The SLA belongs to an incident's peak verdict (Act now keeps its clock while the hysteresis holds the host at
Investigate). The clock starts at the first event of the record at that verdict (opened or escalated); the ack is the
first analyst action after it (any status, seen included, or a note); handled is a close with an outcome (true positive,
benign, false positive, resolved) or an escalation. Review has no SLA. Everything is computed from the stored record and
the board's `now`: the same records give the same numbers, and nothing here writes.

Parameters (params.py, editable in the configuration plane): sla.act.ack_min, sla.act.handle_h, sla.investigate.ack_h,
sla.investigate.handle_h, sla.unowned_min.
"""

from __future__ import annotations

import statistics
from datetime import UTC, datetime, timedelta

from sycope_clusters.params import FACTORY, Params

# events an analyst writes (the system's own are opened/escalated/closed): a status, a note, a next step checked
ACK_KINDS = ("handled", "note", "step")
HANDLED = ("tp", "benign", "fp", "resolved", "escalated", "excepted")    # "seen" is an ack, not handling; "excepted": an
# exception took all the evidence (history._close)
OWNED = ("investigating", "escalated", "tp", "benign", "fp", "resolved")    # someone has it or has closed it
COVERING = ("ack", "tp", "benign", "fp", "resolved")   # out of the queue while it still covers the evidence
VERDICTS = ("act", "investigate")
DAY = 86400.0


def limits(verdict: str, p: Params = FACTORY) -> dict | None:
    """{"ack": seconds, "handle": seconds} for a verdict that has an SLA, else None (Review, Watch)."""
    if verdict == "act":
        return {"ack": p["sla.act.ack_min"] * 60.0, "handle": p["sla.act.handle_h"] * 3600.0}
    if verdict == "investigate":
        return {"ack": p["sla.investigate.ack_h"] * 3600.0, "handle": p["sla.investigate.handle_h"] * 3600.0}
    return None


def start_of(o: dict) -> float:
    """When the incident first showed its peak verdict: the time the record stored when the peak last rose (`peak_at`,
    written since 1.2, immune to the cap on events); an older record: its earliest event at that verdict; none left
    (trimmed): its opening."""
    if o.get("peak_at") is not None:
        return float(o["peak_at"])
    peak = o.get("verdict_peak")
    at = [e["at"] for e in o.get("events") or ()
          if e.get("kind") in ("opened", "escalated", "de-escalated") and e.get("verdict") == peak and e.get("at") is not None]
    return float(min(at)) if at else float(o["opened_at"])


def clock_of(o: dict) -> float:
    """When the SLA clock of the incident's current period started: the peak verdict reached (`start_of`), or the last
    time an analyst's status was lifted by new evidence (a reopen restarts the clock: what was done before it does not
    count for the reopened period). The reopen time is the record's `reopened_at`, else its latest `reopened` event."""
    start = start_of(o)
    at = o.get("reopened_at")
    if at is None:
        at = max((e["at"] for e in o.get("events") or () if e.get("kind") == "reopened" and e.get("at") is not None),
                 default=None)
    return max(start, float(at)) if at is not None else start


def _times(o: dict, start: float) -> tuple[float | None, float | None, bool, bool]:
    """(first analyst action, handled, ack carried over, handled carried over) at or after the clock start. An event
    written before outcomes were recorded in events has no `outcome`: the record's own outcome stands in for it. A status
    set before the clock started is "carried over": it counts as met at the start but is no sample of how fast anyone
    was (the Digest's MTTA/MTTR leave it out)."""
    events = [e for e in (o.get("events") or ()) if e.get("at") is not None and e["at"] >= start]
    ack = min((e["at"] for e in events if e.get("kind") in ACK_KINDS), default=None)
    done = min((e["at"] for e in events if e.get("kind") == "handled" and e.get("outcome") in HANDLED), default=None)
    out, at = o.get("outcome"), o.get("outcome_at")
    ack_c = done_c = False
    if out and out not in ("expired", "merged") and at is not None:
        # the record's own state stands in for an event that is missing; one set before the clock started (the host
        # was handled, left, came back unchanged) still covers the evidence, so it is met from the start
        cur = max(at, start)
        if done is None and out in HANDLED:
            done, done_c = cur, at < start
        if ack is None:
            ack, ack_c = cur, at < start
    if done is not None and (ack is None or done < ack):
        ack, ack_c = done, done_c
    return (float(ack) if ack is not None else None), (float(done) if done is not None else None), ack_c, done_c


def assess(o: dict, p: Params, now: float) -> dict | None:
    """One incident record against its SLA: None when its peak verdict has none. Keys: verdict, start, ack/handle
    ({due, at, breached, late_s, limit}), next ("ack" | "handle" | None: the deadline still open, only for an open
    incident), due, remaining (seconds to it, negative = overdue), breached (the open deadline has passed), limit, owned,
    unowned_due."""
    lim = limits(o.get("verdict_peak"), p)
    if lim is None:
        return None
    start = clock_of(o)
    ack_at, done_at, ack_c, done_c = _times(o, start)
    # an incident that ended without an analyst never counts the time after it ended as waiting
    end = now if o["status"] == "open" else float(o.get("closed_at") or o.get("last_seen") or now)
    out: dict = {"verdict": o["verdict_peak"], "start": start}
    for kind, at, carried in (("ack", ack_at, ack_c), ("handle", done_at, done_c)):
        due = start + lim[kind]
        stop = at if at is not None else end
        out[kind] = {"due": due, "at": at, "breached": stop > due, "late_s": max(0.0, stop - due), "limit": lim[kind],
                     "inherited": carried}
    # a status that still covers the evidence (seen, closed) takes it out of the queue: no timer, no breach
    out["in_queue"] = not (o["status"] == "open" and o.get("outcome") in COVERING)
    if not out["in_queue"]:
        for k in ("ack", "handle"):
            out[k]["breached"] = out[k]["breached"] and out[k]["at"] is not None
            out[k]["late_s"] = out[k]["late_s"] if out[k]["breached"] else 0.0
    nxt = "ack" if ack_at is None else "handle" if done_at is None else None
    out["next"] = nxt if o["status"] == "open" and out["in_queue"] else None
    due = out[out["next"]]["due"] if out["next"] else None
    out["due"], out["remaining"] = due, (due - now if due is not None else None)
    out["breached"] = bool(out["next"] and out["remaining"] < 0)
    out["limit"] = lim[out["next"]] if out["next"] else None
    out["owned"] = o.get("outcome") in OWNED
    out["unowned_due"] = start + p["sla.unowned_min"] * 60.0 if o["verdict_peak"] == "act" else None
    return out


def queue_map(rows: list[dict], p: Params, now: float) -> dict[str, dict]:
    """ui_key -> what the queue column shows, for the open incidents (hosts, groups, campaigns) with an SLA."""
    out = {}
    for o in rows:
        if o["status"] != "open" or not o.get("ui_key"):
            continue
        a = assess(o, p, now)
        if a is None:
            continue
        out[o["ui_key"]] = {"id": o["id"], "verdict": a["verdict"], "next": a["next"], "due": a["due"],
                            "limit": a["limit"], "start": a["start"], "breached": a["breached"],
                            "ack_breached": a["ack"]["breached"], "handle_breached": a["handle"]["breached"]}
    return out


def due_events(rows: list[dict], p: Params, now: float) -> list[dict]:
    """What the webhook may fire now for the open incidents: an SLA deadline passed unmet (`sla.breached`, one per
    kind) and an Act now incident with nobody on it after sla.unowned_min (`actnow.unowned`). The caller keeps which of
    them it has already sent."""
    out = []
    for o in rows:
        if o["status"] != "open":
            continue
        a = assess(o, p, now)
        if a is None or not a["in_queue"]:
            continue
        for kind in ("ack", "handle"):
            k = a[kind]
            if k["at"] is None and now > k["due"]:
                out.append({"event": "sla.breached", "key": f"{o['id']}:{kind}:{int(a['start'])}", "incident": o, "sla": kind,
                            "due": k["due"], "limit_s": k["limit"], "overdue_s": now - k["due"], "start": a["start"]})
        if a["unowned_due"] is not None and not a["owned"] and now >= a["unowned_due"]:
            out.append({"event": "actnow.unowned", "key": f"{o['id']}:unowned:{int(a['start'])}", "incident": o, "due": a["unowned_due"],
                        "limit_s": p["sla.unowned_min"] * 60.0, "overdue_s": now - a["unowned_due"],
                        "start": a["start"]})
    return out


# ---- the Digest (S-8) --------------------------------------------------------------------------------------------

def _median(xs: list[float]) -> float | None:
    return statistics.median(xs) if xs else None


def trends(rows: list[dict], p: Params, now: float, offset_min: int = 0, days: int = 7) -> dict:
    """Week over week, MTTA/MTTR, SLA breaches and Act now per day, from the records of the last two weeks (top-level
    incidents). `week`/`prev`: incidents opened in the last 7 days / the 7 days before, per peak verdict. MTTA/MTTR:
    median seconds from the clock start to the first action / to handled, over the incidents whose ack / handled
    happened in the last 7 days, per verdict. `breaches_24h`/`breaches_7d`: SLA deadlines that passed unmet (or were
    met late) with the deadline inside the last 24 h / 7 d, per verdict. `act_per_day`: Act now incidents opened per
    local day (the configured offset), oldest first."""
    w0, w1 = now - days * DAY, now - 2 * days * DAY
    verdicts = ("act", "investigate", "review")
    week = dict.fromkeys(verdicts, 0)
    prev = dict.fromkeys(verdicts, 0)
    mtta: dict[str, list[float]] = {v: [] for v in VERDICTS}
    mttr: dict[str, list[float]] = {v: [] for v in VERDICTS}
    br24 = dict.fromkeys(VERDICTS, 0)
    br7 = dict.fromkeys(VERDICTS, 0)
    for o in rows:
        v = o.get("verdict_peak")
        if v in week:
            if o["opened_at"] >= w0:
                week[v] += 1
            elif o["opened_at"] >= w1:
                prev[v] += 1
        a = assess(o, p, now)
        if a is None:
            continue
        ack, done = a["ack"], a["handle"]
        if ack["at"] is not None and ack["at"] >= w0 and not ack["inherited"]:
            mtta[v].append(ack["at"] - a["start"])
        if done["at"] is not None and done["at"] >= w0 and not done["inherited"]:
            mttr[v].append(done["at"] - a["start"])
        for k in (ack, done):
            if k["breached"] and k["due"] <= now:
                br7[v] += int(k["due"] >= w0)
                br24[v] += int(k["due"] >= now - DAY)
    off = timedelta(minutes=offset_min)
    today = (datetime.fromtimestamp(now, UTC) + off).date()
    per_day = {(today - timedelta(days=k)).isoformat(): 0 for k in range(days - 1, -1, -1)}
    for o in rows:
        if o.get("verdict_peak") == "act":
            d = (datetime.fromtimestamp(start_of(o), UTC) + off).date().isoformat()
            if d in per_day:
                per_day[d] += 1
    return {"week": week, "prev": prev, "mtta": {v: _median(x) for v, x in mtta.items()},
            "mttr": {v: _median(x) for v, x in mttr.items()}, "mtta_n": {v: len(x) for v, x in mtta.items()},
            "mttr_n": {v: len(x) for v, x in mttr.items()}, "breaches_24h": br24, "breaches_7d": br7,
            "act_per_day": [[d, n] for d, n in per_day.items()]}
