"""The administrator's side (spec 7, D44): the data of the Configuration pages and the ops that change the
configuration. Every route and op here is for a Sycope-confirmed admin only; app.py checks the pass before it calls in.

Reads (GET routes of app.py) are functions returning plain JSON data. Writes are ops of POST /action: `act(live, body)`
runs one. An op that changes what the board is scored with publishes a configuration version, takes it into use
(`Live.reload_config`) and asks for a rescore, all inside the request; the audit line of the activation carries the
new version. `replay` re-scores a stored day with a recorded configuration version and profile snapshot, read-only.
"""

from __future__ import annotations

import ipaddress
import json
import re
import time
from datetime import datetime

from sycope_clusters import attack_map, crown, evidence, ingest, params, playbook, rules, triage
from sycope_clusters import confplane as cfg
from sycope_clusters import profile as prof_mod
from sycope_clusters.addresses import AddressBook
from sycope_clusters.params import Params, env_layer

NEEDS_ADMIN = "needs a Sycope-confirmed admin"
PROFILE_PREFIXES = ("profile.", "calendar.")     # the parameters that shape what the profile learns
TERMS = ("exfil_volume", "shared_cloud", "same_host")
SCANNER_DAYS = 90
MAX_IDS = 500
_DAY = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class NotFound(Exception):
    """The thing asked for is not stored (a 404 for the route)."""


def jsonable(v):
    """Sets, tuples and frozensets as lists (sorted for sets), so a parameter value can go out as JSON."""
    if isinstance(v, (set, frozenset)):
        return sorted(jsonable(x) for x in v)
    if isinstance(v, (list, tuple)):
        return [jsonable(x) for x in v]
    if isinstance(v, dict):
        return {str(k): jsonable(x) for k, x in v.items()}
    return v


# ---- reads -----------------------------------------------------------------------------------------------------

def _type(factory) -> str:
    """How a value is typed in the registry: "int" (whole numbers only), "float" or "list"."""
    if isinstance(factory, (tuple, list, set, frozenset)):
        return "list"
    return "int" if isinstance(factory, int) and not isinstance(factory, bool) else "float"


def registry(live) -> list[dict]:
    """Every parameter with its factory value, bounds, help, and the value in force with where it comes from."""
    p = live.scoring_params()
    out = []
    for pid in sorted(params.REGISTRY):
        r, v = params.REGISTRY[pid], p.explain(pid)
        out.append({"id": pid, "type": _type(r.factory), "factory": jsonable(r.factory), "lo": r.lo, "hi": r.hi,
                    "unit": r.unit,
                    "help": r.help, "learnable": r.learnable, "scope": r.scope, "value": jsonable(v.value),
                    "source": v.source, "n": v.n, "conf": v.conf, "note": v.note})
    return out


def playbook_view(live) -> dict:
    """What the Playbooks editor needs besides the stored overlay: the factory steps (id, kind, the pattern text with
    its {placeholders}, the hash an edit records), the chain rules and families an own step can be bound to, and the
    overlay's warnings (an edit that names a step this release does not have)."""
    _, body = live.confplane.active()
    tpl = [{"id": t, "group": t.split(".")[0], "kind": k, "title": title, "why": why, "hash": playbook.FACTORY_HASH[t],
            "also": list(playbook.SHARED_STEPS.get(t, ()))}
           for t, (k, title, why) in playbook.TEMPLATES.items()]
    # the groups of the editor in id order: chain rules (CR-01 ... CR-10), then families, then the other groups
    tpl.sort(key=lambda t: (0, t["group"]) if t["group"].startswith("CR-") else
             (1, t["group"]) if t["group"].startswith("CL-") else (2, ""))
    return {"templates": tpl, "kinds": list(playbook.KINDS), "placeholders": list(playbook.PLACEHOLDERS),
            "chains": [{"id": c, "title": v[0]} for c, v in evidence.CHAINS.items()],
            "families": [{"id": k, "title": v[0]} for k, v in rules.FAMILIES.items() if k != "UNK"],
            "warnings": playbook.overlay_warnings(cfg.normalize(body)["playbook"])}


def config_view(live) -> dict:
    vid, body = live.confplane.active()
    return {"active": vid, "body": cfg.normalize(body), "versions": live.confplane.versions(200),
            "registry": registry(live), "modified": live.params.modified(), "error": live.config_error,
            "in_use": live.config_version, "playbook": playbook_view(live)}


def profile_history(live, pid: str) -> list[dict]:
    """The value of a learned parameter in each daily profile snapshot, oldest first: [{day, value}]."""
    r = params.REGISTRY.get(pid)
    if r is None:
        raise NotFound(f"unknown parameter {pid!r}")
    return [{"day": d, "value": jsonable(v)} for d, v in live.store.profile_values(pid)]


def exceptions_view(live) -> dict:
    """Every exception (active, pending, expired, removed) and the read-only ones of the Sycope lookup, each with its
    state, for the Silenced editor."""
    now = time.time()
    rows = []
    for e in [*live.store.exceptions(active_only=False), *live.silenced_rows()]:
        # an exception is in force only when it is active: a rejected one (not pending, not active, never removed)
        # is its own state
        state = ("lookup" if e.get("source") else "pending" if e["pending"] else
                 "removed" if not e["active"] and e.get("removed_at") else
                 "rejected" if not e["active"] else
                 "expired" if e["expired"] or (e["expires"] and e["expires"] < now) else "active")
        rows.append({**e, "state": state})
    return {"rows": rows, "now": now, "approval": live.settings.exception_approval}


def version(live, vid: int) -> dict:
    row = live.store.config(vid)
    if row is None:
        raise NotFound(f"there is no configuration version {vid}")
    return {**row, "active": live.store.active_config_id() == vid}


def export(live, vid: int) -> dict:
    if live.store.config(vid) is None:
        raise NotFound(f"there is no configuration version {vid}")
    return live.confplane.export(vid)


def preview(live, vid: int) -> dict:
    row = live.store.config(vid)
    if row is None:
        raise NotFound(f"there is no configuration version {vid}")
    return live.preview_config(row["body"])


def profile_view(live) -> dict:
    prof, store = live.profile, live.store
    p = live.scoring_params()
    admin = (live.config.get("params") or {})
    learned = []
    for pid in sorted(params.REGISTRY):
        r = params.REGISTRY[pid]
        if not (r.learnable or pid.startswith(PROFILE_PREFIXES)):
            continue
        v = p.explain(pid)
        learned.append({"id": pid, "value": jsonable(v.value), "source": v.source, "n": v.n, "conf": v.conf,
                        "note": v.note, "factory": jsonable(r.factory), "lo": r.lo, "hi": r.hi, "unit": r.unit,
                        "help": r.help, "override": jsonable(admin[pid]) if pid in admin else None})
    answers = store.answers()
    sug = prof_mod.waiting(prof.suggestions, answers) if prof is not None else []
    return {"profile_day": prof.day if prof is not None else None,
            "frozen": store.meta("profile_frozen") == "1" or bool(prof is not None and prof.frozen),
            "rhythm": prof.rhythm if prof is not None else None, "learned": learned,
            "suggestions": [dict(s) for s in sug],
            "answers": [{"key": k, **a} for k, a in sorted(answers.items())],
            "internal": dict(live.config.get("internal") or {}),
            "confirmed": dict(prof.confirmed) if prof is not None else {},
            "days": list(prof.days) if prof is not None else []}


def crown_view(live) -> dict:
    book = live._nets()
    eff = crown.effective(live.store, book)
    cand = crown.candidates(live.profile, book, live.store) if live.profile is not None else []
    return {"effective": [{"entity": k, "source": v} for k, v in eff.items()], "rows": live.store.crown_rows(),
            "candidates": cand}


def catalog_view(live) -> dict:
    return {"rules": live.catalog.rows(), "unknown": live.catalog.unknown_rows(),
            "families": {k: list(v) for k, v in rules.FAMILIES.items()}, "live_ids": live.catalog.live_ids(),
            "tactics": list(attack_map.TACTICS)}


# ---- replay ----------------------------------------------------------------------------------------------------

def _bucket(row: tuple) -> tuple:
    """A stored day row as an hourly bucket of ingest.py (what evidence.build reads)."""
    rule, client, server, port, n, first, last, up, down = row[1:10]
    sev, thr, asn, targets, rid = (list(row[10:15]) + [None] * 5)[:5]
    v: list = [None] * len(ingest.BUCKET_FIELDS)
    ix = ingest.BI
    tl = json.loads(targets) if targets else []
    v[ix["timestamp"]] = last
    v[ix["alertName"]], v[ix["alertRuleId"]] = rule, rid
    v[ix["alertSeverity"]] = evidence.SEV_NAME.get(sev)
    v[ix["alertFlagThresholdLevel"]] = evidence.THR_NAME.get(thr)
    v[ix["clientIp"]], v[ix["serverIp"]] = client or None, server or None
    v[ix["serverPort"]] = port or None
    v[ix["sumClientBytes"]], v[ix["sumServerBytes"]] = up or 0, down or 0
    v[ix["serverAsName"]] = v[ix["clientAsName"]] = asn
    v[ix["serverIps"]] = ", ".join(tl) or None
    v[ix["_uniqueServerIps"]] = len(tl) or None
    v[ix["_n"]], v[ix["_first"]], v[ix["_last"]] = n, first, last
    return tuple(v)


def _exceptions_at(live, t: float) -> list[dict]:
    """The stored exceptions that were in force at time t (approved, not yet expired or removed)."""
    out = []
    for e in live.store.exceptions(active_only=False):
        start = e.get("decided_at") or e["created"]
        if e["pending"] or start > t or (e["expires"] and e["expires"] <= t):
            continue
        if not e["active"] and not (e["removed_at"] and e["removed_at"] > t):
            continue
        out.append(e)
    return out


def replay(live, day: str, config: int | None = None, profile: str | None = None, off: str = "") -> dict:
    """The board of a stored day scored again with a configuration version (default: the active one) and the profile
    snapshot of a day (default: that day's). Nothing is written and the live state is not touched. The terms missing
    fields turned off on that day are not stored: `off` names the ones to switch off (default none)."""
    from sycope_clusters import live as live_mod
    if not _DAY.match(day or "") or not _real_day(day):
        raise ValueError("day must be a UTC day as YYYY-MM-DD")
    terms = [t for t in (x.strip() for x in off.split(",")) if t]
    if bad := [t for t in terms if t not in TERMS]:
        raise ValueError(f"off names unknown terms: {', '.join(bad)} (known: {', '.join(TERMS)})")
    store = live.store
    stored = store.days()
    n_rows = (stored.get(day) or {}).get("findings") or 0
    if not n_rows:
        raise NotFound(f"no findings are stored for {day}")
    if config is None:
        vid, body = live.confplane.active()
    else:
        row = store.config(config)
        if row is None:
            raise NotFound(f"there is no configuration version {config}")
        vid, body = config, row["body"]
    body = cfg.migrate(body)
    pday = profile or day
    snap = store.profile(pday)
    later = None
    if snap is None and profile is None:   # a day stored before v1.0 has none: the first one learned after it
        later = next((d for d, _ in store.profile_days() if d > day), None)
        snap = store.profile(later) if later else None
        pday = later or pday
    if snap is None:
        raise NotFound(f"no profile snapshot is stored for {pday} (name another day with profile=YYYY-MM-DD)")
    prof = prof_mod.from_json(snap)
    days = sorted(d for d, v in stored.items() if d < day and (v["alerts"] or 0) > 0)[-live_mod.KEEP_DAYS:]
    wanted = evidence.History.wanted(days, day, prof.calendar)
    # the day's rows as buckets and its board, and a History of the days before it (shared with previews)
    with live.preview_slot(n_rows * (live_mod.ROW_B + live_mod.FINDING_B) + live._hist_bytes(wanted)):
        rows = store.day_rows([day])
        if not rows:
            raise NotFound(f"no findings are stored for {day}")
        p = Params(env=env_layer(live.settings), learned=prof.values, admin=body.get("params"))
        cat = live._catalog(body)
        book_snap = dict(prof.book or {})
        book_snap["admin_internal"] = dict(body.get("internal") or {})
        book = AddressBook.from_snapshot(book_snap)
        now = live_mod.datetime_end(day)
        hist = evidence.History(store.iter_day_rows(wanted), days, day, cat, book, p, profile=prof,
                                priors=live.priors)
        crit = crown.CrownSet(crown.effective(store, book, at=now), book)
        board = evidence.build([_bucket(r) for r in rows], now, cat, hist, exceptions=_exceptions_at(live, now),
                               crown=crit, nets=book, window_s=86400, params=p, profile=prof, priors=live.priors,
                               disabled=frozenset(terms))
        counts: dict[str, int] = {}
        for e in board.entities.values():
            counts[e.verdict] = counts.get(e.verdict, 0) + 1
        top = sorted(board.entities.values(), key=lambda e: (-evidence.VRANK[e.verdict], -e.conf, e.ip))[:25]
        partial = sum(1 for r in rows if len(r) < 15 or r[10] is None)
        notes = ["The environment (SC_*) layer and the priors are today's, not the day's.",
                 "The terms Sycope's missing fields turned off on that day are not stored: the replay scored with "
                 + (", ".join(terms) if terms else "every term on") + "."]
        if later:
            notes.append(f"No profile snapshot is stored for {day} (it was stored before v1.0): the replay used the "
                         f"first one learned after it, {later}.")
        if partial:
            notes.append(f"{partial} stored rows have no severity, threshold or target list (stored before v1.0, or a "
                         "big day backfilled as Sycope's aggregate): they count as unknown.")
        return {"day": day, "config_version": vid, "profile_day": pday, "rows": len(rows),
                "alerts": board.alerts, "counts": dict(sorted(counts.items(), key=lambda kv: -evidence.VRANK[kv[0]])),
                "top": [{"ip": e.ip, "verdict": e.verdict, "conf": round(e.conf, 4), "headline": e.headline,
                         "reason": e.reason, "stage": e.confirmed} for e in top],
                "campaigns": len(board.campaigns), "stories": len(board.stories), "partial_rows": partial,
                "disabled": {"used": terms, "stored": False, "now": [t["term"] for t in live.disabled]}, "notes": notes}


def _real_day(day: str) -> bool:
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        return False
    return True


# ---- ops -------------------------------------------------------------------------------------------------------

def _int(v, what: str) -> int:
    if isinstance(v, bool) or not isinstance(v, int):
        raise triage.ActionError(f"{what} must be a number")
    return v


def _text(v, n: int) -> str:
    return triage._clean_text(v, n)


def _ip(v) -> str:
    try:
        return str(ipaddress.ip_address(str(v or "").strip()))
    except ValueError:
        raise triage.ActionError("ip must be an IP address") from None


def _applied(live) -> None:
    live.reload_config()
    live.rescore_async()


def _publish(live, who: str, mutate, note: str) -> int:
    """Draft and publish a copy of the active body changed by `mutate(body)`, one step, then take it into use."""
    with live._cfg_lock:
        _, active = live.confplane.active()
        body = json.loads(json.dumps(cfg.normalize(cfg.migrate(active))))
        mutate(body)
        vid = live.confplane.draft(body, who, note)
        live.confplane.publish(vid, who)
        live.reload_config()
    live.rescore_async()
    return vid


def _config_draft(live, body: dict, who: str) -> dict:
    data = body.get("body")
    if not isinstance(data, dict):
        raise triage.ActionError("body must be a configuration object")
    return {"id": live.confplane.draft(data, who, _text(body.get("note"), 300))}


def _config_publish(live, body: dict, who: str) -> dict:
    vid = _int(body.get("id"), "id")
    with live._cfg_lock:
        live.confplane.publish(vid, who)
        live.reload_config()
    live.rescore_async()
    return {"id": vid, "version": vid}


def _config_rollback(live, body: dict, who: str) -> dict:
    vid = _int(body.get("id"), "id")
    with live._cfg_lock:
        new = live.confplane.rollback(vid, who)
        live.reload_config()
    live.rescore_async()
    return {"id": new, "version": new, "from": vid}


def _config_import(live, body: dict, who: str) -> dict:
    data = body.get("data")
    if not isinstance(data, dict):
        raise triage.ActionError("data must be an exported configuration object")
    return {"id": live.confplane.import_(data, who)}


def _exception_expire(live, body: dict, who: str) -> dict:
    ids = body.get("ids")
    if not isinstance(ids, list) or not ids or len(ids) > MAX_IDS:
        raise triage.ActionError(f"ids must be a list of 1 to {MAX_IDS} exception numbers")
    ids = [_int(i, "each id") for i in ids]
    note = _text(body.get("note"), 500)
    done, missing = [], []
    for ex_id in dict.fromkeys(ids):
        if live.store.remove_exception(ex_id, who):
            live.store.log(who, "exception:remove", str(ex_id), note, {"id": ex_id, "bulk": True})
            done.append(ex_id)
        else:
            missing.append(ex_id)
    if done:
        live.rescore_async()
    return {"expired": done, "missing": missing}


def _profile_override(live, body: dict, who: str) -> dict:
    pid, value = body.get("pid"), body.get("value")
    r = params.REGISTRY.get(pid) if isinstance(pid, str) else None
    if r is None:
        raise triage.ActionError(f"unknown parameter {pid!r}")
    if not (r.learnable or pid.startswith(PROFILE_PREFIXES)):
        raise triage.ActionError(f"{pid} is not a profile value: change it in the scoring editor")

    def mutate(b: dict) -> None:
        if value is None:
            b["params"].pop(pid, None)
        else:
            b["params"][pid] = value
    vid = _publish(live, who, mutate, f"profile override {pid}")
    live.store.log(who, "profile:override", pid, "", {"value": value, "version": vid}, stamp=(vid, live.store.stamp[1]))
    return {"version": vid}


def _profile_internal(live, body: dict, who: str) -> dict:
    ip, flag = _ip(body.get("ip")), body.get("internal")
    if flag is not None and not isinstance(flag, bool):
        raise triage.ActionError("internal must be true, false or null")

    def mutate(b: dict) -> None:
        if flag is None:
            b["internal"].pop(ip, None)
        else:
            b["internal"][ip] = flag
    vid = _publish(live, who, mutate, f"profile internal {ip}")
    live.store.log(who, "profile:internal", ip, "", {"internal": flag, "version": vid},
                   stamp=(vid, live.store.stamp[1]))
    return {"version": vid}


def _profile_freeze(live, body: dict, who: str) -> dict:
    frozen = body.get("frozen")
    if not isinstance(frozen, bool):
        raise triage.ActionError("frozen must be true or false")
    day = live.freeze_profile(frozen, who)
    if frozen and day is None:
        raise triage.ActionError("there is no learned profile to freeze yet")
    live.rescore_async()
    return {"day": day, "frozen": frozen}


def _crown_add(live, body: dict, who: str) -> dict:
    reason = _text(body.get("reason"), 300)
    if not reason:
        raise triage.ActionError("say why (the reason is kept in the audit log)")
    ent = crown.add(live.store, str(body.get("entity") or ""), who, reason)
    live.rescore_async()
    return {"entity": ent}


def _crown_remove(live, body: dict, who: str) -> dict:
    ent = crown.canonical(str(body.get("entity") or ""))
    reason = _text(body.get("reason"), 300)
    if not reason:
        raise triage.ActionError("say why (the reason is kept in the audit log)")
    if not crown.remove(live.store, ent, who, reason):
        raise triage.ActionError("that entity is not a crown jewel")
    live.rescore_async()
    return {"entity": ent}


def _scanner_exceptions(live, ip: str, who: str) -> list[int]:
    """The audited host-rule exceptions of a confirmed scanner: one per scan rule of the Scanning cluster, through
    the exception path of the analysts (reason "confirmed scanner"), skipping those already in force."""
    have = {e["rule"] for e in live.store.exceptions() if e["kind"] == "host-rule" and e["actor"] == ip}
    ids = []
    for name in sorted(n for n, r in live.catalog.rules.items() if r.family == "CL-04" and r.kind == "scan"):
        if name in have:
            continue
        ans = triage.act({"op": "exception-add", "kind": "host-rule", "rule": name, "actor": ip,
                          "reason": "confirmed scanner", "days": SCANNER_DAYS, "who": who, "admin": True},
                         live.board, live.store, live.catalog, approval=live.settings.exception_approval)
        ids.append(ans["id"])
    return ids


def _suggestion_answer(live, body: dict, who: str) -> dict:
    key, answer = str(body.get("key") or ""), body.get("answer")
    try:
        crown.answer(live.store, key, answer, who, _text(body.get("reason"), 300))
    except ValueError as exc:
        raise triage.ActionError(str(exc)) from None
    kind, role, subject = prof_mod.parse_key(key)
    out: dict = {"key": key, "answer": answer}
    if answer == "accept" and kind == "internal-ip":
        if live.config.get("internal", {}).get(subject) is not True:
            out["version"] = _publish(live, who, lambda b: b["internal"].__setitem__(subject, True),
                                      f"accepted: {subject} is internal")
    elif answer == "accept" and kind == "role" and role == "scanner":
        out["exceptions"] = _scanner_exceptions(live, subject, who)
    live.rescore_async()
    return out


def _catalog_set(live, body: dict, who: str) -> dict:
    key, entry = body.get("key"), body.get("entry")
    if not isinstance(key, str) or not key.strip() or len(key) > 120:
        raise triage.ActionError("key must be a rule name or template id")
    if entry is not None and (not isinstance(entry, dict) or not entry):
        raise triage.ActionError("entry must be an object of rule fields, or null to remove the entry")
    key = key.strip()

    def mutate(b: dict) -> None:
        if entry is None:
            b["catalog"].pop(key, None)
        else:
            b["catalog"][key] = entry
    vid = _publish(live, who, mutate, f"catalog {key}")
    live.store.log(who, "catalog:set", key, "", {"entry": entry, "version": vid}, stamp=(vid, live.store.stamp[1]))
    return {"version": vid}


_OPS = {"config:draft": _config_draft, "config:publish": _config_publish, "config:rollback": _config_rollback,
        "config:import": _config_import, "exception:expire": _exception_expire,
        "profile:override": _profile_override, "profile:internal": _profile_internal,
        "profile:freeze": _profile_freeze, "crown:add": _crown_add, "crown:remove": _crown_remove,
        "suggestion:answer": _suggestion_answer, "catalog:set": _catalog_set}
OPS = frozenset(_OPS)


def act(live, body: dict) -> dict:
    """Run one admin op (the caller checked the pass). Raises triage.ActionError or cfg.ConfigError for the page."""
    op = body.get("op")
    who = _text(body.get("who"), 40) or "admin"
    return {"ok": True, "op": op, **_OPS[op](live, body, who)}
