"""The outbound webhook (W-6): incident events as JSON POSTs to SC_WEBHOOK_URL.

    incident.new      a top-level incident first shows Investigate or Act now
    incident.raised   an incident rises above the peak it showed (Investigate -> Act now), or comes back after an analyst
                      handled it (transition: escalated | reopened)
    incident.status   an analyst took, escalated, marked seen or closed an incident (status: taken | escalated | seen |
                      closed, who, owner, outcome)
    sla.breached      an SLA deadline passed with nobody having acted (sla: ack | handle), once per incident and kind
    actnow.unowned    an Act now incident nobody has taken or escalated after sla.unowned_min, once per incident

A hold (the verdict kept above the evidence), a fall in verdict and an incident leaving the board never send anything:
they are the absence of a rise.

Delivery never blocks a poll or a click: `emit` puts the event on a bounded queue and one daemon thread sends it. When the
queue is full the oldest event is dropped and Health says so. A failed delivery is retried RETRIES times with a growing
pause (not for a 4xx answer other than 408 and 429, which a retry cannot fix); the final failure goes to the audit log
(event, incident, HTTP status or error: never the body, the URL or the secret) and to Health ("last delivery failed at").
Body: JSON. Header X-SC-Signature = "sha256=" + HMAC-SHA256(secret, body) in hex, when SC_WEBHOOK_SECRET is set.

"Once per incident" survives a restart: the markers of what was sent (`webhook_fired`, a JSON object in the store's
meta table, entries older than MARKER_DAYS dropped) are written before the send and read at the start.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import ssl
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from collections.abc import Callable
from datetime import UTC, datetime

log = logging.getLogger(__name__)

EVENTS = ("incident.new", "incident.raised", "incident.status", "sla.breached", "actnow.unowned")
RETRIES = 3                          # tries after the first one
BACKOFF_S = (2.0, 8.0, 30.0)         # the pause before each retry
TIMEOUT_S = 10.0
QUEUE_MAX = 500
MARKER_DAYS = 90
MARKER_KEY = "webhook_fired"
PAYLOAD_VERSION = 1
NO_RETRY = range(300, 500)           # a redirect or a client error: a retry cannot fix it, except these:
RETRY_4XX = (408, 429)


def sign(secret: str, body: bytes) -> str:
    """The value of X-SC-Signature."""
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):      # a redirect would turn the POST into a GET: it is a failure
        return None


def http_send(url: str, body: bytes, headers: dict, timeout: float, verify: bool) -> int:
    """POST `body`; the status code. An error status is returned, not raised; a network error raises."""
    ctx = None
    if not verify:                        # SC_WEBHOOK_VERIFY_TLS=false
        ctx = ssl.create_default_context()
        ctx.check_hostname, ctx.verify_mode = False, ssl.CERT_NONE
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ctx), _NoRedirect)
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with opener.open(req, timeout=timeout) as r:
            return r.status
    except urllib.error.HTTPError as exc:
        return exc.code


def _short(exc: Exception, url: str = "") -> str:
    """What went wrong, without the URL (an address can carry a token)."""
    reason = getattr(exc, "reason", None) or exc
    text = f"{type(exc).__name__}: {reason}"
    return (text.replace(url, "<url>") if url else text)[:200]


class Notifier:
    def __init__(self, url: str = "", secret: str = "", store=None, verify_tls: bool = True,
                 sender: Callable[..., int] | None = None, sleep: Callable[[float], None] | None = None,
                 backoff: tuple = BACKOFF_S, queue_max: int = QUEUE_MAX, clock: Callable[[], float] = time.time):
        self.url, self.secret, self.verify, self.store = url.strip(), secret, verify_tls, store
        self._send = sender or http_send
        self._sleep = sleep or time.sleep
        self.backoff, self.queue_max, self._clock = backoff, queue_max, clock
        self._q: deque = deque()
        self._cv = threading.Condition()
        self._busy = False
        self._thread: threading.Thread | None = None
        self._stop = False
        self._fired: dict | None = None
        self._dirty = False            # markers recorded with persist=False, not written yet
        self._lock = threading.Lock()
        self._seq = 0
        # what Health reads
        self.delivered = self.failed = self.dropped = 0
        self.last_ok_at = self.last_error_at = self.last_drop_at = 0.0
        self.last_error = ""

    @classmethod
    def from_settings(cls, settings, store, **kw) -> Notifier:
        return cls(settings.webhook_url, settings.webhook_secret, store, settings.webhook_verify_tls, **kw)

    @property
    def enabled(self) -> bool:
        return bool(self.url) and self.url_error == ""

    @property
    def url_error(self) -> str:
        """Why the configured address cannot be used ("" = fine): only http and https are posted to."""
        if self.url and not self.url.lower().startswith(("http://", "https://")):
            return "SC_WEBHOOK_URL must start with http:// or https:// (it is not used)"
        return ""

    # ---- queue ---------------------------------------------------------------------------------------------------

    def emit(self, event: str, build: Callable[[], dict], key: str = "", incident: int | None = None) -> bool:
        """Queue one event. `build` returns the fields of the body besides the envelope (incident, detail, ticket); it
        runs on the worker thread, so a ticket that takes a moment to build never holds up the caller. `key` makes
        the event id (the same transition has the same id, so a receiver can drop a repeat); `incident` is the id
        the audit line names on a failure. False when the webhook is off."""
        if not self.enabled or event not in EVENTS:
            return False
        with self._lock:
            self._seq += 1
            eid = f"{event}:{key}" if key else f"{event}:{int(self._clock())}:{self._seq}"
        with self._cv:
            if len(self._q) >= self.queue_max:
                self._q.popleft()
                self.dropped += 1
                self.last_drop_at = self._clock()
            self._q.append((event, eid, self._clock(), build, incident))
            if self._thread is None and not self._stop:
                self._thread = threading.Thread(target=self._run, name="webhook", daemon=True)
                self._thread.start()
            self._cv.notify()
        return True

    def stop(self) -> None:
        with self._cv:
            self._stop = True
            self._cv.notify_all()

    def wait_idle(self, timeout: float = 5.0) -> bool:
        """Until everything queued has been tried (tests, shutdown)."""
        end = time.monotonic() + timeout
        with self._cv:
            while self._q or self._busy:
                left = end - time.monotonic()
                if left <= 0:
                    return False
                self._cv.wait(min(left, 0.05))
        return True

    def queued(self) -> int:
        with self._cv:
            return len(self._q) + int(self._busy)

    def _run(self) -> None:
        while True:
            with self._cv:
                while not self._q and not self._stop:
                    self._cv.wait(1.0)
                if self._stop and not self._q:
                    return
                item = self._q.popleft()
                self._busy = True
            try:
                self._deliver(*item)
            except Exception:
                log.exception("webhook delivery crashed")
            finally:
                with self._cv:
                    self._busy = False
                    self._cv.notify_all()

    # ---- one delivery --------------------------------------------------------------------------------------------

    def body_of(self, event: str, eid: str, at: float, build: Callable[[], dict]) -> bytes:
        try:
            fields = build()
        except Exception as exc:
            log.exception("webhook payload for %s failed", event)
            fields = {"error": f"the payload could not be built: {type(exc).__name__}"}
        doc = {"event": event, "event_id": eid, "version": PAYLOAD_VERSION, "at": at,
               "at_iso": datetime.fromtimestamp(at, UTC).strftime("%Y-%m-%dT%H:%M:%SZ"), **fields}
        return json.dumps(doc, sort_keys=True, ensure_ascii=False, default=str).encode()

    def _deliver(self, event: str, eid: str, at: float, build: Callable[[], dict], incident: int | None) -> bool:
        body = self.body_of(event, eid, at, build)
        headers = {"Content-Type": "application/json", "User-Agent": "sycope-security-triage-webhook/1",
                   "X-SC-Event": event, "X-SC-Delivery": eid}
        if self.secret:
            headers["X-SC-Signature"] = sign(self.secret, body)
        status, error, tries = None, "", 0
        for n in range(RETRIES + 1):
            tries = n + 1
            try:
                status = self._send(self.url, body, headers, TIMEOUT_S, self.verify)
                error = "" if 200 <= status < 300 else f"HTTP {status}"
            except Exception as exc:  # noqa: BLE001  (any failure to send is a failed delivery)
                status, error = None, _short(exc, self.url)
            if not error:
                break
            if status is not None and status in NO_RETRY and status not in RETRY_4XX:
                break
            if n < RETRIES:
                self._sleep(self.backoff[min(n, len(self.backoff) - 1)])
        now = self._clock()
        if not error:
            self.delivered += 1
            self.last_ok_at = now
            return True
        self.failed += 1
        self.last_error, self.last_error_at = f"{event}: {error}", now
        log.warning("webhook %s failed after %d tries: %s", event, tries, error)
        if self.store is not None:
            try:
                self.store.log("system", "webhook:failed", str(incident) if incident is not None else event,
                               f"{event}: {error}", {"event": event, "event_id": eid, "incident": incident,
                                                     "status": status, "error": error, "attempts": tries})
            except Exception:
                log.exception("writing the webhook failure to the audit log failed")
        return False

    # ---- "once" --------------------------------------------------------------------------------------------------

    def _markers(self) -> dict:
        if self._fired is None:
            try:
                self._fired = json.loads((self.store.meta(MARKER_KEY) if self.store else None) or "{}")
            except ValueError:
                self._fired = {}
        return self._fired

    def seen(self, key: str) -> bool:
        with self._lock:
            return key in self._markers()

    def once(self, key: str, now: float | None = None, *, persist: bool = True) -> bool:
        """True the first time `key` is asked for (and records it, so a restart does not send it again). A caller with
        many keys passes persist=False and calls flush() once: the whole document is one meta row, rewritten per call
        otherwise (a lab where nobody acknowledges has tens of thousands of markers)."""
        now = self._clock() if now is None else now
        with self._lock:
            m = self._markers()
            if key in m:
                return False
            m[key] = round(now, 3)
            for k in [k for k, t in m.items() if now - t > MARKER_DAYS * 86400]:
                del m[k]
            if persist:
                self._write_markers()
            else:
                self._dirty = True
            return True

    def flush(self) -> None:
        """Write the markers recorded with persist=False (one write)."""
        with self._lock:
            if self._dirty:
                self._write_markers()

    def _write_markers(self) -> None:
        self._dirty = False
        if self.store is not None:
            self.store.meta(MARKER_KEY, json.dumps(self._markers(), sort_keys=True))

    # ---- Health --------------------------------------------------------------------------------------------------

    def status(self) -> dict:
        return {"on": self.enabled, "url_error": self.url_error, "queued": self.queued(), "delivered": self.delivered, "failed": self.failed,
                "dropped": self.dropped, "last_ok_at": self.last_ok_at or None,
                "last_error": self.last_error, "last_error_at": self.last_error_at or None,
                "last_drop_at": self.last_drop_at or None}
