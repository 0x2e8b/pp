"""Shipped priors: the start values every learned norm is shrunk toward (small networks, a cold start).

data/priors.json is written by tools/build_priors.py from the lab history. A missing or broken file means BUILTIN,
so the service always has numbers to start from.
"""

from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, fields, replace
from pathlib import Path

log = logging.getLogger(__name__)
DATA = Path(__file__).resolve().parent / "data" / "priors.json"


@dataclass(frozen=True)
class Priors:
    version: str
    rule_share: dict[str, float]      # catalog key -> share of hosts showing the rule on a normal day
    kind_share: dict[str, float]      # rule kind -> share of hosts showing any rule of that kind
    default_share: float              # a rule and a kind the table does not list
    alpha_share: float                # strength of the share prior, in host-days
    up_q99: dict[str, float]          # role -> 99th percentile of the daily upload to external, bytes
    answer_q99: dict[str, float]      # service ("*" = any) -> 99th percentile of a normal response, bytes
    alpha_volume: float
    investigate_rate: float           # daily share of hosts at Investigate or above
    alpha_rate: float
    role_service_share: float         # clients a role service must serve, as a share of the segment's active hosts


BUILTIN = Priors(
    version="builtin", rule_share={}, kind_share={}, default_share=0.01, alpha_share=50.0,
    up_q99={"workstation": 5e7, "server": 5e8}, answer_q99={"*": 1e6}, alpha_volume=5.0,
    investigate_rate=0.01, alpha_rate=200.0, role_service_share=0.05,
)


def _number(v) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise TypeError(v)
    return float(v)


def _table(v) -> dict[str, float]:
    if not isinstance(v, dict):
        raise TypeError(v)
    return {str(k): _number(x) for k, x in sorted(v.items())}


def _check(pr: Priors) -> None:
    """Raise ValueError naming the first field or key that is out of range."""
    for name in ("rule_share", "kind_share"):
        for k, v in getattr(pr, name).items():
            if not 0 < v <= 1:
                raise ValueError(f"{name}[{k!r}] = {v} is outside (0, 1]")
    for name in ("up_q99", "answer_q99"):
        for k, v in getattr(pr, name).items():
            if v <= 0:
                raise ValueError(f"{name}[{k!r}] = {v} must be above 0")
    for name in ("default_share", "investigate_rate", "role_service_share"):
        if not 0 < getattr(pr, name) <= 1:
            raise ValueError(f"{name} = {getattr(pr, name)} is outside (0, 1]")
    for name in ("alpha_share", "alpha_volume", "alpha_rate"):
        if getattr(pr, name) <= 0:
            raise ValueError(f"{name} = {getattr(pr, name)} must be above 0")


def load(path: Path | None = None) -> Priors:
    """The priors of a JSON file (default: the packaged one). Fields the file lacks keep their BUILTIN value; a
    missing or broken file, or a bad value anywhere, gives BUILTIN whole (with a warning naming what failed)."""
    src = Path(path or DATA)
    field = "file"
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise TypeError("the top level is not an object")
        kw = {}
        for f in fields(Priors):
            field = f.name
            if f.name not in data:
                continue
            v = data[f.name]
            kw[f.name] = str(v) if f.name == "version" else _table(v) if f.type.startswith("dict") else _number(v)
        field = "range"
        pr = replace(BUILTIN, **kw)
        _check(pr)
        return pr
    except (OSError, ValueError, TypeError) as e:
        log.warning("priors %s unusable (%s: %s), using the built-in priors", src, field, e)
        return BUILTIN


def rule_prior(pr: Priors, key: str, kind: str) -> float:
    """The expected share of hosts with a rule on a normal day: its own, else its kind's, else the default."""
    if key in pr.rule_share:
        return pr.rule_share[key]
    if kind and kind in pr.kind_share:
        return pr.kind_share[kind]
    return pr.default_share
