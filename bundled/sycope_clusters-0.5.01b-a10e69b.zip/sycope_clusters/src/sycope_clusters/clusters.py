"""Security Clusters from the window's hourly finding buckets, on the actor side.

Maciej's clusters are time chains per anchor IP. The input is what Triage reads, the buckets of ingest.Window (exact
first and last alert time, count, strongest severity), not raw alerts: a bucket stands for `_n` alerts and becomes
two rows for the engine, its first alert and its last with the rest of the weight (`_w`). Any gap inside an hourly
bucket is shorter than an hour, so with delta = 1 h the episode boundaries are the ones raw alerts give.

Two things differ from the first board. The kill-chain phase of an alert is its rule's stage in the catalog, not the
template's MITRE tag (rules.py says why); the engine reads a stand-in tactic that maps to that stage, and none for a
rule without a stage. And a cluster describes the host that acts: a victim of other hosts' alerts gets no cluster of
its own, the evidence.attribute lanes (actor, target, external, hygiene) decide which side a bucket belongs to.
"""

from __future__ import annotations

import hashlib
import json
import logging
import sys
import threading
import time
import weakref
from array import array
from bisect import bisect_left, bisect_right
from collections.abc import Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field, replace
from itertools import batched, groupby
from operator import itemgetter
from types import SimpleNamespace

import polars as pl

from sycope_clusters import attack_map, cluster_chains, pipeline, rules, scoring, silence
from sycope_clusters import evidence as ev
from sycope_clusters.addresses import AddressBook, prefix
from sycope_clusters.ingest import BI, HOUR_MS, Window
from sycope_clusters.sycope import CLASSIC_FIELDS

log = logging.getLogger("sycope_clusters.clusters")

# The stand-in tactic the engine reads for a catalog stage (engine/mitre.py maps it to the phase of the same number).
# A rule without a stage gets "": no phase. A command-and-control rule (a beacon, a covert channel, a listed C2
# address) is a Foothold finding and reads "Command and Control", which engine/mitre.py puts in phase 1 too.
STAGE_TACTIC = {0: "Reconnaissance", 1: "Initial Access", 2: "Lateral Movement", 3: "Exfiltration"}
C2_TACTIC = "Command and Control"
C2_CODE = 3     # the step code of a command channel in the chain rules (as in 1.1.2, where C2 was stage 3)


def stand_in(rule: rules.Rule) -> str:
    return C2_TACTIC if rule.stage == 1 and rule.c2_type else STAGE_TACTIC.get(rule.stage, "")


def step_code(rule: rules.Rule) -> int:
    """The stage a chain step carries: the rule's stage, but a command channel keeps the code 3 it had when C2 was
    stage 3, so cluster_chains tells a listed C2 address from Phishing (both Foothold) without a rule at hand."""
    return C2_CODE if rule.stage == 1 and rule.c2_type else rule.stage

# Families whose rules set no kill-chain phase, whatever stage the catalog gives a rule of them (CL-08 floods carry
# stage 3 there; spec 4.2.2: a cluster of them alone cannot rise above Watch). Class D rules never set one either.
NO_PHASE = frozenset({"CL-07", "CL-08", "CL-09", "HYG", "POL"})

_COLS = [(pipeline.COLUMNS[f], BI[f]) for f in CLASSIC_FIELDS]
_LOOKUPS = {"Client Location", "Server Location", "Client Function", "Server Function"}
# what the engine and the board read; the rest of a bucket (ids, lookups) is not copied into the frame: the lookups
# are counted per host while the chunks are cut (Feed.hosts), the ids are only in the raw rings
_DROP = _LOOKUPS | {"Sycope Id", "Rule Id", "Definition Id"}
_KEEP = [(n, i) for n, i in _COLS if n not in _DROP]
_IDX = dict(_COLS)
_HOST = {"Client IP": ("Client Location", "Client Function"), "Server IP": ("Server Location", "Server Function")}
_EXTRA = ("Actor IP", "Counterpart IP", "Family", "Template Tactic", "Attack")   # Attack: attack_map.read_key
_NAME, _RID, _TAC, _C, _S, _N, _FIRST, _LAST, _SSB, _SPORT = (
    BI[k] for k in ("alertName", "alertRuleId", "alertMitreTactic", "clientIp", "serverIp", "_n", "_first", "_last",
                    "sumServerBytes", "serverPort"))
_PROTO = BI["protocolName"]


# Families that never set a phase and make up most of a big window (the lab: 56 % of the rows). Above the memory
# budget Clusters leaves them out (a lean board) and says so on the page; they only extend chains and counts.
LEAN_OUT = frozenset({"HYG", "POL", "CL-09"})


# Most distinct IPs kept per lane entry (the attackers of one target, the internal hosts one outside IP talks to): the
# count stops there, a flood from a /8 does not grow a set for every address.
PEER_CAP = 10_000


class Lane:
    """What the buckets say about one target or one outside IP, summed while the chunks are cut (the buckets
    themselves are never kept: at 2M alerts they are 150 MB of tuples)."""
    __slots__ = ("alerts", "first", "flag", "last", "peers", "rules")

    def __init__(self) -> None:
        self.peers: set[str] = set()       # distinct counterparts, up to PEER_CAP
        self.rules: dict[str, int] = {}    # alert name -> alerts
        self.alerts = 0
        self.first = self.last = 0
        self.flag = False                  # target: it answered (server bytes > 0); outside IP: a TI rule hit it


@dataclass
class Feed:
    """What the buckets give the Clusters board. `actor`: the engine's frame, one row per bucket edge, for the host
    that acts. `targets` (internal host that is only on the receiving side) and `external` (outside IP: TI hit,
    inbound scanner, or alert between outside addresses): the lanes of the board, aggregates per IP, never anchors.
    `lane_fams`: the catalog family of each alert name seen in a lane."""
    actor: pl.DataFrame
    hosts: pl.DataFrame = field(default_factory=lambda: pl.DataFrame(schema=_HOSTS))   # ip, col, val, n
    targets: dict[str, Lane] = field(default_factory=dict)
    external: dict[str, Lane] = field(default_factory=dict)
    unknown: dict[str, int] = field(default_factory=dict)     # alert names the catalog does not have -> alerts
    lane_fams: dict[str, str] = field(default_factory=dict)


@dataclass
class ClusterBoard:
    built_at: float
    now: float
    took_s: float
    snapshot: pipeline.Snapshot
    targets: list[dict] = field(default_factory=list)       # at most LANE_KEEP of each lane, best first
    externals: list[dict] = field(default_factory=list)
    lane_totals: tuple[int, int] = (0, 0)                   # how many targets and outside IPs there were in all
    chains: dict[str, list[tuple[str, float, str]]] = field(default_factory=dict)
    memory: dict[str, dict] = field(default_factory=dict)
    lean: bool = False        # hygiene findings (LEAN_OUT, class D) were left out to stay inside the memory budget
    merged: dict[int, int] = field(default_factory=dict)    # episode id the window now chains into an older one -> that one


_HOSTS = {"ip": pl.Utf8, "col": pl.Utf8, "val": pl.Utf8, "n": pl.Int64}


def _schema() -> dict:
    s = {name: (pl.Int64 if name == "Time" else pl.Int32 if name == "Server Port" else pl.Categorical)
         for name, _ in _KEEP}
    return {**s, **dict.fromkeys(_EXTRA, pl.Categorical), "_w": pl.Int32, "_hour": pl.Int32}


CHUNK = 50_000      # buckets turned into columns at a time


def frame_from_buckets(buckets: Iterable[tuple], catalog: rules.Catalog, nets: AddressBook,
                       lanes: bool = True, lean: bool = False, exceptions: Sequence[dict] = ()) -> Feed:
    """The buckets (a list, or any iterable such as Window.iter_hours() chained) as a Feed. They are cut into chunks,
    each chunk into columns on its own, so the python rows of the whole window are never alive at once. The target
    and external lanes are summed per IP on the way (Lane); `lanes=False` skips them; `lean=True` leaves out the
    hygiene families (LEAN_OUT) and class D; `exceptions` (the analysts' silenced services and hosts, shared with
    Triage) take the buckets they match out of every lane."""
    parts: list[pl.DataFrame] = []
    hosts: list[pl.DataFrame] = []
    feed = Feed(pl.DataFrame())
    exceptions = silence.ExceptionSet.of(exceptions)    # one index for every chunk
    for chunk in batched(buckets, CHUNK):
        df, hs = _chunk_frame(chunk, catalog, nets, feed, lanes, lean, exceptions)
        parts.append(df)
        hosts.append(hs)
    if not parts:
        df, hs = _chunk_frame((), catalog, nets, feed, lanes, lean, exceptions)
        parts, hosts = [df], [hs]
    df, hs = pl.concat(parts, rechunk=False), pl.concat(hosts)
    del parts, hosts      # the chunks are copied into one frame: free them before the engine runs
    # no global sort: the engine sorts what it needs, and the rows keep the buckets' order (hour, then key), which
    # is deterministic; alert_id is the tie-break the engine uses between alerts of the same millisecond
    hs = hs.group_by("ip", "col", "val").agg(pl.col("n").sum())
    feed.actor, feed.hosts = df.with_row_index("alert_id"), hs
    return feed


def _lane_add(lanes: dict[str, Lane], ip: str, peer: str | None, name: str, n: int, first: int, last: int,
              flag: bool) -> None:
    ln = lanes.get(ip)
    if ln is None:
        ln = lanes[sys.intern(ip)] = Lane()
        ln.first = first
    if peer and len(ln.peers) < PEER_CAP:
        ln.peers.add(sys.intern(peer))
    ln.rules[name] = ln.rules.get(name, 0) + n
    ln.alerts += n
    ln.first, ln.last = min(ln.first, first), max(ln.last, last)
    ln.flag = ln.flag or flag


def _lanes_of(b: tuple, rule: rules.Rule, lane: str, subject: str, cp: str | None, nets: AddressBook,
              feed: Feed) -> None:
    """One bucket's part in the Under attack and External lanes. A target: any internal host that only receives.
    An outside IP: the one that attacks an internal host, one that sits between outside addresses, and the outside
    counterpart of a threat-intel rule (TOR, scanner lists, phishing)."""
    name = sys.intern(b[_NAME] or "?")
    n, first, last = int(b[_N] or 1), int(b[_FIRST]), int(b[_LAST])
    feed.lane_fams.setdefault(name, rule.family)
    if lane == "t":
        _lane_add(feed.targets, subject, cp, name, n, first, last, ev._int(b[_SSB]) > 0)
        if cp and not nets.internal(cp):
            _lane_add(feed.external, cp, subject, name, n, first, last, bool(rule.ti))
    elif lane == "x":
        _lane_add(feed.external, subject, None, name, n, first, last, bool(rule.ti))
    elif lane == "a" and rule.ti and cp and not nets.internal(cp):
        _lane_add(feed.external, cp, subject, name, n, first, last, True)


def _chunk_frame(chunk: tuple, catalog: rules.Catalog, nets: AddressBook, feed: Feed, lanes: bool,
                 lean: bool, exceptions: Sequence[dict] = ()) -> tuple[pl.DataFrame, pl.DataFrame]:
    unknown = feed.unknown
    # The loop only decides, per bucket, which host acts and what phase the rule gives; the columns are cut out of
    # the buckets afterwards (a Python append per column and row is what makes this slow).
    sel: list[tuple] = []                       # the bucket of every row
    times: list[int] = []
    weights: list[int] = []
    actors: list[str] = []
    cps: list[str | None] = []
    fams: list[str] = []
    attacks: list[str] = []
    phases: list[str | None] = []

    def emit(b: tuple, rule: rules.Rule, actor: str, cp: str | None, phase: str) -> None:
        n, first, last = int(b[_N] or 1), int(b[_FIRST]), int(b[_LAST])
        for ms, w in ((first, 1), (last, n - 1)) if n >= 2 else ((first, 1),):
            sel.append(b)
            times.append(ms)
            weights.append(w)
            actors.append(actor)
            cps.append(cp)
            fams.append(rule.family)
            attacks.append(rule.attack_key)
            phases.append(phase or None)        # null: no phase (the engine skips it)

    silencer = exceptions.silencer if isinstance(exceptions, silence.ExceptionSet) and exceptions.silencer.has_silence \
        else None
    for b in chunk:
        rule = catalog.get(b[_NAME], b[_TAC], b[_RID])
        client, server = b[_C] or None, b[_S] or None
        sil = silencer.silence_ids(b[_NAME], client, server, str(b[_SPORT] or "") or None, silence.proto_of(b[_PROTO]),
                                   b[_FIRST], b[_LAST]) if silencer else ()
        rule, _dir = ev.resolve(rule, client, server, b[_SSB], nets)    # the rule as it reads in this direction
        if lean and (rule.hygiene or rule.family in LEAN_OUT):
            continue
        if not rule.known:
            unknown[b[_NAME] or "?"] = unknown.get(b[_NAME] or "?", 0) + int(b[_N] or 1)
        for lane, subject, cp in ev.attribute(rule, client, server, nets):
            if exceptions and ev._exception_for(      # the matcher Triage scores findings with, on the bucket
                    SimpleNamespace(rule=rule, subject=subject, cp=cp, port=str(b[_SPORT] or ""), sil=sil),
                    exceptions):
                continue
            if lane == "a":
                emit(b, rule, subject, cp,
                     stand_in(rule) if sets_phase(rule) else "")
                if lanes and rule.ti:
                    _lanes_of(b, rule, lane, subject, cp, nets, feed)
            elif lane == "h":      # a hygiene finding belongs to the host it is about, and sets no phase
                actor, cp = ev.actor_of(rule, client, server, nets)
                if actor:
                    emit(b, rule, actor, cp, "")
            elif lanes:
                _lanes_of(b, rule, lane, subject, cp, nets, feed)
    schema = _schema()
    got: dict[str, pl.Series] = {}

    def put(name: str, values) -> None:
        got[name] = pl.Series(name, values, dtype=schema[name])

    for name, i in _KEEP:       # one column at a time: no second copy of every column is alive at once
        col = map(itemgetter(i), sel)
        if name == "Server Port":
            col = map(pipeline._num, col)
        put(name, list(col))
    put("Time", times)
    put("Mitre Tactic", phases)
    for name, values in (("Actor IP", actors), ("Counterpart IP", cps), ("Family", fams), ("Attack", attacks),
                         ("_w", weights)):
        put(name, values)
    put("Template Tactic", [x or None for x in map(itemgetter(_TAC), sel)])
    put("_hour", [int(x) // HOUR_MS for x in map(itemgetter(_FIRST), sel)])
    df = pl.DataFrame([got[k] for k in schema]).with_columns(pl.from_epoch("Time", time_unit="ms").alias("Time"))
    return df, _host_counts(sel)


def _host_counts(sel: list[tuple]) -> pl.DataFrame:
    """Per host IP, how often each location and function name appears in the chunk's rows (either side)."""
    out = []
    for ip_col, (loc, fn) in _HOST.items():
        ip = pl.Series(list(map(itemgetter(_IDX[ip_col]), sel)), dtype=pl.Utf8)
        for kind, name in (("loc", loc), ("fn", fn)):
            val = pl.Series(list(map(pipeline._txt, map(itemgetter(_IDX[name]), sel))), dtype=pl.Utf8)
            out.append(pl.DataFrame({"ip": ip, "val": val}).drop_nulls().group_by("ip", "val").len()
                       .select("ip", pl.lit(kind).alias("col"), "val", pl.col("len").cast(pl.Int64).alias("n")))
    return pl.concat(out)


def _host_info(hosts: pl.DataFrame, ips: set[str]) -> dict[str, dict]:
    """Sycope's lookup names for each anchor: the location and function it has most often in its alerts."""
    if hosts.is_empty() or not ips:
        return {}
    top = (hosts.filter(pl.col("ip").is_in(list(ips))).sort(["ip", "col", "n", "val"], descending=[False, False, True, False])
           .unique(["ip", "col"], keep="first", maintain_order=True))
    out: dict[str, dict] = {}
    for ip, col, val, _n in top.iter_rows():
        out.setdefault(ip, {})[col] = val
    return out


MIN_DELTA_S = 3600     # a bucket is an hour: below it the episode boundaries would no longer match raw alerts
_warned = False


def _warn_delta(delta_s: int) -> None:
    global _warned
    if not _warned:
        _warned = True
        log.warning("SC_DELTA_SECONDS=%s is below 3600: Clusters chain hourly findings and use 3600", delta_s)


def build(buckets: Iterable[tuple], now: float, catalog: rules.Catalog, nets: AddressBook, crown,
          model: scoring.Model, *, store=None, delta_s: int = 3600, min_alerts: int = 2,
          lean: bool = False, exceptions: Sequence[dict] = ()) -> ClusterBoard:
    """The board for the buckets of the window: clusters per acting host (`crown` answers `ip in crown`)."""
    t0 = time.monotonic()
    if delta_s < MIN_DELTA_S:
        _warn_delta(delta_s)
        delta_s = MIN_DELTA_S
    # the stored past days first, while the window's frame and the engine's memory are not alive yet
    past = _past_safe(store, now, catalog, nets)
    feed = frame_from_buckets(buckets, catalog, nets, lean=lean, exceptions=exceptions)
    actor, unknown, hosts = feed.actor, feed.unknown, feed.hosts
    totals = (len(feed.targets), len(feed.external))
    targets, externals = _lane_rows(feed, crown)      # the attacker sets are dropped before the engine runs
    del feed
    snap = _engine(actor, now, delta_s, min_alerts, crown, model)
    merged: dict[int, int] = {}
    if store is not None and not snap.empty:
        snap, merged = _with_episodes(snap, store, delta_s, now)
        for loser, winner in merged.items():      # a merged episode's status goes to the one it merged into
            try:      # the work layer repeats this from the stored merges on every pass: a failure costs a pass
                store.move_cluster_triage(f"cl:{loser}", f"cl:{winner}")
            except Exception:
                log.exception("moving the status of merged cluster %s to %s failed (retried on the next pass)",
                              loser, winner)
    snap = replace(snap, unknown_names=dict(sorted(unknown.items(), key=lambda kv: -kv[1])),
                   hosts=_host_info(hosts, set(snap.clusters["anchor_ip"].to_list()) if not snap.empty else set()))
    memory: dict[str, dict] = {}
    if past is not None and not snap.empty:
        try:      # display only: a failure here must not cost the board
            memory = _memory(snap, past)
        except Exception:
            log.exception("cluster memory failed")
    chains: dict[str, list[tuple[str, float, str]]] = {}
    if not snap.empty:
        try:      # a failure here costs the multipliers, not the board
            chains, cl = _chains(snap, past, nets, int(now * 1000))
            if chains:      # the bonus is a scoring input: scored again, once, with it
                snap = replace(snap, clusters=scoring.apply(cl, model))
        except Exception:
            log.exception("cluster chains failed")
            chains = {}
    return ClusterBoard(time.time(), now, time.monotonic() - t0, snap, targets, externals, totals, chains=chains,
                        memory=memory, lean=lean, merged=merged)


def _with_episodes(snap: pipeline.Snapshot, store, delta_s: int, now: float) -> tuple[pipeline.Snapshot, dict[int, int]]:
    """The clusters keyed `cl:<episode id>` (and an `episode_id` column) instead of `anchor@first_ms`: the id is what
    the store remembers for this anchor and time range, so the key outlives the first alert leaving the window.
    One call over all clusters, after the engine's parts are joined. Also answers {merged id: winner id}."""
    cl = snap.clusters
    got = store.match_episodes(list(zip(cl["anchor_ip"].to_list(), cl["start_ms"].to_list(), cl["end_ms"].to_list(),
                                        strict=True)), delta_s * 1000, now)
    ids = pl.Series("episode_id", [e for e, _ in got], dtype=pl.Int64)
    cl = cl.with_columns(ids).with_columns(("cl:" + pl.col("episode_id").cast(pl.Utf8)).alias("key"))
    return replace(snap, clusters=cl), {m: w for w, ms in got for m in ms}


# ---- memory: what the earlier days say about a host (spec 4.3) ---------------------------------------------------

PAST_DAYS = 6           # days before today that the badge, the heat and the chronic flag look at
STEP_DAYS = 7           # days the chain rules read: CR-03's 168 h window reaches into the seventh
PAST_CHUNK = 5_000     # stored rows read at a time (a day is ~200k at 2M alerts a day)
SLICE = 250_000        # rows of cluster_alerts joined at a time
CHRONIC_DAYS = 3        # a host is chronic when every rule of the cluster's set was seen on this many of them
_NAME_BITS = 20         # a rule name id takes the low bits of a packed (actor, rule) key
_FAMILIES = sorted(rules.FAMILIES)                          # a family's index takes 5 bits of a packed step key
_FAM_ID = {f: i for i, f in enumerate(_FAMILIES)}
_NO_CP = 0xFFFFFFFF
_STEP_BITS = 7           # family (5 bits) and stage (2) under the actor id of a packed step key


class PastDays(Mapping):
    """What the stored past days say about each acting host: actor ip -> day -> rule name -> alerts, for the days
    before `today`. Built in one pass over Store.iter_day_rows and kept compact on purpose (50,000 hosts over six
    days is a million (host, day, rule) entries: nested dicts would be ~100 MB, this is ~15): per day, a sorted
    array of packed (actor id, rule id) keys and an array of counts. A lookup is a bisect per day.
    `days`: the days the rule counts cover, oldest first; `present`: the stored ones of all the days read (a day the
    store lacks is not the same as a quiet one).
    The chain rules read the same pass: per day a sorted array of packed (actor id, family, stage) keys with the time
    of that day's first alert of the family, the time of its last one and the counterpart of the first (`steps_of`
    gives both times as steps: a rule that needs "after the scan" must see a step that comes after it)."""

    def __init__(self, days: list[str], present: frozenset[str], store, catalog: rules.Catalog,
                 step_days: list[str] | None = None) -> None:
        self.days, self.present = days, present
        self.step_days = step_days or days
        self.store_ref, self.catalog_ref = weakref.ref(store), weakref.ref(catalog)
        self.actors: dict[str, int] = {}
        self.names: list[str] = []
        self._name_id: dict[str, int] = {}
        self._keys: dict[str, array] = {}
        self._counts: dict[str, array] = {}
        self.cps: list[str] = []
        self._cp_id: dict[str, int] = {}
        self._skeys: dict[str, array] = {}
        self._sfirst: dict[str, array] = {}
        self._slast: dict[str, array] = {}
        self._scp: dict[str, array] = {}

    def __getitem__(self, ip: str) -> dict[str, dict[str, int]]:
        aid = self.actors.get(ip)
        if aid is None:
            raise KeyError(ip)
        out: dict[str, dict[str, int]] = {}
        lo_key, hi_key = aid << _NAME_BITS, (aid + 1) << _NAME_BITS
        for d, keys in self._keys.items():
            lo, hi = bisect_left(keys, lo_key), bisect_left(keys, hi_key)
            if hi > lo:
                counts = self._counts[d]
                out[d] = {self.names[keys[i] & ((1 << _NAME_BITS) - 1)]: counts[i] for i in range(lo, hi)}
        if not out:
            raise KeyError(ip)      # a host seen only in the chain steps has no rule counts
        return out

    def __iter__(self) -> Iterator[str]:
        return (ip for ip in self.actors if ip in self)

    def __len__(self) -> int:
        return sum(1 for _ in self)

    def of(self, ip: str) -> dict[str, dict[str, int]]:
        """Like [ip], {} for a host never seen."""
        return self.get(ip) or {}

    def _name(self, name: str) -> int:
        i = self._name_id.get(name)
        if i is None:
            i = self._name_id[name] = len(self.names)
            self.names.append(sys.intern(name))
        return i

    def _flush(self, day: str, acc: dict[int, int]) -> None:
        ks = sorted(acc)
        self._keys[day] = array("Q", ks)
        self._counts[day] = array("I", (min(acc[k], 0xFFFFFFFF) for k in ks))

    def _cp(self, cp: str | None) -> int:
        if not cp:
            return _NO_CP
        i = self._cp_id.get(cp)
        if i is None:
            if len(self.cps) >= _NO_CP - 1:
                return _NO_CP
            i = self._cp_id[cp] = len(self.cps)
            self.cps.append(sys.intern(cp))
        return i

    def _flush_steps(self, day: str, acc: dict[int, list]) -> None:
        ks = sorted(acc)
        self._skeys[day] = array("Q", ks)
        self._sfirst[day] = array("q", (acc[k][0] for k in ks))
        self._slast[day] = array("q", (acc[k][1] for k in ks))
        self._scp[day] = array("I", (self._cp(acc[k][2]) for k in ks))

    def steps_of(self, ip: str) -> list[cluster_chains.Step]:
        """The steps of one host over the days read, oldest day first; [] for a host never seen."""
        aid = self.actors.get(ip)
        if aid is None:
            return []
        out: list[cluster_chains.Step] = []
        lo_key, hi_key = aid << _STEP_BITS, (aid + 1) << _STEP_BITS
        for d in self.step_days:
            keys = self._skeys.get(d)
            if keys is None:
                continue
            lo, hi = bisect_left(keys, lo_key), bisect_left(keys, hi_key)
            for i in range(lo, hi):
                k, cp = keys[i], self._scp[d][i]
                fam, cp = _FAMILIES[(k >> 2) & 31], None if cp == _NO_CP else self.cps[cp]
                first, last = self._sfirst[d][i], self._slast[d][i]
                out.append(cluster_chains.Step(ip, fam, k & 3, first, cp))
                if last > first:
                    out.append(cluster_chains.Step(ip, fam, k & 3, last, cp))
        return out

    def nbytes(self) -> int:
        """What the structure holds (the arrays, the actor, name and counterpart tables with their strings)."""
        arrays = sum(a.buffer_info()[1] * a.itemsize for m in (self._keys, self._counts, self._skeys, self._sfirst,
                                                                self._slast, self._scp) for a in m.values())
        strings = sum(sys.getsizeof(k) for k in self.actors) + sum(sys.getsizeof(n) for n in self.names)
        strings += sum(sys.getsizeof(c) for c in self.cps)
        return (arrays + strings + sys.getsizeof(self.actors) + sys.getsizeof(self._name_id)
                + sys.getsizeof(self._cp_id))


_past: dict[tuple, PastDays] = {}
_past_failed: dict[tuple, float] = {}      # key of a load that failed -> when to try it again
_past_lock = threading.Lock()
RETRY_S = 600


class PastUnavailable(Exception):
    """The past days could not be read a moment ago; not tried again for RETRY_S (same key)."""


def _nets_fp(nets: AddressBook) -> str:
    """What of the address book decides who acts: the lookup entries' networks and privacy (in order: it breaks
    ties), the configured networks and the admin overrides. Not `located`: it grows with every poll."""
    d = [[(str(e.net), e.privacy) for e in nets.entries], [str(n) for n in nets.extra],
         sorted(nets.admin_internal.items())]
    return hashlib.sha1(json.dumps(d, separators=(",", ":")).encode()).hexdigest()


def past_actor_rules(store, today: str, catalog: rules.Catalog, nets: AddressBook, days: int = PAST_DAYS) -> PastDays:
    """The days before `today` as PastDays: the rule counts of the last `days`, the chain steps of the last
    STEP_DAYS (or `days` when that is more). Which host acts in a stored row is decided as the Clusters frame
    does for a bucket (ev.attribute: lane a, or the host a hygiene finding is about), so a name here is the same
    host's name there. Past days do not change, so the result is cached per (asked days, stored days with their
    fetch time, store, catalog, internal-network fingerprint): a day roll, a day the Live backfill adds or fetches
    again, a reloaded catalog or a change of the internal networks is a new key. Only the newest entry of a store
    is kept. A failed load is not tried again for RETRY_S (PastUnavailable)."""
    asked = [ev.prev_day(today, k) for k in range(max(days, STEP_DAYS), 0, -1)]
    have = store.days()
    stored = tuple((d, have[d]["fetched_at"]) for d in asked if d in have)
    key = (tuple(asked), stored, id(store), id(catalog), _nets_fp(nets), days)
    with _past_lock:
        got = _past.get(key)
        if got is not None and got.store_ref() is store and got.catalog_ref() is catalog:
            return got
        if _past_failed.get(key, 0) > time.monotonic():
            raise PastUnavailable
        try:
            got = _load_past(store, catalog, asked, frozenset(d for d, _ in stored), nets, days)
        except Exception:
            _past_failed.clear()        # one failed key at a time is plenty
            _past_failed[key] = time.monotonic() + RETRY_S
            raise
        _past_failed.clear()
        for k in [k for k, v in _past.items() if k[2] == id(store) or v.store_ref() is None]:
            del _past[k]
        _past[key] = got
        return got


def sets_phase(rule: rules.Rule) -> bool:
    """Whether a finding of the rule may set the phase of a cluster. A class C rule is suspected only (Triage gives it
    no confirming weight), class D is hygiene, and the NO_PHASE families are not an attack stage."""
    return rule.cls != "C" and not rule.hygiene and rule.family not in NO_PHASE


def strong(rule: rules.Rule) -> bool:
    """Whether a finding of the rule is a chain step: it sets a phase in the frame (a stage, not a hygiene finding,
    not a family of NO_PHASE: a flood does not stand for command and control)."""
    return rule.stage is not None and sets_phase(rule)


def _load_past(store, catalog: rules.Catalog, asked: list[str], present: frozenset[str], nets: AddressBook,
               days: int = PAST_DAYS) -> PastDays:
    counted = frozenset(asked[-days:])            # the rule counts: the last `days` of the days read
    pd = PastDays(asked[-days:], present, store, catalog, asked)
    acc: dict[int, int] = {}
    steps: dict[int, list] = {}      # packed key -> [first ms, last ms, counterpart of the first]
    cur = None
    actors, name_id = pd.actors, pd._name

    def flush() -> None:
        if cur in counted:
            pd._flush(cur, acc)
        pd._flush_steps(cur, steps)

    for r in store.iter_day_rows([d for d in asked if d in present], chunk=PAST_CHUNK):
        if r[0] != cur:
            if cur is not None:
                flush()
            cur, acc, steps = r[0], {}, {}
        name, client, server = r[1], r[2] or None, r[3] or None
        rule = rules.stored_rule(catalog, name, r[14] if len(r) > 14 else None)
        rule, _dir = ev.resolve(rule, client, server, r[9], nets)
        who: dict[str, str | None] = {}
        for lane, subject, cp in ev.attribute(rule, client, server, nets):
            if lane == "a":
                who[subject] = cp
            elif lane == "h":
                who[ev.actor_of(rule, client, server, nets)[0]] = None
        who.pop(None, None)
        if not who:
            continue
        nid = None
        if cur in counted:
            nid = pd._name_id.get(name or "?")
            if nid is None and len(pd.names) >> _NAME_BITS == 0:     # a million distinct names: nothing real, not kept
                nid = name_id(name or "?")
        first = int(r[6] or 0)      # a row without a time says nothing about when
        last = max(first, int(r[7] or 0))
        step = strong(rule) and first
        for ip, cp in who.items():
            aid = actors.get(ip)
            if aid is None:
                aid = actors[ip] = len(actors)
            if nid is not None:
                k = (aid << _NAME_BITS) | nid
                acc[k] = acc.get(k, 0) + int(r[5] or 0)
            if step:
                sk = (aid << _STEP_BITS) | (_FAM_ID[rule.family] << 2) | step_code(rule)
                got = steps.get(sk)
                if got is None:
                    steps[sk] = [first, last, cp]
                else:
                    if first < got[0]:
                        got[0], got[2] = first, cp
                    got[1] = max(got[1], last)
    if cur is not None:
        flush()
    for d in present:
        if d not in pd._skeys:
            pd._flush_steps(d, {})
        if d in counted and d not in pd._keys:
            pd._flush(d, {})
    return pd


def _rule_sets(snap: pipeline.Snapshot) -> dict[str, list[str]]:
    """cluster_id -> the names of its rules that set a phase, or all its names when none does. The frame's
    "Mitre Tactic" is the stand-in phase: null for a rule without one. Done in slices of cluster_alerts: the join
    of all of them with the alerts is a copy of the whole window at 2M alerts."""
    ca = snap.cluster_alerts.select("cluster_id", "alert_id")
    al = snap.alerts.select("alert_id", "Alert Name", "Mitre Tactic")
    parts = [ca.slice(off, SLICE).join(al, on="alert_id").group_by("cluster_id", "Alert Name")
             .agg(pl.col("Mitre Tactic").is_not_null().any().alias("ph")) for off in range(0, ca.height, SLICE)]
    if not parts:
        return {}
    per = pl.concat(parts).group_by("cluster_id", "Alert Name").agg(pl.col("ph").any())
    per = per.filter(pl.col("ph") | ~pl.col("ph").any().over("cluster_id")).select(
        "cluster_id", pl.col("Alert Name").cast(pl.Utf8))
    out: dict[str, list[str]] = {}
    for cid, nm in per.iter_rows():
        out.setdefault(cid, []).append(nm)
    return out


def _past_safe(store, now: float, catalog: rules.Catalog, nets: AddressBook) -> PastDays | None:
    if store is None:
        return None
    try:
        return past_actor_rules(store, ev.day_key(now * 1000), catalog, nets)
    except PastUnavailable:
        return None
    except Exception:
        log.exception("cluster memory: the past days could not be read (not tried again for %d s)", RETRY_S)
        return None


def _memory(snap: pipeline.Snapshot, past: PastDays) -> dict[str, dict]:
    """cluster key -> {badge new|recurring, days, heat (PAST_DAYS + 1 cells, oldest first, today last; None = the
    store lacks that day), chronic}. The cluster's rule set is `_rule_sets`; `days` counts the past days with an alert
    of the set; chronic = every rule of the set on at least CHRONIC_DAYS of them. Today's cell is the cluster's
    own alert count. Never feeds a score."""
    sets = _rule_sets(snap)
    out: dict[str, dict] = {}
    for cid, key, ip, n in snap.clusters.select("cluster_id", "key", "anchor_ip", "alert_count").iter_rows():
        names, seen = sets.get(cid, []), past.of(ip)
        heat: list[int | None] = [None if d not in past.present else sum(seen.get(d, {}).get(nm, 0) for nm in names)
                                  for d in past.days]
        days = sum(1 for h in heat if h)
        chronic = bool(names) and all(
            sum(1 for d in seen.values() if d.get(nm)) >= CHRONIC_DAYS for nm in names)
        out[key] = {"badge": "recurring" if days >= 1 else "new", "days": days, "heat": [*heat, int(n)],
                    "chronic": chronic}
    return out


# ---- chain rules (spec 4.3 item 3) -------------------------------------------------------------------------------

_TACTIC_STAGE = {**{t: st for st, t in STAGE_TACTIC.items()}, C2_TACTIC: C2_CODE}


def _today_steps(alerts: pl.DataFrame, anchors: pl.Series, now_ms: int) -> pl.DataFrame:
    """The window's steps, per (actor, hour, family, stage) the first and the last alert: actor, family, stage,
    first_ms, cp, sorted by actor. A row of the frame with a phase is a strong finding (see `strong`); the hour keeps
    the windows of the rules apart at an hour's resolution without a row per alert. Only the actors with a cluster,
    plus the scans of the last CR-07 window of any actor (the worm counts hosts that have no card)."""
    first = pl.col("Time").dt.epoch("ms")
    steps = (alerts.lazy().filter(pl.col("Mitre Tactic").is_not_null())
             .group_by("Actor IP", "_hour", "Family", "Mitre Tactic")
             .agg(first.min().alias("first_ms"), first.max().alias("last_ms"),
                  pl.col("Counterpart IP").sort_by(first).first().alias("cp"))
             .select(pl.col("Actor IP").cast(pl.Utf8).alias("actor"), pl.col("Family").cast(pl.Utf8).alias("family"),
                     pl.col("Mitre Tactic").cast(pl.Utf8).replace_strict(_TACTIC_STAGE, return_dtype=pl.Int64)
                     .alias("stage"), "first_ms", "last_ms", pl.col("cp").cast(pl.Utf8)))
    # the hour's first and last alert are both steps: a later one of a family can come after another family's
    got = steps.collect()
    cols = ["actor", "family", "stage", "first_ms", "cp"]
    steps = pl.concat([got.select(cols), got.filter(pl.col("last_ms") > pl.col("first_ms"))
                       .select("actor", "family", "stage", pl.col("last_ms").alias("first_ms"), "cp")]).lazy()
    scan_lo = now_ms - cluster_chains.CHAINS["CR-07"][1] * cluster_chains.HOUR_MS
    lo = now_ms - max(h for _, h, _ in cluster_chains.CHAINS.values()) * cluster_chains.HOUR_MS
    return (steps.filter((pl.col("first_ms") >= lo) & (pl.col("first_ms") <= now_ms)
                         & (pl.col("actor").is_in(anchors.implode()) | ((pl.col("family") == "CL-04")
                                                              & (pl.col("first_ms") >= scan_lo))))
            .sort("actor").collect())


def _chains(snap: pipeline.Snapshot, past: PastDays | None, nets: AddressBook,
            now_ms: int) -> tuple[dict[str, list[tuple[str, float, str]]], pl.DataFrame]:
    """(actor -> its chains, the clusters with `chain_bonus` set). The steps of a host are its strong findings of the
    window (the frame) and of the stored past days; CR-01, CR-03, CR-05, CR-08 and CR-09 are matched host by host, one host's steps alive at a
    time. The multiplier is the largest of the host's chains, not their product (a second reading of the same
    behaviour is no second proof), and goes on its newest cluster. CR-07 puts it on every cluster-holding member."""
    cl = snap.clusters
    anchors = cl["anchor_ip"].unique().sort()
    anchor_set = set(anchors.to_list())
    today = _today_steps(snap.alerts, anchors, now_ms)

    def segment(ip: str) -> str:
        e = nets.entry(ip)      # a lookup entry wider than a /24 (/64) is no worm segment: 10.0.0.0/8 is a site
        if e is not None and e.net.prefixlen >= (24 if e.net.version == 4 else 64):
            return str(e.net)
        return prefix(ip, v4=24)

    rows = groupby(today.iter_rows(), key=itemgetter(0))
    nxt = next(rows, None)
    hit: dict[str, dict[str, list[cluster_chains.Step]]] = {}
    seg: dict[str, set[str]] = {}
    for actor in sorted(anchor_set | set(today["actor"].unique().to_list())):
        while nxt is not None and nxt[0] < actor:
            nxt = next(rows, None)
        mine: list[cluster_chains.Step] = []
        if nxt is not None and nxt[0] == actor:
            mine = [cluster_chains.Step(actor, fam, stage, ms, cp) for _a, fam, stage, ms, cp in nxt[1]]
            nxt = next(rows, None)
        if actor in anchor_set:
            if past is not None:
                mine += past.steps_of(actor)
            got = cluster_chains.match(mine, now_ms)
            if got:
                hit[actor] = got
        if cluster_chains.worm_steps(mine, now_ms):
            seg.setdefault(segment(actor), set()).add(actor)
    worm = {n: hs for n, hs in seg.items() if len(hs) >= cluster_chains.WORM_HOSTS}
    who = set(hit) | {a for hs in worm.values() for a in hs & anchor_set}
    if not who:
        return {}, cl
    runs: dict[str, list[tuple[int, int, str]]] = {}      # actor -> (start, end, cluster id), by start
    mine = cl.filter(pl.col("anchor_ip").is_in(pl.Series(list(who)).implode())).sort("anchor_ip", "start_ms")
    for cid, ip, st, en in mine.select("cluster_id", "anchor_ip", "start_ms", "end_ms").iter_rows():
        runs.setdefault(ip, []).append((st, en, cid))

    def episode(actor: str, ms: int) -> object:
        """The cluster that holds a step; a step older than the window (or in no cluster) is one episode a day."""
        r = runs[actor]
        i = bisect_right(r, (ms, sys.maxsize)) - 1
        return r[i][2] if i >= 0 and ms <= r[i][1] else ("day", ms // 86_400_000)

    out: dict[str, list[tuple[str, float, str]]] = {}
    for actor, m in hit.items():
        out[actor] = [(cid, cluster_chains.CHAINS[cid][2],
                       cluster_chains.text(cid, cluster_chains.episodes_of(actor, steps, episode)))
                      for cid, steps in m.items()]
    for name, hs in worm.items():
        for actor in hs & anchor_set:
            out.setdefault(actor, []).append(("CR-07", cluster_chains.CHAINS["CR-07"][2],
                                              cluster_chains.worm_text(len(hs), name)))
    for rows in out.values():
        rows.sort(key=lambda r: r[0])        # the rules in id order, the order they are listed in
    bonus = {max(runs[a], key=lambda r: (r[1], r[0]))[2]: max(m for _, m, _ in c) for a, c in out.items()}
    return out, cl.with_columns(pl.col("cluster_id").replace_strict(bonus, default=None, return_dtype=pl.Float64)
                                .fill_null(pl.col("chain_bonus")).alias("chain_bonus"))


LANE_KEEP = 5000      # entries of each lane the board keeps (a worm or a flood can touch 100k addresses)


def _lane_rows(feed: Feed, crown) -> tuple[list[dict], list[dict]]:
    """The board's two lanes from the aggregates. Under attack: crown jewels first, then the most attackers. External:
    the busiest first. Each is cut to LANE_KEEP after sorting."""
    def common(ip: str, ln: Lane) -> dict:
        top = min(ln.rules.items(), key=lambda kv: (-kv[1], kv[0]))[0]
        return {"ip": ip, "alerts": ln.alerts, "top_rule": top,
                "families": sorted({feed.lane_fams[n] for n in ln.rules}), "first": ln.first, "last": ln.last}
    targets = [{"key": f"ct:{ip}", **common(ip, ln), "attackers": len(ln.peers), "crown": ip in crown,
                "answered": ln.flag} for ip, ln in feed.targets.items()]
    targets.sort(key=lambda t: (not t["crown"], -t["attackers"], -t["alerts"], t["ip"]))
    externals = [{**common(ip, ln), "peers": len(ln.peers), "ti": ln.flag} for ip, ln in feed.external.items()]
    externals.sort(key=lambda e: (-e["alerts"], e["ip"]))
    return targets[:LANE_KEEP], externals[:LANE_KEEP]


_FLOW = ["_hour", "Actor IP", "Counterpart IP", "Server Port"]


def _flow_split(alerts: pl.DataFrame, cluster_alerts: pl.DataFrame) -> tuple[pl.DataFrame, pl.DataFrame]:
    """(names, counted): per (cluster, alert name) its max severity weight `w`, and the (cluster, name) pairs that
    count. Several rules on one flow in one hour (same actor, counterpart and port) are one signal said many
    ways: the strongest counts (tie: first name in order), the others are "same flow". A row without a counterpart
    is no flow (a scan has no server): it counts as itself."""
    sev = pl.col("Alert Severity").cast(pl.Utf8).replace_strict(pipeline.SEVERITY_WEIGHTS, default=0,
                                                                return_dtype=pl.Int64)
    j = (cluster_alerts.select("cluster_id", "alert_id")
         .join(alerts.select("alert_id", "Alert Name", "Alert Severity", *_FLOW), on="alert_id")
         .with_columns(pl.col("Alert Name").cast(pl.Utf8), sev.alias("w")).drop("alert_id", "Alert Severity"))
    names = j.group_by("cluster_id", "Alert Name").agg(pl.col("w").max())
    flow = j.filter(pl.col("Counterpart IP").is_not_null())
    win = (flow.group_by("cluster_id", *_FLOW, "Alert Name").agg(pl.col("w").max())
           .sort(["cluster_id", *_FLOW, "w", "Alert Name"], descending=[False] * (len(_FLOW) + 1) + [True, False])
           .unique(["cluster_id", *_FLOW], keep="first", maintain_order=True))
    alone = j.filter(pl.col("Counterpart IP").is_null())
    counted = pl.concat([win.select("cluster_id", "Alert Name"), alone.select("cluster_id", "Alert Name")]).unique()
    return names, counted


def dedup_sigma(feed_actor: pl.DataFrame, cluster_alerts: pl.DataFrame) -> pl.DataFrame:
    """(cluster_id, sigma_sev): the alert-type term, the sum over the counted rules of each one's max severity weight."""
    names, counted = _flow_split(feed_actor, cluster_alerts)
    return (names.join(counted, on=["cluster_id", "Alert Name"]).group_by("cluster_id")
            .agg(pl.col("w").sum().alias("sigma_sev")).sort("cluster_id"))


def same_flow_names(feed_actor: pl.DataFrame, cluster_alerts: pl.DataFrame) -> dict[str, list[str]]:
    """cluster_id -> the names that never count: always beaten by a stronger rule on the same flow-hour."""
    names, counted = _flow_split(feed_actor, cluster_alerts)
    out = names.join(counted, on=["cluster_id", "Alert Name"], how="anti").sort("cluster_id", "Alert Name")
    res: dict[str, list[str]] = {}
    for cid, nm in out.select("cluster_id", "Alert Name").iter_rows():
        res.setdefault(cid, []).append(nm)
    return res


def _dedup(clusters: pl.DataFrame, cluster_alerts: pl.DataFrame, alerts: pl.DataFrame) -> pl.DataFrame:
    """pipeline.build_frame's sigma_fix: the engine's sigma_sev replaced by the one-rule-per-flow-hour term."""
    return (clusters.drop("sigma_sev").join(dedup_sigma(alerts, cluster_alerts), on="cluster_id", how="left")
            .with_columns(pl.col("sigma_sev").fill_null(0).cast(pl.Int64)))


PART_ROWS = 60_000      # rows the engine takes at a time; a bigger frame is split by anchor host


def _engine(actor: pl.DataFrame, now: float, delta_s: int, min_alerts: int, crown, model) -> pipeline.Snapshot:
    """The engine over the actor frame. Clusters are per anchor host, so a big frame goes through in parts of about
    PART_ROWS rows (hosts hashed into parts): the engine's working memory is a few times its input, and it was the
    biggest share of the peak at 2M alerts. The one thing that spans clusters, the 0-100 normalisation of the two
    scores, is done again over all of them."""
    k = min(16, -(-actor.height // PART_ROWS))
    if k <= 1:
        return _by_family(pipeline.build_frame(actor, now, delta_s, min_alerts, crown, model, anchor_cols=("Actor IP",),
                                               related=False, sigma_fix=_dedup))
    part = actor["Actor IP"].to_physical() % k
    snaps = []
    for i in range(k):
        sub = actor.filter(part == i)
        if sub.is_empty():
            continue
        sn = pipeline.build_frame(sub, now, delta_s, min_alerts, crown, model, anchor_cols=("Actor IP",), related=False,
                                  sigma_fix=_dedup)
        if sn.empty:
            continue
        sn = _by_family(sn)
        sfx = pl.col("cluster_id") + f"_p{i}"
        snaps.append(replace(sn, clusters=sn.clusters.with_columns(sfx), cluster_alerts=sn.cluster_alerts.with_columns(sfx),
                             alerts=actor.clear()))      # the whole frame is attached once, below
    if not snaps:
        return replace(pipeline.build_frame(actor.clear(), now, delta_s, min_alerts, crown, model,
                                            anchor_cols=("Actor IP",)), alerts=actor)
    cl = _renorm(pl.concat([x.clusters for x in snaps], how="vertical_relaxed"))
    ca = pl.concat([x.cluster_alerts for x in snaps])
    return replace(snaps[0], alerts=actor, clusters=cl, cluster_alerts=ca, took_s=sum(x.took_s for x in snaps),
                   unknown_names={})


def _renorm(cl: pl.DataFrame) -> pl.DataFrame:
    """pawel_norm, maciej_norm and threat_score over all clusters, as engine/features.add_threat_score makes them."""
    def norm(col: str) -> pl.Expr:
        lo, hi = pl.col(col).min(), pl.col(col).max()
        return pl.when(hi == lo).then(pl.lit(0.0)).otherwise((pl.col(col) - lo) / (hi - lo) * 100.0)
    return cl.with_columns(norm("pawel_score").alias("pawel_norm"), norm("maciej_score").alias("maciej_norm")).with_columns(
        ((pl.col("pawel_norm") + pl.col("maciej_norm")) / 2.0).round(1).alias("threat_score"),
        pl.col("pawel_norm").round(1), pl.col("maciej_norm").round(1))


def _by_family(snap: pipeline.Snapshot) -> pipeline.Snapshot:
    """cluster_type, its label and the other types from the catalog family of the alerts (weighted by alerts); the
    tactics column and the technique count are the product's own ATT&CK mapping (attack_map), since the engine read
    stand-ins for the phase and the templates' tags are not shown."""
    if snap.empty:
        return snap
    j = snap.cluster_alerts.join(snap.alerts.select("alert_id", "Family", "Attack", "_w"), on="alert_id")
    fam = j.group_by("cluster_id", "Family").agg(pl.col("_w").sum().alias("w")).sort(
        ["cluster_id", "w", "Family"], descending=[False, True, False])
    rows = []
    for (cid,), g in fam.group_by("cluster_id", maintain_order=True):
        fams = g["Family"].to_list()
        rows.append({"cluster_id": cid, "cluster_type": fams[0], "cluster_label": rules.FAMILIES[fams[0]][0],
                     "secondary_types": sorted(fams[1:])})
    types = pl.DataFrame(rows, schema={"cluster_id": pl.Utf8, "cluster_type": pl.Utf8, "cluster_label": pl.Utf8,
                                       "secondary_types": pl.List(pl.Utf8)})
    att = (j.select("cluster_id", pl.col("Attack").cast(pl.Utf8)).unique()
           .with_columns(pl.col("Attack").str.split("|").list.get(0).alias("tac"),
                         pl.col("Attack").str.split("|").list.get(1).alias("tech")))
    tac = (att.filter(pl.col("tac") != "").group_by("cluster_id")
           .agg(pl.col("tac").unique().sort().alias("tactics")))
    ntech = (att.filter(pl.col("tech") != "").group_by("cluster_id")
             .agg(pl.col("tech").n_unique().cast(pl.UInt32).alias("n_techniques")))
    cl = (snap.clusters.drop("cluster_type", "cluster_label", "secondary_types", "tactics", "n_tactics",
                             "n_techniques")
          .join(types, on="cluster_id", how="left").join(tac, on="cluster_id", how="left")
          .join(ntech, on="cluster_id", how="left")
          .with_columns(pl.col("tactics").list.len().fill_null(0).cast(pl.UInt32).alias("n_tactics"),
                        pl.col("n_techniques").fill_null(0).cast(pl.UInt32)))
    return replace(snap, clusters=cl)


def _raw(r: tuple) -> dict:
    """A raw ring alert (sycope.FIELDS order) as the detail page lists it: the template's tag is "tpl_tag"."""
    tpl = attack_map.tpl_tag(r[BI["alertMitreId"]], r[BI["alertMitreTechnique"]], r[_TAC])
    return {"t": r[BI["timestamp"]], "name": r[_NAME], "severity": r[BI["alertSeverity"]], "tpl_tag": tpl,
            "client": r[_C], "server": r[_S],
            "port": pipeline._num(r[BI["serverPort"]]), "id": r[BI["id"]], "def_id": r[BI["alertDefId"]]}


def detail(cb: ClusterBoard, key: str, window: Window | None = None, max_alerts: int = 300) -> dict | None:
    """One cluster for the detail panel: the engine's detail, the cluster's buckets (rule, counterpart, port, how
    many alerts, first and last time) and, from the anchor's raw ring, its alerts inside the cluster's time range
    (the ones PCAP links hang on; the ring holds the newest only, so an old cluster can have none)."""
    snap = cb.snapshot
    d = pipeline.detail(snap, key)
    if d is None:
        return None
    c = d["cluster"]
    ids = snap.cluster_alerts.filter(pl.col("cluster_id") == c["cluster_id"]).select("alert_id")
    al = snap.alerts.join(ids, on="alert_id")
    g = (al.group_by("Alert Name", "Counterpart IP", "Server Port")
         .agg(pl.col("_w").sum().alias("n"), pl.col("Time").min().dt.epoch("ms").alias("first"),
              pl.col("Time").max().dt.epoch("ms").alias("last"))
         .sort(["n", "first", "Alert Name"], descending=[True, False, False]))
    d["buckets"] = [{"rule": r["Alert Name"], "counterpart": r["Counterpart IP"], "port": r["Server Port"],
                     "n": r["n"], "first": r["first"], "last": r["last"]} for r in g.iter_rows(named=True)]
    rel = (al.filter(pl.col("Counterpart IP").is_not_null()).group_by("Counterpart IP")
           .agg(pl.col("_w").sum().alias("n")).sort(["n", "Counterpart IP"], descending=[True, False]).head(25))
    d["related"] = [{"ip": r["Counterpart IP"], "count": r["n"]} for r in rel.iter_rows(named=True)]
    names = {t["name"] for t in d["types"]}
    raw = window.host_alerts(c["anchor_ip"], max_alerts) if window is not None else []
    d["alerts"] = [_raw(r) for r in raw if c["start_ms"] <= (r[BI["timestamp"]] or 0) <= c["end_ms"]
                   and r[BI["alertName"]] in names]
    attack = {t["name"]: t["attack"] for t in d["types"]}
    for a in d["alerts"]:       # the raw ring has no rule at hand: the alert's reading is its type's in this cluster
        a["attack"] = attack.get(a["name"], "")
    d["alerts_shown"] = len(d["alerts"])
    d["same_flow"] = same_flow_names(al, snap.cluster_alerts.filter(pl.col("cluster_id") == c["cluster_id"])).get(
        c["cluster_id"], [])
    return d
