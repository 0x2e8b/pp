"""Who acts, confirmed by Sycope.

The page runs inside Sycope (Passthrough) for a signed-in user, but the Passthrough passes on neither the user nor the
session: it drops the browser's Cookie header (a Set-Cookie still reaches the browser, so a cookie never comes back),
and Sycope's session cookie is HttpOnly, out of the page's reach. What Sycope does keep is a line in its audit log
(stream auditMessages) for every change a user makes to their own preferences, with the user and what was written.
So, once per browser session (a pass lasts PASS_HOURS):

  1. GET whoami: the service answers with a claim (a time and a random part, kept by the page) and its proof, an HMAC
     of the claim with the service's key;
  2. the page writes the proof into the signed-in user's own preferences in Sycope (PUT /npm/api/v1/user-preferences,
     key PROOF_KEY): only that user's session can, and Sycope logs who did it;
  3. GET whoami with the claim (header X-SC-Claim): the service works the proof out again, finds the audit line that
     wrote it (with its own Sycope login), takes the user from that line and the roles from Sycope's user record, and
     answers with a pass it signed;
  4. every action carries the pass (header X-SC-Pass); the name and the admin role come from the pass, not from what
     the page says.

The claim never goes to Sycope: whoever reads the audit log sees the proof, but cannot redeem it without the claim.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
import time
from collections.abc import Callable
from pathlib import Path

PROOF_KEY = "sc-triage-proof"   # the preference the page writes (the same key every time: nothing piles up)
PASS_HOURS = 8                  # a shift
CLAIM_SECONDS = 180             # how long a claim can be redeemed
AUDIT_NQL = ('src stream="auditMessages" | where methodName = "updateUserPreferences" | sort timestamp desc '
             '| limit 500')
_CLAIM = re.compile(r"(\d{10})\.([0-9a-f]{24})")


class IdentityError(Exception):
    """A claim that cannot be redeemed (malformed, too old) or a user Sycope does not allow; the message says which."""


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def load_key(state_dir: str) -> bytes:
    """The service's signing key: <state_dir>/identity.key, made once (32 random bytes, mode 600). Without a state
    directory a key for this process only: its passes end with a restart."""
    if not state_dir:
        return secrets.token_bytes(32)
    p = Path(state_dir) / "identity.key"
    try:
        k = p.read_bytes()
        if len(k) >= 32:
            return k
    except FileNotFoundError:
        pass
    k = secrets.token_bytes(32)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(k)
    return k


class Identity:
    """audit(start, end) gives Sycope's audit lines of preference changes (dicts with user, message), user(name) the
    user's record (roles, firstName, lastName, enabled); both with the service's own login."""

    def __init__(self, key: bytes, audit: Callable[[float, float], list[dict]], user: Callable[[str], dict],
                 now: Callable[[], float] = time.time) -> None:
        self._key, self._audit, self._user, self._now = key, audit, user, now
        self._lock = threading.Lock()
        self._seen: tuple[float, list[dict]] = (0.0, [])   # the last audit read, shared by pages checking at once

    def _mac(self, kind: str, data: str) -> bytes:
        return hmac.new(self._key, f"{kind}:{data}".encode(), hashlib.sha256).digest()

    def proof(self, claim: str) -> str:
        return self._mac("proof", claim).hex()[:32]

    def challenge(self) -> dict:
        claim = f"{int(self._now())}.{secrets.token_hex(12)}"
        return {"claim": claim, "proof": self.proof(claim), "key": PROOF_KEY, "seconds": CLAIM_SECONDS}

    def _lines(self) -> list[dict]:
        with self._lock:
            at, rows = self._seen
            now = self._now()
            if now - at >= 2:
                rows = self._audit(now - 600, now + 60)
                self._seen = (now, rows)
            return rows

    def redeem(self, claim: str) -> dict:
        """The pass once Sycope's audit shows the claim's proof written ({"verified": True, "pass", "user", "name",
        "admin", "exp"}), {"verified": False, "pending": True} until then."""
        m = _CLAIM.fullmatch(claim or "")
        if not m:
            raise IdentityError("not a claim of this service")
        age = self._now() - int(m.group(1))
        if age > CLAIM_SECONDS or age < -60:
            raise IdentityError("the check took too long: reload the page to start it again")
        proof = self.proof(claim)
        for r in self._lines():
            msg = r.get("message")
            msg = msg if isinstance(msg, str) else json.dumps(msg)
            user = r.get("user")
            user = user[0] if isinstance(user, list) and user else user
            if proof in msg and PROOF_KEY in msg and isinstance(user, str) and user:
                return self.issue(user)
        return {"verified": False, "pending": True}

    def issue(self, username: str) -> dict:
        rec = self._user(username) or {}
        if rec.get("enabled") is False:
            raise IdentityError("this Sycope user is disabled")
        roles = [r.get("name") if isinstance(r, dict) else r for r in rec.get("roles") or []]
        name = " ".join(x for x in (rec.get("firstName"), rec.get("lastName")) if x)
        exp = int(self._now() + PASS_HOURS * 3600)
        payload = {"u": username, "n": name, "a": "ROLE_ADMIN" in roles, "exp": exp}
        body = _b64(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode())
        return {"verified": True, "pass": f"v1.{body}.{_b64(self._mac('pass', body))}", "user": username,
                "name": name, "admin": payload["a"], "exp": exp}

    def check(self, token: str | None) -> dict | None:
        """What a valid, unexpired pass says ({"u", "n", "a", "exp"}), else None."""
        if not token or len(token) > 1200:
            return None
        parts = token.split(".")
        if len(parts) != 3 or parts[0] != "v1":
            return None
        try:
            if not hmac.compare_digest(_unb64(parts[2]), self._mac("pass", parts[1])):
                return None
            p = json.loads(_unb64(parts[1]))
        except (ValueError, TypeError):
            return None
        if not isinstance(p, dict) or not isinstance(p.get("u"), str) or not p["u"]:
            return None
        if not isinstance(p.get("exp"), int) or p["exp"] < self._now():
            return None
        return p
