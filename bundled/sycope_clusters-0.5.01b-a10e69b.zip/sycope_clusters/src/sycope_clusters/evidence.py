"""The triage model: alerts -> findings -> evidence per host -> verdicts, stories and the analyst's lanes.

Deterministic and explainable term by term. One finding = one rule between one host and one counterpart (and
port) over the window; 150,000 alerts a day make ~8,000 findings. Each finding carries bits of evidence (log2 of
a likelihood ratio):

    bits = min(class bits + severity + threshold level,  rarity cap,  novelty cap)  - deductions

    rarity cap   log2(1/p), p = share of hosts (of the host's role) with the same rule and counterpart on a
                 comparable day, from the learned profile: shrunk toward the shipped prior, so a small network leans
                 on the prior and a large one on its own days (profile.rarity; never today, so a worm cannot make its
                 own alerts look common). An alert one host in five has can carry at most 2.3 bits; an indicator
                 match never less than ti_min_cap_bits.
    novelty cap  log2((D+2)/(d+1)): d of the last D comparable days (not dormant, same day class) this host already
                 had the rule. New = ~3 bits, every day = 0.17 bit. Threat intel never drops below half its weight
                 (a beacon that runs for weeks).
    deductions   shared cloud/CDN counterpart outside our networks (-1 for intel, beacon, covert), an "upload" that
                 is a download (re-read as a traffic anomaly), a DNS resolver relaying its clients' lookups.

An "exfiltration" upload confirms Impact from max(exfil_floor_bytes, the host's normal daily upload) on, +1 bit at
10x that, +2 at 100x. Every capped term leaves a trace line naming where its number came from (learned, prior,
factory, env, admin).

Per host: the strongest finding of each family counts (rules that see the same thing do not add up), families add
up (independent evidence), plus kill-chain progression and chain rules (CR-01..CR-10, CR-08/09 stronger when the
second step hits a host the first step touched). Confidence = 1 / (1 + 2^-(E - 8)): a prior of 1 in 256, so 8 bits
is a coin toss, 10 bits 80%, 12 bits 94%. Risk = confidence x impact of the confirmed stage (crown jewel x 1.5).
A stage is confirmed when a finding of it carries >= 2 bits. The verdict comes from a decision table with the
reason in words. Campaigns: more hosts of one network segment at Investigate or above than its size and the usual
daily share explain (a binomial tail under campaign_p).
"""

from __future__ import annotations

import ipaddress
import math
import re
from collections import Counter, defaultdict
from collections.abc import Collection, Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from functools import lru_cache
from operator import itemgetter

from sycope_clusters import attack_map, fmt, silence
from sycope_clusters import calendar as cal
from sycope_clusters import priors as _priors
from sycope_clusters import shared_infra as _infra
from sycope_clusters.addresses import AddressBook, prefix
from sycope_clusters.aliases import extend
from sycope_clusters.campaigns import binom_tail  # noqa: F401  (part of this module's interface)
from sycope_clusters.campaigns import campaigns as _campaigns
from sycope_clusters.params import CLOUD_ASN_NAMES, FACTORY, Params, factory
from sycope_clusters.profile_roles import WORKSTATION, text_role
from sycope_clusters.rules import FAMILIES, OBJECTIVES, STAGES, Catalog, Rule, stored_rule
from sycope_clusters.sycope import FIELDS

IX = {f: i for i, f in enumerate(FIELDS)}
# a row of this length is an hourly bucket of ingest.py (FIELDS + _n, _first, _last), not one alert
BUCKET_LEN = len(FIELDS) + 3
SEV_W = {"Info": 1, "Low": 2, "Medium": 3, "High": 4, "Critical": 5}
SEV_NAME = {v: k for k, v in SEV_W.items()}
SEV_ADJ = {**{s: factory(f"sev_adj.{s}") for s in range(1, 6)}, 0: 0.0}
THR_LEVEL = {"Minor": 1, "Major": 2, "Critical": 3}
THR_NAME = {1: "Minor", 2: "Major", 3: "Critical"}
THR_ADJ = {0: 0.0, **{t: factory(f"thr_adj.{t}") for t in range(1, 4)}}
# The model constants are the factory values of the parameter registry (params.py); the scoring reads a Params.
CONFIRM = factory("confirm_bits")        # bits a finding needs to confirm its stage
EXFIL_MIN = factory("exfil_floor_bytes")  # an "exfiltration" alert below this upload never confirms Impact
EXFIL_X1, EXFIL_X2 = 10, 100             # an upload this many times its bar adds 1 / 2 bits
PRIOR = factory("prior_bits")            # prior log-odds in bits (1 in 256)
IMPACT = {None: factory("impact.none"), **{k: factory(f"impact.{k}") for k in range(4)}}
CROWN = factory("crown_mult")
VERDICTS = ("act", "investigate", "review", "watch")
VRANK = {"act": 3, "investigate": 2, "review": 1, "watch": 0}
HANDLED = ("ack", "tp", "benign", "fp", "resolved")   # out of the queue until the host shows something new

# Counterparts whose IPs are shared by thousands of sites or tenants (names; the set is the cloud_asns parameter)
CLOUD_ASNS = CLOUD_ASN_NAMES

_CHAIN_TEXT = {
    "CR-01": ("Data theft in progress", "command channel and a large upload"),
    "CR-02": ("Full kill chain (24 h)", "three of: scanning, credentials or lateral, command channel, exfiltration"),
    "CR-03": ("Full kill chain (7 days)", "three of the four kill-chain groups within the last 7 days"),
    "CR-04": ("Staged exfiltration", "data collected internally, then uploaded out"),
    "CR-05": ("Confirmed C2", "threat-intel contact and beacon or covert channel"),
    "CR-06": ("Compromised, then calling home",
              "attacked over credentials or lateral movement, then itself calls a command channel or a listed C2"),
    "CR-08": ("Credential theft, then lateral movement", "credential attack first, lateral movement later"),
    "CR-09": ("Recon, then exploitation", "scanning first, then credential attack or lateral movement"),
    "CR-10": ("Persistent channel", "the same command or intel contact on 5 or more of the last 7 days"),
}
# id -> (title, bonus in bits, what it means); the bonus is the chain.<id>.bonus parameter
CHAINS = {c: (title, factory(f"chain.{c}.bonus"), what) for c, (title, what) in _CHAIN_TEXT.items()}
WEEK_GROUPS = ({"CL-04"}, {"CL-05", "CL-10"}, {"CL-02", "CL-03"}, {"CL-06"})
PERSIST_DAYS = factory("persist_days")
ACT_CHAINS = factory("act_chains")

SHORT = {"Suspicious SSH Protocol Change": "unusual SSH", "SSH Protocol Change": "unusual SSH",
         "Unauthorized LLMNR/NetBIOS Activity": "LLMNR/NetBIOS traffic", "LLMNR/NetBIOS": "LLMNR/NetBIOS traffic",
         "Possible Lateral Movement": "lateral-movement pattern", "Rogue RDP Access": "RDP",
         "Suspicious Host": "suspicious-host pattern", "Kerberos External": "Kerberos to the internet",
         "LDAP External": "LDAP to the internet", "Frequent Short-Lived Connections": "many short connections",
         "Long-Duration Session": "very long session", "Repeated Connection": "repeated connections",
         "Small Payload Beaconing": "small-payload beaconing", "C2 Polling": "C2-like polling"}
extend(SHORT)      # the official names of the rules above (aliases.py)

# a learned role as the tag a host card shows
ROLE_TAG = {"resolver": "DNS resolver", "dhcp": "DHCP server", "directory": "directory server",
            "database": "database server", "file": "file server", "web": "web server", "mail": "mail server",
            "proxy": "proxy / NAT gateway", "iot-ot": "IoT/OT device"}


_PROFILE = None


def _pf():
    """The profile module (it imports this one, so it is imported when first needed)."""
    global _PROFILE
    if _PROFILE is None:
        from sycope_clusters import profile
        _PROFILE = profile
    return _PROFILE


@lru_cache(maxsize=1)
def default_priors() -> _priors.Priors:
    return _priors.load()


def empty_profile(today: str, p: Params, pr: _priors.Priors, catalog: Catalog, book: AddressBook):
    """A cold start: the profile learned from no history at all, so every norm is its prior."""
    from sycope_clusters.store import Store
    return _pf().learn(Store(None), today, pr, p, book, catalog)


def day_key(ms: float) -> str:
    return datetime.fromtimestamp(ms / 1000, UTC).strftime("%Y-%m-%d")


def prev_day(day: str, n: int = 1) -> str:
    return (datetime.strptime(day, "%Y-%m-%d") - timedelta(days=n)).strftime("%Y-%m-%d")


def fmt_bytes(n: float | None) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" or n >= 100 else f"{n:.1f} {unit}"
        n /= 1000
    return f"{n:.1f} TB"


def pct(x: float) -> str:
    return f"{x * 100:.0f}%" if x >= 0.01 else f"{x * 100:.1f}%" if x >= 0.001 else "<0.1%"


class Nets(AddressBook):
    """Which IPs are ours: private ranges, SC_INTERNAL_NETS, and (optionally) any IP Sycope gives a location. The
    address book without lookup entries; kept for callers that only have those settings."""

    def __init__(self, extra: str = "", located: set[str] | None = None) -> None:
        super().__init__([], extra, located)


def direction_of(client: str | None, server: str | None, nets: AddressBook) -> str:
    """Which way one alert's pair crosses the edge of our networks: "internal" (both sides ours), "outbound" (our
    client reaches an outside server), "inbound" (an outside client reaches our server), "" when a side is missing
    or both are outside."""
    if not client or not server:
        return ""
    ci, si = nets.internal(client), nets.internal(server)
    return "internal" if ci and si else "outbound" if ci else "inbound" if si else ""


def resolve(rule: Rule, client: str | None, server: str | None, down, nets: AddressBook) -> tuple[Rule, str]:
    """(the rule as it reads for this pair, the pair's direction). A rule with variants changes family, class,
    stage and kind with the direction; an inbound variant needs the internal server to have answered (`down`, the
    bytes it sent back), else the exposure is not shown and the base rule stays (a variant that only sets the ATT&CK
    technique and tactic still applies: see Rule.for_direction)."""
    d = direction_of(client, server, nets)
    if rule.variants and d:
        return rule.for_direction(d, not (d == "inbound" and not down)), d
    return rule, d


def actor_of(rule: Rule, client: str | None, server: str | None, nets: AddressBook) -> tuple[str | None, str | None]:
    """(internal actor, its counterpart) of one alert for the threat lane, or (None, None) when no internal host
    acts (inbound attacks: the internal side is a target, see attribute())."""
    ci, si = nets.internal(client), nets.internal(server)
    if rule.subject == "server" and si:
        return server, client
    if ci:
        return client, server
    return None, None


def edge_forbidden(rule: Rule, p: Params) -> bool:
    """A protocol that must not cross the edge (SMB, NFS), seen going out: it weighs whatever its volume."""
    return rule.reclassified and rule.direction == "outbound" and rule.name in p["edge_forbidden_rules"]


def attribute(rule: Rule, client: str | None, server: str | None, nets: AddressBook):
    """Lanes of one alert: (lane, subject, counterpart) tuples. lane a = an internal host acts (threat), t = an
    internal host is the target, h = hygiene finding about a host, x = only external IPs (kept for the external
    lane)."""
    ci, si = nets.internal(client), nets.internal(server)
    out = []
    if rule.hygiene:
        subj = server if (rule.subject == "server" and si) else client if ci else server if si else None
        if subj:
            out.append(("h", subj, server if subj == client else client))
        return out
    if rule.subject == "server" and si:
        out.append(("a", server, client))
        return out
    if ci:
        out.append(("a", client, server))
        if si and server and server != client:
            out.append(("t", server, client))
    elif si:
        out.append(("t", server, client))
    elif client or server:
        out.append(("x", client or server, server if client else None))
    return out


# ---- what the store remembers about each host (set by Live before every board) --------------------------------------

@dataclass(frozen=True)
class Hold:
    """What the stored decisions say about one host, for the hysteresis (apply_hold). `changed_at` is when the
    service last changed its verdict, `analyst_at` the newest analyst action on the host (a status, or the closure of
    an incident it was in), `shown` the highest verdict rank the host was shown in the last `hysteresis.step_h` (-1:
    none), `armed` that the host was Act now: when it last was (`act_at`) and when evidence at Review or above was
    last seen (`evid_at`, the 72 h clock). `trail`: the verdicts logged for the host that `shown` reads, ((at, rank), ...)
    oldest first: those since the window began and the one in force when it began. `shown_after(t)` is what `shown`
    would be for an action at t (an exception counts as one, see apply_hold)."""
    changed_at: float = 0.0
    analyst_at: float = 0.0
    shown: int = -1
    armed: bool = False
    act_at: float = 0.0
    evid_at: float = 0.0
    trail: tuple = ()

    def shown_after(self, t: float) -> int:
        """The highest verdict rank shown by rows logged after `t` (-1 none): what the service said before an action
        does not count toward holding the host after it."""
        return max((r for a, r in self.trail if a > t), default=-1)


@dataclass
class Memory:
    """Facts from the stored incidents and verdicts that the scoring reads. Empty: the board is scored on the
    alerts and the past days alone (a fresh install, the fixtures, replays)."""
    undecided: dict = field(default_factory=dict)    # host -> UTC days it was in an incident nobody decided
    recurring: dict = field(default_factory=dict)    # host -> its recent incidents that ended without a decision
    holds: dict = field(default_factory=dict)        # host -> Hold


# ---- history: what a normal day looks like ---------------------------------------------------------------------

class History:
    """Built from the stored past days. Answers: on how many of the comparable past days did this host have this
    rule (novelty), which strong families it showed during the week (CR-03), which intel/C2 channels it kept
    (persistence), and the first steps of the two-step chain rules. Rarity comes from the profile (profile.rarity);
    the History's own shares of hosts per day only feed the known-service candidates.

    Days: novelty looks at the last 7 comparable days (calendar.comparable: not dormant, today's day class when 3
    of them exist); the week windows (persistence, CR-03) at the last 7 days that are not dormant. The calendar is
    the profile's when one is given, else learned from the rows' own acting hosts per day.

    `rows` is a list (any order) or an iterator grouped by day (Store.iter_day_rows): read once, so 14 stored days of
    a big network are never held at the same time."""

    def __init__(self, rows: Iterable[tuple], days: list[str], today: str, catalog: Catalog, nets: AddressBook,
                 p: Params = FACTORY, *, profile=None, priors: _priors.Priors | None = None,
                 calendar: cal.Calendar | None = None) -> None:
        pf = _pf()
        self.today = today
        self.nets = nets
        self.priors = priors or default_priors()
        if isinstance(rows, list):     # grouped by day (stable): a day's seen-set is dropped when the next day starts
            rows = sorted(rows, key=itemgetter(0))
        if calendar is None and profile is None:
            rows = list(rows)          # two passes: the acting hosts per day first
        if calendar is None:
            calendar = profile.calendar if profile is not None else cal.learn(_acting(rows, catalog, nets), p)
        self.profile = profile if profile is not None else empty_profile(today, p, self.priors, catalog, nets)
        self.calendar = calendar
        self.days = sorted(d for d in days if d < today)
        self.hab_days, self.week_days, self.prev_days = _windows(self.days, today, calendar)
        self.yesterday = prev_day(today)
        hab_set = set(self.hab_days) - {self.yesterday}
        # days as bits of an int (a set of day strings costs ~200 B, an int 28): `.bit_count()` is the number of days
        bit: dict[str, int] = {}
        self.day_bit = bit
        self.memory = Memory()
        self._skip: dict[str, int] = {}
        self.hab: dict[tuple, int] = defaultdict(int)
        self.yfirst: dict[tuple, int] = {}
        day_actors: dict[str, set] = defaultdict(set)
        sig_day: dict[tuple, Counter] = defaultdict(Counter)
        seen_sig_actor: set = set()     # (signature, host) of the day in hand: rows come grouped by day
        seen_day = None
        self.ext_seen: set[str] = set()
        self.host_days: dict[str, int] = defaultdict(int)
        self.pair_days: dict[tuple, int] = defaultdict(int)   # (actor, rule, counterpart) of intel/C2/covert rules
        week_rows: list[tuple] = []                            # (actor, family, listed-C2 flag, signature, rule) of strong rules
        steps: list[tuple] = []                                # (actor, family, first_ms, counterpart, signature, rule)
        prev_set = set(self.prev_days)
        week = set(self.week_days)
        floor = p["exfil_floor_bytes"]
        up_bar: dict[str, float] = {}
        for day, rule_name, client, server, port, n, first_ms, last_ms, up, down, *extra in rows:
            if day != seen_day:
                seen_sig_actor.clear()
                seen_day = day
                b = bit.setdefault(day, 1 << len(bit))
            rule = stored_rule(catalog, rule_name, extra[-1] if len(extra) == 5 else None)
            rule_name = rule.name       # the catalog's name for it: one rule across a rename in Sycope
            rule, _dir = resolve(rule, client or None, server or None, down, nets)
            for ip in (client, server):
                if ip and not nets.internal(ip):
                    self.ext_seen.add(ip)
            if rule.hygiene:
                # only the share of hosts hitting one service matters here (known-service candidates)
                lane = attribute(rule, client or None, server or None, nets)
                if lane and day in prev_set:
                    _, subj, cp = lane[0]
                    srv_side = rule.subject == "server" and subj == server
                    who, srv = (cp, subj) if srv_side else (subj, cp)
                    if who and srv:
                        sig = (rule_name, srv, port or "")
                        if (sig, who) not in seen_sig_actor:
                            seen_sig_actor.add((sig, who))
                            sig_day[sig][day] += 1
                continue
            actor, cp = actor_of(rule, client or None, server or None, nets)
            if actor is None:
                continue
            key = (actor, rule_name)
            if day in week and rule.cls in ("A", "B"):
                if rule.family in ("CL-01", "CL-02", "CL-03") and cp:
                    self.pair_days[(actor, rule_name, cp)] |= b
                exfil_ok = True
                if rule.kind == "exfil" and not edge_forbidden(rule, p):
                    bar = up_bar.get(actor)
                    if bar is None:
                        bar = up_bar[actor] = max(floor, pf.exfil_norm(self.profile, actor)[0])
                    exfil_ok = (up or 0) >= bar and (up or 0) * 2 >= (down or 0)
                sig = (rule_name, cp or "", port or "") if cp else (rule_name,)
                fam, stg = rule.family, rule.stage
                if rule.kind == "exfil" and edge_forbidden(rule, p):   # small volume: exposure, not exfiltration
                    bar = up_bar.get(actor)
                    if bar is None:
                        bar = up_bar[actor] = max(floor, pf.exfil_norm(self.profile, actor)[0])
                    if (up or 0) < bar:
                        fam, stg = "CL-05", 2
                if stg is not None and exfil_ok:
                    week_rows.append((actor, fam, rule.c2 and fam == "CL-01", sig, rule))
                if fam in ("CL-04", "CL-05") and first_ms:
                    steps.append((actor, fam, first_ms, cp, sig, rule))
            if day in hab_set:
                self.hab[key] |= b
                self.host_days[actor] |= b
            elif day == self.yesterday:
                self.host_days[actor] |= b
                if first_ms:  # a row without a timestamp says nothing about before the window
                    self.yfirst[key] = min(self.yfirst.get(key, first_ms), first_ms)
            if day in prev_set:
                day_actors[day].add(actor)
                sig = (rule_name, cp or "", port or "") if cp else (rule_name,)
                if (sig, actor) not in seen_sig_actor:
                    seen_sig_actor.add((sig, actor))
                    sig_day[sig][day] += 1
        self.day_actors = {d: len(s) for d, s in day_actors.items()}
        # share of acting hosts with a signature per day, Laplace-smoothed (known-service candidates only)
        valid = [d for d in self.prev_days if self.day_actors.get(d)]
        self.sig_share: dict[tuple, float] = {}
        if valid:
            base = sum(1 / (self.day_actors[d] + 2) for d in valid)
            for sig, c in sig_day.items():
                self.sig_share[sig] = (base + sum(c[d] / (self.day_actors[d] + 2) for d in valid if d in c)) / len(valid)
        self.sig_days = {sig: len(c) for sig, c in sig_day.items()}
        # the same count over the comparable days only: the numerator that goes with `depth` on screen
        hab_all = set(self.hab_days)
        self.sig_days_hab = {sig: sum(1 for d in c if d in hab_all) for sig, c in sig_day.items()}
        memo: dict[tuple, float] = {}

        def rare(actor: str, sig: tuple, rule: Rule) -> float:
            r = pf.role(self.profile, actor)
            v = memo.get((r, sig))
            if v is None:
                v = memo[(r, sig)] = pf.rarity(self.profile, sig, r, rule.key, rule.kind, self.priors).p
            return v

        # the strong, uncommon families each host showed during the week (for the 7-day kill chain)
        self.week_fams: dict[str, set] = defaultdict(set)
        for actor, fam, c2w, sig, rule in week_rows:
            if rare(actor, sig, rule) < p["week_share"]:
                self.week_fams[actor].add((fam, c2w))
        # the first steps of the two-step chain rules (scanning, credential attacks) per host: those rare enough to
        # have confirmed their stage in the window (rarity cap log2(1/p) >= confirm_bits)
        self.steps: dict[str, list[tuple]] = defaultdict(list)
        for actor, fam, first_ms, cp, sig, rule in steps:
            if rare(actor, sig, rule) <= 2 ** -p["confirm_bits"]:
                self.steps[actor].append((fam, first_ms, cp))

    @staticmethod
    def wanted(days: list[str], today: str, calendar: cal.Calendar) -> list[str]:
        """The stored days whose rows a History needs: the comparable days, the week and the two weeks behind the
        known-service shares (all of them before today and not dormant)."""
        hab, week, prev = _windows(sorted(d for d in days if d < today), today, calendar)
        return sorted({*hab, *week, *prev})

    @property
    def depth(self) -> int:
        return len(self.hab_days)

    def set_memory(self, memory: Memory) -> None:
        """The stored decisions to read from now on: the days a host sat in an incident nobody decided do not teach
        habit (novelty). Cheap: a bit mask per host with such days."""
        self.memory = memory
        self._skip = {a: m for a, days in memory.undecided.items()
                      if (m := sum(self.day_bit.get(d, 0) for d in days)) or self.yesterday in days}

    def novelty(self, actor: str, rule_name: str, window_start_ms: float) -> tuple[int, int]:
        """(days seen, days looked at) before the current window. The days the host was in an incident that ended
        with nobody deciding are not counted as seen (see skipped)."""
        skip = self._skip.get(actor, 0)
        d = (self.hab.get((actor, rule_name), 0) & ~skip).bit_count()
        D = len(self.hab_days)
        if self.yesterday in self.hab_days and not self._yesterday_skipped(actor):
            f = self.yfirst.get((actor, rule_name))
            if f is not None and f < window_start_ms:
                d += 1
        return d, D

    def _yesterday_skipped(self, actor: str) -> bool:
        return self.yesterday in self.memory.undecided.get(actor, ())

    def skipped(self, actor: str, rule_name: str, window_start_ms: float) -> int:
        """How many of the comparable days this host had the rule on a day it was in an incident nobody decided."""
        skip = self._skip.get(actor)
        if not skip and not self._yesterday_skipped(actor):
            return 0
        n = (self.hab.get((actor, rule_name), 0) & (skip or 0)).bit_count()
        if self.yesterday in self.hab_days and self._yesterday_skipped(actor):
            f = self.yfirst.get((actor, rule_name))
            if f is not None and f < window_start_ms:
                n += 1
        return n

    def share(self, sig: tuple) -> float | None:
        return self.sig_share.get(sig)

    def first_step(self, actor: str, family: str, since_ms: float, until_ms: float) -> tuple[int, set] | None:
        """The earliest stored alert of `family` this host had between the two times (before the window) and the
        counterparts it touched then, or None."""
        got = [(t, cp) for fam, t, cp in self.steps.get(actor, ()) if fam == family and since_ms <= t < until_ms]
        if not got:
            return None
        return min(t for t, _ in got), {cp for _, cp in got if cp}


def _windows(days: list[str], today: str, calendar: cal.Calendar) -> tuple[list[str], list[str], list[str]]:
    """(comparable days for novelty, the week of non-dormant days, two weeks of non-dormant days), oldest first."""
    live = [d for d in days if d not in calendar.dormant]
    return sorted(cal.comparable(calendar, today, days, 7)), live[-7:], live[-14:]


def row_rule_id(row: tuple) -> str | None:
    """The template id of a stored day_findings row (Store.day_rows: the last column), None for a short row."""
    return row[14] if len(row) > 14 else None


def _acting(rows: list[tuple], catalog: Catalog, nets: AddressBook) -> dict[str, int]:
    """Acting hosts per stored day (the calendar's input when no profile brings one)."""
    acts: dict[str, set] = defaultdict(set)
    for row in rows:
        day, rule_name, client, server = row[:4]
        rule = stored_rule(catalog, rule_name, row_rule_id(row))
        rule, _dir = resolve(rule, client or None, server or None, row[9] if len(row) > 9 else None, nets)
        if rule.hygiene:
            continue
        actor, _cp = actor_of(rule, client or None, server or None, nets)
        if actor is not None:
            acts[day].add(actor)
    return {d: len(a) for d, a in sorted(acts.items())}


# ---- findings ---------------------------------------------------------------------------------------------------

NO_TARGETS: frozenset = frozenset()
_LINE_KEYS = ("term", "value", "source", "text", "conf")
_LINE_IX = {k: i for i, k in enumerate(_LINE_KEYS)}


class Line(tuple):
    """One trace line {term, value, source, text[, conf]} as an immutable tuple: it reads like the dict it was
    (line["term"], dict(line), .get) and the same line is shared by every finding it explains (300k findings carry
    about 30k distinct lines)."""
    __slots__ = ()

    def __new__(cls, term: str, value: float, source: str, text: str, conf: float | None = None):
        return tuple.__new__(cls, (term, value, source, text, conf))

    def __getitem__(self, k):
        if type(k) is str:
            v = tuple.__getitem__(self, _LINE_IX[k])
            if v is None and k == "conf":
                raise KeyError(k)
            return v
        return tuple.__getitem__(self, k)

    def get(self, k: str, default=None):
        try:
            return self[k]
        except KeyError:
            return default

    def keys(self):
        return _LINE_KEYS if tuple.__getitem__(self, 4) is not None else _LINE_KEYS[:4]

    def __repr__(self) -> str:
        return repr(dict(self))


def _days(n: int) -> str:
    return f"{n} day" + ("" if n == 1 else "s")


def _push(f, name: str, v) -> None:
    """Append to a finding's trace, notes or deds: tuples (an empty one shared by every finding that has none)."""
    setattr(f, name, (*getattr(f, name), v))


@dataclass(slots=True)
class Finding:
    lane: str
    subject: str
    rule: Rule
    cp: str | None
    port: str
    n: int = 0
    first: int = 0
    last: int = 0
    sev: int = 0
    thr: int = 0
    up: int = 0
    down: int = 0
    sessions: int = 0
    uniq: int = 0
    asn: int | None = None
    country: str | None = None
    targets: set | frozenset = NO_TARGETS   # one shared empty set until the first target (memory at 300k findings)
    # scoring
    family: str = ""
    stage: int | None = None
    cls: str = ""
    kind: str = ""
    base: float = 0.0
    bits: float = 0.0
    caps: tuple = ()
    deds: tuple = ()
    notes: tuple = ()
    days_seen: int = 0
    days_looked: int = 0
    days_skipped: int = 0       # comparable days left out of days_seen: the host was in an incident nobody decided
    excepted: dict | None = None
    sil: tuple = ()             # the silence rules (ids) that matched the alerts of this finding (1.4): its key part
    counted: bool = False
    as_server: bool = False     # the subject is the alert's server (client = cp)
    direction: str = ""         # inbound, outbound or internal across the edge of our networks ("" = unknown)
    persistent: int = 0         # days of the last week with the same intel/C2 channel (0 = not persistent)
    tpl_tactic: str = ""        # the template's own MITRE tag of the first alert (the "template tag": detail views
    tpl_technique: str = ""     # only; never the stage and not what the UI shows, see rule.technique and attack_map)
    tpl_mitre: str = ""
    trace: tuple = ()   # a Line {"term", "value", "source", "text"} of every capped term

    @property
    def unseen(self) -> bool:
        """New for this host: it never had the rule on the comparable days. Days left out of the habit count (an
        incident nobody decided) still mean it had it, so only the unmasked count says "new"."""
        return self.days_looked >= 3 and self.days_seen + self.days_skipped == 0

    @property
    def sig(self) -> tuple:
        return (self.rule.name, self.cp or "", self.port or "") if self.cp else (self.rule.name,)

    @property
    def tpl_tag(self) -> str:
        """The template's MITRE tag as the alert carried it ("T1021 Remote Services (Lateral Movement)"), "" if none."""
        return attack_map.tpl_tag(self.tpl_mitre, self.tpl_technique, self.tpl_tactic)


def _int(v) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def _port(r) -> str:
    p = r[IX["serverPort"]]
    if p not in (None, ""):
        return str(p)
    ps = r[IX["serverPorts"]]
    if ps:
        first = str(ps).split(",")[0].strip()
        return first if first.isdigit() else ""
    return ""


def alert_total(rows: list[tuple]) -> int:
    """The alerts the rows stand for: one each, or `_n` for a bucket row."""
    return sum(r[BUCKET_LEN - 3] if len(r) >= BUCKET_LEN else 1 for r in rows)


def collect(rows: list[tuple], catalog: Catalog, nets: AddressBook, silencer: silence.Silencer | None = None):
    """Findings of every lane, and the external IPs' records. A row is one alert (FIELDS order) or an hourly bucket
    of ingest.py: the same fields plus how many alerts it stands for and the time of the first and the last, and
    (when the window matched silence rules, Window.rows) the tuple of the silence rule ids that match it. A row without
    that last element is matched here by `silencer` (alerts, a replay); findings of different silence rules are
    kept apart, a rule never takes the alerts of a finding it did not match."""
    fx: dict[tuple, Finding] = {}
    ext: dict[str, dict] = {}
    locs: dict[str, str] = {}
    per_rule: Counter = Counter()
    i_cloc, i_sloc = IX["clientLocation"], IX["serverLocation"]
    i_name, i_sev, i_tac, i_c, i_s, i_ts = (IX[k] for k in ("alertName", "alertSeverity", "alertMitreTactic",
                                                             "clientIp", "serverIp", "timestamp"))
    i_tech, i_mid, i_rid = IX["alertMitreTechnique"], IX["alertMitreId"], IX["alertRuleId"]
    i_thr, i_up, i_down, i_sasn, i_scc, i_casn, i_ccc, i_sips, i_uniq, i_sess = (
        IX[k] for k in ("alertFlagThresholdLevel", "sumClientBytes", "sumServerBytes", "serverAsName", "serverCountry",
                        "clientAsName", "clientCountry", "serverIps", "_uniqueServerIps", "_countSessions"))
    i_proto = IX["protocolName"]
    match = silencer is not None and silencer.has_silence
    for r in rows:
        rule = catalog.get(r[i_name], r[i_tac], r[i_rid])
        if len(r) >= BUCKET_LEN:
            cnt, t_first, t_last = r[BUCKET_LEN - 3:BUCKET_LEN]
            sil = r[BUCKET_LEN] if len(r) > BUCKET_LEN else None
        else:
            cnt, t_first, sil = 1, r[i_ts] or 0, None
            t_last = t_first
        if sil is None:
            sil = (silencer.silence_ids(r[i_name], r[i_c] or None, r[i_s] or None, _port(r) or None,
                                        silence.proto_of(r[i_proto]), t_first, t_last) if match else ())
        per_rule[rule.name] += cnt
        client, server = r[i_c] or None, r[i_s] or None
        port = _port(r)
        sev = SEV_W.get(r[i_sev], 0)
        thr = THR_LEVEL.get(r[i_thr], 0)
        up, down = _int(r[i_up]), _int(r[i_down])
        sess, uniq = _int(r[i_sess]), _int(r[i_uniq])
        sips = r[i_sips]
        if client and r[i_cloc] and client not in locs:
            locs[client] = r[i_cloc]
        if server and r[i_sloc] and server not in locs:
            locs[server] = r[i_sloc]
        rule, direction = resolve(rule, client, server, down, nets)
        for lane, subj, cp in attribute(rule, client, server, nets):
            key = (lane, subj, rule.name, cp, port, rule.direction if rule.reclassified else "", sil)
            f = fx.get(key)
            if f is None:
                f = fx[key] = Finding(lane, subj, rule, cp, port, first=t_first, last=t_last, direction=direction,
                                      as_server=subj == server and subj != client, tpl_tactic=r[i_tac] or "",
                                      tpl_technique=r[i_tech] or "", tpl_mitre=r[i_mid] or "", sil=sil)
            f.n += cnt
            f.first = min(f.first, t_first)
            f.last = max(f.last, t_last)
            f.sev = max(f.sev, sev)
            f.thr = max(f.thr, thr)
            f.up += up
            f.down += down
            f.sessions = max(f.sessions, sess)
            f.uniq = max(f.uniq, uniq)
            if cp and cp == server:
                if f.asn is None and r[i_sasn] not in (None, ""):
                    f.asn = _int(r[i_sasn]) or None
                    f.country = r[i_scc]
            elif cp and cp == client and f.asn is None and r[i_casn] not in (None, ""):
                f.asn = _int(r[i_casn]) or None
                f.country = r[i_ccc]
            if sips and len(f.targets) < 64:
                if f.targets is NO_TARGETS:
                    f.targets = set()
                for t in str(sips).split(","):
                    t = t.strip()
                    if t:
                        f.targets.add(t)
                        if len(f.targets) >= 64:
                            break
        # external IPs: every external side of an alert
        for ip, other, asn, cc, inbound in ((client, server, r[i_casn], r[i_ccc], True),
                                           (server, client, r[i_sasn], r[i_scc], False)):
            if not ip or nets.internal(ip):
                continue
            e = ext.get(ip)
            if e is None:
                e = ext[ip] = {"ip": ip, "n": 0, "first": t_first, "last": t_last, "rules": Counter(), "in_hosts": set(),
                               "out_hosts": set(), "ti": set(), "asn": None, "country": None, "up": 0, "down": 0,
                               "families": set(), "classes": set()}
            e["n"] += cnt
            e["first"] = min(e["first"], t_first)
            e["last"] = max(e["last"], t_last)
            e["rules"][rule.name] += cnt
            if not rule.hygiene:
                e["families"].add(rule.family)
                e["classes"].add(rule.cls)
            if rule.ti and rule.subject == "ti":  # an IP list names this IP (a DNS rule names a domain)
                e["ti"].add(rule.ti)
            if e["asn"] is None and asn not in (None, ""):
                e["asn"] = _int(asn) or None
                e["country"] = cc
            if other and nets.internal(other):
                (e["in_hosts"] if inbound else e["out_hosts"]).add(other)
                if inbound:
                    e["down"] += down     # what our host sent back to it
                else:
                    e["up"] += up         # what our host sent to it
    for name, n in per_rule.items():   # the queue of unknown rules shows how many alerts each one had
        catalog.seen(name, n)
    return fx, ext, locs, per_rule


# ---- scoring one finding ----------------------------------------------------------------------------------------

def asn_label(asn: int | None, country: str | None = None) -> str:
    if not asn:
        return country or ""
    org = CLOUD_ASNS.get(asn)
    return f"{org} AS{asn}" if org else f"AS{asn}" + (f" {country}" if country else "")


@lru_cache(maxsize=4096)
def _network(text: str):
    try:
        return ipaddress.ip_network(text, strict=False)
    except ValueError:
        return None


@lru_cache(maxsize=100_000)
def _inside(ip: str, net: str) -> bool:
    n = _network(net)
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return n is not None and a.version == n.version and a in n


def _exception_for(f: Finding, exceptions: list[dict]) -> dict | None:
    """The exception that covers a finding: the first in list order. The 1.0 kinds match the finding's subject, a
    silence rule (1.4) was matched against the bucket's alerts before and names itself in `f.sil`."""
    if isinstance(exceptions, silence.ExceptionSet):
        return exceptions.find(f)
    return silence.find_linear(f, exceptions)


def role_source(book: AddressBook, ip: str, role: str) -> str:
    """Where a host's role came from: the source of the lookup or file entry whose function or service names it
    (as profile_roles reads them), else "learned" (the netflow aggregate)."""
    for e in book.covering(ip):
        for text in (e.function, e.service):
            if text and text_role(text) == role:
                return e.source or "sycope-lookup"
    return "learned"


def _source_of(text: str) -> str:
    """The trace source of a profile norm, from the text profile.exfil_norm / answer_norm give with it."""
    return "learned" if text.startswith(("learned", "held")) else "prior"


def _bar(term: str, norm: float, why: str, floor_pid: str, p: Params) -> tuple[float, dict]:
    """max(floor, norm) and its trace line: the source is the floor's layer when the floor binds, else the norm's."""
    floor = p[floor_pid]
    src = p.explain(floor_pid).source if floor > norm else _source_of(why)
    text = f"{term} {fmt_bytes(norm)} - {why}; floor {fmt_bytes(floor)} {p.explain(floor_pid).source}"
    return max(floor, norm), Line(term, float(max(floor, norm)), src, text)


def missing(term: str, text: str) -> dict:
    """The trace line of a term that was turned off because Sycope does not send the field it needs."""
    return Line(term, 0.0, "missing data", text)


def _rarity_cap(f: Finding, prof, role: str, pr: _priors.Priors, p: Params,
                memo: dict | None = None) -> tuple[float, str, Line]:
    """The rarity cap, its text and trace line; with a memo (one build) a finding of the same signature, role and
    class shares the text and the line of the first."""
    if memo is not None:
        key = ("rarity", f.sig, role, f.rule.key, f.rule.kind, f.cls)
        got = memo.get(key)
        if got is None:
            got = memo[key] = _rarity_cap(f, prof, role, pr, p)
        return got
    pf = _pf()
    s = pf.rarity(prof, f.sig, role, f.rule.key, f.rule.kind, pr)
    cap = math.log2(1 / max(s.p, 1e-6))
    with_cp = f.cp or "any counterpart"
    if s.n:
        pop = prof.population
        who = f"{role}s" if role in pop and pop[role] != pop.get("*") and s.n == pop[role] else "hosts"
        low = "; low norm confidence" if s.conf < 0.5 else ""
        src, how = "learned", (f"learned, {len(prof.days)} days, {s.n:,} host-days, norm confidence {s.conf:.2f}"
                               f"{low}")
        why = f"{pct(s.p)} of {who} have it with {with_cp} on a comparable day - {how}"
    else:
        src, how = "prior", "shipped prior, no history yet"
        why = f"{pct(s.p)} of hosts are expected to have it with {with_cp} - {how}"
    floor = p["ti_min_cap_bits"]
    if f.cls == "A" and cap < floor:
        cap = floor
        src = p.explain("ti_min_cap_bits").source
        why += f" (an indicator match keeps at least {floor:g} bits)"
    # the norm confidence: the page says "low norm confidence" under 0.5
    return cap, why, Line("rarity", round(cap, 2), src, why, round(s.conf, 2) if s.n else None)


def _proto(rule: Rule) -> str:
    n = rule.name
    return "SMB" if "SMB" in n else "NFS" if "NFS" in n else "LDAP" if "LDAP" in n else n


def _edge_forbidden(f: Finding, r: Rule, prof, p: Params, disabled: Collection[str]) -> float:
    """SMB or NFS going out weighs whatever the volume, but a small one is not exfiltration: below the exfiltration
    bar (or with no byte counts) it is a credential and share exposure, Lateral (CL-05, class B, stage 2); at or
    above the bar it stays exfiltration (CL-06, class B, stage 3); returns the usual size bonus in bits."""
    proto = _proto(r)
    bar = None
    if "exfil_volume" not in disabled:
        norm, why = _pf().exfil_norm(prof, f.subject)
        bar, line = _bar("exfil norm", norm, why, "exfil_floor_bytes", p)
        _push(f, "trace", line)
    if bar is None or f.up < bar:
        f.family, f.stage, f.cls, f.kind = "CL-05", 2, "B", "cred"
        tail = ("credentials can leak (NTLM)" if proto == "SMB" else "the export is reachable from outside")
        size = "no byte counts to size it" if bar is None else f"{fmt_bytes(f.up)} uploaded, under {fmt_bytes(bar)}"
        _push(f, "notes", f"{proto} to the internet: {tail}, weighs regardless of volume ({size}: not exfiltration)")
        return 0.0
    big = f.up >= EXFIL_X1 * bar
    _push(f, "notes", f"{proto} to the internet: {fmt_bytes(f.up)} uploaded"
                      + (f", {f.up / bar:,.0f}x its normal daily upload" if big else "") + ", weighs regardless of volume")
    return (2.0 if f.up >= EXFIL_X2 * bar else 1.0) if big else 0.0


def _reclass_note(f: Finding) -> str:
    """Why the same rule reads differently across the edge, for the Why table; what it was before comes from the
    shipped rule, so the sentence is true for each."""
    from sycope_clusters.rules import CATALOG
    base = CATALOG.get(f.rule.name)
    was = ("hygiene" if base.cls == "D" else f"{FAMILIES[base.family][0].lower()}, weak" if base.cls == "C"
           else FAMILIES[base.family][0].lower()) if base else "hygiene"
    label = FAMILIES[f.family][0].lower()
    if f.direction == "inbound":
        return f"answered from the internet: an exposed service, read as {label} (inside the network the rule is {was})"
    if f.cls == "D":
        return f"outbound across the internet edge: a policy finding, no threat weight (inside the network: {was})"
    return f"outbound across the internet edge: read as {label}, with threat weight (inside the network the rule is {was})"


def score_finding(f: Finding, hist: History, window_start: float, exceptions: list[dict], resolver: bool,
                  p: Params = FACTORY, *, prof=None, pr: _priors.Priors | None = None, role: str = WORKSTATION,
                  nets: AddressBook | None = None, resolver_source: str = "learned",
                  disabled: Collection[str] = frozenset(), memo: dict | None = None) -> None:
    """Score one finding. `memo` (one per build) lets findings share equal texts, trace lines and caps."""
    prof = prof if prof is not None else hist.profile
    pr = pr or hist.priors
    r = f.rule
    f.family, f.stage, f.cls, f.kind = r.family, r.stage, r.cls, r.kind
    bonus = 0.0
    if edge_forbidden(r, p) and f.kind == "exfil":
        bonus = _edge_forbidden(f, r, prof, p, disabled)
    elif f.kind == "exfil" and "exfil_volume" in disabled:
        f.cls, f.stage = "C", None
        why = "no byte counts in the alerts: the upload cannot be sized, so exfiltration stays suspected"
        _push(f, "trace", missing("exfil_volume", why))
        _push(f, "notes", why)
    elif f.kind == "exfil" and f.down > 2 * f.up and f.down > 0:
        f.family, f.stage, f.cls, f.kind = "CL-07", None, "C", "download"
        _push(f, "notes", f"download, not upload: {fmt_bytes(f.down)} in, {fmt_bytes(f.up)} out - read as a traffic "
                       f"anomaly, not exfiltration")
    elif f.kind == "exfil":
        norm, why = _pf().exfil_norm(prof, f.subject)
        bar, line = _bar("exfil norm", norm, why, "exfil_floor_bytes", p)
        _push(f, "trace", line)
        if f.up < bar:
            f.cls, f.stage = "C", None
            _push(f, "notes", f"only {fmt_bytes(f.up)} uploaded, under {fmt_bytes(bar)} "
                           f"({'the floor' if bar > norm else 'its normal daily upload'}): too little to confirm "
                           f"exfiltration")
        elif f.up >= EXFIL_X1 * bar:
            bonus = 2.0 if f.up >= EXFIL_X2 * bar else 1.0
            _push(f, "notes", f"{fmt_bytes(f.up)} uploaded: {f.up / bar:,.0f}x its normal daily upload")
    if r.reclassified:
        _push(f, "notes", _reclass_note(f))
    if f.cls == "D":
        f.base = 0.0
    else:
        f.base = max(0.0, p[f"class_bits.{f.cls}"] + (p[f"sev_adj.{f.sev}"] if f.sev in range(1, 6) else 0)
                     + (p[f"thr_adj.{f.thr}"] if f.thr in range(1, 4) else 0)) + bonus
    x = _exception_for(f, exceptions)
    if x:
        f.excepted = {"id": x["id"], "who": x["who"], "reason": x["reason"], "kind": x["kind"],
                      "expires": x.get("expires")}
        f.bits = 0.0
        return
    if f.base <= 0:
        f.bits = 0.0
        return
    caps = []
    cap, why, line = _rarity_cap(f, prof, role, pr, p, memo)
    caps.append(("rarity", cap, why))
    _push(f, "trace", line)
    d, D = hist.novelty(f.subject, r.name, window_start)
    f.days_seen, f.days_looked = d, D
    f.days_skipped = hist.skipped(f.subject, r.name, window_start)
    if f.days_skipped:
        _push(f, "notes", f"{_days(f.days_skipped)} not counted as habit: incidents nobody decided")
    cloud = p["cloud_asns"]
    outside = bool(f.cp and not (nets if nets is not None else hist.nets).internal(f.cp))
    shared = bool(f.asn in cloud and outside)
    infra = None
    if "shared_cloud" in disabled and outside and f.kind in ("ti", "beacon", "covert"):
        shared = False
        _push(f, "trace", missing("shared_cloud", "no ASN in the alerts: no shared-cloud deduction"))
        # the ASN is missing: the shipped prefix list (and the admin's) stands in for cloud_asns
        infra = _infra.provider(f.cp, p["shared_infra_extra"])
        shared = infra is not None
    persist = p["persist_days"]
    week = len(hist.week_days)
    # a channel to a host outside our networks; a daily poll between our own hosts is a habit (OT, monitoring)
    if (week >= persist and outside and f.family in ("CL-01", "CL-02", "CL-03") and f.cls in ("A", "B")
            and not shared):
        dd = hist.pair_days.get((f.subject, r.name, f.cp), 0).bit_count()
        if dd >= persist:
            f.persistent = dd
            _push(f, "notes", f"the same channel to {f.cp} on {dd} of the last {week} days: persistence, not habit")
    if D >= 3 and d > 0 and not f.persistent:
        # habituation: what this host already did on d of the last D days says little today
        cap = math.log2((D + 2) / (d + 1))
        why = f"this host had it on {d} of the last {D} comparable days"
        if f.cls == "A" and cap < f.base / 2:
            cap, why = f.base / 2, why + " (threat intel keeps half its weight)"
        caps.append(("habit", cap, why))
        _push(f, "trace", Line("habit", round(cap, 2), "learned", why))
    if resolver and f.port == "53" and f.cls in ("A", "B"):
        how = "learned role" if resolver_source == "learned" else f"role from {resolver_source}"
        why = f"a DNS resolver ({how}): the real client is behind it"
        caps.append(("resolver", p["class_bits.C"], why))
        _push(f, "trace", Line("resolver", p["class_bits.C"], resolver_source, why))
    f.caps = tuple((w, round(v, 2), why) for w, v, why in caps)
    if memo is not None:
        f.caps = memo.setdefault(f.caps, f.caps)
    bits = min([f.base, *(v for _, v, _ in caps)])
    if shared and f.kind in ("ti", "beacon", "covert"):
        if infra is not None:
            src = "prefix list"
            why = f"shared infrastructure ({infra}, prefix list): shared IPs, lists go stale"
        else:
            src = p.explain("cloud_asns").source
            why = f"{asn_label(f.asn)}: shared IPs, lists go stale (shared cloud list: {src})"
        _push(f, "deds", ("shared cloud", 1.0, why))
        _push(f, "trace", Line("shared cloud", 1.0, src, why))
    f.bits = round(max(0.0, bits - sum(v for _, v, _ in f.deds)), 2)



# ---- per host ---------------------------------------------------------------------------------------------------

@dataclass(slots=True)
class Entity:
    ip: str
    findings: list
    crown: bool = False
    tags: list = field(default_factory=list)
    families: dict = field(default_factory=dict)       # family -> its counted finding
    confirmed: int | None = None
    severe: bool = False       # a confirmed Objectives finding or a confirmed C2-type one (see severe())
    suspected: int | None = None
    progression: float = 0.0
    chains: list = field(default_factory=list)          # [(id, bits, continuity text or "")]
    linked: set = field(default_factory=set)            # chain rules whose second step hit what the first touched
    E: float = 0.0
    conf: float = 0.0
    risk: float = 0.0
    verdict: str = "watch"
    reason: str = ""
    raw_verdict: str = ""      # what the evidence alone says (apply_hold may keep the verdict higher)
    raw_reason: str = ""
    held: str = ""             # why the verdict is higher than the evidence says ("" = not held)
    recur_n: int = 0           # incidents of this host in the recurrence window that ended without a decision
    recur_bits: float = 0.0    # the bits that adds to the evidence
    excepted_at: float = 0.0   # when the newest exception covering all of its evidence was added or approved (0: none)
    first: int = 0
    last: int = 0
    alerts: int = 0
    novelty: str = ""
    days_active: int = 0
    fingerprint: list = field(default_factory=list)   # what the analyst saw when handling it (change = back)
    pattern: list = field(default_factory=list)       # confirmed families + chains (stories group by it)
    headline: str = ""
    path: str = ""
    story: str | None = None


def severe(f: Finding) -> bool:
    """A finding that was stage 3 before 1.2 moved C2 to Foothold: Objectives (exfiltration, floods) or a C2-type
    finding (beacon, covert channel, listed C2 address). The verdict and the risk weight read it so that moving the
    stage model did not demote a confirmed command channel (deviation from alert_cluster: its stage 3 is the only
    "top" there). A class C finding is suspected only and is never severe."""
    return f.cls != "C" and (f.stage == OBJECTIVES or (f.stage == 1 and f.rule.c2_type))


def _lis(seq: list[int]) -> int:
    tails: list[int] = []
    for s in seq:
        i = next((k for k, v in enumerate(tails) if v > s), None)
        if i is None:
            tails.append(s)
        else:
            tails[i] = s
    return len(tails)


NO_WEIGHT_FAMILIES = ("HYG", "POL")   # hygiene and policy findings never add threat weight


def inbound_index(actor_f: dict[str, list[Finding]], confirm: float) -> dict[str, tuple[int, list[str]]]:
    """host -> (when the first credential attack or lateral movement of another actor against it began, the attackers
    by ip) for CR-06. Only findings that would be a chain leg count: scored, a stage, >= confirm_bits, not class C;
    that is the same test score_entity applies to the actor's own legs (conf_f and strong), so an attacker's finding
    counts exactly when it counts for the attacker. Call it after score_finding has run on every actor."""
    out: dict[str, tuple[int, set[str]]] = {}
    for actor, fs in actor_f.items():
        for f in fs:
            if f.family not in ("CL-05", "CL-10") or f.cls == "C" or f.stage is None or f.bits < confirm:
                continue
            for victim in ({f.cp} if f.cp else set()) | set(f.targets):
                if victim == actor:
                    continue
                t, who = out.get(victim, (f.first, set()))
                out[victim] = (min(t, f.first), who | {actor})
    return {v: (t, sorted(who)) for v, (t, who) in out.items()}


def score_entity(e: Entity, hist: History, window_start: float | None = None, chain_days: int | None = None,
                 p: Params = FACTORY, disabled: Collection[str] = frozenset(),
                 inbound: dict[str, tuple[int, list[str]]] | None = None) -> None:
    chain_days = p["chain_days"] if chain_days is None else chain_days
    confirm = p["confirm_bits"]
    fams: dict[str, Finding] = {}
    for f in e.findings:
        if f.bits > 0 and f.family not in NO_WEIGHT_FAMILIES and (f.family not in fams
                                                                  or f.bits > fams[f.family].bits):
            fams[f.family] = f
    weak = [k for k, f in fams.items() if f.cls == "C"]
    if len(weak) > 1:  # weak signals do not add up: only the strongest one counts
        keep = max(weak, key=lambda k: fams[k].bits)
        for k in weak:
            if k != keep:
                _push(fams[k], "notes", "weak signal: only the strongest weak signal of a host counts")
                del fams[k]
    for f in fams.values():
        f.counted = True
    e.families = fams
    conf_f = [f for f in e.findings if f.stage is not None and f.bits >= confirm]
    sus_f = [f for f in e.findings if f.stage is not None and f.bits > 0]
    e.confirmed = max((f.stage for f in conf_f), default=None)
    e.severe = any(severe(f) for f in conf_f)
    e.suspected = max((f.stage for f in sus_f), default=None)
    first_by_stage: dict[int, int] = {}
    for f in conf_f:
        first_by_stage[f.stage] = min(first_by_stage.get(f.stage, f.first), f.first)
    order = [s for s, _ in sorted(first_by_stage.items(), key=lambda kv: kv[1])]
    e.progression = float(min(3, max(0, _lis(order) - 1)))
    # chain rules on confirmed families
    strong: dict[str, list[Finding]] = defaultdict(list)
    for f in conf_f:
        if f.cls != "C":     # a class C finding is suspected only: its bits count, it is never a chain leg
            strong[f.family].append(f)
    strong_any = {k for k, v in strong.items() if v}
    t0 = {k: min(f.first for f in v) for k, v in strong.items()}

    def touched(fs: list[Finding], targets: bool = True) -> set:
        s = set()
        for f in fs:
            if f.cp:
                s.add(f.cp)
            if targets:
                s |= f.targets
        return s

    # the first step of CR-08 (credentials, 48 h) and CR-09 (scanning, 72 h) may lie before the 24 h window: in the
    # stored days (only alerts before the window, the window has its own)
    before: dict[str, tuple[int, set]] = {}
    if window_start and chain_days > 1:
        for fam, days in (("CL-05", min(2, chain_days)), ("CL-04", min(3, chain_days))):
            got = hist.first_step(e.ip, fam, window_start - (days - 1) * 86400000, window_start)
            if got:
                before[fam] = got

    def earlier(fam: str, what: str, t_next: int) -> str:
        if fam not in before or fam in strong_any:
            return ""
        return f"{what} {max(1, round((t_next - before[fam][0]) / 3600000))} h earlier, before the 24 h window"

    chains = []
    ti_c2 = any(f.rule.c2_type for f in strong.get("CL-01", []))      # a listed C2 address (Phishing is not one)
    c2 = strong_any & {"CL-02", "CL-03"} or ({"CL-01"} if ti_c2 else set())
    if ti_c2 and strong_any & {"CL-02", "CL-03"}:
        chains.append(("CR-05", p["chain.CR-05.bonus"], ""))
    if "CL-06" in strong_any and c2:
        chains.append(("CR-01", p["chain.CR-01.bonus"], ""))
    for fam, (t, _) in before.items():
        t0[fam] = min(t0.get(fam, t), t)
    cred = "CL-05" in strong_any or "CL-05" in before
    if cred and "CL-10" in strong_any and t0["CL-05"] <= t0["CL-10"]:
        both = (touched(strong.get("CL-05", [])) | before.get("CL-05", (0, set()))[1]) & touched(strong["CL-10"])
        text = ", ".join(x for x in (f"same hosts: {', '.join(sorted(both)[:3])}" if both else "",
                                     earlier("CL-05", "the credential attack was", t0["CL-10"])) if x)
        chains.append(("CR-08", p["chain.CR-08.bonus"] + (p["chain.CR-08.same_hosts_bonus"] if both else 0.0), text))
        if both:
            e.linked.add("CR-08")
    if "CL-04" in strong_any or "CL-04" in before:
        later = [f for k in ("CL-05", "CL-10") for f in strong.get(k, []) if f.first >= t0["CL-04"]]
        if later:
            scans, past = strong.get("CL-04", []), before.get("CL-04", (0, set()))[1]
            later_cp = {f.cp for f in later if f.cp}
            hit = (touched(scans) | past) & later_cp
            off = ""
            if "same_host" in disabled:   # the target lists are not trusted: the counterpart link stays
                kept = (touched(scans, targets=False) | past) & later_cp
                if kept != hit:           # say so only when the lists were what made the link
                    off = "same-host link through the scan's target lists is off (no target lists in the alerts)"
                    for f in scans:
                        if f.targets & (hit - kept):
                            _push(f, "trace", missing("same_host", off))
                hit = kept
            text = ", ".join(x for x in (f"then went after {', '.join(sorted(hit)[:3])}, a host it scanned" if hit
                                         else "", earlier("CL-04", "the scan was", min(f.first for f in later)),
                                         off) if x)
            chains.append(("CR-09", p["chain.CR-09.bonus"] + (p["chain.CR-09.same_hosts_bonus"] if hit else 0.0), text))
            if hit:
                e.linked.add("CR-09")
    four = sum(1 for g in ({"CL-04"}, {"CL-05", "CL-10"}, {"CL-02", "CL-03"}, {"CL-06"}) if g & strong_any)
    if ti_c2 and not strong_any & {"CL-02", "CL-03"}:
        four += 1
    if four >= 3:
        chains.append(("CR-02", p["chain.CR-02.bonus"], ""))
    if "CL-12" in strong_any and "CL-06" in strong_any and t0["CL-12"] <= t0["CL-06"]:
        chains.append(("CR-04", p["chain.CR-04.bonus"], ""))
    if inbound and e.ip in inbound and c2:
        # CR-06: attacked over credentials or lateral movement, then its own command channel starts (the first
        # finding of a family of that channel is not older than the first inbound attack)
        t_in, attackers = inbound[e.ip]
        legs = [min(f.first for f in strong[k] if k != "CL-01" or f.rule.c2_type) for k in sorted(c2)]
        calls = [t for t in legs if t >= t_in]
        if calls:
            hours = max(1, round((min(calls) - t_in) / 3600000))
            chains.append(("CR-06", p["chain.CR-06.bonus"],
                           f"attacked by {', '.join(attackers[:3])} {hours} h before the first call out"))
    if four < 3 and four >= 1 and len(hist.week_days) >= 3:
        wk = hist.week_fams.get(e.ip, set())
        fams_wk = {fam for fam, _ in wk if fam != "CL-01"} | ({"CL-02"} if any(fam == "CL-01" and c2w
                                                                                for fam, c2w in wk) else set())
        got = [g for g in WEEK_GROUPS if g & (strong_any | fams_wk)]
        if len(got) >= 3:
            names = ", ".join(sorted(FAMILIES[next(iter(g & (strong_any | fams_wk)))][0] for g in got))
            chains.append(("CR-03", p["chain.CR-03.bonus"], f"over the last 7 days: {names}"))
    pers = [f for f in e.findings if f.persistent and f.bits >= confirm]
    if pers:
        f = max(pers, key=lambda f: f.persistent)
        last = len(hist.week_days)
        chains.append(("CR-10", p["chain.CR-10.bonus"], f"{f.cp} on {f.persistent} of the last {last} days"))
    chains.sort(key=lambda c: c[0])      # the rules in id order, the order they are listed in
    e.chains = chains
    e.E = round(sum(f.bits for f in fams.values()) + e.progression + sum(b for _, b, _ in chains), 2)
    e.recur_n = hist.memory.recurring.get(e.ip, 0)
    if fams and e.recur_n >= min(p["recurrence.min1"], p["recurrence.min2"]):
        # the same host again and again, each time ended with nobody deciding: that is evidence of its own
        e.recur_bits = p["recurrence.bits2"] if e.recur_n >= p["recurrence.min2"] else p["recurrence.bits1"]
        e.E = round(e.E + e.recur_bits, 2)
    e.conf = 1 / (1 + 2 ** -(e.E - p["prior_bits"]))
    e.risk = round(e.conf * impact_of(e, p), 4)
    e.first = min(f.first for f in e.findings)
    e.last = max(f.last for f in e.findings)
    e.alerts = sum(f.n for f in e.findings)
    fg = [f for f in e.findings if foreground(f)]
    deep = [f for f in e.findings if f.base >= 1.5 and not f.excepted]
    if any(f.unseen for f in fg):
        e.novelty = "new"
    elif deep and all(f.days_looked >= 3 and f.days_seen >= 3 for f in deep):
        e.novelty = "recurring"
    e.days_active = hist.host_days.get(e.ip, 0).bit_count() if hist.depth else 0
    e.pattern = sorted({f.family for f in conf_f} | {c for c, _, _ in chains})
    # any real evidence counts as a change for "snooze until change", not only confirmed stages
    e.fingerprint = sorted({f.family for f in e.findings if foreground(f)} | set(e.pattern))
    e.verdict, e.reason = verdict(e, p)


def _local_time(epoch: float, now: float, offset_min: int) -> str:
    """A time the way the pages show it: HH:MM today, otherwise YYYY-MM-DD HH:MM, in the configured time zone."""
    return fmt.tm(epoch, now, offset_min)


local_time = _local_time      # the same, for the modules that write times into text (ticket.py, notify.py)
VERDICT_NAMES = {"act": "Act now", "investigate": "Investigate", "review": "Review", "watch": "Watch"}
_BY_RANK = {v: k for k, v in VRANK.items()}


def apply_hold(e: Entity, h: Hold | None, now: float, p: Params = FACTORY) -> None:
    """Hysteresis on the host verdict, after verdict(): the evidence alone is kept in `raw_verdict`.

    Without an analyst's action on the host since the service last changed its verdict (a status, or the closure of
    an incident it was in) the verdict does not fall below one level under the highest one the host was shown in the
    last `hysteresis.step_h`: Act now falls to Investigate at once, to Review a day after the last Act now or
    Investigate was shown, and so on. A host that was Act now also stays at least Investigate until
    `hysteresis.act_hold_h` have passed with nothing above Watch. Nothing here keeps a host above Investigate, and a
    rise is never held. An analyst's action ends both at once. Everything comes from `h` (the store) and `now`: the
    same state gives the same verdict."""
    e.raw_verdict, e.raw_reason = e.verdict, e.reason
    if h is None:
        return
    raw = VRANK[e.verdict]
    shown, armed = h.shown, h.armed
    if e.excepted_at > h.analyst_at:
        # an exception that covers the host's evidence is an analyst's decision on it (reason, expiry, second person):
        # it ends the hold like any action, and what was shown before it does not count either
        shown, armed = h.shown_after(e.excepted_at), armed and e.excepted_at <= h.act_at
        if e.excepted_at > h.changed_at:
            return
    elif h.analyst_at and h.analyst_at > h.changed_at:
        return
    floor = VRANK["investigate"]
    step = max(0, min(shown - 1, floor)) if shown >= 0 else 0
    kept = armed and raw < floor and (raw >= VRANK["review"] or now - h.evid_at < p["hysteresis.act_hold_h"] * 3600)
    eff = max(raw, step, floor if kept else 0)
    if eff == raw:
        return
    e.verdict = _BY_RANK[eff]
    if kept and eff == floor:
        at = _local_time(h.act_at, now, int(p["calendar.utc_offset_min"]))
        e.held = f"held at {VERDICT_NAMES[e.verdict]}: Act now on {at}, no analyst decision"
    else:
        e.held = (f"held at {VERDICT_NAMES[e.verdict]}: the evidence now says {VERDICT_NAMES[e.raw_verdict]}, and a "
                  f"verdict falls one level in {p['hysteresis.step_h']:g} h unless an analyst acts")
    e.reason = e.held


def conf_text(c: float) -> str:
    return "99%" if c >= 0.995 else "<1%" if c < 0.01 else f"{c * 100:.0f}%"


def conf_word(c: float, p: Params = FACTORY) -> str:
    """Confidence in a word for lists and reasons: low, medium or high (the % goes in a tooltip)."""
    return "low" if c < p["wording.conf_low"] else "medium" if c < p["wording.conf_high"] else "high"


def impact_of(e: Entity, p: Params = FACTORY) -> float:
    """The weight risk = confidence x impact uses: that of the highest stage with confirmed evidence; a severe host (a
    command channel at Foothold) weighs at least what Objectives does, so it kept its 1.1.2 risk; a crown jewel x
    crown_mult. The one place score_entity and the host page's Why math both read."""
    w = p[f"impact.{'none' if e.confirmed is None else e.confirmed}"]
    if e.severe:
        w = max(w, p[f"impact.{OBJECTIVES}"])
    return w * (p["crown_mult"] if e.crown else 1.0)


def impact_why(e: Entity, p: Params = FACTORY) -> str:
    """Why the weight differs from the stage's own, for the Why math ("" when it does not)."""
    if e.severe and e.confirmed is not None and e.confirmed != OBJECTIVES and \
            p[f"impact.{OBJECTIVES}"] > p[f"impact.{e.confirmed}"]:
        return "a command channel weighs as Objectives"
    return ""


def rank(e: Entity) -> int | None:
    """The stage a host is queued by: Objectives for a severe host (a command channel ranks with it), else the
    highest stage with evidence."""
    return OBJECTIVES if e.severe else e.confirmed


def severe_what(e: Entity) -> str:
    """What makes a host severe, in a word: the Objectives stage, or a command channel at Foothold."""
    return STAGES[OBJECTIVES] if e.confirmed == OBJECTIVES else "command channel"


def stage_claim(stage: int | None, c: float, p: Params = FACTORY, what: str | None = None) -> str:
    """How a reason names a stage: confirmed only when the confidence is high, otherwise a signal of that stage.
    `what` names a command channel (a Foothold finding that weighs like Objectives): the same two forms."""
    if stage is None:
        return f"activity, {conf_word(c, p)} confidence ({conf_text(c)})"
    if what == "command channel":
        if c >= p["wording.conf_high"]:
            return f"command channel confirmed, confidence {conf_text(c)}"
        return f"command-channel evidence, {conf_word(c, p)} confidence ({conf_text(c)})"
    if c >= p["wording.conf_high"]:
        return f"{STAGES[stage]} confirmed, confidence {conf_text(c)}"
    return f"{STAGES[stage]}-stage signal, {conf_word(c, p)} confidence ({conf_text(c)})"


def verdict(e: Entity, p: Params = FACTORY) -> tuple[str, str]:
    ids = {c for c, _, _ in e.chains}
    cont = {c: t for c, _, t in e.chains if t}
    ct = conf_text(e.conf)
    top = OBJECTIVES
    for c in sorted(p["act_chains"]):
        if c in ids and e.conf >= p["verdict.act_chain_conf"]:
            return "act", f"{CHAINS[c][0]} ({CHAINS[c][2]}), confidence {ct}"
    for c in ("CR-08", "CR-09"):
        if c in e.linked and e.conf >= p["verdict.linked_conf"]:
            return "act", f"{CHAINS[c][0]}: {cont[c]}, confidence {ct}"
    # "severe": Objectives or a command channel. 1.1.2 had both at the top stage; the verdict keeps treating them alike
    # (deviation from alert_cluster: there C2 is stage 3 of the model; here it is Foothold, but never a lesser verdict)
    if e.severe and e.conf >= p["verdict.impact_conf"]:
        what = ("reached Objectives (exfiltration or a flood)" if e.confirmed == top else
                ("command channel confirmed" if e.conf >= p["wording.conf_high"] else "command-channel evidence")
                + " (a beacon, a covert channel or a listed C2 address)")
        return "act", f"{what}, confidence {ct}"
    if e.crown and e.severe:
        return "act", (f"{severe_what(e)} on a crown jewel (data or a command channel on the most important hosts), "
                       f"confidence {ct}")
    if e.crown and e.confirmed is not None and e.confirmed >= 2 and e.conf >= p["verdict.crown_stage_conf"]:
        return "act", f"crown jewel at {STAGES[e.confirmed]}, confidence {ct}"
    if e.severe:
        # missing an exfiltration or a C2 channel costs far more than one look: it is never left in Review
        tail = (f"Act now needs {p['verdict.impact_conf'] * 100:.0f}%" if e.conf >= p["wording.conf_high"] else
                "kept at Investigate because a missed command channel or exfiltration costs more than one look")
        return "investigate", f"{stage_claim(top, e.conf, p, severe_what(e))}; {tail}"
    if e.risk >= p["verdict.investigate_risk"]:
        return "investigate", stage_claim(e.confirmed, e.conf, p)
    for c in ("CR-03", "CR-06", "CR-08", "CR-09", "CR-10"):
        if c in ids:
            return "investigate", f"{CHAINS[c][0]} ({cont.get(c) or CHAINS[c][2]})"
    ti_new = [f for f in e.findings if f.cls == "A" and f.bits >= p["verdict.ti_new_bits"] and f.unseen]
    if ti_new:
        f = ti_new[0]
        return "investigate", f"new contact with {fmt.with_article(f.rule.ti or 'listed')} IP ({f.cp})"
    if e.risk >= p["verdict.review_risk"] or e.confirmed is not None:
        return "review", (f"{STAGES[e.confirmed]}-stage signal, " if e.confirmed is not None else "") + \
            f"{conf_word(e.conf, p)} confidence ({ct})"
    if any(f.cls == "A" and f.bits > 0 for f in e.findings):
        return "review", "threat-intel contact seen before"
    return "watch", "weak or background signals only"


# ---- words ------------------------------------------------------------------------------------------------------

def cp_label(f: Finding, names: dict | None = None, port: bool = True) -> str:
    if not f.cp:
        return ""
    s = f.cp + (f":{f.port}" if port and f.port and f.kind != "scan" else "")
    if names and names.get(f.cp):
        s += f" ({names[f.cp]})"
    elif f.asn:
        s += f" ({asn_label(f.asn, f.country)})"
    return s


def phrase(f: Finding, names: dict | None = None, short: bool = False) -> str:
    k, cp, rn = f.kind, cp_label(f, names), f.rule.name
    lbl = SHORT.get(rn, rn)
    if k == "ti":  # the list the IP is on is the point: keep it even on the one-line card
        what = f"{fmt.with_article(f.rule.ti)} IP" if f.rule.ti else "a listed IP"
        return f"contacted {what} {cp}" if cp else f"contacted {what}"
    if k == "beacon":
        return f"{lbl} to {cp}" if cp else lbl
    if k == "covert":
        return f"{rn.replace('Suspicious ', '')} to {cp}" if cp else rn
    if k == "scan":
        n = max(f.uniq, len(f.targets))
        if n > 1:
            return f"scanned {n} hosts" + (f" on :{f.port}" if f.port else "")
        return f"scanned {cp}" if cp else rn.lower()
    if k == "brute":
        return f"brute-forced {cp}" + (f" ({f.sessions:,} sessions in a minute)" if f.sessions and not short else "")
    if k == "cred":
        return f"{lbl} towards {cp}" if cp else lbl
    if k == "lateral":
        return f"{lbl} to {cp}" if cp else lbl + (f" (x{f.n})" if f.n > 1 and not short else "")
    if k == "exposure":
        return f"{rn} reached from {cp}: exposed to the internet" if cp else f"{rn}: exposed to the internet"
    if k == "remote":
        if "RDP" not in rn:       # the other rules of the family: a web shell, an exposed database port
            return f"{rn} with {cp}" if cp else rn
        return f"RDP across the internet edge with {cp}" if cp else "RDP across the internet edge"
    if k == "exfil":
        return f"uploaded {fmt_bytes(f.up)} to {cp}" if cp else f"uploaded {fmt_bytes(f.up)}"
    if k == "download":
        return f"downloaded {fmt_bytes(f.down)} from {cp}" if cp else f"downloaded {fmt_bytes(f.down)}"
    if k == "staging":
        return f"pulled {fmt_bytes(f.down or f.up)} from {cp}" if cp else "large internal transfer"
    if k == "dos":
        what = "spam" if "SPAM" in rn else "flood traffic"
        return f"sent {what} to {cp}" if cp else f"sent {what}"
    return f"{rn} ({cp})" if cp and not short else rn


def foreground(f: Finding) -> bool:
    """Worth a line in the story: real evidence that says something about the attack."""
    return f.bits >= 1 and (f.stage is not None or f.cls in ("A", "B"))


def narrative(e: Entity, names: dict | None = None, p: Params = FACTORY) -> tuple[list[dict], list[dict]]:
    """Foreground steps (one per family, in order of first evidence) and the background (what it does every day)."""
    fg: dict[str, list[Finding]] = defaultdict(list)
    for f in e.findings:
        if foreground(f):
            fg[f.family].append(f)
    steps = []
    for fam, fs in fg.items():
        fs.sort(key=lambda f: (-f.bits, -max(f.uniq, len(f.targets)), -f.n))
        lead = fs[0]
        first = min(f.first for f in fs)
        text = phrase(lead, names)
        if len(fs) > 1:
            text += f" (+{len(fs) - 1} more)"
        note = ""
        if fam in ("CL-05", "CL-10") and "CR-09" in e.linked:
            note = "against a host it scanned"
        steps.append({"t": first, "family": fam, "label": FAMILIES[fam][0], "text": text, "bits": round(lead.bits, 2),
                      "stage": lead.stage, "new": lead.unseen, "note": note,
                      "confirmed": lead.stage is not None and lead.bits >= p["confirm_bits"]})
    steps.sort(key=lambda s: s["t"])
    bg: dict[str, dict] = {}
    for f in e.findings:
        if not foreground(f) and (f.base >= 1.5 or f.excepted or f.bits > 0):
            b = bg.setdefault(f.rule.name, {"rule": f.rule.name, "n": 0, "cps": Counter(), "days": 0, "looked": 0,
                                            "excepted": bool(f.excepted)})
            b["n"] += f.n
            if f.cp:
                b["cps"][cp_label(f, names)] += f.n
            b["days"] = max(b["days"], f.days_seen)
            b["looked"] = max(b["looked"], f.days_looked)
            b["skipped"] = max(b.get("skipped", 0), f.days_skipped)
    back = sorted(({**b, "cps": [c for c, _ in b["cps"].most_common(2)],
                    "habit": b["looked"] >= 3 and b["days"] >= 3} for b in bg.values()),
                  key=lambda b: (-b["habit"], -b["n"]))
    return steps, back


def headline(e: Entity, steps: list[dict], back: list[dict], names: dict | None = None) -> tuple[str, str]:
    """(one line for the card, the same without the chain rule's name: the path a story shows)."""
    if steps:
        parts = []
        for s in steps[:3]:
            lead = max((f for f in e.findings if f.family == s["family"] and foreground(f)), key=lambda f: f.bits)
            parts.append(phrase(lead, names, short=True))
        path = " → ".join(parts) + (" → …" if len(steps) > 3 else "")
        if e.chains:
            best = max(e.chains, key=lambda c: c[1])
            return f"{CHAINS[best[0]][0]}: {path}", path
        return path, path
    if back:
        b = back[0]
        text = f"Background only: {SHORT.get(b['rule'], b['rule'])} x{b['n']:,}" + \
            (f" ({b['cps'][0]})" if b["cps"] else "")
        return text, text
    return "No threat evidence", "No threat evidence"


# ---- the board -------------------------------------------------------------------------------------------------

@dataclass
class TargetIncident:
    """A host attacked from outside that answered (or whose attacker is on a threat list): an incident about a
    victim, not about a host that acts. Shaped like an Entity where the queue and the triage state need it
    (verdict, fingerprint, risk, first/last)."""
    ip: str
    verdict: str
    headline: str
    reason: str
    first: int
    last: int
    alerts: int
    crown: bool
    families: list
    fingerprint: list
    risk: float
    attackers: list
    ti: list
    answered: int
    kinds: list
    port: str = ""
    conf: float | None = None
    confirmed: int | None = None
    trace: list = field(default_factory=list)   # where the "big answer" bar came from


@dataclass
class Board:
    built_at: float
    now: float
    took_s: float
    window_start: float
    alerts: int
    findings: int
    entities: dict
    items: list
    stories: dict
    targets: list
    externals: list
    hygiene: list
    tuning: dict
    counts: dict
    history: dict
    unknown_rules: list
    rule_stats: dict
    names: dict = field(default_factory=dict)
    target_f: dict = field(default_factory=dict)
    hyg_f: dict = field(default_factory=dict)
    ext: dict = field(default_factory=dict)
    locs: dict = field(default_factory=dict)
    campaigns: list = field(default_factory=list)
    roles: dict = field(default_factory=dict)
    role_tips: dict = field(default_factory=dict)   # host -> {role tag -> where it comes from, in words}
    role_src: dict = field(default_factory=dict)    # host -> {role tag -> "admin" | "learned" | "lookup" | "kept"}
    name_src: dict = field(default_factory=dict)    # host -> where its name comes from
    target_inc: dict = field(default_factory=dict)
    params: Params = field(default_factory=Params.factory)   # what the board was scored with
    config_version: int | None = None    # the configuration version it was scored with (set by Live)
    profile_day: str | None = None       # the learned profile it was scored on (None: a cold start on priors)


def build(rows: list[tuple], now: float, catalog: Catalog, hist: History | None, triage: dict | None = None,
          exceptions: list[dict] | None = None, crown: set | None = None, nets: AddressBook | None = None,
          names: dict | None = None, window_s: float = 86400, campaign_min: int | None = None,
          chain_days: int | None = None, *, params: Params | None = None, profile=None,
          priors: _priors.Priors | None = None, disabled: Collection[str] = frozenset()) -> Board:
    """The board of the alerts in the window. `profile` is the learned environment profile (None: the History's,
    else a cold start on the priors alone); `priors` the shipped priors (None: the History's, else the packaged
    file). `disabled` names the terms Sycope's missing fields turn off (health.disabled_terms: exfil_volume,
    shared_cloud, same_host): each is skipped and the findings it touches get a "missing data" trace line."""
    import time as _time
    t0 = _time.monotonic()
    pf = _pf()
    p = params or Params.factory()
    nets = nets or Nets()
    crown = crown or set()
    exceptions = silence.ExceptionSet.of(exceptions, p["calendar.utc_offset_min"])
    names = names or {}
    window_start = (now - window_s) * 1000
    today = day_key(now * 1000)
    pr = priors or (hist.priors if hist is not None else None) or default_priors()
    prof = profile if profile is not None else hist.profile if hist is not None else None
    if prof is None:
        prof = empty_profile(today, p, pr, catalog, nets)
    hist = hist or History([], [], today, catalog, nets, p, profile=prof, priors=pr)
    fx, ext, locs, per_rule = collect(rows, catalog, nets, exceptions.silencer)
    actor_f: dict[str, list[Finding]] = defaultdict(list)
    target_f: dict[str, list[Finding]] = defaultdict(list)
    hyg_f: dict[str, list[Finding]] = defaultdict(list)
    lanes = {"a": actor_f, "t": target_f, "h": hyg_f}
    for f in fx.values():
        d = lanes.get(f.lane)
        if d is not None:
            d[f.subject].append(f)
    svc_alerts: Counter = Counter()
    svc_clients: dict[tuple, set] = defaultdict(set)
    for f in fx.values():
        if f.lane not in ("a", "h"):
            continue
        server_side = f.rule.subject == "server" and nets.internal(f.subject)
        client, server = (f.cp, f.subject) if server_side else (f.subject, f.cp)
        if server and client and nets.internal(server) and f.port:
            svc_clients[(f.rule.name, server, f.port)].add(client)
            svc_alerts[(f.rule.name, server, f.port)] += f.n
    n_actors = len(actor_f)
    on_board = {*actor_f, *target_f, *hyg_f}
    # roles from the learned profile (lookup function or the services a host offers); the resolver correction
    # reads the role table itself, which names a held host's resolver role too
    # where each role of a host comes from; an admin's role (the networks file, a confirmed suggestion) beats a
    # learned one, so a learned tag is dropped from a host an admin described
    cand: dict[str, list[tuple[str, str]]] = defaultdict(list)
    for r in sorted(prof.roles):
        for ip in prof.roles[r]:
            if ip in on_board:
                cand[ip].append((r, role_source(nets, ip, r)))
    roles: dict[str, list[str]] = defaultdict(list)
    role_tips: dict[str, dict[str, str]] = defaultdict(dict)
    role_src: dict[str, dict[str, str]] = defaultdict(dict)   # "kept": a held host's role from an earlier profile
    for ip, got in cand.items():
        by_admin = ip in prof.confirmed or any(src == "file" for _r, src in got)
        for r, src in got:
            tag = ROLE_TAG.get(r, r)
            if src == "learned":
                if by_admin:
                    continue
                n = (prof.role_days.get(ip) or {}).get(r)
                kind = "kept" if ip in prof.held else "learned"
                tip = ("learned role (kept from an earlier profile)" if kind == "kept" else
                       f"learned role from {n[0]} of {n[1]} days" if n
                       else "learned role from the netflow of the comparable days")
            elif src == "file":
                kind, tip = "admin", "admin: the networks file says so"
            else:
                kind, tip = "lookup", "Sycope lookup: its function or service names this role"
            roles[ip].append(tag)
            role_tips[ip][tag] = tip
            role_src[ip][tag] = kind
    for ip, r in sorted(prof.confirmed.items()):
        if ip in on_board:
            tag = ROLE_TAG.get(r, r)
            if tag not in roles[ip]:
                roles[ip].append(tag)
            role_tips[ip][tag] = "admin: confirmed in Configuration"
            role_src[ip][tag] = "admin"
    resolvers = set(prof.roles.get("resolver", ()))
    resolver_src = {ip: role_source(nets, ip, "resolver") for ip in sorted(resolvers & set(actor_f))}
    # score
    entities: dict[str, Entity] = {}
    memo: dict = {}
    exc_at = {x["id"]: float(x.get("decided_at") or x.get("created") or 0) for x in exceptions if x.get("id") is not None}
    for ip, fs in actor_f.items():       # every finding is scored before the first host is (CR-06 reads the others')
        resolver = ip in resolvers
        role = pf.role(prof, ip)
        for f in fs:
            score_finding(f, hist, window_start, exceptions, resolver, p, prof=prof, pr=pr, role=role, nets=nets,
                          resolver_source=resolver_src.get(ip, "learned"), disabled=disabled, memo=memo)
    inbound = inbound_index(actor_f, p["confirm_bits"])
    for ip, fs in actor_f.items():
        e = Entity(ip, fs, crown=ip in crown, tags=list(roles.get(ip, [])))
        score_entity(e, hist, window_start, chain_days, p, disabled, inbound)
        # an exception is an analyst's decision on the host when it covers all the evidence that carries weight and
        # some of that evidence is strong (would confirm a stage): then the host is released (apply_hold). An exception
        # on one weak finding decides nothing about an Act now host, and one that covers only what is left after the
        # strong evidence aged out is not the moment the decision was taken. The moment is persisted by the incident's
        # excepted closure (history._close), which keeps the release once the excepted findings leave the window.
        if fs and not any(f.bits > 0 for f in fs) and any(f.excepted and f.base >= p["confirm_bits"] for f in fs):
            e.excepted_at = max(exc_at.get(f.excepted.get("id"), 0.0) for f in fs if f.excepted)
        apply_hold(e, hist.memory.holds.get(ip), now, p)
        steps, back = narrative(e, names, p)
        e.headline, e.path = headline(e, steps, back, names)
        entities[ip] = e
    for fs in target_f.values():
        for f in fs:
            r = f.rule
            f.family, f.stage, f.cls, f.kind = r.family, r.stage, r.cls, r.kind
            if r.reclassified:
                _push(f, "notes", _reclass_note(f))
    # silenced findings of the target and hygiene lanes carry no weight anyway: they are only marked, so the host page
    # can list them under Silenced with the rule that took them
    if exceptions:
        for d in (target_f, hyg_f):
            for fs in d.values():
                for f in fs:
                    if (x := _exception_for(f, exceptions)):
                        f.excepted = {"id": x["id"], "who": x["who"], "reason": x["reason"], "kind": x["kind"],
                                      "expires": x.get("expires")}
    triage = triage or {}
    # stories: hosts with the same confirmed pattern and verdict
    groups: dict[tuple, list[Entity]] = defaultdict(list)
    for e in entities.values():
        if e.verdict != "watch" and e.pattern:
            chains = tuple(c for c in e.pattern if c.startswith("CR-"))
            groups[(e.verdict, chains or tuple(e.pattern))].append(e)
    stories: dict[str, dict] = {}
    parts = []
    for (v, fp), members in groups.items():
        if len(members) >= 3:
            parts += [(v, fp, anchor, ms) for anchor, ms in _split_by_ties(members, p)]
    for v, fp, anchor, members in parts:
        if len(members) < 3:
            continue
        members.sort(key=lambda e: (-e.risk, -e.last))
        key = f"{v}:{'+'.join(fp)}" + (f"+at-{re.sub(r'[^A-Za-z0-9]', '-', anchor)}" if anchor else "")
        chains = [c for c in fp if c.startswith("CR-")]
        fam_count = Counter(f for m in members for f in m.pattern if not f.startswith("CR-"))
        fams = [f for f, _ in fam_count.most_common()]
        where = ("" if not anchor else f" in {anchor[4:]}" if anchor.startswith("net-") else
                 f" around {anchor}" + (f" ({names[anchor]})" if names.get(anchor) else ""))
        title = story_title(chains, fams, p) + where
        nets24 = Counter(prefix(m.ip) for m in members)
        scanners = Counter(prefix(m.ip) for m in members if "CL-04" in m.pattern)
        spread = [(n, c) for n, c in scanners.most_common(3) if c >= 3]
        for m in members:
            m.story = key
        stories[key] = {"key": key, "verdict": v, "title": title, "pattern": list(fp), "anchor": anchor,
                        "members": [m.ip for m in members],
                        "count": len(members), "nets": nets24.most_common(4), "spread": spread,
                        "conf": max(m.conf for m in members), "risk": max(m.risk for m in members),
                        "last": max(m.last for m in members), "first": min(m.first for m in members),
                        "new": sum(1 for m in members if m.novelty == "new"),
                        "confirmed": max((m.confirmed for m in members if m.confirmed is not None), default=None),
                        "rank": max((rank(m) for m in members if rank(m) is not None), default=None),
                        "suspected": max((m.suspected for m in members if m.suspected is not None), default=None),
                        "sample": [m.path for m in members[:3]], "crown": sum(1 for m in members if m.crown)}
    # queue items (triage overlay is applied when a page asks: see overlay())
    items = []
    for s in stories.values():
        items.append({"type": "story", "key": s["key"], "verdict": s["verdict"], "risk": s["risk"], "last": s["last"]})
    for e in entities.values():
        if not e.story:
            items.append({"type": "host", "key": e.ip, "verdict": e.verdict, "risk": e.risk, "last": e.last})
    items.sort(key=lambda it: (-VRANK[it["verdict"]], -it["risk"], -it["last"]))
    counts = Counter(e.verdict for e in entities.values())
    # lanes
    tuning = _tuning(svc_clients, svc_alerts, n_actors, hist, exceptions, alert_total(rows), catalog)
    services = {(s["rule"], s["server"], s["port"]) for s in tuning["services"]}
    targets = _targets(target_f, entities, crown, ext, names, services, nets)
    externals = _externals(ext, hist, entities, p)
    target_inc = _target_incidents(targets, target_f, entities, ext, nets, p, prof)
    for ti in target_inc.values():
        items.append({"type": "target", "key": ti.ip, "verdict": ti.verdict, "risk": ti.risk, "last": ti.last})
    items.sort(key=lambda it: (-VRANK[it["verdict"]], -it["risk"], -it["last"]))
    hygiene = _hygiene(hyg_f)
    rule_stats = _rule_stats(fx, n_actors, per_rule, p)
    total_alerts = alert_total(rows)
    explained = sum(c["alerts"] for c in tuning["services"])
    hist_info = {"days": hist.days, "depth": hist.depth, "prev_days": len(hist.prev_days)}
    campaigns = _campaigns(entities, stories, prof, p, min_hosts=campaign_min, hosts=on_board, book=nets)
    return Board(built_at=_time.time(), now=now, took_s=round(_time.monotonic() - t0, 2), window_start=window_start,
                 alerts=total_alerts, findings=len(fx), entities=entities, items=items, stories=stories,
                 targets=targets, externals=externals, hygiene=hygiene, tuning=tuning,
                 counts={"verdict": dict(counts), "actors": n_actors, "targets": len(target_f),
                         "externals": len(ext), "stories": len(stories), "explained": explained,
                         "hygiene_hosts": len(hyg_f)},
                 history=hist_info, unknown_rules=catalog.unknown(), rule_stats=rule_stats, names=names,
                 target_f=dict(target_f), hyg_f=dict(hyg_f), ext=ext, locs=locs, campaigns=campaigns,
                 roles=dict(roles), role_tips={k: dict(v) for k, v in role_tips.items()},
                 role_src={k: dict(v) for k, v in role_src.items()}, target_inc=target_inc, params=p,
                 # a profile learned from no stored day is the priors alone: a cold start, not a profile day
                 profile_day=prof.day if profile is not None and prof.days else None)


def _ties(e: Entity, p: Params = FACTORY) -> set:
    """What a host's confirmed evidence went after: its counterparts and the hosts it reached. A sweep's list of
    scanned addresses is left out: two scans of the same range would tie hosts that have nothing else in common."""
    out: set = set()
    for f in e.findings:
        if f.stage is not None and f.bits >= p["confirm_bits"]:
            if f.cp:
                out.add(f.cp)
            if f.kind != "scan":
                out |= f.targets
    return out


def _split_by_ties(members: list[Entity], p: Params = FACTORY) -> list[tuple[str | None, list[Entity]]]:
    """One pattern can hide separate incidents: hosts that went after different targets. Split a group into the
    hosts tied together by what their confirmed evidence touched (connected through shared counterparts) when that
    gives two or more parts of 3+ hosts and a tenth of the group each; each part is named by the counterpart most
    of its hosts share. The hosts left over stay together as the group they were. Otherwise the group stays whole:
    unrelated small pieces would flood the queue."""
    n = len(members)
    parent = {e.ip: e.ip for e in members}

    def find(x: str) -> str:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    by_tie: dict[str, list[str]] = defaultdict(list)
    ties = {e.ip: _ties(e, p) for e in members}
    for ip, ts in ties.items():
        for t in ts:
            by_tie[t].append(ip)
    for ips in by_tie.values():
        for ip in ips[1:]:
            ra, rb = find(ips[0]), find(ip)
            if ra != rb:
                parent[ra] = rb
    comp: dict[str, list[Entity]] = defaultdict(list)
    for e in members:
        comp[find(e.ip)].append(e)
    big = [c for c in comp.values() if len(c) >= max(3, n / 10)]
    if len(big) < 2:
        return [(None, members)]
    out, used = [], set()
    for c in sorted(big, key=lambda c: -len(c)):
        # named by where the attack went (a counterpart of the non-scan evidence of 30%+ of its hosts), else by
        # what most of them touched, else by the network most of them sit in
        aims = Counter(cp for e in c for cp in {f.cp for f in e.findings if f.cp and f.kind != "scan"
                                                and f.stage is not None and f.bits >= p["confirm_bits"]})
        touched = Counter(t for e in c for t in ties[e.ip])
        anchor = next((x for x, k in (aims.most_common(1) + touched.most_common(1)) if k >= 0.3 * len(c)),
                      "net-" + Counter(prefix(e.ip) for e in c).most_common(1)[0][0])
        out.append((anchor, c))
        used |= {e.ip for e in c}
    rest = [e for e in members if e.ip not in used]
    if rest:
        out.append((None, rest))
    return out


def story_title(chains: list[str], fams: list[str], p: Params = FACTORY) -> str:
    c = set(chains)
    if {"CR-08", "CR-09"} <= c and not c & set(p["act_chains"]):
        return "Recon, credential theft and lateral movement"
    if c:
        return CHAINS[next(x for x in CHAINS if x in c)][0]      # CHAINS is in id order: the first rule listed wins
    return " + ".join(FAMILIES[f][0] for f in fams[:3])


def _targets(target_f: dict, entities: dict, crown: set, ext: dict, names: dict, services: set,
             nets: AddressBook) -> list[dict]:
    out = []
    for ip, fs in target_f.items():
        attackers_int = {f.cp for f in fs if f.cp and nets.internal(f.cp)}
        attackers_ext = {f.cp for f in fs if f.cp and not nets.internal(f.cp)}
        fams = Counter()
        rules = Counter()
        for f in fs:
            fams[f.family] += f.n
            rules[f.rule.name] += f.n
        ti = sorted({t for a in attackers_ext for t in (ext.get(a) or {}).get("ti", ())})
        inbound_edge = [f for f in fs if f.cp in attackers_ext and f.kind in ("brute", "remote", "scan", "cred", "exposure")]
        responded = sum(f.down for f in fs)
        alerts = sum(f.n for f in fs)
        on_service = sum(f.n for f in fs if (f.rule.name, ip, f.port) in services)
        real = [k for k in fams if k not in ("HYG", "POL", "CL-09", "CL-07")]
        if ti or inbound_edge or (ip in crown and real and on_service < 0.8 * alerts) or len(real) >= 3:
            heat = "hot"
        elif on_service >= 0.8 * alerts:
            heat = "service"
        else:
            heat = "warm" if len(attackers_int | attackers_ext) >= 10 or attackers_ext else "noted"
        out.append({"ip": ip, "name": names.get(ip), "crown": ip in crown, "heat": heat,
                    "attackers": len(attackers_int | attackers_ext), "internal": len(attackers_int),
                    "external": len(attackers_ext), "ti": ti, "alerts": alerts,
                    "families": [k for k, _ in fams.most_common()], "rules": rules.most_common(4), "service": on_service,
                    "first": min(f.first for f in fs), "last": max(f.last for f in fs), "responded": responded,
                    "top_attackers": [a for a, _ in Counter({f.cp: f.n for f in fs if f.cp}).most_common(5)]})
    rank = {"hot": 3, "warm": 2, "service": 1, "noted": 0}
    out.sort(key=lambda t: (-rank[t["heat"]], -t["crown"], -t["external"], -t["attackers"], -t["alerts"]))
    return out


_INBOUND = {"remote": "RDP from the internet", "exposure": "exposed-service access from the internet", "brute": "brute force from the internet",
            "cred": "a credential attack from the internet", "scan": "a scan from the internet"}
ANSWER_BIG = factory("answer_floor_bytes")   # a victim that sent this much back to its attacker may have let it in


_SERVICE_NAME = {"Unauthorized RDP from/to the Internet": "RDP", "Unprotected Docker Daemon": "Docker daemon"}


def _service(rule: Rule) -> str:
    return _SERVICE_NAME.get(rule.name) or _proto(rule)


def _target_incidents(targets: list, target_f: dict, entities: dict, ext: dict, nets: AddressBook,
                      p: Params = FACTORY, prof=None) -> dict:
    """Hosts attacked from outside that need a decision of their own: an attack across the edge (RDP, brute
    force, credentials, a scan) or a listed address, and the host answered (or the address is listed). Victims of
    internal attackers are not: those attackers are incidents already, with this host in their story. A host that
    acts itself is not either: its own incident says more. A big answer is one above max(answer_floor_bytes, what
    the service normally sends back per client)."""
    out = {}
    for t in targets:
        ip = t["ip"]
        e = entities.get(ip)
        if (e is not None and e.verdict != "watch") or t["heat"] != "hot" or not t["external"]:
            continue
        fs = [f for f in target_f.get(ip, ()) if f.cp and not nets.internal(f.cp)]
        edge = [f for f in fs if f.kind in _INBOUND]
        listed = [f for f in fs if (ext.get(f.cp) or {}).get("ti")]
        answered = sum(f.down for f in fs)
        if not (edge or listed) or not (answered or listed):
            continue
        main = max(edge or listed, key=lambda f: (f.down, f.n))
        ti_names = sorted({x for f in listed for x in (ext.get(f.cp) or {}).get("ti", ())})
        attackers = sorted({f.cp for f in fs})
        if prof is not None:
            norm, why = _pf().answer_norm(prof, ip, main.port or "")
            bar, line = _bar("answer norm", norm, why, "answer_floor_bytes", p)
        else:
            bar = p["answer_floor_bytes"]
            line = Line("answer norm", float(bar), p.explain("answer_floor_bytes").source,
                        f"answer floor {fmt_bytes(bar)}")
        _push(main, "trace", line)
        big = answered >= bar
        exposed = [f for f in fs if f.rule.reclassified and f.rule.direction == "inbound"]     # inbound variant: answered by definition
        verdict = "investigate" if (t["crown"] or big or (listed and answered) or exposed) else "review"
        what = _INBOUND.get(main.kind) or f"contact with {fmt.with_article(ti_names[0] if ti_names else 'listed')} address"
        head = f"{what[0].upper()}{what[1:]} to {ip}" + (f":{main.port}" if main.port else "") + \
            (f" from {main.cp}" if len(attackers) == 1 else f" from {len(attackers)} outside addresses")
        why = [f"exposed to the internet and answered: {_service(exposed[0].rule)}" if exposed else "",
               f"it answered {fmt_bytes(answered)}" if answered else "it did not answer",
               "a crown jewel" if t["crown"] else "", f"the source is on a threat list ({', '.join(ti_names)})"
               if ti_names else "", "a target: no sign it acts itself"]
        fams = sorted({f.family for f in fs})
        out[ip] = TargetIncident(
            ip=ip, verdict=verdict, headline=head, reason="; ".join(w for w in why if w), first=min(f.first for f in fs),
            last=max(f.last for f in fs), alerts=sum(f.n for f in fs), crown=t["crown"], families=fams,
            fingerprint=fams + (["TI"] if listed else []) + (["answered"] if big else []),
            risk=round((0.2 if verdict == "investigate" else 0.05) * (p["crown_mult"] if t["crown"] else 1.0), 4),
            attackers=attackers[:20], ti=ti_names, answered=answered, kinds=sorted({f.kind for f in fs}),
            port=main.port or "", trace=(line,))
    return out


def _externals(ext: dict, hist: History, entities: dict, p: Params = FACTORY) -> list[dict]:
    out = []
    for ip, e in ext.items():
        attacks_in = bool(e["in_hosts"] and e["families"] & {"CL-04", "CL-05", "CL-11", "CL-10"})
        listed = "A" in e["classes"] and e["asn"] not in p["cloud_asns"]
        touches = bool(e["in_hosts"] or e["out_hosts"])
        rating = ("context" if not touches else "hostile" if attacks_in or listed
                  else "suspicious" if e["classes"] & {"A", "B", "C"} else "context")
        out.append({"ip": ip, "rating": rating, "ti": sorted(e["ti"]), "asn": e["asn"],
                    "asn_label": asn_label(e["asn"], e["country"]), "country": e["country"],
                    "in_hosts": len(e["in_hosts"]), "out_hosts": len(e["out_hosts"]),
                    "hosts": sorted(e["in_hosts"] | e["out_hosts"])[:50], "n": e["n"],
                    "rules": e["rules"].most_common(4), "first": e["first"], "last": e["last"],
                    "up": e["up"], "down": e["down"], "new": bool(hist.depth) and ip not in hist.ext_seen,
                    "families": sorted(e["families"]),
                    "wave": bool(e["ti"]) and len(e["out_hosts"]) >= 3})
    rank = {"hostile": 2, "suspicious": 1, "context": 0}
    out.sort(key=lambda x: (-rank[x["rating"]], -(x["in_hosts"] + x["out_hosts"]), -x["n"]))
    return out


def _hygiene(hyg_f: dict) -> list[dict]:
    by: dict[str, dict] = {}
    for ip, fs in hyg_f.items():
        for f in fs:
            b = by.setdefault(f.rule.name, {"rule": f.rule.name, "family": f.rule.family, "hosts": Counter(),
                                            "alerts": 0, "peers": Counter()})
            b["hosts"][ip] += f.n
            b["alerts"] += f.n
            if f.cp:
                b["peers"][f"{f.cp}:{f.port}" if f.port else f.cp] += f.n
    out = [{"rule": b["rule"], "family": b["family"], "label": FAMILIES[b["family"]][0], "hosts": len(b["hosts"]),
            "alerts": b["alerts"], "top": b["hosts"].most_common(8), "peers": b["peers"].most_common(3)}
           for b in by.values()]
    out.sort(key=lambda b: -b["hosts"])
    return out


def _rule_stats(fx: dict, n_actors: int, per_rule: Counter, p: Params = FACTORY) -> dict:
    st: dict[str, dict] = {}
    for f in fx.values():
        s = st.setdefault(f.rule.name, {"rule": f.rule.name, "family": f.rule.family, "cls": f.rule.cls,
                                        "stage": f.rule.stage, "known": f.rule.known, "alerts": 0, "actors": set(),
                                        "findings": 0, "bits": 0.0, "base": 0.0, "chronic": 0, "download": 0,
                                        "exfil": 0, "cloud": 0})
        if f.lane == "a":
            s["actors"].add(f.subject)
            s["findings"] += 1
            s["bits"] += f.bits
            s["base"] += f.base
            if f.days_looked >= 3 and f.days_seen >= 3:
                s["chronic"] += 1
            if f.rule.kind == "exfil":
                s["exfil"] += 1
                if f.kind == "download":
                    s["download"] += 1
            if f.asn in p["cloud_asns"]:
                s["cloud"] += 1
    out = {}
    for name, s in st.items():
        s["alerts"] = per_rule.get(name, 0)
        nf = max(1, s["findings"])
        out[name] = {**{k: v for k, v in s.items() if k != "actors"}, "actors": len(s["actors"]),
                     "share": len(s["actors"]) / max(1, n_actors), "value": (s["bits"] / s["base"]) if s["base"] else 0,
                     "chronic_pct": s["chronic"] / nf, "download_pct": (s["download"] / s["exfil"]) if s["exfil"] else 0,
                     "cloud_pct": s["cloud"] / nf}
    return out


def _tuning(svc_clients: dict, svc_alerts: Counter, n_actors: int, hist: History, exceptions: list, total: int,
            catalog: Catalog) -> dict:
    """Known-service candidates: one internal server:port that a large share of hosts hits with the same rule,
    day after day. Its alerts describe a service, not an attack; the analyst can accept it in one click."""
    services = []
    for sig, actors in svc_clients.items():
        name = sig[0]
        if catalog.get(name).cls == "A":
            continue
        share = len(actors) / max(1, n_actors)
        if len(actors) < max(10, 0.02 * n_actors):
            continue
        hist_share = hist.share(sig)
        days = hist.sig_days.get(sig, 0)
        days_seen = min(hist.sig_days_hab.get(sig, 0), hist.depth)
        steady = hist.depth >= 3 and days >= min(5, hist.depth - 1) and (hist_share or 0) >= 0.01
        if not (steady or (hist.depth < 3 and share >= 0.05)):
            continue
        covered = any((x["kind"] == "service" and x["rule"] in (name, "*") and x["server"] == sig[1]
                       and (x["port"] or "") in ("", sig[2]))
                      or (x["kind"] == "silence" and x.get("rule") in (None, name) and x.get("dst") == sig[1]
                          and not (x.get("src") or x.get("proto") or x.get("win_from") is not None)
                          and (x.get("port") or "") in ("", sig[2])) for x in exceptions)
        services.append({"rule": name, "server": sig[1], "port": sig[2], "actors": len(actors),
                         "alerts": svc_alerts[sig], "share_alerts": svc_alerts[sig] / max(1, total),
                         "share_hosts": share, "days": days_seen, "depth": hist.depth, "excepted": covered})
    services.sort(key=lambda s: -s["alerts"])
    return {"services": services[:50], "exceptions": exceptions}


# ---- triage overlay -----------------------------------------------------------------------------------------------

def overlay(e: Entity, t: dict | None) -> dict | None:
    """The analyst's state of one host as the pages show it: handled (out of the queue) unless the host shows
    something it did not show when it was handled."""
    if not t:
        return None
    new_parts = sorted(set(e.fingerprint) - set(t.get("fingerprint") or []))
    escalated = VRANK.get(e.verdict, 0) > VRANK.get(t.get("verdict") or "watch", 0)
    changed = bool(new_parts) or escalated
    return {"status": t["status"], "who": t.get("who"), "note": t.get("note"), "at": t.get("at"),
            "owner": t.get("owner"), "reason": t.get("reason"),
            "changed": changed, "new_parts": new_parts, "escalated": escalated,
            "handled": t["status"] in HANDLED and not changed}
