"""Which addresses are ours, and what we know about them.

Entries come from Sycope Lookups, the operator's network file and the settings; the book answers "is this IP
internal", "which entry names it" and "what is its location / function / business unit". Overlapping entries are
normal (a /8, the VLAN in it, one host): the most specific one answers, and a field it leaves empty comes from the
next less specific one.

The decision order for internal/external (spec 5.2): an admin override for the address, then the `privacy` of the
most specific lookup entry that has a usable one, then the configured networks (SC_INTERNAL_NETS), then the private
ranges, then "Sycope gave this IP a location".
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import re
from dataclasses import dataclass, fields
from functools import lru_cache

SOURCES = ("admin", "sycope-lookup", "file", "default")
DEFAULT_NETS = ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "169.254.0.0/16",
                "127.0.0.0/8", "fc00::/7", "fe80::/10", "::1/128")
_INTERNAL, _EXTERNAL = frozenset({"private", "internal"}), frozenset({"public", "external"})
_TEXT = ("name", "privacy", "location", "function", "service", "business_unit", "severity")


@dataclass(frozen=True)
class Entry:
    net: ipaddress.IPv4Network | ipaddress.IPv6Network
    name: str = ""
    privacy: str = ""
    location: str = ""
    function: str = ""
    service: str = ""
    business_unit: str = ""
    severity: str = ""
    source: str = "default"


def _nets(text: str) -> list:
    out = []
    for n in re.split(r"[\s,;]+", text or ""):
        if n:
            try:
                out.append(ipaddress.ip_network(n, strict=False))
            except ValueError:
                continue
    return out


_DEFAULTS = _nets(",".join(DEFAULT_NETS))


def _bits(version: int) -> int:
    return 32 if version == 4 else 128


class AddressBook:
    def __init__(self, entries: list[Entry] = (), extra: str = "", located: set[str] | None = None,
                 admin_internal: dict[str, bool] | None = None) -> None:
        self.entries = list(entries)
        self.extra = _nets(extra)
        self.located = set(located or ())
        self.admin_internal = dict(admin_internal or {})
        self.unknown_privacy = 0     # entries whose privacy is neither internal nor external (ignored); for Health
        self._idx: dict[int, dict[int, dict[int, list[Entry]]]] = {4: {}, 6: {}}
        for e in self.entries:
            p = e.privacy.strip().lower()
            if p and p not in _INTERNAL and p not in _EXTERNAL:
                self.unknown_privacy += 1
            n = e.net
            self._idx[n.version].setdefault(n.prefixlen, {}).setdefault(int(n.network_address), []).append(e)
        # one dict per prefix length, longest first: a lookup is at most 33 / 129 probes, never a scan
        self._plans = {v: [(plen, ((1 << plen) - 1) << (_bits(v) - plen)) for plen in sorted(by, reverse=True)]
                       for v, by in self._idx.items()}
        self._cache: dict[str, tuple[bool, str]] = {}

    def _matches(self, ip: str | None):
        """Entries covering the address, most specific first (the order they were given within one prefix)."""
        if not ip:
            return
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return
        by, n = self._idx[a.version], int(a)
        for plen, mask in self._plans[a.version]:
            hit = by[plen].get(n & mask)
            if hit:
                yield from hit

    def covering(self, ip: str | None) -> list[Entry]:
        """Every entry that covers the address, most specific first."""
        return list(self._matches(ip))

    def entry(self, ip: str | None) -> Entry | None:
        return next(self._matches(ip), None)

    def field(self, ip: str | None, name: str) -> str:
        """The most specific non-empty value of one field (name, privacy, location, function, service,
        business_unit, severity) over all entries that cover the address."""
        if name not in _TEXT:
            raise ValueError(f"unknown field {name}")
        return next((v for e in self._matches(ip) if (v := getattr(e, name))), "")

    def _decide(self, ip: str) -> tuple[bool, str]:
        if ip in self.admin_internal:
            return bool(self.admin_internal[ip]), "admin"
        for e in self._matches(ip):
            p = e.privacy.strip().lower()
            if p in _INTERNAL or p in _EXTERNAL:
                return p in _INTERNAL, e.source
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return False, "default"
        if any(a.version == n.version and a in n for n in self.extra):
            return True, "file"
        if any(a.version == n.version and a in n for n in _DEFAULTS):
            return True, "default"
        if ip in self.located:
            return True, "sycope-lookup"
        return False, "default"

    def _decision(self, ip: str | None) -> tuple[bool, str]:
        if not ip:
            return False, "default"
        v = self._cache.get(ip)
        if v is None:
            v = self._cache[ip] = self._decide(ip)
        return v

    def internal(self, ip: str | None) -> bool:
        return self._decision(ip)[0]

    def source(self, ip: str | None) -> str:
        """Where the internal/external answer for the address came from (one of SOURCES)."""
        return self._decision(ip)[1]

    def internal_cidrs(self) -> list:
        """The networks the book itself calls internal (the default ranges, SC_INTERNAL_NETS, lookup entries whose
        privacy is internal), collapsed: IPv4 first, then IPv6. What a flow filter can express; an exception that
        only the address decision knows (an admin override, a located IP) is not in it."""
        nets = [*_DEFAULTS, *self.extra, *(e.net for e in self.entries if e.privacy.strip().lower() in _INTERNAL)]
        return [n for v in (4, 6) for n in ipaddress.collapse_addresses(x for x in nets if x.version == v)]

    def snapshot(self) -> dict:
        """The whole book as plain JSON data (entries in the given order: it breaks ties)."""
        return {"entries": [{"net": str(e.net), **{k: getattr(e, k) for k in (*_TEXT, "source")}}
                            for e in self.entries],
                "extra": [str(n) for n in self.extra], "located": sorted(self.located),
                "admin_internal": {k: self.admin_internal[k] for k in sorted(self.admin_internal)}}

    @classmethod
    def from_snapshot(cls, d: dict) -> AddressBook:
        names = {f.name for f in fields(Entry)} - {"net"}
        es = [Entry(ipaddress.ip_network(e["net"]), **{k: v for k, v in e.items() if k in names})
              for e in d.get("entries", [])]
        return cls(es, ",".join(d.get("extra", [])), set(d.get("located", [])), d.get("admin_internal"))

    def digest(self) -> str:
        return hashlib.sha256(json.dumps(self.snapshot(), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@lru_cache(maxsize=100_000)
def prefix(ip: str, v4: int = 24, v6: int = 64) -> str:
    """The network of an address as text: 10.1.2.3 -> 10.1.2.0/24, 2001:db8:1:2::5 -> 2001:db8:1:2::/64. Anything
    that is not an address comes back unchanged."""
    try:
        a = ipaddress.ip_address(ip)
        return str(ipaddress.ip_network(f"{a}/{v4 if a.version == 4 else v6}", strict=False))
    except ValueError:
        return ip


def net16(ip: str) -> str:
    """The wider group of the campaign view: /16 for IPv4, /48 for IPv6."""
    return prefix(ip, 16, 48)
