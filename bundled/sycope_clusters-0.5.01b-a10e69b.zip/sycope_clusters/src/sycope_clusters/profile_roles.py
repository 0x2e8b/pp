"""Roles, segments and suggestions for the environment profile (profile.py).

Roles (spec 5.4): the lookup's networkFunction / service first, then the services a host offers in the netflow
aggregate: a port served to at least max(3, role_service_share x the active hosts of its segment) clients on the
median comparable day. Resolver and service roles apply at once (spec 12, call 1). Roles that would only lower the
evidence of a host (scanner, backup, monitoring) are suggestions an admin confirms (D38), never roles, and are never
offered for a host the incident history holds back from the norms.

Segments: the most specific lookup subnet (no wider than /16, /48 for IPv6) that holds segment_min_hosts active
hosts, else the host's /24 (/64) widened one bit at a time until it holds that many or reaches /16 (/48).
"""

from __future__ import annotations

import ipaddress
import math
import re
from collections import Counter, defaultdict
from statistics import median

from sycope_clusters import fmt
from sycope_clusters.addresses import AddressBook, prefix
from sycope_clusters.priors import Priors

WORKSTATION = "workstation"
PORT_ROLE = {"53": "resolver", "67": "dhcp", **dict.fromkeys(("88", "389", "636", "3268"), "directory"),
             **dict.fromkeys(("1433", "1521", "3306", "5432", "27017"), "database"), "445": "file",
             **dict.fromkeys(("80", "443", "8080", "8443"), "web"),
             **dict.fromkeys(("25", "465", "587", "993"), "mail"),
             **dict.fromkeys(("502", "102", "20000", "44818", "47808"), "iot-ot")}
PROXY_PORTS = ("3128", "8080")
# the main role when a host has several: the one that says most about what the host is for
ROLE_ORDER = ("directory", "resolver", "dhcp", "database", "file", "mail", "proxy", "web", "iot-ot")
LOWERING = ("scanner", "backup", "monitoring")
CROWN_ROLES = ("directory", "database", "file")
FAN_IN_MIN = 10    # clients on the busiest day before a server is the top fan-in of its segment
MONITOR_PORTS = frozenset({"161", "162", "623", "5666", "9100", "10050", "10051"})
# words of a lookup's networkFunction / service -> role
_WORDS = {"dns": "resolver", "resolver": "resolver", "dhcp": "dhcp", "directory": "directory", "ldap": "directory",
          "kerberos": "directory", "dc": "directory", "database": "database", "db": "database", "sql": "database",
          "file": "file", "nas": "file", "smb": "file", "mail": "mail", "smtp": "mail", "exchange": "mail",
          "proxy": "proxy", "nat": "proxy", "gateway": "proxy", "web": "web", "http": "web", "iot": "iot-ot",
          "ot": "iot-ot", "scada": "iot-ot", "plc": "iot-ot", "ics": "iot-ot", "workstation": WORKSTATION,
          "desktop": WORKSTATION, "laptop": WORKSTATION, "scanner": "scanner", "vulnerability": "scanner",
          "backup": "backup", "monitoring": "monitoring", "nms": "monitoring", "snmp": "monitoring"}
_PHRASES = (("domain controller", "directory"), ("active directory", "directory"), ("file server", "file"))
_LIMIT = {4: 16, 6: 48}
_START = {4: 24, 6: 64}
_BITS = {4: 32, 6: 128}


def text_role(text: str) -> str | None:
    """The role a lookup's free text names, or None."""
    t = text.lower()
    for phrase, r in _PHRASES:
        if phrase in t:
            return r
    for w in re.split(r"[^a-z0-9]+", t):
        if w in _WORDS:
            return _WORDS[w]
    return None


def _net(version: int, value: int, plen: int) -> str:
    cls = ipaddress.IPv4Network if version == 4 else ipaddress.IPv6Network
    return str(cls((value << (_BITS[version] - plen), plen)))


def segments(hosts: set[str], book: AddressBook, min_hosts: int,
             known: dict[str, int] | None = None) -> tuple[dict[str, str], dict[str, int]]:
    """(host -> segment, segment -> active hosts in it). With `known` (last week's segments), a host inside one of
    them joins it first."""
    seg_of: dict[str, str] = {}
    seg_n: dict[str, int] = {}
    parsed = []
    for ip in sorted(hosts):
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            continue
        parsed.append((ip, a.version, int(a)))
    if known:
        for ip, v, x in parsed:
            for plen in range(_BITS[v] - 1, _LIMIT[v] - 1, -1):
                net = _net(v, x >> (_BITS[v] - plen), plen)
                if net in known:
                    seg_of[ip] = net
                    break
    if book.entries:
        cand: dict[str, list[str]] = {}
        count: Counter = Counter()
        for ip, v, _x in parsed:
            if ip in seg_of:
                continue
            nets = []
            for e in book.covering(ip):
                net = str(e.net)
                if _LIMIT[v] <= e.net.prefixlen < _BITS[v] and net not in nets:
                    nets.append(net)
            cand[ip] = nets
            count.update(nets)
        for ip, nets in cand.items():
            for net in nets:
                if count[net] >= min_hosts:
                    seg_of[ip] = net
                    seg_n[net] = count[net]
                    break
    rest = [(ip, v, x) for ip, v, x in parsed if ip not in seg_of]
    levels: dict[tuple, Counter] = {}
    for v in (4, 6):
        mine = [x for _ip, vv, x in rest if vv == v]
        for plen in range(_START[v], _LIMIT[v] - 1, -1):
            levels[(v, plen)] = Counter(x >> (_BITS[v] - plen) for x in mine)
    for ip, v, x in rest:
        for plen in range(_START[v], _LIMIT[v] - 1, -1):
            key = x >> (_BITS[v] - plen)
            c = levels[(v, plen)][key]
            if c >= min_hosts or plen == _LIMIT[v]:
                net = _net(v, key, plen)
                seg_of[ip] = net
                seg_n[net] = c
                break
    return seg_of, seg_n


def _medians(rows: dict, ndays: int) -> dict:
    """key -> median over the comparable days of a per-day count (a day without a row counts 0)."""
    return {k: median(sorted([*by_day.values(), *[0] * (ndays - len(by_day))])) for k, by_day in rows.items()}


def _need(pr: Priors, seg_active: Counter, seg_of: dict[str, str], ip: str, nd: int) -> float:
    """Clients a port must serve before the host has the port's role: max(3, share of the segment's active hosts)."""
    return max(3, pr.role_service_share * seg_active.get(seg_of.get(ip, ""), 0) / nd)


def role_day_counts(role_sets: dict[str, set], srv: list[tuple], days: list[str], active: dict[str, set],
                    seg_of: dict[str, str], pr: Priors) -> dict[str, dict[str, list[int]]]:
    """host -> role -> [days it served enough clients on that role's port, comparable days]: what "learned role from
    N of M days" says. Only roles the flows gave (a role from the lookup or an old profile has no count)."""
    nd = max(1, len(days))
    mine: dict[str, set] = defaultdict(set)
    for r, ips in role_sets.items():
        for ip in ips:
            mine[ip].add(r)
    seg_active: Counter = Counter()
    for d in days:
        seg_active.update(seg_of.get(h, "") for h in active.get(d, ()))
    seen: dict[tuple, set] = defaultdict(set)
    ds = set(days)
    for d, ip, port, c, _up, _down, ext in srv:
        if ext or d not in ds or ip not in mine:
            continue
        port = str(port)
        r = "proxy" if port in PROXY_PORTS and "proxy" in mine[ip] else PORT_ROLE.get(port)
        if r in mine[ip] and (c or 0) >= _need(pr, seg_active, seg_of, ip, nd):
            seen[(ip, r)].add(d)
    out: dict[str, dict[str, list[int]]] = {}
    for (ip, r), got in sorted(seen.items()):
        out.setdefault(ip, {})[r] = [len(got), nd]
    return out


def roles_of(hosts: set[str], book: AddressBook, srv: list[tuple], cli: list[tuple], days: list[str],
             active: dict[str, set], seg_of: dict[str, str], iot: set[str], pr: Priors,
             held: set[str] = frozenset(), prev_role_of: dict[str, str] | None = None):
    """(role -> hosts, host -> main role, host -> (lowering role, reason) from the lookup). `cli` holds our own
    hosts only. An explicit lookup function wins over the flows. A held host (one the incident history keeps out of
    the norms) keeps the role of the previous profile whatever its flows show; only a resolver role still comes
    automatically (it moves evidence to the clients behind it, it does not lower it)."""
    nd = max(1, len(days))
    seg_active: Counter = Counter()
    for d in days:
        seg_active.update(seg_of.get(h, "") for h in active.get(d, ()))
    clients: dict[tuple, dict] = defaultdict(dict)
    for d, ip, port, c, _up, _down, ext in srv:
        if not ext:
            clients[(ip, str(port))][d] = c or 0
    peers: dict[str, dict] = defaultdict(dict)
    for d, ip, pe, *_ in cli:
        peers[ip][d] = pe or 0
    med_clients = _medians(clients, nd)
    med_peers = _medians(peers, nd)
    found: dict[str, set] = defaultdict(set)
    for (ip, port), c in sorted(med_clients.items()):
        need = _need(pr, seg_active, seg_of, ip, nd)
        if c < need:
            continue
        if port in PROXY_PORTS and med_peers.get(ip, 0) >= max(3, c):
            found[ip].add("proxy")
        elif port in PORT_ROLE:
            found[ip].add(PORT_ROLE[port])
    for ip in iot:
        found[ip].add("iot-ot")
    prev_role_of = prev_role_of or {}
    role_of: dict[str, str] = {}
    lowering: dict[str, tuple[str, str]] = {}
    for ip in sorted(hosts | set(found) | (set(prev_role_of) & held)):
        named = None
        if book.entries:
            for fld in ("function", "service"):
                text = book.field(ip, fld)
                r = text_role(text) if text else None
                if r in LOWERING:
                    lowering.setdefault(ip, (r, f"the Sycope lookup says {text!r}"))
                elif r and named is None:
                    named = r
        if named:
            found[ip] = set() if named == WORKSTATION else {named}
        elif ip in held:
            old = prev_role_of.get(ip)
            found[ip] = ({old} if old else set()) | ({"resolver"} & found.get(ip, set()))
            named = old
        mine = found.get(ip)
        if named and named != WORKSTATION:
            role_of[ip] = named
        elif mine and not named and ip not in held:
            role_of[ip] = next(r for r in ROLE_ORDER if r in mine)
    role_sets: dict[str, set] = defaultdict(set)
    for ip, rs in found.items():
        for r in rs:
            role_sets[r].add(ip)
    return dict(role_sets), role_of, lowering


def suggest(days: list[str], srv: list[tuple], ext_cli: list[tuple], book: AddressBook, excluded: set[str],
            role_of: dict[str, str], lowering: dict[str, tuple[str, str]], scan_days: dict[str, set],
            mon_days: dict[str, set], per_host: dict[str, list[float]], role_norm: dict[str, float], ceiling: float,
            min_peers: int, seg_of: dict[str, str] | None = None) -> list[dict]:
    """What an admin may want to confirm: public IPs that look like ours, lowering roles, crown jewel candidates.
    A public IP looks like ours only from both sides (spec 5.2 item 5): a server to many of our hosts and a client
    to many outside peers, each on at least 3 of the comparable days."""
    out: dict[str, dict] = {}

    def add(kind: str, subject: str, reason: str, what: str = "", basis: str = "") -> None:
        """`basis` is what the suggestion rests on, without counts (profile.evidence_key): a rejected suggestion
        comes back only when it changes."""
        key = f"{kind}:{what + ':' if what else ''}{subject}"
        out.setdefault(key, {"kind": kind, "subject": subject, "reason": reason, "key": key,
                             "basis": basis or what, **({"role": what} if what else {})})

    out_days: dict[str, set] = defaultdict(set)
    out_top: Counter = Counter()
    for d, ip, pe, *_ in ext_cli:
        if (pe or 0) >= min_peers:
            out_days[ip].add(d)
            out_top[ip] = max(out_top[ip], pe or 0)
    ext_days: dict[str, set] = defaultdict(set)
    ext_top: Counter = Counter()
    for d, ip, _port, c, _up, _down, ext in srv:
        if ext:
            ext_days[ip].add(d)
            ext_top[ip] = max(ext_top[ip], c or 0)
    for ip in sorted(ext_days):
        if len(ext_days[ip]) >= 3 and len(out_days.get(ip, ())) >= 3 and not book.internal(ip):
            add("internal-ip", ip, f"served up to {ext_top[ip]} of your hosts on {len(ext_days[ip])} of the last "
                f"{len(days)} days and talked to up to {out_top[ip]} outside addresses itself on "
                f"{len(out_days[ip])}: it behaves like one of your servers. Add it to the Sycope lookup or mark it "
                "internal", basis="server+client")
    need = max(3, math.ceil(len(days) / 2))
    for ip in sorted(set(scan_days) | set(lowering)):
        if ip in excluded:
            continue
        if ip in lowering:
            r, why = lowering[ip]
            add("role", ip, f"{why}: confirm it as {fmt.with_article(r)} to read its alerts as expected", r)
        elif len(mon_days.get(ip, ())) >= need:
            add("role", ip, f"scanned monitoring ports on {len(mon_days[ip])} of {len(days)} days: a monitoring "
                "poller?", "monitoring")
        elif len(scan_days[ip]) >= need:
            add("role", ip, f"scanned on {len(scan_days[ip])} of {len(days)} days: a vulnerability scanner?", "scanner")
    for ip, ups in sorted(per_host.items()):
        if ip in excluded:
            continue
        limit = ceiling * role_norm.get(role_of.get(ip, WORKSTATION), role_norm[WORKSTATION])
        heavy = sum(1 for u in ups if u >= limit)
        if heavy >= max(3, math.ceil(0.7 * len(ups))):
            add("role", ip, f"uploaded more than {ceiling:g}x a normal {role_of.get(ip, WORKSTATION)} on {heavy} of "
                f"{len(ups)} days: a backup server?", "backup")
    for ip, r in sorted(role_of.items()):
        if r in CROWN_ROLES and not book.field(ip, "severity"):
            add("crown", ip, f"{fmt.with_article(r)} server: a crown jewel?", basis=r)
    fan: dict[str, int] = {}
    fan_days: dict[str, set] = defaultdict(set)
    for d, ip, _port, c, _up, _down, ext in srv:
        if not ext and (c or 0) > 0:
            fan[ip] = max(fan.get(ip, 0), c)
            fan_days[ip].add(d)
    top: dict[str, tuple[int, str]] = {}
    for ip in sorted(fan):
        if fan[ip] < FAN_IN_MIN or len(fan_days[ip]) < max(3, math.ceil(len(days) / 2)) or ip in excluded \
                or book.field(ip, "severity"):
            continue
        seg = (seg_of or {}).get(ip) or prefix(ip)
        if seg not in top or fan[ip] > top[seg][0]:
            top[seg] = (fan[ip], ip)
    for seg, (c, ip) in sorted(top.items()):
        add("crown", ip, f"served up to {c} clients on {len(fan_days[ip])} of the last {len(days)} days, the busiest "
            f"server of {seg}: a crown jewel?", basis="fan-in")
    return [out[k] for k in sorted(out, key=lambda k: (out[k]["kind"], out[k]["subject"], k))]
