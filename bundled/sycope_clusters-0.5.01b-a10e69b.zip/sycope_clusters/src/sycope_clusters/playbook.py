"""Next steps for an incident: what to check, in what order, with the links that do it.

Deterministic, from the same evidence as the verdict, so a junior gets the checklist a senior would follow and an
auditor can see why each step is there: the chain rules first (they say what kind of attack this is), then the
families with the most evidence, then the context (a crown jewel, recorded packets). Every step says what to look at
and why.

    check   in Sycope or in the recorded packets; its links are flows of a pair or the alerts of a rule
    ask     outside Sycope: EDR, the auth logs, the host's owner
    act     containment once the checks confirm it; these are the recommended actions of the ticket for IT

A step's id stays the same while its evidence does (host, rule, counterpart), so a checked step stays checked across
refreshes and new evidence brings new, unchecked steps. Ids carry the host, so the steps of several hosts can be kept
under one group incident.

Template ids. Besides its instance id every step has a `template`: the id of the generator branch that made it,
the same for every host and every release as long as the step means the same thing. The name is
`<chain or family>.<kind>.<slug>` (CR-08.ask.auth-logs, CL-04.check.targets); steps that belong to neither use a
group word in place of the chain or family: pcap, crown, verdict (the host), target (an attacked host), group,
campaign. The kind in the name is the factory kind; the slug says what the step does. A branch with several wordings
of one step has one template per wording (CL-04.check.ports, .targets, .scanned). TEMPLATES holds the text of every
template with {placeholders}; the generators fill it, so FACTORY_HASH (title + why of the pattern) changes exactly
when a step's factory text changes.

The overlay. The admin's edits are patches over the factory steps, keyed by template id (spec D46), kept in the
configuration (`playbook`, a list of operations, see validate_overlay) and applied by apply() after the factory
steps are built: hide, edit (title, why, kind; stale when the factory text changed since), add (a step of their own
bound to a chain, a family or a finding kind, with an optional link template) and move (after another template).
Instance ids never change, so what the team ticked survives every edit.
"""

from __future__ import annotations

import hashlib
import re
from collections import Counter
from types import SimpleNamespace
from urllib.parse import quote, urlsplit

from sycope_clusters import evidence as ev
from sycope_clusters.params import FACTORY, Params, factory
from sycope_clusters.rules import FAMILIES, Catalog, display_name

H = 3600 * 1000
MAX_HOST = 8
KINDS = ("check", "ask", "act")
VL = {"act": "Act now", "investigate": "Investigate", "review": "Review", "watch": "Watch"}
# families whose first look a chain step already gives
_COVERED = {"CR-01": {"CL-06"}, "CR-04": {"CL-12"}, "CR-05": {"CL-01", "CL-02", "CL-03"}}
_ADMIN_PORTS = {"22": "SSH", "135": "RPC", "445": "SMB", "3389": "RDP", "5985": "WinRM", "5986": "WinRM"}

# template id -> (factory kind, title, why); {name} is filled by the generator that makes the step
TEMPLATES: dict[str, tuple[str, str, str]] = {
    # chain rules
    "CR-01.act.contain": (
        "act", "Contain {ip} now: isolate it, or block {dest} at the edge",
        "A command channel and a large upload on the same host: data is leaving under someone else's control."),
    "CR-01.check.what-left": (
        "check", "Work out what left: {size} up to {cpl}",
        "The size and the time tell the data owner what to look for."),
    "CR-02.act.escalate": (
        "act", "Escalate to incident response",
        ("Three of the four kill-chain steps (scanning, credentials or lateral movement, a command channel, "
        "exfiltration) on one host: more than one analyst's alert.")),
    "CR-04.check.compare": (
        "check", "Compare what it collected ({staged} from internal hosts) with what went out ({sent} to {cpl})",
        "Data staged inside and then uploaded: amounts that match mean the same data."),
    "CR-05.ask.process": (
        "ask", "Find the process on {ip} that talks to {cpl}",
        ("EDR or netstat on the host. A listed address and a beacon on one host is a known-bad channel, not a "
        "coincidence.")),
    "CR-05.act.block": (
        "act", "Block {addr} at the firewall or proxy; isolate {ip} if the process is unknown",
        "It cuts the channel while the host is examined."),
    "CR-06.check.attackers": (
        "check", "Look at the hosts that attacked {ip}: {attackers}",
        ("They went after it over credentials or lateral movement before it started calling a command channel: "
         "what else did they reach, and are they compromised too?")),
    "CR-06.ask.login": (
        "ask", "Did a login from {attackers} to {ip} succeed before its first call out? Ask the owner, check the auth logs",
        ("Windows: event 4624 (logon type 3 or 10) with the attacker as source; Linux: 'Accepted' lines of sshd. A "
         "successful login shortly before the channel starts is the likely way in.")),
    "CR-06.act.isolate": (
        "act", "Isolate {ip} and block {addr} at the firewall or proxy",
        "Attacked from inside, then calling out: the host is probably compromised, and the channel is how it is run."),
    "CR-08.ask.auth-logs": (
        "ask", "Find the account it used: logons from {ip} on {where}",
        ("Windows: event 4624 (logon type 3 or 10) with source {ip}; Linux: 'Accepted' lines of sshd. A credential "
        "attack and then movement to other hosts means the attack probably worked.")),
    "CR-08.act.reset-password": (
        "act", "Reset the password of the account it used and check the hosts it reached",
        "Stolen credentials keep working until they are changed."),
    "CR-09.check.follow": (
        "check", "Did the attack on {tgt} work? Look for a longer session or data both ways after the attempts",
        ("It scanned {tgt} first and then went after it: a session that lasts or carries data after the attempts "
        "means it got in.")),
    "CR-09.check.next": (
        "check", "{tgt} is at {verdict} itself now: look at it next",
        "The host it attacked acts on its own: the next hop of the same attack."),
    "CR-10.check.days": (
        "check", "The same channel to {cpl} on {n} of the last {days} days: an implant, or a program nobody listed?",
        "Look at Last days on this page and ask the owner whether known software uses this address."),
    # families
    "CL-01.check.exchange": (
        "check", "See what was exchanged with {cpl} ({ti}): ports, bytes each way, how long",
        "One lookup or a blocked attempt is not a compromise; a session that carries data is."),
    "CL-01.check.shared-cloud": (
        "check", "{cp} is a shared {cloud} address: check the name the host looked up (DNS or proxy logs)",
        "Threat lists often carry shared cloud addresses: a stale entry is the usual false positive here."),
    "CL-01.check.other-hosts": (
        "check", "Other internal hosts that talked to {cp}",
        "Many hosts: a widely used service, or a wider infection. One host: start there."),
    "CL-02.check.rhythm": (
        "check", "Look at the rhythm of connections to {cpl}: regular intervals and small payloads point to a beacon",
        "Malware calls home on a timer; people and most programs do not."),
    "CL-02.ask.program": (
        "ask", "Ask the owner which program on {ip} talks to {cp}{asn}",
        "Updaters, monitoring agents and sync clients poll too; the owner or EDR can tell."),
    "CL-03.check.traffic": (
        "check", "See the traffic to {cpl}: how much and how long",
        "TOR, proxies and protocol tricks hide what the traffic is."),
    "CL-03.ask.allowed": (
        "ask", "Is it allowed on {ip} (a VPN, a privacy tool)? Ask the owner",
        "Most policies forbid anonymizers on company hosts; the owner's answer decides benign or not."),
    "CL-04.check.ports": (
        "check", "See which ports of {cp} it probed and which answered",
        "An answer is a service it found; that is where it goes next."),
    "CL-04.check.targets": (
        "check", "See which of the {n} hosts it scanned{on} answered",
        "An answer is a service it found; that is where it goes next."),
    "CL-04.check.scanned": (
        "check", "See what it scanned and what answered",
        "An answer is a service it found; that is where it goes next."),
    "CL-04.ask.authorized": (
        "ask", "Is {ip} an authorized scanner (vulnerability scanner, monitoring, an admin's tool)?",
        ("Most scanning inside a network is IT's own tools. If it is one, close as benign and allow it (Allow this "
        "behaviour) so it stops coming back.")),
    "CL-05.check.login-success": (
        "check", ("Did a login succeed? After the attempts on {cpl}, look for one session that lasts longer or carries "
        "more data"), "Failed attempts are short and alike; the one that worked stands out."),
    "CL-05.ask.brute-logs": (
        "ask", "Check the auth logs of {target} for logons from {ip}",
        "Windows: 4625 failed and 4624 successful logons; Linux: sshd 'Failed' and 'Accepted'."),
    "CL-05.ask.external-process": (
        "ask", "Find the process on {ip} that talks Kerberos or LDAP to {cpl}",
        "Kerberos and LDAP never need to leave the network; outside, they leak tickets and directory data."),
    "CL-05.check.llmnr": (
        "check", "See which hosts it exchanged LLMNR/NetBIOS traffic with",
        ("Tools like Responder answer these lookups to catch password hashes; ordinary Windows hosts send them too, so "
        "it matters only with other evidence.")),
    "CL-05.check.sessions": (
        "check", "Look at the sessions to {cpl}: duration and bytes each way",
        ("A change in how a host logs in (client, protocol, timing) is how stolen credentials or tunnels show in "
        "flows.")),
    "CL-05.ask.auth-logs": (
        "ask", "Check the auth logs of {target} for logons from {ip}",
        "The logs say whether a login worked and which account it used."),
    "CL-10.check.reach": (
        "check", "See which internal hosts it reached over {proto}{n} and which answered",
        "A host that answered is where the attacker may be now."),
    "CL-10.check.next-hop": (
        "check", "{tgt}, a host it reached, is at {verdict}: look at it next", "The next hop of the same attack."),
    "CL-10.ask.admin-host": (
        "ask", "Is {ip} an admin workstation or a jump host?",
        "Admins move between servers all day: then it is benign (Admin activity)."),
    "CL-11.check.rdp-sessions": (
        "check", "See the RDP sessions with {cpl}: who started them and how long they lasted",
        "RDP across the internet edge is how ransomware crews get in."),
    "CL-05.check.edge-process": (
        "check", "Find which process or host on {ip} talks {proto} to {cpl}",
        "{proto} is not meant to leave the network: a misconfigured client or something sending data out."),
    "CL-05.act.block-edge": (
        "act", "Block outbound 445, 2049, 389 and 636 at the edge",
        "File-sharing and directory protocols have no business on the internet; the block also stops the leak."),
    "CL-05.ask.reset-creds": (
        "ask", "Reset the credentials of the users on {ip} if NTLM or directory credentials could have leaked?",
        "{proto} to an outside server hands over a challenge-response that can be cracked or relayed."),
    "CL-11.act.close-rdp": (
        "act", "Close RDP at the edge (allow it only through the VPN)",
        "An exposed RDP port is found by scanners within hours."),
    "CL-06.check.upload": (
        "check", "See the upload to {cpl}: {up} out, {down} in, when",
        "The time and the size are what the data owner needs to say what it was."),
    "CL-06.ask.sanctioned": (
        "ask", "Is {dest} a service the company uses (backup, file sharing)?{asn}",
        "A sanctioned backup or sync is benign (Backup or sync job); an unknown destination is not."),
    "CL-12.check.staging": (
        "check", "See which internal hosts it pulled data from ({size})",
        "Collecting from many hosts before an upload is how data theft is prepared."),
    "CL-08.check.flood": (
        "check", "See the flood traffic to {cpl}",
        "An internal host that sends floods is usually a bot, or a load test someone forgot to announce."),
    "CL-08.act.isolate": (
        "act", "Isolate {ip} unless it is an announced test", "A bot takes orders from outside; it will flood again."),
    "CL-07.check.compare-days": (
        "check", "Compare with the days before (Last days on this page)",
        "Unusual volume alone is weak: a backup or an update window is the usual cause."),
    # the host's context
    "pcap.check.packets": (
        "check", "Open the packets recorded for {done} alert{s} of {ip}",
        "Packets show what flows cannot: the commands, the files, the names."),
    "crown.ask.owner": (
        "ask", "{ip} is a crown jewel: tell its owner or service team before you act",
        "Isolating or restarting a critical system needs its owner, who also knows what is normal for it."),
    "verdict.act.isolate": (
        "act", "Isolate {ip} (EDR or its switch port) if a check above confirms the attack",
        "Act now: the evidence already points to a compromise; containment buys time to find out how far it went."),
    # a host attacked from outside
    "target.check.answer": (
        "check", "See what {cp} sent and what {ip} sent back{on}",
        "Short refused attempts are noise; a session that lasts or carries data is a login."),
    "target.ask.auth-logs": (
        "ask", "Check the auth logs of {ip} for logons from outside",
        ("Windows: 4624 logon type 10 (RDP) or 3; Linux: 'Accepted' lines of sshd. A successful login from the "
        "internet is the incident.")),
    "target.ask.exposed": (
        "ask", "Should {svc} on {ip} be reachable from the internet at all?",
        "Most are not meant to be: an open admin port is found by scanners within hours."),
    "target.check.after": (
        "check", "See whom {ip} reached after the attack",
        "A host that was let in starts acting itself: new connections out after the session."),
    "target.check.sessions": (
        "check", "Look for successful sessions on {ip}{on} from {who}",
        "An answered connection on a service meant to stay inside may already be a login."),
    "target.act.close": (
        "act", "Close {svc} at the edge (VPN only) and block {who}",
        "Removes the exposure; the block stops this source, the closed port stops the next one."),
    # a group of hosts, a campaign
    "group.check.lead": (
        "check", "Start with {ip}{name}, the host with the most evidence",
        "The {n} hosts share the pattern: what explains one usually explains the rest."),
    "group.check.shared": (
        "check", "{n} of the {total} hosts have {cp} in their evidence: one source or one target behind all of them?",
        "A shared counterpart is the thread that ties the group together."),
    "group.ask.rollout": (
        "ask", "Is this a tool rolled out on these hosts (a scanner, an agent, a backup job)?",
        ("The same behaviour on many hosts at once is more often software than an attacker. If it is, close the "
        "group as benign in one go.")),
    "campaign.check.first": (
        "check", "Start with the most urgent incident inside: {lbl} ({verdict})",
        "The campaign is made of its incidents; the top one tells the most."),
    "campaign.check.shared": (
        "check", "{n} of its {total} hosts have {cp} in their evidence",
        "One counterpart behind many hosts: one source driving the wave, or one target everyone goes after."),
    "campaign.check.where": (
        "check", "See where it is: most hosts are in {top}",
        "A wave inside one segment points to one cause there (a switch, a server, a rollout)."),
    "campaign.ask.change": (
        "ask", "Is a change, a rollout or a scan planned in {net}?",
        "Most network-wide waves are planned work; a change ticket closes them as benign."),
    "campaign.act.escalate": (
        "act", "Escalate to incident response if the top incidents hold up",
        "Act now across a whole network: more than one analyst can contain."),
}
# a step one chain rule makes for several: template -> the other rules it serves (listed once, under the first)
SHARED_STEPS = {"CR-02.act.escalate": ("CR-03",)}
# what an admin sees to know a factory step changed: sha1 of the pattern text, 12 hex
FACTORY_HASH: dict[str, str] = {
    t: hashlib.sha1(f"{title}\n{why}".encode()).hexdigest()[:12] for t, (_k, title, why) in TEMPLATES.items()}

# The templates only Clusters has (a chain rule Triage does not know). Kept apart from TEMPLATES so Triage's pinned
# set and its golden hashes stay as they are; the overlay treats them like any other template (ALL_HASH).
CLUSTER_TEMPLATES: dict[str, tuple[str, str, str]] = {
    "CR-07.check.segment": (
        "check", "Check the other scanning hosts in {segment}",
        ("Several hosts of one segment scanning within hours is a worm or a rolled-out tool: the others show how far "
         "it went and what started it.")),
}
ALL_HASH: dict[str, str] = {**FACTORY_HASH, **{
    t: hashlib.sha1(f"{title}\n{why}".encode()).hexdigest()[:12] for t, (_k, title, why) in CLUSTER_TEMPLATES.items()}}


def _step(sid: str, tpl: str, links: list | tuple = (), src: str = "", **v: object) -> dict:
    """A step of a template, its {placeholders} filled from `v`."""
    kind, title, why = TEMPLATES.get(tpl) or CLUSTER_TEMPLATES[tpl]
    return {"id": sid[:160], "kind": kind, "title": title.format(**v), "why": why.format(**v),
            "links": [x for x in links if x], "src": src, "template": tpl}


def _pair(f: ev.Finding) -> tuple[str | None, str | None]:
    return (f.cp, f.subject) if f.as_server else (f.subject, f.cp)


def _flows(c: str | None, s: str | None, port: str | None, first: int, last: int, label: str) -> dict | None:
    if not (c or s):
        return None
    return {"t": "flows", "c": c, "s": s, "port": port or None, "from": first, "to": last, "label": label}


def _fflows(f: ev.Finding | None, label: str = "", after: int = 0) -> dict | None:
    """The flows of a finding's pair, its port, its time (plus `after` ms, to see what followed)."""
    if f is None:
        return None
    c, s = _pair(f)
    port = f.port if f.kind != "scan" else None
    return _flows(c, s, port, f.first, f.last + after, label or f"flows {c or 'any'} → {s or 'any'}"
                  + (f":{port}" if port else ""))


def _alerts(f: ev.Finding, label: str = "") -> dict:
    c, s = _pair(f)
    return {"t": "alerts", "rule": f.rule.name, "c": c, "s": s, "from": f.first, "to": f.last,
            "label": label or f"{display_name(f.rule.name)} alerts"}


def _host(ip: str, label: str) -> dict:
    return {"t": "host", "ip": ip, "label": label}


def _strong(e: ev.Entity, fam: str, p: Params = FACTORY) -> list[ev.Finding]:
    confirm = p["confirm_bits"]
    return sorted((f for f in e.findings if f.family == fam and f.stage is not None and f.bits >= confirm),
                  key=lambda f: (-f.bits, -f.n))


def _top(e: ev.Entity, fam: str) -> ev.Finding | None:
    """The finding that speaks for a family: the counted one, else its strongest."""
    f = e.families.get(fam)
    if f is not None:
        return f
    fs = sorted((f for f in e.findings if f.family == fam and f.bits > 0), key=lambda f: (-f.bits, -f.n))
    return fs[0] if fs else None


def _touched(fs: list[ev.Finding]) -> set:
    out = set()
    for f in fs:
        if f.cp:
            out.add(f.cp)
        out |= f.targets
    return out


def _cpl(f: ev.Finding | None, names: dict) -> str:
    return (ev.cp_label(f, names) or "the other side") if f else "the other side"


# CR-06 (compromised, then calling home) and CR-08 (credential theft, then lateral movement) already mean a compromise
# for a ticket, though they do not force Act now on their own.
P1_CHAINS = factory("p1_chains")


def _names(chains: tuple) -> str:
    n = [ev.CHAINS[c][0] for c in chains]
    return ", ".join(n[:-1]) + " or " + n[-1] if len(n) > 1 else "".join(n)


def priority(verdict: str, crown: bool | int = False, chains: list | tuple = (),
             p: Params = FACTORY) -> tuple[str, str, str]:
    """P1-P4 for a ticket as (P, reason, raise_hint), from the verdict, a crown jewel and the chains that already mean
    a compromise (the p1_chains parameter). raise_hint says in plain English what would raise it one level; "" for
    P1."""
    p1 = tuple(sorted(p["p1_chains"]))
    hard = sorted(set(chains) & set(p1))
    if verdict == "act" and (crown or hard):
        return "P1", "Act now " + ("on a crown jewel" if crown else "with " + ", ".join(ev.CHAINS[c][0] for c in hard)), ""
    if verdict == "act":
        return "P2", "Act now", "P1 on a crown jewel, or with " + _names(p1)
    if verdict == "investigate" and crown:
        return "P2", "Investigate on a crown jewel", "P1 if it reaches Act now"
    if verdict == "investigate":
        return "P3", "Investigate", "P2 if it reaches Act now, or on a crown jewel"
    return "P4", VL.get(verdict, verdict), "P3 if it reaches Investigate"


# ---- one host -----------------------------------------------------------------------------------------------------

_INBOUND = re.compile(r"attacked by (.+?) \d+ h before")


def _inbound_attackers(e: ev.Entity) -> list[str]:
    """The attacker ips CR-06 names in its text (evidence.score_entity writes them; a snapshot keeps the same text)."""
    for c, _b, text in e.chains:
        if c == "CR-06" and (m := _INBOUND.search(text or "")):
            return [x.strip() for x in m.group(1).split(",") if x.strip()]
    return []


def _chain_steps(b: ev.Board, e: ev.Entity) -> list[dict]:
    ip, names, out = e.ip, b.names, []
    chains = {c for c, _, _ in e.chains}
    if "CR-01" in chains:
        x = _top(e, "CL-06")
        out.append(_step(f"{ip}/cr01-contain", "CR-01.act.contain", src="CR-01", ip=ip,
                         dest=x.cp if x and x.cp else "the destination"))
        if x:
            out.append(_step(f"{ip}/cr01-what:{x.cp}", "CR-01.check.what-left", [_fflows(x)], "CR-01",
                             size=ev.fmt_bytes(x.up), cpl=_cpl(x, names)))
    if "CR-05" in chains:
        x = _top(e, "CL-02") or _top(e, "CL-03")
        ti = _top(e, "CL-01")
        ch = x or ti
        out.append(_step(f"{ip}/cr05-process:{ch.cp if ch else ''}", "CR-05.ask.process", [_fflows(ch)], "CR-05",
                         ip=ip, cpl=_cpl(ch, names)))
        out.append(_step(f"{ip}/cr05-block:{ti.cp if ti else ''}", "CR-05.act.block", src="CR-05", ip=ip,
                         addr=ti.cp if ti and ti.cp else "the listed address"))
    if "CR-06" in chains:
        atk = _inbound_attackers(e)
        x = _top(e, "CL-02") or _top(e, "CL-03") or _top(e, "CL-01")
        who = ", ".join(atk) or "the hosts that attacked it"
        out.append(_step(f"{ip}/cr06-attackers", "CR-06.check.attackers",
                         [_host(h, f"quick look at {h}") for h in atk[:MAX_HOST]], "CR-06", ip=ip, attackers=who))
        out.append(_step(f"{ip}/cr06-login", "CR-06.ask.login", [_fflows(x)], "CR-06", ip=ip, attackers=who))
        out.append(_step(f"{ip}/cr06-isolate", "CR-06.act.isolate", src="CR-06", ip=ip,
                         addr=x.cp if x and x.cp else "the command-channel address"))
    if "CR-02" in chains or "CR-03" in chains:
        out.append(_step(f"{ip}/cr02-escalate", "CR-02.act.escalate", src="CR-02" if "CR-02" in chains else "CR-03"))
    if "CR-04" in chains:
        st, ex = _top(e, "CL-12"), _top(e, "CL-06")
        if st and ex:
            out.append(_step(f"{ip}/cr04-compare", "CR-04.check.compare",
                             [_fflows(st, "flows of the collection"), _fflows(ex, "flows of the upload")], "CR-04",
                             staged=ev.fmt_bytes(st.down or st.up), sent=ev.fmt_bytes(ex.up), cpl=_cpl(ex, names)))
    if "CR-09" in chains:
        scans = _strong(e, "CL-04", b.params)
        t0 = min((f.first for f in scans), default=0)
        later = [f for k in ("CL-05", "CL-10") for f in _strong(e, k, b.params) if f.first >= t0]
        hit = sorted(_touched(scans) & {f.cp for f in later if f.cp})
        for tgt in hit[:2]:
            f2 = next(f for f in later if f.cp == tgt)
            out.append(_step(f"{ip}/cr09-follow:{tgt}", "CR-09.check.follow",
                             [_flows(ip, tgt, f2.port, f2.first, f2.last + H, f"flows {ip} → {tgt}"
                                     + (f":{f2.port}" if f2.port else ""))], "CR-09", tgt=tgt))
            te = b.entities.get(tgt)
            if te is not None and te.verdict != "watch":
                out.append(_step(f"{ip}/cr09-next:{tgt}", "CR-09.check.next", [_host(tgt, f"quick look at {tgt}")],
                                 "CR-09", tgt=tgt, verdict=VL[te.verdict]))
    if "CR-08" in chains:
        lat = _strong(e, "CL-10", b.params)
        reached = sorted(_touched(lat))[:4]
        where = ", ".join(reached) if reached else "the hosts it reached"
        out.append(_step(f"{ip}/cr08-account", "CR-08.ask.auth-logs", [_fflows(lat[0]) if lat else None], "CR-08",
                         ip=ip, where=where))
        out.append(_step(f"{ip}/cr08-reset", "CR-08.act.reset-password", src="CR-08"))
    if "CR-10" in chains:
        pers = [f for f in e.findings if f.persistent and f.bits >= b.params["confirm_bits"]]
        if pers:
            f = max(pers, key=lambda f: f.persistent)
            out.append(_step(f"{ip}/cr10-days:{f.cp}", "CR-10.check.days", [_fflows(f)], "CR-10",
                             cpl=_cpl(f, names), n=f.persistent, days=f.days_looked))
    return out


EDGE_OUT = ("Unauthorized LDAP Activity", "Unauthorized NFS Export Data", "SMB External",
            "SMB Traffic to External Networks")


def _edge_out_steps(ip: str, f: ev.Finding, k: str, cpl: str) -> list[dict]:
    proto = ev._proto(f.rule)
    return [_step(f"{ip}/edge-process:{f.cp}", "CL-05.check.edge-process", [_fflows(f)], k, ip=ip, proto=proto, cpl=cpl),
            _step(f"{ip}/edge-block", "CL-05.act.block-edge", src=k),
            _step(f"{ip}/edge-creds", "CL-05.ask.reset-creds", [], k, ip=ip, proto=proto)]


def _family_steps(b: ev.Board, e: ev.Entity, k: str, f: ev.Finding) -> list[dict]:
    ip, names = e.ip, b.names
    cpl = _cpl(f, names)
    asn = ev.asn_label(f.asn, f.country)
    if k == "CL-01":
        out = [_step(f"{ip}/ti-see:{f.cp}", "CL-01.check.exchange", [_fflows(f), _alerts(f)], k, cpl=cpl,
                     ti=f.rule.ti or "on a threat list")]
        if any(d[0] == "shared cloud" for d in f.deds):   # an outside shared cloud address (not one of ours)
            out.append(_step(f"{ip}/ti-cloud:{f.cp}", "CL-01.check.shared-cloud", [], k, cp=f.cp,
                             cloud=ev.CLOUD_ASNS.get(f.asn) or "cloud"))
        if f.cp:
            other = _flows(f.cp, None, None, f.first, f.last, f"every host with {f.cp}") if f.as_server else \
                _flows(None, f.cp, None, f.first, f.last, f"every host with {f.cp}")
            out.append(_step(f"{ip}/ti-others:{f.cp}", "CL-01.check.other-hosts", [other], k, cp=f.cp))
        return out
    if k == "CL-02":
        return [_step(f"{ip}/beacon-rhythm:{f.cp}", "CL-02.check.rhythm", [_fflows(f)], k, cpl=cpl),
                _step(f"{ip}/beacon-owner:{f.cp}", "CL-02.ask.program", [], k, ip=ip, cp=f.cp or "it",
                      asn=f" ({asn})" if asn else "")]
    if k == "CL-03":
        return [_step(f"{ip}/covert-see:{f.cp}", "CL-03.check.traffic", [_fflows(f)], k, cpl=cpl),
                _step(f"{ip}/covert-policy", "CL-03.ask.allowed", [], k, ip=ip)]
    if k == "CL-04":
        n = max(f.uniq, len(f.targets))
        if f.cp and "Vertical" in f.rule.name:   # many ports of one host: the port of the alert is just one of them
            tpl, link = "CL-04.check.ports", _flows(ip, f.cp, None, f.first, f.last, f"flows {ip} → {f.cp}")
        elif n > 1:
            tpl, link = "CL-04.check.targets", _flows(ip, None, f.port, f.first, f.last, f"flows of {ip} as client"
                                                      + (f" to :{f.port}" if f.port else ""))
        else:
            tpl, link = "CL-04.check.scanned", _flows(ip, f.cp, None, f.first, f.last, f"flows of {ip} as client")
        return [_step(f"{ip}/scan-scope:{f.rule.name}", tpl, [link], k, cp=f.cp, n=n,
                      on=f" on :{f.port}" if f.port else ""),
                _step(f"{ip}/scan-authorized", "CL-04.ask.authorized", [], k, ip=ip)]
    if f.rule.direction == "outbound" and f.rule.name in EDGE_OUT:    # SMB, NFS or LDAP going out
        out = _edge_out_steps(ip, f, k, cpl)
        if k == "CL-05":
            return out
    if k == "CL-05":
        target = f.cp or "the target"
        if f.kind == "brute":
            return [_step(f"{ip}/brute-success:{f.cp}", "CL-05.check.login-success",
                          [_fflows(f, "the attempts and what followed", after=H)], k, cpl=cpl),
                    _step(f"{ip}/brute-logs:{f.cp}", "CL-05.ask.brute-logs", [], k, ip=ip, target=target)]
        if f.rule.name in ("Kerberos External", "LDAP External"):
            return [_step(f"{ip}/cred-ext:{f.cp}", "CL-05.ask.external-process", [_fflows(f)], k, ip=ip, cpl=cpl)]
        if "LLMNR" in f.rule.name:
            return [_step(f"{ip}/llmnr", "CL-05.check.llmnr", [_fflows(f)], k)]
        return [_step(f"{ip}/cred-see:{f.cp}", "CL-05.check.sessions", [_fflows(f, after=H)], k, cpl=cpl),
                _step(f"{ip}/cred-logs:{f.cp}", "CL-05.ask.auth-logs", [], k, ip=ip, target=target)]
    if k == "CL-10":
        reached = sorted(f.targets | ({f.cp} if f.cp else set()))
        proto = _ADMIN_PORTS.get(str(f.port or ""), "admin protocols")
        out = [_step(f"{ip}/lateral-reach:{f.rule.name}", "CL-10.check.reach",
                     [_flows(ip, f.cp, f.port, f.first, f.last, f"flows of {ip}" + (f" to {f.cp}" if f.cp else "")
                             + (f":{f.port}" if f.port else ""))], k, proto=proto,
                     n=f" ({len(reached)})" if reached else "")]
        acting = [t for t in reached if t in b.entities and b.entities[t].verdict in ("act", "investigate")]
        for t in acting[:2]:
            out.append(_step(f"{ip}/lateral-next:{t}", "CL-10.check.next-hop", [_host(t, f"quick look at {t}")], k,
                             tgt=t, verdict=VL[b.entities[t].verdict]))
        # asked until an admin gave the host a role or the profile learned one (a lookup-only role, a role kept for a
        # held host and a location do not say it is not an admin workstation)
        if not {"admin", "learned"} & set((getattr(b, "role_src", None) or {}).get(ip, {}).values()):
            out.append(_step(f"{ip}/lateral-admin", "CL-10.ask.admin-host", [], k, ip=ip))
        return out
    if k == "CL-11":
        return [_step(f"{ip}/remote-see:{f.cp}", "CL-11.check.rdp-sessions", [_fflows(f)], k, cpl=cpl),
                _step(f"{ip}/remote-close", "CL-11.act.close-rdp", src=k)]
    if k == "CL-06":
        return [*(out if f.rule.direction == "outbound" and f.rule.name in EDGE_OUT else []),
                _step(f"{ip}/exfil-see:{f.cp}", "CL-06.check.upload", [_fflows(f)], k, cpl=cpl,
                      up=ev.fmt_bytes(f.up), down=ev.fmt_bytes(f.down)),
                _step(f"{ip}/exfil-service:{f.cp}", "CL-06.ask.sanctioned", [], k, dest=f.cp or "the destination",
                      asn=f" It is {asn}." if asn else "")]
    if k == "CL-12":
        return [_step(f"{ip}/staging-see", "CL-12.check.staging", [_fflows(f)], k, size=ev.fmt_bytes(f.down or f.up))]
    if k == "CL-08":
        return [_step(f"{ip}/dos-see:{f.cp}", "CL-08.check.flood", [_fflows(f)], k, cpl=cpl),
                _step(f"{ip}/dos-isolate", "CL-08.act.isolate", src=k, ip=ip)]
    if k == "CL-07":
        return [_step(f"{ip}/anomaly-days", "CL-07.check.compare-days", [_fflows(f)], k)]
    return []


def _host_steps(b: ev.Board, e: ev.Entity, pcap_done: int = 0, chain_extra: list[dict] | tuple = ()) -> list[dict]:
    """The factory steps for one host, most telling first, at most MAX_HOST (containment last). `chain_extra`: steps
    of a chain rule the evidence model does not have (Clusters' CR-07), placed with the chain steps."""
    out: list[dict] = []
    seen: set = set()

    def add(steps: list[dict]) -> None:
        for s in steps:
            if s["id"] not in seen:
                seen.add(s["id"])
                out.append(s)

    add(_chain_steps(b, e))
    add(list(chain_extra))
    if pcap_done:
        add([pcap_step(e.ip, pcap_done)])
    if e.crown:
        add([_step(f"{e.ip}/crown", "crown.ask.owner", src="crown", ip=e.ip)])
    covered = set().union(*(_COVERED.get(c, set()) for c, _, _ in e.chains)) if e.chains else set()
    fams = sorted(((k, f) for k, f in e.families.items() if f.bits >= 1 and k in FAMILIES),
                  key=lambda kv: -kv[1].bits)
    for k, f in fams[:3]:
        steps = _family_steps(b, e, k, f)
        add(steps[1:] if k in covered else steps)
    if e.verdict == "act" and not any(s["kind"] == "act" for s in out):
        add([_step(f"{e.ip}/isolate", "verdict.act.isolate", src="verdict", ip=e.ip)])
    acts = [s for s in out if s["kind"] == "act"]
    rest = [s for s in out if s["kind"] != "act"]
    return rest[:MAX_HOST - min(3, len(acts))] + acts[:3]


def for_host(b: ev.Board, e: ev.Entity, pcap_done: int = 0, overlay: list[dict] | tuple = ()) -> list[dict]:
    """The next steps for one host: the factory steps with the admin's overlay applied."""
    steps = _host_steps(b, e, pcap_done)
    return apply(steps, overlay, {**_host_ctx(b, [e], e), "own_prefix": e.ip + "/"}) if overlay else steps


def pcap_step(ip: str, done: int) -> dict:
    return _step(f"{ip}/pcap", "pcap.check.packets", [{"t": "pcap", "label": "recorded packets"}], "pcap",
                 done=done, s="s" if done != 1 else "", ip=ip)


# ---- a host attacked from outside ---------------------------------------------------------------------------------

_SERVICE = {"22": "SSH", "23": "Telnet", "445": "SMB", "3389": "RDP", "5900": "VNC", "21": "FTP", "1433": "MSSQL",
            "3306": "MySQL", "5985": "WinRM", "5986": "WinRM", "443": "HTTPS", "80": "HTTP"}


def for_target(b: ev.Board, ti: ev.TargetIncident, overlay: list[dict] | tuple = ()) -> list[dict]:
    """A victim: did the attack get in, should the service be exposed at all, and who else it reached."""
    ip = ti.ip
    fs = sorted((f for f in b.target_f.get(ip, ()) if f.cp in ti.attackers), key=lambda f: (-f.down, -f.n))
    top = fs[0] if fs else None
    svc = _SERVICE.get(str(ti.port), f"port {ti.port}" if ti.port else "the service")
    out = []
    if top:
        out.append(_step(f"{ip}/tgt-answer:{top.cp}", "target.check.answer",
                         [_flows(top.cp, ip, top.port, top.first, top.last + H, f"flows {top.cp} → {ip}"
                                 + (f":{top.port}" if top.port else ""))], "target", cp=top.cp, ip=ip,
                         on=f" on :{top.port}" if top.port else ""))
    if set(ti.kinds) & {"brute", "cred", "remote", "exposure"}:
        out.append(_step(f"{ip}/tgt-logs", "target.ask.auth-logs", [], "target", ip=ip))
    out.append(_step(f"{ip}/tgt-exposed", "target.ask.exposed", [], "target", svc=svc, ip=ip))
    if "exposure" in ti.kinds and top:
        out.append(_step(f"{ip}/tgt-sessions", "target.check.sessions",
                         [_flows(top.cp, ip, top.port, top.first, top.last + H, f"flows {top.cp} → {ip}")], "target",
                         ip=ip, on=f":{top.port}" if top.port else "",
                         who=top.cp if len(ti.attackers) == 1 else "those sources"))
    out.append(_step(f"{ip}/tgt-after", "target.check.after",
                     [_flows(ip, None, None, ti.first, ti.last + 6 * H, f"flows of {ip} as client")], "target", ip=ip))
    out.append(_step(f"{ip}/tgt-close", "target.act.close", src="target", svc=svc,
                     who=ti.attackers[0] if len(ti.attackers) == 1 else "the sources"))
    if not overlay:
        return out
    present = {"chain": set(), "family": set(ti.families),
               "kind": {k: set(ti.families) for k in ti.kinds}}
    by = {("family", fam): _vals(top) for fam in ti.families} | {("kind", k): _vals(top) for k in ti.kinds}
    return apply(out, overlay, {"ip": ip, **_vals(top), "present": present, "by": by, "own_prefix": ip + "/"})


# ---- a Clusters cluster -----------------------------------------------------------------------------------------

def for_cluster(ip: str, rows: list[dict], chains: list[str], verdict: str, crown: bool, names: dict,
                overlay: list[dict] | tuple = (), *, worm: tuple[str, list[str]] | None = None) -> list[dict]:
    """The next steps of one Clusters cluster: its buckets (`rows`: rule, cp, port, n, first, last, up, down, targets,
    asn, country) and the chain rules that matched its host. Built the way for_snapshot builds a host, from plain
    Finding / Entity containers with the catalog's own weight of each rule (bits), so the families and chains pick the
    same steps as for a Triage host; nothing of evidence's scoring runs. `worm`: (segment, the hosts scanning in it),
    for CR-07, which Triage does not have."""
    fs = []
    for r in rows:
        rule = r["rule"]
        f = ev.Finding("a", ip, rule, r.get("cp"), str(r.get("port") or ""), n=r.get("n") or 0, first=r.get("first") or 0,
                       last=r.get("last") or 0, up=r.get("up") or 0, down=r.get("down") or 0, asn=r.get("asn"),
                       country=r.get("country"), targets=frozenset(r.get("targets") or ()))
        f.family, f.stage, f.cls, f.kind, f.bits = rule.family, rule.stage, rule.cls, rule.kind, rule.bits
        fs.append(f)
    e = ev.Entity(ip, fs, crown=bool(crown))
    for f in fs:        # the family's finding is its strongest (most alerts on a tie), as score_entity picks it
        if f.bits > 0 and (f.family not in e.families or (f.bits, f.n) > (e.families[f.family].bits,
                                                                          e.families[f.family].n)):
            e.families[f.family] = f
    e.chains = [(c, 0.0, "") for c in chains]
    e.verdict = verdict
    board = SimpleNamespace(names=names or {}, entities={}, params=FACTORY)
    extra = []
    if worm and "CR-07" in chains:
        segment, hosts = worm
        extra.append(_step(f"{ip}/cr07-segment", "CR-07.check.segment",
                           [_host(h, f"quick look at {h}") for h in hosts[:MAX_HOST] if h != ip], "CR-07",
                           segment=segment))
    steps = _host_steps(board, e, 0, extra)
    return apply(steps, overlay, {**_host_ctx(board, [e], e), "own_prefix": ip + "/"}) if overlay else steps


def for_cluster_target(ip: str, row: dict, overlay: list[dict] | tuple = (),
                       catalog: Catalog | None = None) -> list[dict]:
    """The next steps of an Under attack entry of the Clusters board (a host that only receives): the lane row says
    how many sources, the strongest rule and whether it answered, not who the sources were, so the steps are the
    ones of for_target that need no source address."""
    out = []
    if (catalog or Catalog()).get(row.get("top_rule") or "").kind in ("brute", "cred", "remote", "exposure"):
        out.append(_step(f"{ip}/tgt-logs", "target.ask.auth-logs", [], "target", ip=ip))
    out.append(_step(f"{ip}/tgt-exposed", "target.ask.exposed", [], "target", svc="the service", ip=ip))
    out.append(_step(f"{ip}/tgt-after", "target.check.after",
                     [_flows(ip, None, None, row.get("first") or 0, (row.get("last") or 0) + 6 * H,
                             f"flows of {ip} as client")], "target", ip=ip))
    out.append(_step(f"{ip}/tgt-close", "target.act.close", src="target", svc="the service", who="the sources"))
    if not overlay:
        return out
    fams = set(row.get("families") or ())
    return apply(out, overlay, {"ip": ip, "present": {"chain": set(), "family": fams, "kind": {}}, "by": {},
                                "own_prefix": ip + "/"})


# ---- a group of hosts, a campaign -------------------------------------------------------------------------------

def _shared(b: ev.Board, ips: list[str], need: float = 0.5) -> list[tuple[str, int]]:
    """Counterparts that half or more of the hosts have in their evidence."""
    cnt: Counter = Counter()
    for ip in ips:
        e = b.entities.get(ip)
        if e is None:
            continue
        cnt.update({f.cp for f in e.findings if f.cp and f.bits >= b.params["confirm_bits"]})
    top = sorted(cnt.items(), key=lambda kv: (-kv[1], kv[0]))[:3]      # ties by address, not by set order
    return [(cp, n) for cp, n in top if n >= max(2, need * len(ips))]


def for_story(b: ev.Board, s: dict, overlay: list[dict] | tuple = ()) -> list[dict]:
    """A group of hosts with one pattern: one host's checks explain most of the others."""
    members = [b.entities[ip] for ip in s["members"] if ip in b.entities]
    if not members:
        return []
    lead = max(members, key=lambda m: (m.crown, m.risk, m.last))
    key = s["key"]
    out = [_step(f"grp:{key}/lead", "group.check.lead", [_host(lead.ip, f"quick look at {lead.ip}")], "group",
                 ip=lead.ip, name=f" ({b.names[lead.ip]})" if b.names.get(lead.ip) else "", n=len(members))]
    lead_steps = _host_steps(b, lead)
    out += [st for st in lead_steps if st["kind"] != "act"][:3]
    for cp, n in _shared(b, s["members"]):
        out.append(_step(f"grp:{key}/shared:{cp}", "group.check.shared",
                         [_flows(None, cp, None, s["first"], s["last"], f"every host with {cp}")], "group", n=n,
                         total=len(members), cp=cp))
        break
    # the families the hosts confirmed (a story's key names its chains, not always its families)
    fams = {f for m in members for f in m.pattern if not f.startswith("CR-")}
    if fams & {"CL-04", "CL-10"}:
        out.append(_step(f"grp:{key}/rollout", "group.ask.rollout", [], "group"))
    acts = [st for st in lead_steps if st["kind"] == "act"][:2]
    out += acts
    return apply(out, overlay, _host_ctx(b, members, lead)) if overlay else out


def for_campaign(b: ev.Board, c: dict, kids: list[dict], overlay: list[dict] | tuple = ()) -> list[dict]:
    """Many hosts of one network: the most urgent incidents inside first, then what drives the wave."""
    net = c["net"]
    ranked = sorted(kids, key=lambda x: (-ev.VRANK[x["verdict"]], -x["risk"]))
    out = []
    if ranked:
        k0 = ranked[0]
        ukey = ("s:" + k0["key"]) if k0["type"] == "story" else ("h:" + k0["ip"])
        lbl = k0.get("title") if k0["type"] == "story" else f"host {k0['ip']}"
        out.append(_step(f"camp:{net}/first", "campaign.check.first",
                         [{"t": "key", "key": ukey, "label": "quick look"}], "campaign", lbl=lbl,
                         verdict=VL[k0["verdict"]]))
    ips: list[str] = []
    for x in kids:
        ips.extend(b.stories[x["key"]]["members"] if x["type"] == "story" else [x["ip"]])
    for cp, n in _shared(b, ips, 0.3):
        out.append(_step(f"camp:{net}/shared:{cp}", "campaign.check.shared",
                         [_flows(None, cp, None, c["first"], c["last"], f"every host with {cp}")], "campaign", n=n,
                         total=len(ips), cp=cp))
        break
    nets = c.get("nets24") or c.get("nets") or []
    if nets:
        top = nets[0][0] if isinstance(nets[0], (list, tuple)) else nets[0]
        out.append(_step(f"camp:{net}/where", "campaign.check.where", [], "campaign", top=top))
    out.append(_step(f"camp:{net}/change", "campaign.ask.change", [], "campaign", net=net))
    if c["verdict"] == "act":
        out.append(_step(f"camp:{net}/escalate", "campaign.act.escalate", src="campaign"))
    if not overlay:
        return out
    members = [b.entities[ip] for ip in ips if ip in b.entities]
    if not members:
        return apply(out, overlay, {"ip": "", "present": {"chain": set(c.get("chains") or ()),
                                                          "family": set(c.get("families") or ()), "kind": {}}})
    lead = max(members, key=lambda m: (m.crown, m.risk, m.last))
    ctx = _host_ctx(b, members, lead)
    ctx["present"]["chain"] |= set(c.get("chains") or ())
    ctx["present"]["family"] |= set(c.get("families") or ()) & set(FAMILIES)
    return apply(out, overlay, ctx)


# ---- a record of the history ------------------------------------------------------------------------------------

def _cp_port(label: str | None) -> tuple[str | None, str]:
    """"203.0.113.66:443 (AS63018 US)" -> ("203.0.113.66", "443"): the counterpart as the snapshot printed it."""
    tok = (label or "").split(" ")[0]
    if not tok:
        return None, ""
    if tok.count(":") == 1:
        ip, port = tok.split(":")
        return ip, port
    return tok, ""


def for_snapshot(snap: dict, catalog: Catalog | None = None, overlay: list[dict] | tuple = ()) -> list[dict]:
    """The next steps of a record: those stored with its snapshot at its peak (the overlay of that time already in
    them), or, for a host record from before they were stored, rebuilt from the evidence the snapshot keeps (its
    counted families, chains and top findings) with the overlay of now. The links point at the time of the evidence:
    they work while Sycope still keeps those flows and alerts."""
    if snap.get("steps") is not None:
        return snap["steps"]
    if snap.get("what") != "host" or not snap.get("ip"):
        return []
    catalog = catalog or Catalog()
    ip = snap["ip"]
    fs = []
    for x in snap.get("findings") or []:
        rule = catalog.get(x.get("rule"))
        cp, port = _cp_port(x.get("cp"))
        f = ev.Finding("a", ip, rule, cp, port, n=x.get("n") or 0, first=x.get("first") or 0, last=x.get("last") or 0)
        f.family, f.stage, f.cls, f.kind = x.get("family") or rule.family, x.get("stage"), rule.cls, rule.kind
        f.bits, f.counted = x.get("bits") or 0.0, bool(x.get("counted"))
        fs.append(f)
    e = ev.Entity(ip, fs, crown=bool(snap.get("crown")))
    for fam in snap.get("families") or []:
        mine = [f for f in fs if f.family == fam["family"]]
        if mine:
            e.families[fam["family"]] = max(mine, key=lambda f: (f.counted, f.rule.name == fam.get("rule"), f.bits))
    e.chains = [(c["id"], c.get("bits") or 0, c.get("continuity") or "") for c in snap.get("chains") or []]
    e.verdict = snap.get("verdict") or "review"
    board = SimpleNamespace(names={ip: snap["name"]} if snap.get("name") else {}, entities={}, params=FACTORY)
    return for_host(board, e, 0, overlay)


# ---- the overlay --------------------------------------------------------------------------------------------------

OPS = ("edit", "hide", "move", "add")
PLACEHOLDERS = ("ip", "cp", "port", "from", "to", "rule")
_FIELDS = {"edit": {"op", "template", "factory_hash", "title", "why", "kind"}, "hide": {"op", "template"},
           "move": {"op", "template", "after"}, "add": {"op", "id", "bind", "kind", "title", "why", "link"}}
_BINDS = ("chain", "family", "kind")
_ID = re.compile(r"[A-Za-z0-9_:-]{1,80}")   # no ".": factory template ids always have one; no "/": instance ids do
_PH = re.compile(r"\{(" + "|".join(PLACEHOLDERS) + r")\}")
_CTRL = re.compile(r"[\x00-\x20\x7f]")
MAX_TITLE, MAX_WHY, MAX_LABEL, MAX_URL = 300, 1000, 80, 500
# the families whose findings speak for a chain, strongest hint first (the values of an added step's placeholders)
_CHAIN_FAMS = {"CR-01": ("CL-06", "CL-02"), "CR-02": ("CL-04", "CL-05", "CL-10", "CL-02", "CL-06"),
               "CR-03": ("CL-04", "CL-05", "CL-10", "CL-02", "CL-06"), "CR-04": ("CL-06", "CL-12"),
               "CR-05": ("CL-02", "CL-03", "CL-01"), "CR-06": ("CL-05", "CL-10", "CL-02", "CL-03", "CL-01"),
               "CR-08": ("CL-10", "CL-05"), "CR-09": ("CL-04", "CL-05", "CL-10"), "CR-10": ("CL-02", "CL-01")}


def _vals(f: ev.Finding | None) -> dict:
    """The placeholder values a finding gives ({ip} is the incident's host)."""
    if f is None:
        return {}
    return {"cp": f.cp, "port": f.port or None, "from": f.first, "to": f.last, "rule": f.rule.name}


def _host_ctx(b: ev.Board, members: list[ev.Entity], lead: ev.Entity) -> dict:
    """What an overlay needs to know of an incident: the chains, families and finding kinds in its evidence (where
    an added step appears) and the values of the link placeholders, from the lead host's strongest evidence, or the
    evidence of the bound section."""
    present: dict = {"chain": set(), "family": set(), "kind": {}}
    for m in members:
        present["chain"] |= {c for c, _, _ in m.chains}
        present["family"] |= {k for k, f in m.families.items() if f.bits >= 1 and k in FAMILIES}
        for f in m.findings:
            if f.kind and f.bits >= 1 and f.family in FAMILIES:
                present["kind"].setdefault(f.kind, set()).add(f.family)
    fs = sorted((f for f in lead.findings if f.bits > 0), key=lambda f: (-f.bits, -f.n, f.rule.name))
    by: dict = {}
    for k in sorted(present["family"]):
        by[("family", k)] = _vals(_top(lead, k))
    for kind in sorted(present["kind"]):
        by[("kind", kind)] = _vals(next((f for f in fs if f.kind == kind), None))
    for c in sorted(present["chain"]):
        by[("chain", c)] = _vals(next((x for x in (_top(lead, k) for k in _CHAIN_FAMS.get(c, ())) if x), None))
    return {"ip": lead.ip, **_vals(fs[0] if fs else None), "present": present, "by": by}


def _text_errors(op: dict, field: str, limit: int, required: bool = True) -> list[str]:
    v = op.get(field)
    if v is None and not required:
        return []
    if not isinstance(v, str) or not v.strip():
        return [f"{field} must be text"]
    return [f"{field} is longer than {limit} characters"] if len(v) > limit else []


def _link_errors(link: object) -> list[str]:
    """Why a link template is not allowed: http or https only, the host fixed by the template, placeholders only in
    the path or the query (their values are URL-encoded when the link is drawn)."""
    if not isinstance(link, dict) or set(link) != {"label", "url"}:
        return ["link must be an object with a label and a url"]
    errs = _text_errors(link, "label", MAX_LABEL)
    errs = [f"link {e}" for e in errs]
    url = link["url"]
    if not isinstance(url, str) or not url:
        return errs + ["link url must be text"]
    if len(url) > MAX_URL:
        return errs + [f"link url is longer than {MAX_URL} characters"]
    if _CTRL.search(url) or not url.isascii():
        return errs + ["link url must be plain ASCII without spaces (an international host name as punycode)"]
    stray = _PH.sub("", url)
    if "{" in stray or "}" in stray:
        return errs + ["link url has a { or } that is not one of the placeholders " + ", ".join(
            "{" + p + "}" for p in PLACEHOLDERS)]
    try:
        parts = urlsplit(url)
        parts.port  # noqa: B018  (a bad port raises here)
    except ValueError:
        return errs + ["link url is not a valid address"]
    if parts.scheme.lower() not in ("http", "https"):
        return errs + ["link url must start with http:// or https://"]
    if not parts.hostname:
        return errs + ["link url needs a host name after http:// or https://"]
    if _PH.search(parts.netloc):
        return errs + ["a placeholder cannot be in the scheme or the host of a link url, only in its path or query"]
    if _PH.search(parts.fragment):
        return errs + ["a placeholder cannot be in the fragment of a link url, only in its path or query"]
    return errs


def _op_errors(op: dict) -> list[str]:
    kind = op["op"]
    errs = [f"unknown field {f}" for f in sorted(set(op) - _FIELDS[kind])]
    if kind != "add":
        t = op.get("template")
        if not isinstance(t, str) or not t.strip() or len(t) > 120:
            errs.append("template must be the id of a step")
    if kind == "edit":
        if not isinstance(op.get("factory_hash"), str) or not op["factory_hash"]:
            errs.append("factory_hash must be text (the hash of the factory step when it was edited)")
        if not any(op.get(f) is not None for f in ("title", "why", "kind")):
            errs.append("an edit changes title, why or kind")
        errs += _text_errors(op, "title", MAX_TITLE, False) + _text_errors(op, "why", MAX_WHY, False)
        if op.get("kind") is not None and op["kind"] not in KINDS:
            errs.append(f"kind must be one of {', '.join(KINDS)}")
    elif kind == "move":
        if not isinstance(op.get("after"), str) or not op["after"].strip():
            errs.append("after must be the id of a step")
        elif op["after"] == op.get("template"):
            errs.append("a step cannot be moved after itself")
    elif kind == "add":
        i = op.get("id")
        if not isinstance(i, str) or not _ID.fullmatch(i):
            errs.append("id must be 1 to 80 letters, digits or _ : - (no dot: factory step ids have one)")
        bind = op.get("bind")
        if not isinstance(bind, dict) or len(bind) != 1 or next(iter(bind)) not in _BINDS:
            errs.append("bind must name one of chain, family or kind, like {\"chain\": \"CR-08\"}")
        else:
            (bk, bv), = bind.items()
            if not isinstance(bv, str) or not bv.strip():
                errs.append(f"bind {bk} must be text")
            elif bk == "chain" and bv not in ev.CHAINS:
                errs.append(f"bind chain {bv!r} is not a chain rule ({', '.join(sorted(ev.CHAINS))})")
            elif bk == "family" and bv not in FAMILIES:
                errs.append(f"bind family {bv!r} is not a family ({', '.join(sorted(FAMILIES))})")
        if op.get("kind") not in KINDS:
            errs.append(f"kind must be one of {', '.join(KINDS)}")
        errs += _text_errors(op, "title", MAX_TITLE) + _text_errors(op, "why", MAX_WHY)
        if "link" in op:
            errs += _link_errors(op["link"])
    return errs


def validate_overlay(ops: object) -> list[str]:
    """Every problem of the overlay operations, one sentence each starting `playbook[i]:`; [] when it is allowed.
    Edit {op, template, factory_hash, title?, why?, kind?}; hide {op, template}; move {op, template, after}; add
    {op, id, bind: {chain|family|kind: value}, kind, title, why, link?: {label, url}}. A template id this release
    does not know is not an error (an upgrade may have removed the step), see overlay_warnings."""
    if not isinstance(ops, (list, tuple)):
        return ["playbook must be a list of overlay operations"]
    errs, ids = [], set()
    for i, op in enumerate(ops):
        if not isinstance(op, dict):
            errs.append(f"playbook[{i}]: must be an object")
        elif op.get("op") not in OPS:
            errs.append(f"playbook[{i}]: unknown op {op.get('op')!r} (one of {', '.join(OPS)})")
        else:
            errs += [f"playbook[{i}]: {e}" for e in _op_errors(op)]
            if op["op"] == "add" and isinstance(op.get("id"), str):
                if op["id"] in ids:
                    errs.append(f"playbook[{i}]: id {op['id']} is already used by an earlier added step")
                ids.add(op["id"])
    return errs


def overlay_warnings(ops: object) -> list[str]:
    """Edits, hides and moves that name a step this release does not have (renamed or removed by an upgrade, or a
    typo). They do nothing; they do not make the overlay invalid."""
    if not isinstance(ops, (list, tuple)):
        return []
    known = set(ALL_HASH) | {o["id"] for o in ops if isinstance(o, dict) and o.get("op") == "add"
                             and isinstance(o.get("id"), str)}
    out = []
    for i, op in enumerate(ops):
        if not isinstance(op, dict) or op.get("op") not in ("edit", "hide", "move"):
            continue
        for f in ("template", "after"):
            v = op.get(f)
            if isinstance(v, str) and v not in known:
                out.append(f"playbook[{i}]: {f} {v!r} is not a step of this release or an added step")
    return out


def _fill(template: str, vals: dict, encode: bool) -> str:
    """The template with its placeholders filled; a missing value is empty, never "None"."""
    def one(m: re.Match) -> str:
        v = vals.get(m.group(1))
        v = "" if v is None else str(v)
        return quote(v, safe="") if encode else v
    return _PH.sub(one, template)


def _link(link: dict, vals: dict) -> list[dict]:
    """The link of an added step, URL-encoded, or none when its template is not allowed (never trust a stored one
    blindly: the host and the scheme are those of the template)."""
    if _link_errors(link):
        return []
    return [{"t": "url", "label": _fill(link["label"], vals, False), "url": _fill(link["url"], vals, True)}]


def _present_of(steps: list[dict]) -> dict:
    """What the steps themselves say of the evidence, for a caller that gives no `present`."""
    srcs = {s.get("src") or "" for s in steps}
    return {"chain": {x for x in srcs if x.startswith("CR-")}, "family": {x for x in srcs if x in FAMILIES},
            "kind": {}}


def _in_section(s: dict, bind: str, value: str, present: dict) -> bool:
    if s.get("bind"):                       # an added step sits with the others of its own section
        return s["bind"] == {bind: value}
    src = s.get("src") or ""
    if bind == "kind":
        return src in (present.get("kind") or {}).get(value, ())
    return src == value


def apply(steps: list[dict], overlay: list[dict] | tuple, ctx: dict | None = None) -> list[dict]:
    """The steps with the admin's overlay: hide, add, edit (so an edit can aim at an added step), then move.

    ctx gives the values of the link placeholders ({ip} {cp} {port} {from} {to} {rule}; times in ms) and may carry
    `present` ({"chain": set, "family": set, "kind": {finding kind: set of families}}: what the incident's evidence
    holds, default: what the steps' own sources say) and `by` ({(chain|family|kind, value): placeholder values of
    that section}). An added step appears once, after the last factory step of its section (the end of the list
    when that section has no step) and in the order of the overlay; a section absent from the evidence gets none.
    An edit whose factory_hash differs from FACTORY_HASH marks its step `stale` and keeps the factory text in
    `factory`. A move whose target is hidden, absent or the step itself leaves the step where it is. Operations
    that cannot be read are skipped (validate_overlay is for the writer). An added step's instance id is the op id,
    prefixed with ctx["own_prefix"] ("<ip>/" on a host's page, so ticking it on one host leaves the others)."""
    ops = [o for o in overlay or () if isinstance(o, dict) and o.get("op") in OPS]
    if not ops:
        return list(steps)
    ctx = ctx or {}
    present = ctx.get("present") or _present_of(steps)
    hidden = {o["template"] for o in ops if o["op"] == "hide" and isinstance(o.get("template"), str)}
    edits = {o["template"]: o for o in ops if o["op"] == "edit" and isinstance(o.get("template"), str)}
    out = [dict(s) for s in steps if s.get("template") not in hidden]
    for o in (o for o in ops if o["op"] == "add"):
        if _op_errors({k: v for k, v in o.items() if k != "link"}) or o["id"] in hidden \
                or any(s.get("id") == ctx.get("own_prefix", "") + o["id"] for s in out):
            continue
        (bk, bv), = o["bind"].items()
        if bv not in (present.get(bk) or ()):
            continue
        vals = {p: ctx.get(p) for p in PLACEHOLDERS} | (ctx.get("by") or {}).get((bk, bv), {})
        step = {"id": ctx.get("own_prefix", "") + o["id"], "kind": o["kind"], "title": o["title"], "why": o["why"],
                "links": _link(o["link"], vals) if "link" in o else [], "src": "overlay", "template": o["id"],
                "bind": {bk: bv}, "added": True}
        at = max((i for i, s in enumerate(out) if _in_section(s, bk, bv, present)), default=len(out) - 1)
        out.insert(at + 1, step)
    for s in out:
        o = edits.get(s.get("template"))
        if o is None:
            continue
        if not s.get("added") and o.get("factory_hash") != ALL_HASH.get(s["template"]):
            s["stale"], s["factory"] = True, {"title": s["title"], "why": s["why"]}
        for f in ("title", "why"):
            if isinstance(o.get(f), str) and o[f].strip():
                s[f] = o[f]
        if o.get("kind") in KINDS:
            s["kind"] = o["kind"]
    for o in (o for o in ops if o["op"] == "move"):
        t, after = o.get("template"), o.get("after")
        block = [s for s in out if s.get("template") == t]
        rest = [s for s in out if s.get("template") != t]
        idx = max((i for i, s in enumerate(rest) if s.get("template") == after), default=None)
        if not block or idx is None or t == after:
            continue
        out = rest[:idx + 1] + block + rest[idx + 1:]
    return out

