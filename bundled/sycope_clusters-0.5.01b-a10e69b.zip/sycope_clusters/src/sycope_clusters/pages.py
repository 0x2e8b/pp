"""HTML of the three pages: Live clusters, Scoring model, System status.

The look is the recorder's (look.py): analysts reach both through Sycope Passthrough and should feel in Sycope.
Every route is one path segment of [A-Za-z0-9_-] (Passthrough rule `GET ^/([A-Za-z0-9_-]+)?/?$`) and nothing
is posted: the live page reads `data` and `cluster` as JSON with GET. Server-side text is escaped with _e(),
the script escapes everything it puts into innerHTML with esc().
"""

from __future__ import annotations

import dataclasses
import html
import json
import re
import time
from urllib.parse import quote

from sycope_clusters import cluster_work, clusters, fmt, health, pipeline, profile, rules, scoring, triage
from sycope_clusters.config import HELP, Settings
from sycope_clusters.engine.mitre import PHASE_NAMES, TACTIC_PHASE
from sycope_clusters.fmt import FMT_JS, TIME_TAG_JS
from sycope_clusters.look import _CAL, _CHEV, _CSS, _FONT_CSS, _INFO_JS, _LUPA, _MENU_JS, _REFRESH, _gear, logo

VERSION = "0.5.01b"

# Kill-chain phases and cluster types on the dark Sycope background.
PHASE_COLORS = {"Objectives": "#e0122d", "Lateral": "#ff7a00", "Foothold": "#e5c100", "Recon": "#276edb",
                "Other": "#808297"}
TYPE_COLORS = {k: v[2] for k, v in rules.FAMILIES.items()}

VERDICT_LABELS = {"act": "Act now", "investigate": "Investigate", "review": "Review", "watch": "Watch"}
VERDICT_COLORS = {"act": "#e0122d", "investigate": "#ff7a00", "review": "#e5c100", "watch": "#4aa3ff"}
VERDICT_HELP = {"act": "Open it now.", "investigate": "Look at it today.",
                "review": "Check when the top is clear.",
                "watch": "No action, the board keeps an eye on it."}   # the priority bands are added by the page

# Outline icons in the style of Sycope's top bar (24 grid, 1.6 stroke, round caps; drawn for this page).
ICONS = {
    "act": '<path d="M8.2 2.5h7.6l5.7 5.7v7.6l-5.7 5.7H8.2l-5.7-5.7V8.2z"/><path d="M12 7.5v5.5"/><path d="M12 16.6v.1"/>',
    "investigate": '<path d="M10.4 3.6 2.2 17.8A1.8 1.8 0 0 0 3.8 20.5h16.4a1.8 1.8 0 0 0 1.6-2.7L13.6 3.6a1.8 1.8 0 0 0-3.2 0z"/>'
                   '<path d="M12 9v4.5"/><path d="M12 17v.1"/>',
    "review": '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20.5 20.5-5.4-5.4"/><path d="M10.5 7.5v3l2 1.4"/>',
    "watch": '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    "source": '<circle cx="6.5" cy="17.5" r="2.5"/><path d="M8.5 15.5 19 5"/><path d="M12 5h7v7"/>',
    "target": '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.2"/><path d="M12 1.8v3.4M12 18.8v3.4M1.8 12h3.4M18.8 12h3.4"/>',
    "jewel": '<path d="M6.5 3.5h11l4 5.5L12 21 2.5 9z"/><path d="M2.5 9h19"/><path d="m9.5 3.5-1.8 5.5L12 21l4.3-12-1.8-5.5"/>',
    "clock": '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    "bell": '<path d="M6.5 9a5.5 5.5 0 1 1 11 0c0 5.6 2.5 7.5 2.5 7.5H4s2.5-1.9 2.5-7.5"/><path d="M10.2 20a2 2 0 0 0 3.6 0"/>',
    "layers": '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 12.5 9 5 9-5"/><path d="m3 16.5 9 5 9-5"/>',
    # the triage's tabs
    "list": '<path d="M8.5 6.5h12M8.5 12h12M8.5 17.5h12"/><path d="M3.8 6.5h.1M3.8 12h.1M3.8 17.5h.1"/>',
    "globe": '<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17"/><path d="M12 3.5c2.5 2.3 3.8 5.2 3.8 8.5s-1.3 6.2-3.8 8.5c-2.5-2.3-3.8-5.2-3.8-8.5s1.3-6.2 3.8-8.5z"/>',
    "sliders": '<path d="M3.5 7h9M17.5 7h3M3.5 17h3M11.5 17h9"/><circle cx="15" cy="7" r="2.3"/><circle cx="9" cy="17" r="2.3"/>',
    "shield": '<path d="M12 3 4.5 6v5.6c0 4.5 3.1 8.2 7.5 9.4 4.4-1.2 7.5-4.9 7.5-9.4V6z"/><path d="m8.8 12 2.2 2.2 4.2-4.4"/>',
    "gear": '<circle cx="12" cy="12" r="3"/><path d="M12 2.8v2.4M12 18.8v2.4M2.8 12h2.4M18.8 12h2.4M5.5 5.5l1.7 1.7M16.8 16.8l1.7 1.7M5.5 18.5l1.7-1.7M16.8 7.2l1.7-1.7"/>',
    "audit": '<path d="M8.5 4.5h-2A1.5 1.5 0 0 0 5 6v13.5A1.5 1.5 0 0 0 6.5 21h11a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5h-2"/><rect x="8.5" y="3" width="7" height="3.2" rx="1"/><path d="M8.5 11h7M8.5 15h4.5"/>',
}

_CSS_EXTRA = """
.psw{display:inline-flex;margin:0 6px 0 4px;border:1px solid var(--head);border-radius:5px;overflow:hidden}
.psw a{display:inline-flex;align-items:center;height:26px;padding:0 14px;background:var(--panel2);color:var(--fg)}
.psw a+a{border-left:1px solid var(--head)}.psw a:hover{text-decoration:none;background:var(--head)}
.psw a[aria-current=page]{background:var(--blue);color:#fff}
/* the top bar: the product switch, the toggle and the logo never shrink or wrap; the search box shrinks instead (ui.py .gs) */
.psw,.vsw,.logo{flex:none}.psw a,.vsw button,.logo .lname{white-space:nowrap}.top .sub{white-space:nowrap;flex:none}.top .mut,.top .me{white-space:nowrap}
@media (max-width:1500px){.top .sub{display:none}}
.vsw{display:inline-flex;margin:0 6px 0 4px;border:1px solid var(--head);border-radius:5px;overflow:hidden}
.vsw button{display:inline-flex;align-items:center;height:26px;padding:0 12px;border:0;background:var(--panel2);color:var(--fg);font:inherit;cursor:pointer}
.vsw button+button{border-left:1px solid var(--head)}.vsw button:hover{background:var(--head)}
.vsw button[aria-pressed=true]{background:var(--blue);color:#fff}
.vsc{flex:none;margin:0 6px 0 -2px;color:var(--mut);font-size:11.5px;white-space:nowrap;cursor:default}
.tiles2{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin-bottom:8px}.tiles2 .card{margin:0;padding:14px 16px}
.tv{font-size:26px;line-height:1.1;font-weight:400}.tl2{font-size:12px;color:var(--mut);margin-top:4px}
.phs{display:flex;gap:10px;flex-wrap:wrap;margin-top:6px}.phs span{display:inline-flex;align-items:center;gap:6px;font-size:12px}
.sq{display:inline-block;width:10px;height:10px;border-radius:2px;flex:none}
.hcard{padding:12px 16px 8px}.hwrap{display:flex;align-items:stretch;height:150px}
.hy{flex:none;width:44px;position:relative}.hplot{flex:1;position:relative;border-bottom:1px solid var(--hline)}
.hplot .g i{position:absolute;left:0;right:0;font-style:normal;border-top:1px solid rgba(255,255,255,.08)}
.hplot .g b{position:absolute;right:100%;margin-right:8px;transform:translateY(-50%);font-weight:400;font-size:11px;color:var(--mut)}
.hbars{position:absolute;inset:0;display:flex;align-items:flex-end;gap:2px}
.hbars>div{flex:1;height:100%;display:flex;flex-direction:column-reverse;min-width:1px}.hbars>div:hover{filter:brightness(1.25)}
.hx{position:relative;height:18px;margin:5px 0 0 44px}.hx span{position:absolute;transform:translateX(-50%);font-size:11px;color:var(--mut);white-space:nowrap}
.hleg{display:flex;gap:14px;justify-content:flex-end;font-size:12px;color:var(--mut);margin-top:2px}.hleg span{display:inline-flex;align-items:center;gap:6px}
.vchips{display:flex;gap:8px}.vchips button{cursor:pointer;font:inherit;font-size:14px}
.phchip .n{margin-left:8px;color:var(--mut);font-size:12px}.chip.on .n{color:#dfe3ff}
.badge.ph{color:#fff}.ph-Objectives{background:#e0122d}.ph-Lateral{background:#ff7a00;color:var(--ink)!important}
.ph-Foothold{background:#e5c100;color:var(--ink)!important}.ph-Recon{background:#276edb}.ph-none{background:var(--head)}
.sc{display:flex;flex-direction:column;justify-content:center;gap:3px;width:100%}.sc b{font-weight:400;font-family:"Roboto Mono",monospace;font-size:12px}
.sc i{display:block;height:4px;border-radius:2px;background:#1c1d3b;overflow:hidden}.sc i u{display:block;height:100%;text-decoration:none}
.tdot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:7px;flex:none}
.crown{color:#ffd700;margin-left:6px;font-size:12px}
.more table{min-width:0}.more td,.more th{font-size:12px}.more th{height:32px}
.terms td:nth-child(3),.terms th:nth-child(3){text-align:right;font-family:"Roboto Mono",monospace}
.terms tr.tot td{background:var(--panel2);font-weight:600}
.cols2{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(0,1fr);gap:18px}
.ipch{display:flex;flex-wrap:wrap;gap:6px}.ipch button{display:inline-flex;gap:8px;align-items:center;height:26px;padding:0 10px;border:0;border-radius:4px;background:var(--panel2);color:var(--fg);font:12px "Roboto Mono",monospace;cursor:pointer}
.ipch button:hover{background:var(--head)}.ipch em{font-style:normal;color:var(--mut)}
.viz{background:var(--panel);border-radius:5px;padding:12px 16px;margin-bottom:16px}.viz svg{display:block;width:100%}
.viz .ax{fill:var(--mut);font-size:11px}.viz .zl{font-size:12px;letter-spacing:.6px}
.loading{padding:40px;text-align:center;color:var(--mut)}
.errbox{background:var(--badbg);border:1px solid var(--bad);border-radius:6px;padding:8px 12px;margin-bottom:8px}
.formula{font:13px/1.7 "Roboto Mono",monospace;background:var(--panel2);border-radius:5px;padding:12px 14px;overflow-x:auto;white-space:pre}
.doc p{max-width:110ch;line-height:1.55}.doc td code{font-size:12px}
.vsep{width:1px;height:24px;background:var(--line)}
.rf2{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--mut)}
.ic{fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;flex:none}
.vbar{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:14px}
.vt{display:flex;align-items:center;gap:14px;padding:14px 16px;border:1px solid transparent;border-radius:5px;background:var(--panel);color:var(--fg);font:inherit;text-align:left;cursor:pointer;position:relative;overflow:hidden}
.vt::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--vc)}
.vt:hover{background:var(--panel2)}.vt.on{border-color:var(--vc);background:linear-gradient(90deg,color-mix(in srgb,var(--vc) 22%,transparent),var(--panel) 70%)}
.vt .ic{color:var(--vc)}.vt b{display:block;font-size:30px;font-weight:400;line-height:1}.vt .vl{display:block;font-size:14px;margin-top:3px}
.vt .vh2{display:block;font-size:11px;color:var(--mut);margin-top:2px;line-height:1.3}
.board{display:flex;flex-direction:column;gap:8px}
.bc{border-radius:5px;background:linear-gradient(90deg,color-mix(in srgb,var(--vc) 9%,var(--panel)) 0,var(--panel) 40%);overflow:hidden;position:relative}
.bc::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:var(--vc)}
.bc-main{display:grid;grid-template-columns:84px minmax(0,1fr) 280px 300px 18px;align-items:center;gap:16px;padding:10px 16px 6px 20px;cursor:pointer}
.bc-main:hover{background:#ffffff07}
.bc-sc{display:flex;flex-direction:column;align-items:center;justify-content:center;height:54px;border:1px solid color-mix(in srgb,var(--vc) 55%,transparent);border-radius:6px;background:color-mix(in srgb,var(--vc) 8%,transparent)}
.bc-sc b{font-size:27px;font-weight:600;line-height:1}.bc-sc span{font:9.5px/1 "Roboto Mono",monospace;letter-spacing:.8px;text-transform:uppercase;color:var(--vc);margin-top:5px}
.bc-ip{display:flex;align-items:center;flex-wrap:wrap;gap:8px;font:19px/1.2 "Roboto Mono",monospace}.bc.v-act .bc-ip{font-size:20px}
.bc-ip .cp{cursor:copy}.bc-ip .cp:hover{text-decoration:underline dotted}
.pill{display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 8px;border-radius:11px;background:var(--panel2);color:#dfe3f0;font:500 11px/1 "Kumbh Sans",sans-serif;letter-spacing:.3px;text-transform:uppercase;white-space:nowrap}
.pill.src{background:#3a1d28;color:#ff9aa6}.pill.tgt{background:#17325a;color:#8cc4ff}.pill.jw{background:#423812;color:#ffd700}
.pill.live{background:#14382a;color:var(--ok)}.pill.live i{width:7px;height:7px;border-radius:50%;background:var(--ok);animation:pulse 1.6s infinite}
@keyframes pulse{0%{box-shadow:0 0 0 0 rgba(62,207,114,.7)}70%{box-shadow:0 0 0 7px rgba(62,207,114,0)}100%{box-shadow:0 0 0 0 rgba(62,207,114,0)}}
.bc-what{font-size:14.5px;margin-top:3px}.bc-what q{quotes:"\\201C" "\\201D";color:#fff}.bc-what em{font-style:normal;color:var(--mut)}
.bc-sub{font-size:12px;color:var(--mut);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.kc{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:3px}.kc span{letter-spacing:-.2px;display:flex;flex-direction:column;gap:5px;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;color:var(--nul)}
.kc span i{display:block;height:6px;border-radius:3px;background:#1c1d3b;border:1px solid #2f3060}
.kc span.on{color:#e6e8f0}.kc span.on i{border-color:transparent}.kc span.hi{font-weight:600;color:#fff}
.kcap{font-size:11px;color:var(--mut);margin-top:5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bc-m{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.bc-m div{display:flex;flex-direction:column;gap:3px}
.bc-m b{display:flex;align-items:center;gap:6px;font-size:15px;font-weight:400;white-space:nowrap}.bc-m span{font-size:11px;color:var(--mut)}
.bc-m .ic{color:var(--mut)}
.bc .caret{justify-self:end}.bc.open .caret{transform:rotate(90deg);border-left-color:var(--info)}
.bc-more table{min-width:0}.bc-more .grid{overflow-x:auto}.bc-more td,.bc-more th{font-size:12px}.bc-more th{height:32px}
.bc-more h3{font-size:12px;margin:12px 0 6px;color:var(--mut);text-transform:uppercase;letter-spacing:.6px;font-weight:400}
.why{display:flex;gap:12px;align-items:flex-start;padding:10px 14px;margin:0 0 6px;border-radius:5px;background:var(--panel);border-left:3px solid var(--vc,var(--info));font-size:14px;line-height:1.5}
.why .ic{color:var(--vc,var(--info));margin-top:2px}.why b{font-weight:600}
.bc-more{padding:12px 18px 16px 22px;border-top:1px solid var(--line);background:#191a37}.bc-more[hidden]{display:none}
.oth{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}.oth button{display:inline-flex;align-items:center;gap:8px;height:28px;padding:0 10px;border:1px solid transparent;border-radius:4px;background:var(--panel2);color:var(--fg);font:12px inherit;cursor:pointer}
.oth button.on{border-color:var(--info)}.oth button:hover{background:var(--head)}
.bmore{display:block;margin:12px auto 0;padding:9px 22px}
.ovw{margin-top:18px}.ovw>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;color:var(--mut);padding:8px 0}
.ovw>summary::-webkit-details-marker{display:none}.ovw[open]>summary .caret{transform:rotate(90deg);border-left-color:var(--info)}.ovw>summary:hover{color:#fff}
.headline{display:flex;align-items:baseline;flex-wrap:wrap;gap:6px 14px;margin:0 0 12px;font-size:15px;color:var(--mut)}
.headline b{font-size:22px;font-weight:400;color:#fff}.headline i{font-style:normal;color:var(--nul)}
.headline .hl-act b{color:var(--red);font-weight:600}.headline .hl-act{color:#fff}.headline .hl-r{font-size:12px;margin-left:6px}
.pill.new{background:var(--blue);color:#fff}.hn{font:14px "Kumbh Sans",sans-serif;color:#dfe3f0}
.spkw{margin-top:5px;height:24px}.spk{display:block;width:100%;height:24px}.spk rect{fill:#5a6aa8}.bc.v-act .spk rect{fill:color-mix(in srgb,var(--vc) 75%,#8c9eff)}
.spk line{stroke:#ffffff24;stroke-width:1;vector-effect:non-scaling-stroke}
.bell{display:flex;align-items:center;justify-content:center;width:36px;height:36px;border:0;border-radius:4px;background:none;color:var(--mut);cursor:pointer}
.bell:hover{background:var(--panel2);color:#fff}.bell.on{color:#ffd700}
.psets{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin-bottom:16px}
.pset{display:flex;gap:10px;padding:12px;border-radius:5px;background:var(--panel2);cursor:pointer;border:1px solid transparent}
.pset:has(input:checked){border-color:var(--info);background:#26285a}.pset input{margin-top:3px}.pset b{display:block;font-weight:600;margin-bottom:4px}.pset .mut{font-size:12px;line-height:1.45}
.mform .frow{display:flex;flex-wrap:wrap;gap:12px 18px;align-items:flex-end;margin:10px 0}.flbl{width:100%;font-size:12px;color:var(--mut)}
.fld2{display:flex;flex-direction:column;gap:5px;font-size:12px;color:var(--mut)}.fld2 input[type=number]{width:150px}.fld2.sm input{width:84px}.fld2 select{height:34px}
.cmp{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:12px}.vcs{display:flex;gap:8px;margin:6px 0}
.vc{display:flex;flex-direction:column;min-width:96px;padding:8px 10px;border-radius:5px;background:var(--panel2);border-left:3px solid var(--vc);font-size:12px;color:var(--mut)}.vc b{font-size:20px;font-weight:400;color:#fff}
td.vsp,th.vsp{width:14px;background:var(--panel)!important;border:0}
@media (max-width:1300px){.psets{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:1500px){.bc-main{grid-template-columns:84px minmax(0,1fr) 280px 18px}.bc-m{display:none}}
@media (max-width:1000px){.bc-main{grid-template-columns:80px minmax(0,1fr) 18px}.kc,.kcap{display:none}.vbar{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:1300px){.tiles2{grid-template-columns:repeat(3,minmax(0,1fr))}.cols2{grid-template-columns:1fr}}
@media (max-width:700px){.tiles2{grid-template-columns:repeat(2,minmax(0,1fr))}}
"""


def _svg(name: str, px: int) -> str:
    return f'<svg class="ic" width="{px}" height="{px}" viewBox="0 0 24 24" aria-hidden="true">{ICONS[name]}</svg>'


def _e(value: object) -> str:
    return html.escape("" if value is None else str(value))


def _classify_link(name: object) -> str:
    """An alert name the catalog does not know, as a link that opens the Rule catalog card of the Configuration tab
    with the classify dialog for it (confui.cfClassifyLink; an admin's tab, anyone else lands on the queue)."""
    return f'<a href="./?tab=config&amp;classify={quote(str(name), safe="")}" title="Classify this rule">{_e(name)}</a>'


UNKNOWN_HELP = _e("Classify them in Configuration > Rule catalog; until then they count as weak evidence from their "
                  "MITRE tactic.")


def _info(tip: str) -> str:
    return f' <span class="info" tabindex="0" role="note" aria-label="{_e(tip)}" data-tip="{_e(tip)}">i</span>'


def _norm(product: str, compare: bool) -> str:
    """triage, clusters (the board with its own verdicts: compare mode only) or episodes. Without the compare mode the
    old `clusters` product is the Episodes view."""
    return "episodes" if product == "episodes" or (product == "clusters" and not compare) else product


def _pname(product: str, compare: bool = True) -> str:
    return {"triage": "Triage", "clusters": "Clusters", "episodes": "Episodes"}[_norm(product, compare)]


def _menu(active: str, product: str = "triage", compare: bool = True) -> str:
    product = _norm(product, compare)
    # the Scoring model page sets the Clusters verdict: only in the compare mode the Clusters product has one
    own = ("scoring", "Scoring model", "scoring") if product == "clusters" else ("digest", "Daily digest", "digest")
    items = [("help", "How to read this", "help"), own, ("system", "System status", "system")]
    # Help and System are shared pages: from Clusters they are asked for as Clusters, so the top bar stays on its product
    frm = {"clusters": "?from=clusters", "episodes": "?from=episodes"}.get(product, "")
    links = "".join(f'<a href="{h}{frm if k in ("help", "system") else ""}"{" class=\"cur\"" if k == active else ""}>{_e(lbl)}</a>'
                    for h, lbl, k in items)
    return (f'<details class="menu"><summary title="Menu" aria-label="Menu">{_gear(24)}</summary>'
            f'<div class="menup">{links}</div></details>')


# the tab icon inline (a shield in the Sycope blue): no /favicon.ico request, the same icon behind the Passthrough
_ICON = ('<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 16 16%27%3E'
         '%3Cpath d=%27M8 1 2 3.5v4C2 11 4.6 14 8 15c3.4-1 6-4 6-7.5v-4z%27 fill=%27%231c48f7%27/%3E%3C/svg%3E">')


def _switch(product: str, compare: bool = True) -> str:
    """Triage | Clusters | Episodes: the same alerts, three ways to look at them. Clusters (the board with its own
    verdicts) only in the compare mode; without it the switch is Triage | Episodes."""
    cur = ' aria-current="page"'
    p = _norm(product, compare)
    clusters = f'<a href="clusters"{cur if p == "clusters" else ""}>Clusters</a>' if compare else ""
    return (f'<nav class="psw" aria-label="Product"><a href="./"{cur if p == "triage" else ""}>Triage</a>{clusters}'
            f'<a href="episodes"{cur if p == "episodes" else ""}>Episodes</a></nav>')


_VIEW_TIP = "Simple: what happened, how sure, what to do. Full: every column, filter and number."
# 1.4.4: Simple | Full is kept per scope, not once for the whole app. The scope names what the toggle on the page changes.
SCOPES = {"list": "list", "incident": "incidents", "clusters": "board", "episodes": "episodes"}


def _scope_tip(scope: str) -> str:
    return f"Simple or Full for {SCOPES[scope]}; the other pages keep their own"


def _vsw(simple: bool, scope: str = "list") -> str:
    """The Simple | Full toggle (1.3), right of the Triage | Clusters switch, with a muted hint naming the scope it changes
    (1.4.4). The script keeps it (see _VIEW_JS)."""
    on = ' aria-pressed="true"'
    off = ' aria-pressed="false"'
    tip = _e(_scope_tip(scope))
    return (f'<div class="vsw" id="vsw" role="group" aria-label="View" title="{_e(_VIEW_TIP)} {tip}.">'
            f'<button type="button" data-v="simple"{on if simple else off}>Simple</button>'
            f'<button type="button" data-v="full"{off if simple else on}>Full</button></div>'
            f'<span class="vsc" id="vsc" title="{tip}">{_e(SCOPES[scope])}</span>')


# The view the browser keeps, one localStorage key per scope (sc-view:list, :incident, :clusters, :episodes). A scope with
# no key of its own starts from the old single key sc-view (1.3), which is left alone. ?view=simple|full overrides the
# scope of the opened page and is stored for it only. Read before the first paint, so Simple never flashes as Full. The
# server also writes the class when the address says ?view=simple. SCV.simple is the page's own scope; SCV.inc is the
# incident scope, which the quick look drawer follows whatever page it is on.
_VIEW_BOOT = """<script>(function(){var SC="@@SCOPE@@",u=null,s;try{u=new URLSearchParams(location.search).get("view")}catch(x){}
function rd(sc){var v="";try{v=localStorage.getItem("sc-view:"+sc)||localStorage.getItem("sc-view")||""}catch(x){}return v==="simple"}
if(u==="simple"||u==="full"){s=u==="simple";try{localStorage.setItem("sc-view:"+SC,u)}catch(x){}}else s=rd(SC);
window.SCV={scope:SC,simple:s,inc:SC==="incident"?s:rd("incident"),fns:[],get:rd,on:function(f){this.fns.push(f)}};if(s)document.body.classList.add("simple")})();</script>"""

# The toggle's buttons; a page registers SCV.on(fn) to redraw what differs between the two views (fn gets the scope that changed).
_VIEW_JS = """<script>(function(){var V=window.SCV,b=document.getElementById("vsw");if(!V)return;
function pr(el,s){var bt=el?el.querySelectorAll("button"):[];for(var i=0;i<bt.length;i++)bt[i].setAttribute("aria-pressed",((bt[i].getAttribute("data-v")||bt[i].getAttribute("data-dv"))==="simple")===s?"true":"false")}
function paint(){pr(b,V.simple);pr(document.getElementById("dvsw"),V.inc);var d=document.getElementById("drawer");if(d)d.classList.toggle("simple",V.inc)}
V.put=function(sc,v){var s=v==="simple";if(sc==="incident"){if(s===V.inc)return;V.inc=s;if(V.scope==="incident")V.simple=s}else{if(sc!==V.scope||s===V.simple)return;V.simple=s}
  try{localStorage.setItem("sc-view:"+sc,s?"simple":"full")}catch(x){}
  if(sc===V.scope){document.body.classList.toggle("simple",s);
    try{var u=new URLSearchParams(location.search);if(u.has("view")){u.delete("view");var q=u.toString();history.replaceState(null,"",location.pathname+(q?"?"+q:""))}}catch(x){}}
  paint();V.fns.forEach(function(f){try{f(sc)}catch(e){if(window.console)console.error(e)}})};
V.set=function(v){V.put(V.scope,v)};V.setInc=function(v){V.put("incident",v)};
if(b)b.addEventListener("click",function(e){var t=e.target.closest("button[data-v]");if(t)V.set(t.getAttribute("data-v"))});paint()})();</script>"""


def _page(title: str, body: str, active: str, settings: Settings, topctl: str = "", sub: str = "",
          script: str = "", product: str = "triage", css: str = "", offset_min: int = 0,
          simple: bool = False, view_toggle: str = "") -> str:
    base = f'<base href="{_e(settings.base_href.rstrip("/"))}/">' if settings.base_href else ""
    top = (f'<div class="top">{logo(product, settings.clusters_compare)}{_switch(product, settings.clusters_compare)}{_vsw(simple, view_toggle) if view_toggle else ""}{f'<span class="sub">{_e(sub)}</span>' if sub else ""}<span class="sp"></span>'
           + (topctl or f'<span class="mut">as of {_ts(time.time(), "hm")}</span>{fmt.tz_switch()}')
           + f"{_menu(active, product, settings.clusters_compare)}</div>")
    boot = _VIEW_BOOT.replace("@@SCOPE@@", view_toggle) if view_toggle else ""
    wire = _VIEW_JS if view_toggle else ""
    cls = ' class="simple"' if simple and view_toggle else ""
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1">{base}{_ICON}'
            f"<title>{_e(title)}</title><style>{_FONT_CSS}{_CSS}{_CSS_EXTRA}{css}</style></head>"
            f'<body{cls}><script>window.SC_OFF={int(offset_min)}</script>{boot}{top}<div class="wrap">{body}</div>{TIME_TAG_JS}{_INFO_JS}{_MENU_JS}{wire}{script}</body></html>')


def _ts(epoch: float | None, mode: str = "dt") -> str:
    if not epoch:
        return '<span class="null">&lt;null&gt;</span>'
    pattern = {"hm": "%H:%M", "full": "%Y-%m-%d %H:%M:%S"}.get(mode, "%Y-%m-%d %H:%M")
    return f'<time class="ts" data-e="{int(epoch)}" data-f="{mode}">{time.strftime(pattern, time.gmtime(epoch))}</time>'


def _grid(head: list, rows: list[list[str]]) -> str:
    th = "".join(f"<th>{_e(h[0])}{_info(h[1])}</th>" if isinstance(h, tuple) else f"<th>{_e(h)}</th>" for h in head)
    tr = "".join("<tr>" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for r in rows)
    return f'<div class="grid"><table><tr>{th}</tr>{tr}</table></div>'


# ---- Live clusters ----------------------------------------------------------------------------------------

_PRESETS = (("15m", "Last 15 minutes"), ("1h", "Last hour"), ("6h", "Last 6 hours"), ("12h", "Last 12 hours"),
            ("24h", "Last 24 hours"))


def live_page(settings: Settings, offset_min: int = 0, simple: bool = False) -> str:
    presets = "".join(f'<button type="button" class="mi" data-t="{k}"><b>{k}</b>{_e(lbl)}</button>'
                      for k, lbl in _PRESETS)
    topctl = (
        f'<div class="tpk"><details class="dd tlr"><summary>{_CAL}<span class="tld"><span id="tlbl">Last 6 hours'
        f'</span><span class="mut" id="tspan"></span></span>{_CHEV}</summary><div class="ddp">{presets}</div></details></div>'
        f'<button type="button" class="lnk me" id="me"></button>{fmt.tz_switch()}'
        f'<button type="button" class="bell" id="bell" aria-label="Notifications">{_svg("bell", 20)}</button>'
        f'<span class="mut" id="asof">loading…</span>'
        f'<span class="rfg"><form class="rf" onsubmit="return false"><button type="button" id="reload" '
        f'title="Read the newest snapshot now" aria-label="Refresh">{_REFRESH}</button></form>'
        f'<details class="rfd"><summary title="Auto refresh" aria-label="Auto refresh">{_CHEV}</summary>'
        f'<div class="rfp"><label class="sw"><input type="checkbox" id="auto" checked><span></span></label>'
        f'<span>Auto refresh every <b id="every">{settings.poll_seconds}</b> s</span></div></details></span>')
    types = "".join(f'<label class="mi"><input type="checkbox" value="{_e(k)}" class="tchk">'
                    f'<span class="tdot" style="background:{TYPE_COLORS.get(k, "#808297")}"></span>{_e(k)} '
                    f'<span class="mut">{_e(v)}</span></label>' for k, (v, _help, _col) in rules.FAMILIES.items())
    sorts = [("priority", "Priority"), ("alerts", "Alerts"), ("last", "Last alert"), ("impact", "Impact"),
             ("certainty", "Certainty")]
    dbg = ([("ref_a", "Reference score A"), ("ref_b", "Reference score B"), ("blend", "Blend 0-100")]
           if settings.debug_models else [])      # the page drops these buttons again for anyone who is not an admin
    sort_items = "".join(f'<button type="button" class="mi" data-sort="{k}">{_e(v)}</button>' for k, v in sorts)
    sort_items += "".join(f'<button type="button" class="mi" data-sort="{k}" data-dbg="1">{_e(v)}</button>'
                          for k, v in dbg)
    body = f"""
<div id="err"></div>
<div class="tabs" id="tabs"></div>
<div id="clctl">
<div class="headline" id="headline"></div>
<div class="vbar" id="vbar"></div>
<div class="tools">
  <div class="vchips"><button type="button" class="chip" data-view="board">Threat Board</button>
  <button type="button" class="chip" data-view="table">Table</button>
  <button type="button" class="chip" data-view="timeline">Timeline</button>
  <button type="button" class="chip" data-view="quadrant">Impact × Certainty</button></div>
  <span class="vsep"></span>
  <label class="sel-opt" id="grp" title="One card per host shows each host once, with its strongest cluster">
    <input type="checkbox" id="perhost" style="width:18px;height:18px" checked> one card per host</label>
  <label class="sel-opt"><input type="checkbox" id="critonly" style="width:18px;height:18px"> crown jewels only</label>
  <label class="sel-opt"><input type="checkbox" id="liveonly" style="width:18px;height:18px"> active now</label>
  <label class="sel-opt" title="Seen and closed clusters leave the board until they rise to a higher verdict">
    <input type="checkbox" id="hideh" style="width:18px;height:18px" checked> hide handled <span class="mut" id="hidehn"></span></label>
  <button type="button" class="b2" id="qact" disabled title="Tick clusters, then act on them together">Action &#9662;</button>
  <span class="mut" id="seln"></span>
  <span class="sp"></span>
  <form class="srch" onsubmit="return false"><label class="vh" for="q">Search</label>{_LUPA}
    <input type="search" id="q" placeholder="Search IP, alert, type…" autocomplete="off"></form>
  <details class="dd" id="sortdd"><summary>Sort: <span id="sortlbl">Priority</span>{_CHEV}</summary>
    <div class="ddp">{sort_items}</div></details>
</div>
<div class="tools" style="margin-top:-2px">
  <div class="chips" id="phchips" style="margin:0"></div>
  <details class="dd" id="typedd"><summary>Cluster type <span id="tcount" class="mut"></span>{_CHEV}</summary>
    <div class="ddp">{types}<button type="button" class="mi" id="tclear">Clear</button></div></details>
</div>
</div>
<div id="view"><div class="loading">Reading alerts from Sycope…</div></div>
<details class="ovw" id="ovw"><summary><span class="caret"></span>Overview: alerts, clusters and alert volume over time</summary>
<div class="tiles2" id="tiles" style="margin-top:12px"></div>
<div class="card hcard"><div class="cth"><h2 class="ct" style="font-size:15px">Alerts over time, by kill-chain phase of the rule</h2>
<span class="mut" id="hcap"></span></div><div id="hist"></div></div></details>
"""
    cfg = {"t": settings.default_range if settings.default_range in dict(_PRESETS) else "6h",
           "poll": settings.poll_seconds, "phases": PHASE_NAMES[::-1], "phaseColors": PHASE_COLORS,
           "typeColors": TYPE_COLORS, "presets": dict(_PRESETS), "icons": ICONS,
           "tacticPhase": {t: PHASE_NAMES[i] for t, i in TACTIC_PHASE.items()},
           "verdicts": [{"key": k, "label": lbl, "color": VERDICT_COLORS[k], "help": VERDICT_HELP[k]}
                        for k, lbl in VERDICT_LABELS.items()],
           "compare": settings.clusters_compare, "rawdata": bool(settings.sycope_ui_url or settings.sycope_url), "reasons": triage.REASONS,
           "famNames": {k: v[0] for k, v in rules.FAMILIES.items()},
           "ruleNames": rules.DISPLAY_NAMES, "actionWords": {**triage.ACTION_WORDS, **cluster_work.ACTION_WORDS},
           "sycopeUi": (settings.sycope_ui_url or settings.sycope_url).rstrip("/"),
           "recorderUrl": ((settings.sycope_ui_url or settings.sycope_url).rstrip("/") + "/npm/api/v1/passthrough/"
                           + settings.recorder_passthrough) if settings.recorder_passthrough else ""}
    # "<" escaped: a value can never close the <script> element it sits in
    script = f"<script>window.SC={json.dumps(cfg).replace('<', chr(92) + 'u003c')};</script><script>{_LIVE_JS}</script>"
    return _page("Sycope Security Clusters", body, "live", settings, topctl=topctl, script=script, product="clusters", offset_min=offset_min,
                 css=_WORK_CSS, simple=simple, view_toggle="clusters")


# Used by this page and by the Triage page (ui.py): who is acting (the Sycope user, confirmed once a shift), the dialogs,
# the menu, the status words and the ticket-priority tag. One text, so the identity code cannot drift between the two.
# A page defines afterMe() (what to redraw when the user is known) and refreshAll().
_WORK_JS_SHARED = FMT_JS + r"""// a failed read: when the service cannot be reached at all (the page opened from the wrong address), say where to go
function netErr(e){if(e&&e.name==="TypeError")e.net=true;throw e}     // put on the fetch itself: only a request that never got an answer is "cannot reach"
function readErr(e,what,svc){var m=(e&&e.message)||"",net=e&&e.net;
  return '<div class="errbox" title="'+esc(m)+'">'+(net?'Cannot reach the Security '+svc+' service. Open it from the Sycope menu (Passthrough .../clusters/).':'Cannot read '+what+': '+esc(m))+'</div>'}
// an audit action in words, its code in a tooltip; a target such as cl:9097 as "cluster 9097"
function own(o,k){return !!o&&Object.prototype.hasOwnProperty.call(o,k)}
function aw(a,W){var t=own(W,a)?W[a]:own(C.actionWords,a)?C.actionWords[a]:"";return t?'<span title="'+esc(a)+'">'+esc(t)+'</span>':esc(a)}
function tgt(t){var m=/^cl:(\d+)$/.exec(t||"");if(m)return '<span title="'+esc(t)+'">cluster '+m[1]+'</span>';m=/^ct:(.+)$/.exec(t||"");if(m)return '<span title="'+esc(t)+'">target '+esc(m[1])+'</span>';return esc(t)}
function rn(n){var c=own(C.ruleNames,n)?C.ruleNames[n]:"";return c?'<span title="'+esc("Alert name in Sycope: "+n)+'">'+esc(c)+'</span>':esc(n)}
function ii(html,r){return '<span class="ii'+(r?" r":"")+'" tabindex="0" role="note" aria-label="Explanation">i<span class="iit">'+html+'</span></span>'}
function priTag(P){return P?'<span class="tg pri'+(P[0]==="P1"?" p1":"")+'" title="Ticket priority '+esc(P[0])+': '+esc(P[1]+(P[2]?". "+P[2]:""))+'">'+esc(P[0])+'</span>':""}
// ---- one menu for a right click, a row's ⋯ and Action ▾, as in Sycope: only what works for the thing under it ----
var CM=null;
function cmClose(){if(CM){CM.remove();CM=null}}
function cmShow(items,x,y,from,above){cmClose();var out=[];
  items.forEach(function(it){if(!it||(it.sep&&(!out.length||out[out.length-1].sep)))return;out.push(it)});while(out.length&&out[out.length-1].sep)out.pop();
  out=out.filter(function(it,i){return !it.head||i===0||(out[i+1]&&!out[i+1].sep&&!out[i+1].head)});
  if(!out.some(function(it){return it.run||it.href}))return false;
  var m=document.createElement("div");m.className="cm";m.setAttribute("role","menu");
  m.innerHTML=out.map(function(it,i){if(it.sep)return '<div class="cm-sep" role="separator"></div>';if(it.head)return '<div class="cm-h">'+it.head+'</div>';
    var inner=esc(it.label)+(it.href?'<span class="cm-x">↗</span>':""),tip=it.tip?' title="'+esc(it.tip)+'"':"";
    return it.href?'<a class="cm-i" role="menuitem" tabindex="-1" href="'+esc(it.href)+'" target="_blank" rel="noopener noreferrer" data-cm="'+i+'"'+tip+'>'+inner+'</a>'
      :'<button type="button" class="cm-i" role="menuitem" tabindex="-1" data-cm="'+i+'"'+tip+'>'+inner+'</button>'}).join("");
  m._items=out;m._from=from||null;document.body.appendChild(m);CM=m;
  // below the point (or the button); a menu opened from a button never covers it: it goes where there is more room
  // and scrolls inside when even that is too short
  var w=m.offsetWidth,hh=m.offsetHeight,top=y,below=innerHeight-y-8,up=above!=null?above-12:0;
  if(hh>below){if(above==null)top=Math.max(8,innerHeight-hh-8);else if(hh<=up)top=above-4-hh;
    else if(below>=up)m.style.maxHeight=below+"px";else{m.style.maxHeight=up+"px";top=8}}
  m.style.left=Math.max(8,Math.min(x,innerWidth-w-8))+"px";m.style.top=top+"px";return true}
function cmAt(el,items){var r=el.getBoundingClientRect();return cmShow(items,r.left,r.bottom+4,el,r.top)}
// ---- who is acting: the Sycope user when the page runs inside Sycope (Passthrough), else a name kept in this browser ----
var ME={name:"",full:"",roles:[],src:"",check:"",checkErr:""},KNOWN=[],NAMES_LOADED=false;
try{ME.name=localStorage.getItem("sc-who")||"";if(ME.name)ME.src="browser"}catch(x){}
function meBadge(){var el=$("#me");if(!el)return;el.textContent=ME.name?ME.name:"set your name";var p=ME.src==="sycope"?passFor(ME.name):null;
  if(p)el.insertAdjacentHTML("beforeend",' <span class="vok" aria-hidden="true">✓</span>');
  el.title=ME.src==="sycope"?"Signed in to Sycope as "+ME.name+(ME.full?" ("+ME.full+")":"")+(ME.roles.length?" · roles: "+ME.roles.join(", "):"")+"\n"
    +(p?"✓ Sycope confirmed it: your actions go into the audit log under this name, marked as confirmed (until "+tm(p.exp*1000,"hm")+")"
      :ME.check==="busy"?"Checking it with Sycope… (a few seconds, once a shift)"
      :ME.check==="no"?"Sycope could not confirm it"+(ME.checkErr?" ("+ME.checkErr+")":"")+": your actions are recorded under this name without the ✓"
      :"Not confirmed by Sycope yet")
    :"Your name for the audit log, kept in this browser ("+(IN_SYCOPE?"Sycope did not say who is signed in":"the page runs outside Sycope")+"): click to change. Without Sycope's confirmation the audit log shows it without the ✓.";
  el.classList.toggle("sy",ME.src==="sycope")}
var IN_SYCOPE=location.pathname.indexOf("/npm/api/v1/passthrough/")>=0;  // inside Sycope: same origin, its session
// Sycope's own API from its origin: its session cookie, or the token its UI keeps (npm-jwt-token) when it uses one
function sycopeGet(path){var h={Accept:"application/json"};
  return fetch(path,{credentials:"same-origin",headers:h}).then(function(r){if(r.status!==401&&r.status!==403)return r;var t=null;try{t=localStorage.getItem("npm-jwt-token")}catch(x){}
    if(!t)return r;h.Authorization="Bearer "+t.replace(/^"|"$/g,"");return fetch(path,{credentials:"same-origin",headers:h})})}
function loadMe(){if(!IN_SYCOPE){meBadge();return Promise.resolve()}return sycopeGet("/npm/api/v1/logged-user")
  .then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json()})
  .then(function(u){if(u&&u.username){ME.name=u.username;ME.full=[u.firstName,u.lastName].filter(Boolean).join(" ");ME.roles=(u.roles||[]).map(function(r){return r&&r.name}).filter(Boolean);ME.src="sycope"}})
  .catch(function(){}).then(function(){meBadge();afterMe();return checkMe()})}
// ---- who is acting, confirmed by Sycope once a shift (identity.py) ----
// The service gives a code; the page writes it into the signed-in user's own Sycope preferences, which only that user's
// session can do and which Sycope's audit log records with the user; the service finds the line and answers with a pass
// it signed. Every action carries the pass, so the audit log has the name Sycope confirmed, not the one this page says.
var PASS=null,CHECKING=null;try{PASS=JSON.parse(localStorage.getItem("sc-pass")||"null")}catch(x){}
function passFor(name){return PASS&&PASS.pass&&name&&PASS.user===name&&PASS.exp*1000>Date.now()+60000?PASS:null}
function setPass(p){PASS=p;try{if(p)localStorage.setItem("sc-pass",JSON.stringify(p));else localStorage.removeItem("sc-pass")}catch(x){}}
function pause(ms){return new Promise(function(r){setTimeout(r,ms)})}
function redeem(claim,n){return fetch("whoami",{credentials:"same-origin",headers:{Accept:"application/json","X-SC-Claim":claim}})
  .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})
  .then(function(j){if(j.verified)return j;if(n>=14)throw new Error("it did not show up in Sycope's audit log within 30 s");return pause(2000).then(function(){return redeem(claim,n+1)})})}
function checkMe(){if(!IN_SYCOPE||ME.src!=="sycope")return Promise.resolve();if(passFor(ME.name)){meBadge();return Promise.resolve()}
  setPass(null);ME.check="busy";ME.checkErr="";meBadge();
  CHECKING=getJ("whoami").then(function(c){var b={};b[c.key]=JSON.stringify(c.proof);
      return fetch("/npm/api/v1/user-preferences?merge=true",{method:"PUT",credentials:"same-origin",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(b)})
        .then(function(r){if(!r.ok)throw new Error("Sycope did not let the page save the check, HTTP "+r.status);return redeem(c.claim,0)})})
    .then(function(p){if(p.user!==ME.name)throw new Error("Sycope confirmed "+p.user+", but the page shows "+ME.name);setPass(p);ME.check="ok"})
    .catch(function(e){ME.check="no";ME.checkErr=e.message})
    .then(function(){CHECKING=null;meBadge()});
  return CHECKING}
function askName(){return dlg({title:"Your name for the audit log",body:'<p class="mut">'+(IN_SYCOPE?"Sycope did not say who is signed in (the session may have expired).":"The page runs outside Sycope, so it cannot ask Sycope who you are.")+' The name is kept in this browser and goes into the audit log with every action.</p>',
  fields:[{name:"who",label:"Name",required:true,max:40,value:ME.src==="browser"?ME.name:""}],ok:"Save"}).then(function(v){if(!v)return null;ME.name=v.who;ME.src="browser";try{localStorage.setItem("sc-who",v.who)}catch(x){}meBadge();return ME.name})}
function ensureWho(){return ME.name?Promise.resolve(ME.name):askName()}
function isVerified(){return !!passFor(ME.name)}
function isAdmin(){var p=passFor(ME.name);return p?!!p.admin:ME.roles.indexOf("ROLE_ADMIN")>=0}
function addName(n){if(n&&n!=="system"&&KNOWN.indexOf(n)<0)KNOWN.push(n)}
function loadNames(){if(NAMES_LOADED)return Promise.resolve(KNOWN);NAMES_LOADED=true;addName(ME.name);
  return Promise.all([getJ("audit?days=0&limit=1").then(function(d){((d.facets||{}).who||[]).forEach(addName)}).catch(function(){}),
    (IN_SYCOPE?sycopeGet("/npm/api/v1/users"):Promise.resolve({ok:false})).then(function(r){return r.ok?r.json():null}).then(function(j){((j&&j.data)||[]).forEach(function(u){if(u&&u.enabled!==false&&!u.system)addName(u.username)})}).catch(function(){})])
  .then(function(){KNOWN.sort();return KNOWN})}
// ---- dialogs: in the page, with the scope said out loud (never the browser's prompt or confirm) ----
// Escape closes an open dropdown panel of the dialog (.sil-pk-p) first, focus back on its button; the next one closes the dialog
function dlgKey(w,e,done){if(e.key==="Escape"){e.stopPropagation();var pk=w.querySelector(".sil-pk-p:not([hidden])");if(pk){pk.hidden=true;var pb=pk.parentNode.querySelector("button[aria-expanded]");if(pb){pb.setAttribute("aria-expanded","false");pb.focus()}}else done(false)}else if(e.key==="Enter"&&e.target.tagName==="INPUT"){e.preventDefault();done(true)}}
function dlg(o){return new Promise(function(res){var w=document.createElement("div");w.className="dlg-w";
  var fld=function(x){var id="dlg-"+x.name,lab='<span>'+esc(x.label)+(x.required?' <b class="req">required</b>':"")+'</span>';
    if(x.type==="select")return '<label class="dlg-f">'+lab+'<select id="'+id+'">'+(x.options||[]).map(function(op){return '<option value="'+esc(op[0])+'"'+(String(op[0])===String(x.value)?" selected":"")+'>'+esc(op[1])+'</option>'}).join("")+'</select></label>';
    if(x.type==="textarea")return '<label class="dlg-f">'+lab+'<textarea id="'+id+'" rows="3" maxlength="'+(x.max||500)+'" placeholder="'+esc(x.placeholder||"")+'">'+esc(x.value||"")+'</textarea></label>';
    return '<label class="dlg-f">'+lab+'<input id="'+id+'" type="text" maxlength="'+(x.max||200)+'" value="'+esc(x.value||"")+'" placeholder="'+esc(x.placeholder||"")+'"'+(x.list?' list="'+id+'-l" autocomplete="off"':"")+'>'
      +(x.list?'<datalist id="'+id+'-l">'+x.list.map(function(n){return '<option value="'+esc(n)+'">'}).join("")+'</datalist>':"")+'</label>'};
  w.innerHTML='<div class="dlg'+(o.wide?" wide":"")+'" role="dialog" aria-modal="true" aria-label="'+esc(o.title)+'"><h3>'+esc(o.title)+'</h3>'+(o.body?'<div class="dlg-b">'+o.body+'</div>':"")+(o.fields||[]).map(fld).join("")
    +'<div class="dlg-err" role="alert"></div><div class="dlg-a"><button type="button" class="b2" data-dlg="0">Cancel</button><button type="button" class="b2 '+(o.danger?"warn":"pri")+'" data-dlg="1">'+esc(o.ok||"OK")+'</button></div></div>';
  document.body.appendChild(w);
  (o.fields||[]).forEach(function(x){if(!x.deps)return;var master=w.querySelector("#dlg-"+x.deps.field),me=w.querySelector("#dlg-"+x.name);
    var fill=function(){var list=x.deps.map[master.value]||[];me.innerHTML=list.map(function(r){return '<option value="'+esc(r)+'">'+esc(r)+'</option>'}).join("");me.closest(".dlg-f").style.display=list.length?"":"none"};
    master.addEventListener("change",fill);fill()});
  if(o.setup)o.setup(w);
  var first=w.querySelector("textarea,input,select")||w.querySelector('[data-dlg="1"]');if(first)first.focus();
  var done=function(ok){if(!ok){w.remove();res(null);return}var v={},bad="";
    (o.fields||[]).forEach(function(x){var el=w.querySelector("#dlg-"+x.name),shown=el&&el.closest(".dlg-f").style.display!=="none",val=shown?el.value.trim():"";if(x.required&&shown&&!val&&!bad)bad=x.label+" is required.";v[x.name]=val});
    if(!bad&&o.collect){var ex=o.collect(w);if(typeof ex==="string")bad=ex;else Object.keys(ex).forEach(function(k){v[k]=ex[k]})}
    if(bad){w.querySelector(".dlg-err").textContent=bad;return}w.remove();res(v)};
  w.addEventListener("mousedown",function(e){w._down=e.target===w});
  w.addEventListener("click",function(e){var b=e.target.closest("[data-dlg]");if(b){done(b.dataset.dlg==="1");return}if(e.target===w&&w._down)done(false)});
  w.addEventListener("keydown",function(e){dlgKey(w,e,done)})})}
function toastUndo(msg,prev,o){var t=document.createElement("div");t.className="toast";t.innerHTML='<span>'+esc(msg)+'</span>'+((prev&&prev.length)||(o&&o.undo)?'<button type="button" class="b2">Undo</button>':"");document.body.appendChild(t);
  var gone=false,kill=function(){if(gone)return;gone=true;t.classList.add("out");setTimeout(function(){t.remove()},400)};
  var b=t.querySelector("button");if(b)b.onclick=function(){b.disabled=true;(o.undo?o.undo():post({op:"restore",rows:prev,who:ME.name||"analyst",scope:o.scope||"",label:o.label||""}))
    .then(function(){kill();toast("Undone: back as it was");setTimeout(refreshAll,250)}).catch(function(e){b.disabled=false;toast(e.message,true)})};
  setTimeout(kill,10000)}
// ---- the analyst's state of an incident ----
var STW={investigating:"In progress",escalated:"Escalated",ack:"Seen",tp:"Closed: true positive",benign:"Closed: benign",fp:"Closed: false positive",resolved:"Resolved"};
var DONEW={investigating:"Taken: in progress, yours",escalated:"Escalated",ack:"Marked seen",tp:"Closed as a true positive",benign:"Closed as benign",fp:"Closed as a false positive",resolved:"Resolved",open:"Reopened"};
var CLOSEW=[["tp","True positive: an attack, handled"],["benign","Benign: real, but allowed (pentest, backup, admin)"],["fp","False positive: the detection is wrong"]];
function ownerOf(t){return t&&!t.changed&&(t.status==="investigating"||t.status==="escalated")&&t.owner?t.owner:null}
"""

_LIVE_JS = r"""
(function(){
"use strict";
var C=window.SC, $=function(s,r){return (r||document).querySelector(s)}, $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var P=new URLSearchParams(location.search);
var S={t:P.get("t")||C.t, sort:P.get("sort")||"priority", view:P.get("view")||"board", q:P.get("q")||"",
  vd:new Set((P.get("verdict")||"").split(",").filter(Boolean)), perhost:P.get("perhost")!=="0", live:P.get("live")==="1", limit:50, pick:{},
  ph:new Set((P.get("phase")||"").split(",").filter(Boolean)), ty:new Set((P.get("type")||"").split(",").filter(Boolean)),
  crit:P.get("crit")==="1", size:+(P.get("size")||100), page:1, open:new Set((P.get("open")||"").split(",").filter(Boolean)), data:null, details:{}, lane:P.get("lane")||"clusters", hideh:P.get("handled")!=="1", sel:new Set(),
  ho:{hours:0,data:null,err:""}, endedOpen:{}, recs:{}};
if(["clusters","targets","external","ended","handover"].indexOf(S.lane)<0)S.lane="clusters";
if(["board","table","timeline","quadrant"].indexOf(S.view)<0)S.view="board";     // ?view=simple|full is the Simple | Full toggle's, not a board view
// ---- Simple view (1.3): body.simple from SCV; Simple shows the main board as one card per host and sets the analysis filters aside for Full ----
var SIMPLE=!!(window.SCV&&window.SCV.simple),SAVE=null,STEPS_ALL=false;
function simpleState(){if(SIMPLE&&!SAVE){SAVE={view:S.view,lane:S.lane,hideh:S.hideh,perhost:S.perhost,live:S.live,crit:S.crit,ph:S.ph,ty:S.ty,sort:S.sort};
    S.view="board";S.lane="clusters";S.hideh=true;S.perhost=true;S.live=false;S.crit=false;S.ph=new Set();S.ty=new Set();S.sort="priority"}
  else if(!SIMPLE&&SAVE){S.view=SAVE.view;S.lane=SAVE.lane;S.hideh=SAVE.hideh;S.perhost=SAVE.perhost;S.live=SAVE.live;S.crit=SAVE.crit;S.ph=SAVE.ph;S.ty=SAVE.ty;S.sort=SAVE.sort;SAVE=null}}
simpleState();
var SORTKEY={priority:"score",ref_a:"ref_a_score",ref_b:"ref_b_score",blend:"blend_score",alerts:"alert_count",last:"end_ms",impact:"impact_score",certainty:"certainty_score"};
var SORTLBL={priority:"Priority",ref_a:"Reference score A",ref_b:"Reference score B",blend:"Blend 0-100",alerts:"Alerts",last:"Last alert",impact:"Impact",certainty:"Certainty"};
function passHdr(h){h=h||{};var p=passFor(ME.name);if(p)h["X-SC-Pass"]=p.pass;return h}
function esc(v){return v==null?"":String(v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function nul(){return '<span class="null">&lt;null&gt;</span>'}
function dur(s){if(s==null)return nul();s=Math.round(s);if(s<60)return s+" s";if(s<3600)return Math.floor(s/60)+" min "+(s%60?(s%60)+" s":"");
  var h=Math.floor(s/3600),m=Math.floor(s%3600/60);return h+" h"+(m?" "+m+" min":"")}
function phb(p){return p?'<span class="badge ph ph-'+esc(p)+'">'+esc(p)+'</span>':'<span class="badge ph ph-none">no phase</span>'}
function sevb(s){return s?'<span class="badge b-'+esc(String(s).toLowerCase())+'">'+esc(s)+'</span>':nul()}
function tcol(t){return C.typeColors[t]||"#808297"}
function sync(){var u=new URLSearchParams();if(S.t!==C.t)u.set("t",S.t);if(S.sort!=="priority")u.set("sort",S.sort);if(S.view!=="board")u.set("view",S.view);
  if(S.vd.size)u.set("verdict",Array.from(S.vd).join(","));if(!S.perhost)u.set("perhost","0");if(S.live)u.set("live","1");
  if(S.q)u.set("q",S.q);if(S.lane!=="clusters")u.set("lane",S.lane);if(!S.hideh)u.set("handled","1");if(S.ph.size)u.set("phase",Array.from(S.ph).join(","));if(S.ty.size)u.set("type",Array.from(S.ty).join(","));
  if(S.crit)u.set("crit","1");if(S.size!==100)u.set("size",S.size);var s=u.toString();try{history.replaceState(null,"",location.pathname+(s?"?"+s:""))}catch(e){}}
// ---- tooltip (the #tip of the (i) help) ----
var tip=null;function showTip(ev,txt){tip=tip||$("#tip");if(!tip)return;tip.textContent=txt;tip.style.display="block";
  var w=tip.offsetWidth,h=tip.offsetHeight,x=Math.min(ev.clientX+14,innerWidth-w-8),y=ev.clientY+14;if(y+h>innerHeight-8)y=ev.clientY-h-10;tip.style.left=x+"px";tip.style.top=y+"px"}
function hideTip(){if(tip)tip.style.display="none"}
// ---- data ----
var timer=null, busy=false, again=false;
function load(){if(busy){again=true;return}busy=true;again=false;fetch("data?t="+encodeURIComponent(S.t),{credentials:"same-origin",headers:passHdr({Accept:"application/json"})})
  .catch(netErr).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json()}).then(function(d){S.data=d;$("#err").innerHTML="";render();
    S.open.forEach(function(k){fetchDetail(k,true)})})
  .catch(function(e){$("#err").innerHTML=readErr(e,"the clusters","Clusters")})
  .then(function(){busy=false;if(again){again=false;load();return}schedule()})}
function schedule(){clearTimeout(timer);var d=S.data,wait=(!d||!d.ready)?5000:($("#auto").checked?C.poll*1000:0);if(wait)timer=setTimeout(load,wait)}
var pending=new Set();
function fetchDetail(k,quiet){if(pending.has(k))return;pending.add(k);fetch("cluster?key="+encodeURIComponent(k)+"&t="+encodeURIComponent(S.t),{credentials:"same-origin",headers:passHdr()})
  .then(function(r){return r.ok?r.json():null},function(){return null}).then(function(d){pending.delete(k);S.details[k]=d||{gone:true};$$('[data-dk="'+cssq(k)+'"]').forEach(function(el){el.innerHTML=detailHtml(k)})})}
function cssq(s){return String(s).replace(/["\\]/g,"\\$&")}
// ---- filters ----
var LIVE_MS=15*60*1000;function isLive(c){return S.data&&(S.data.now*1000-c.end_ms)<LIVE_MS}
function passes(c){if(S.hideh&&c.state&&c.state.handled)return false;if(S.vd.size&&!S.vd.has(c.verdict))return false;if(S.live&&!isLive(c))return false;if(S.ph.size&&!S.ph.has(c.highest_phase||"none"))return false;if(S.ty.size&&!S.ty.has(c.cluster_type))return false;
  if(S.crit&&!c.critical_host)return false;if(!S.q)return true;
  var hay=[c.anchor_ip,c.cluster_type,c.cluster_label,c.highest_phase,c.severity_max,(c.tactics||[]).join(" "),(c.secondary_types||[]).join(" "),c.critical_host?"critical jewel":"",c.lead_alert,(c.top_names||[]).join(" "),c.verdict,(c.state||{}).owner,(c.state||{}).status].join(" ").toLowerCase();
  return S.q.toLowerCase().split(/\s+/).filter(Boolean).every(function(w){return hay.indexOf(w)>=0})}
function sorted(list){var k=SORTKEY[S.sort]||"score";return list.slice().sort(function(a,b){var x=a[k],y=b[k];if(x==null)x=-Infinity;if(y==null)y=-Infinity;
  return y-x||(b.score||0)-(a.score||0)||(b.end_ms-a.end_ms)})}
function visible(){var d=S.data;return d?sorted(d.clusters.filter(passes)):[]}
// ---- render ----
function render(){var d=S.data;if(!d)return;
  $("#tlbl").textContent=C.presets[S.t]||S.t;$("#tspan").textContent=rng((d.now-d.range_s)*1000,d.now*1000);
  $("#asof").innerHTML=d.ready?("as of "+tm(d.built_at*1000,"hm")+(d.poll_ok?"":' <span class="dot fail" title="'+esc(d.poll_msg)+'"></span>')):"reading Sycope…";
  $("#sortlbl").textContent=SORTLBL[S.sort]||S.sort;
  $$(".vchips .chip").forEach(function(b){b.classList.toggle("on",b.dataset.view===S.view)});
  $$(".tchk").forEach(function(c){c.checked=S.ty.has(c.value)});$("#tcount").textContent=S.ty.size?"("+S.ty.size+")":"";$("#critonly").checked=S.crit;
  $("#perhost").checked=S.perhost;$("#liveonly").checked=S.live;$("#hideh").checked=S.hideh;
  laneTabs(d);
  if(!d.ready){$("#view").innerHTML='<div class="loading">'+esc(d.poll_msg||"Reading alerts from Sycope…")+'</div>';tiles(d);return}
  noteSeen(d);var cl=S.lane==="clusters",nh=(d.clusters||[]).filter(function(c){return c.state&&c.state.handled}).length;
  $("#clctl").hidden=!cl;$("#ovw").hidden=!cl;$("#hidehn").textContent=nh?"("+num(nh)+")":"";selBar();
  if(!cl){if(S.lane==="targets")laneTargets(d);else if(S.lane==="external")laneExternal(d);else if(S.lane==="ended")laneEnded(d);else laneHandover();return}
  headline(d);tiles(d);histo(d);chips(d);var v=visible();
  vbar(d);$("#grp").style.display=S.view==="board"?"":"none";
  if(S.view==="timeline")timeline(v,d);else if(S.view==="quadrant")quadrant(v);else if(S.view==="table")table(v);else board(v,d)}
function tiles(d){var cl=d.clusters||[],n=cl.length,red=n?(d.alerts_clustered/n):0;
  var ph=C.phases.map(function(p){return '<span><i class="sq" style="background:'+C.phaseColors[p]+'"></i>'+esc(p)+' <b>'+num((d.phases||{})[p]||0)+'</b></span>'}).join("");
  var t=[["Alerts in range",num(d.alerts_in_range),"from Sycope, "+num(d.alerts_total)+" kept in memory"],
    ["Clusters",num(n),"time-chained per anchor IP, gap ≤ "+dur(d.delta_s)],
    ["Anchor IPs",num(d.anchors||0),"hosts with at least one cluster"],
    ["Alerts in these clusters",num(d.alerts_clustered||0),"whole clusters, also their alerts before the range; an alert in two clusters counts once"],
    ["Alerts per cluster",n?red.toFixed(1):"0","what an analyst no longer reads one by one"]];
  $("#tiles").innerHTML=t.map(function(x){return '<div class="card"><div class="tv">'+x[1]+'</div><div class="tl2">'+esc(x[0])+'</div><div class="tl2" style="font-size:11px">'+esc(x[2])+'</div></div>'}).join("")
    +'<div class="card"><div class="tl2" style="margin:0 0 4px">Clusters by highest phase</div><div class="phs" style="flex-direction:column;gap:4px">'+ph+'</div></div>'}
function nice(top){if(top<=5)return[5,1];var m=Math.pow(10,Math.floor(Math.log10(top))),s=[1,2,2.5,5,10].map(function(f){return f*m}).find(function(x){return top/x<=5});return[Math.ceil(top/s)*s,s]}
function histo(d){var h=d.hist,keys=C.phases.concat(["Other"]),tot=[],mx=0;for(var i=0;i<h.n;i++){var s=0;keys.forEach(function(k){s+=h.series[k][i]});tot.push(s);if(s>mx)mx=s}
  var ax=nice(mx||1),top=ax[0],grid="";for(var g=0;g<=top;g+=ax[1])grid+='<i style="bottom:'+(g/top*100)+'%"><b>'+(g>=1000?(g/1000)+"k":g)+'</b></i>';
  var bars="";for(i=0;i<h.n;i++){var segs="",t0=(h.start+i*h.step)*1000;keys.forEach(function(k){var v=h.series[k][i];if(v)segs+='<span style="display:block;width:100%;height:'+(v/top*100)+'%;background:'+(C.phaseColors[k]||"#808297")+'"></span>'});
    var tt=rng(t0,t0+h.step*1000)+"\n"+num(tot[i])+" alerts"+keys.filter(function(k){return h.series[k][i]}).map(function(k){return "\n"+k+": "+num(h.series[k][i])}).join("");
    bars+='<div data-tip="'+esc(tt)+'">'+segs+'</div>'}
  var xs="",every=Math.max(1,Math.ceil(h.n/8));for(i=0;i<=h.n;i+=every){xs+='<span style="left:'+(i/h.n*100)+'%">'+tm((h.start+i*h.step)*1000,h.step>=3600?"dhm":"hm")+'</span>'}
  $("#hist").innerHTML='<div class="hwrap"><div class="hy"></div><div class="hplot"><div class="g">'+grid+'</div><div class="hbars">'+bars+'</div></div></div><div class="hx">'+xs+'</div>'
    +'<div class="hleg">'+keys.map(function(k){return '<span><i class="sq" style="background:'+(C.phaseColors[k]||"#808297")+'"></i>'+esc(k)+'</span>'}).join("")+'</div>';
  $("#hcap").textContent="one bar = "+dur(h.step);
  $$("#hist .hbars>div").forEach(function(b){b.onmousemove=function(e){showTip(e,b.dataset.tip)};b.onmouseleave=hideTip})}
function chips(d){var cl=d.clusters,cnt={};cl.forEach(function(c){var p=c.highest_phase||"none";cnt[p]=(cnt[p]||0)+1});
  $("#phchips").innerHTML='<button type="button" class="chip phchip'+(S.ph.size?"":" on")+'" data-ph="">All<span class="n">'+num(cl.length)+'</span></button>'
    +C.phases.map(function(p){return '<button type="button" class="chip phchip'+(S.ph.has(p)?" on":"")+'" data-ph="'+esc(p)+'"><i class="sq" style="background:'+C.phaseColors[p]+';margin-right:8px"></i>'+esc(p)+'<span class="n">'+num(cnt[p]||0)+'</span></button>'}).join("")}
// ---- table ----
var COLS=[["sel","","","44px"],
  ["rank","#","rank","44px"],
  ["score","Score","score","110px","The score of the model in use: stage × points × severity multiplier + crown jewel + alert types + kill-chain progression, times the chain bonus. The bar is the priority, 0-100. The card shows every term."],
  ["anchor","Anchor IP","anchor_ip","130px","The host the cluster is built around: it is the client or the server of every alert in it. One alert can be in two clusters, one per IP."],
  ["type","Cluster type","cluster_type","140px","The rule family (CL-01..CL-12, HYG, POL) most of its alerts belong to, from the rule catalog."],
  ["phase","Highest phase","highest_phase","110px","The furthest kill-chain phase among its alerts' MITRE tactics. It dominates the score."],
  ["status","Status","","150px","The analyst's state of the cluster: New, In progress (owner), Escalated, Seen, Closed. Seen and closed clusters come back as New if they rise to a higher verdict."],
  ["mem","Memory","","170px","Whether its rule set was seen on this host on earlier days (New / Recurring Nd) and one cell per day, the last 6 days and today; a hollow cell is a day nothing was kept for. Display only."],
  ["p","P","","44px","Ticket priority P1-P4 from the verdict, a crown jewel and the chain rules matched. Hover the tag for why."],
  ["acts","","","200px"],
  ["chain","Chain","","246px","Chain rules matched on this host: the score multiplier that was applied and one chip per matched rule (the filled chip set the multiplier). Hover a chip for the rule and how many clusters hold its steps."],
  ["sev","Max severity","severity_max","104px"],
  ["alerts","Alerts","alert_count","80px"],
  ["types","Types","n_alert_types","64px","Distinct alert names."],
  ["tac","Tactics","n_tactics","68px"],
  ["imp","Impact","impact_score","72px","0-100: mean severity + tactic weight + recency (Threat × Certainty quadrant, y)."],
  ["cer","Certainty","certainty_score","84px","0-100: detection confidence + volume + tactic diversity (quadrant, x)."],
  ["first","First alert","start_ms","124px"],
  ["last","Last alert","end_ms","124px"],
  ["dur","Duration","duration_s","110px"]];
function cell(k,c){switch(k){
  case "sel":return editing()?'<input type="checkbox" class="selx" data-sel="'+esc(c.key)+'"'+(S.sel.has(c.key)?" checked":"")+' aria-label="Select" title="Tick several to act on them together (Action ▾)">':"";
  case "status":return stPill(c.state,c.verdict);case "mem":return memBadge(c.memory)+heatStrip(c.memory);case "p":return priTag(c.p);case "chain":return chainCell(c);
  case "acts":return '<span class="btns">'+quick(c.key,c.state,true)+KB+'</span>';
  case "rank":return '<span class="caret"></span><span class="mono" style="margin-left:8px">'+c.rank+'</span>';
  case "score":return '<span class="sc"><b>'+num(c.score)+'</b><i><u style="width:'+Math.max(2,c.priority||0)+'%;background:'+(C.phaseColors[c.highest_phase]||"#808297")+'"></u></i></span>';
  case "anchor":return '<span class="mono ell">'+esc(c.anchor_ip)+'</span>'+(c.critical_host?'<span class="crown" title="critical host">&#9733;</span>':"");
  case "type":return '<span class="tdot" style="background:'+tcol(c.cluster_type)+'"></span><span class="ell">'+esc(c.cluster_type)+' '+esc(c.cluster_label)+'</span>';
  case "phase":return phb(c.highest_phase);case "sev":return sevb(c.severity_max);
  case "alerts":return num(c.alert_count);case "types":return num(c.n_alert_types);case "tac":return num(c.n_tactics);
  case "imp":return num(c.impact_score,1);case "cer":return num(c.certainty_score,1);
  case "first":return tm(c.start_ms,"dhm");case "last":return tm(c.end_ms,"dhm");case "dur":return dur(c.duration_s)}}
// the main list is paged; the folded chronic list is its own (the same on every page, up to 100 rows)
function table(v){var main=v.filter(function(c){return !isChronic(c)}),chron=v.filter(isChronic),total=main.length,nchron=chron.length,pages=Math.max(1,Math.ceil(total/S.size));if(S.page>pages)S.page=pages;var rows=main.slice((S.page-1)*S.size,S.page*S.size);
  var cols=COLS.map(function(c){return c[3]}).join(" "),minw=COLS.reduce(function(a,c){return a+parseInt(c[3])},0)+"px";
  var head=COLS.map(function(c){var on=SORTKEY[S.sort]===c[2];return '<span data-col="'+c[0]+'"><span class="hl">'+esc(c[1])+(c[4]?' <span class="info" tabindex="0" data-tip="'+esc(c[4])+'">i</span>':"")+(on?' <span class="arr">&#9660;</span>':"")+'</span><span class="fld">'+esc(c[2])+'</span></span>'}).join("");
  var row=function(c){var o=S.open.has(c.key);return '<details class="job'+((c.state||{}).handled?" handled":"")+'" data-k="'+esc(c.key)+'"'+(o?" open":"")+'><summary>'+COLS.map(function(k){return '<span'+(k[0]==="sel"?' class="c-sel"':k[0]==="chain"?' class="c-chain"':k[0]==="status"?' class="c-status"':"")+'>'+cell(k[0],c)+'</span>'}).join("")+'</summary><div class="more" data-dk="'+esc(c.key)+'">'+(o?detailHtml(c.key):"")+'</div></details>'};
  var chrows=chron.slice(0,100);
  var body=rows.map(row).join("")+(chrows.length?'<details class="chron" id="chron"'+(chronOpen()?" open":"")+'><summary><span class="caret"></span>Chronic ('+num(nchron)+')'+CHRONW+'</summary>'+chrows.map(row).join("")+(nchron>chrows.length?'<div class="mut" style="padding:8px 12px">'+num(chrows.length)+' of '+num(nchron)+' shown</div>':"")+'</details>':"")
    ||'<div class="empty">No cluster matches. '+(S.data.clusters.length?"Clear a filter or widen the time range.":"Not enough alerts in this range yet (a cluster needs 2 alerts of one IP).")+'</div>';
  var sizes=[50,100,200,500].map(function(n){return '<a href="#" data-size="'+n+'"'+(n===S.size?' class="on"':"")+'>'+n+'</a>'}).join("");
  var pl="";if(pages>1){pl+=S.page>1?'<a href="#" data-page="'+(S.page-1)+'">&lsaquo;</a>':'<span class="dim">&lsaquo;</span>';
    var a=Math.max(1,S.page-3),b=Math.min(pages,a+6);for(var i=a;i<=b;i++)pl+='<a href="#" data-page="'+i+'"'+(i===S.page?' class="on"':"")+'>'+i+'</a>';
    pl+=S.page<pages?'<a href="#" data-page="'+(S.page+1)+'">&rsaquo;</a>':'<span class="dim">&rsaquo;</span>'}
  $("#view").innerHTML='<div class="card" style="padding:0 0 10px"><div class="jobs" style="--cols:'+cols+';--minw:'+minw+'"><div class="jhead">'+head+'</div>'+body+'</div>'
    +'<div class="pbar" style="padding:10px 12px 0"><span class="sizes">Rows per page '+sizes+'</span><span class="pages">'+pl+'</span><span class="recs">'+num(total)+(nchron?" + "+num(nchron)+" chronic":"")+' of '+num(S.data.clusters.length)+' clusters</span></div></div>';
  bindTable();chronBind()}
function bindTable(){$$("#view .job").forEach(function(j){j.addEventListener("toggle",function(){var k=j.dataset.k;if(j.open){S.open.add(k);if(!S.details[k])fetchDetail(k);j.querySelector(".more").innerHTML=detailHtml(k)}else S.open.delete(k)})});
  bindIp()
  $$("#view .jhead>span").forEach(function(h){var c=COLS.find(function(x){return x[0]===h.dataset.col});var key=Object.keys(SORTKEY).find(function(s){return SORTKEY[s]===c[2]});if(key){h.style.cursor="pointer";h.onclick=function(e){if(e.target.classList.contains("info"))return;S.sort=key;S.page=1;sync();render()}}});
  $$("#view .info").forEach(function(i){i.onmouseenter=function(e){showTip(e,i.dataset.tip)};i.onmouseleave=hideTip});
  $$("#view [data-size]").forEach(function(a){a.onclick=function(e){e.preventDefault();S.size=+a.dataset.size;S.page=1;sync();render()}});
  $$("#view [data-page]").forEach(function(a){a.onclick=function(e){e.preventDefault();S.page=+a.dataset.page;render();$("#view").scrollIntoView()}});
}
function bindIp(){$("#view").onclick=function(e){var b=e.target.closest("[data-ip]");if(b){S.q=b.dataset.ip;$("#q").value=S.q;S.page=1;S.limit=50;sync();render();return}
  var cp=e.target.closest(".cp");if(cp){e.stopPropagation();copy(cp.textContent,cp);return}
  var o=e.target.closest("[data-pick]");if(o){var card=o.closest(".bc"),k=o.dataset.pick;S.pick[card.dataset.host]=k;S.open.add(k);if(!S.details[k])fetchDetail(k);
    var m=card.querySelector(".bc-more");m.dataset.dk=k;m.innerHTML=othersHtml(card.dataset.host,k)+'<div data-dk="'+esc(k)+'">'+detailHtml(k)+'</div>';return}
  var h=e.target.closest(".bc-main");if(h){var c=h.closest(".bc"),k=c.dataset.k,m=c.querySelector(".bc-more"),open=m.hidden;m.hidden=!open;c.classList.toggle("open",open);
    if(open){S.open.add(k);if(!S.details[k])fetchDetail(k);m.innerHTML=othersHtml(c.dataset.host,k)+'<div data-dk="'+esc(k)+'">'+detailHtml(k)+'</div>'}else S.open.delete(k)}}}
function copy(t,el){var done=function(){var o=el.textContent;el.textContent="copied";setTimeout(function(){el.textContent=o},900)};
  if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(done);else{var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(x){}a.remove()}}
var PH_IDX={"Recon":0,"Foothold":1,"Lateral":2,"Objectives":3};
function whyHtml(D){var c=D.cluster,t=D.types||[];if(!t.length)return "";
  var top=t.slice().sort(function(a,b){return (PH_IDX[b.phase]??-1)-(PH_IDX[a.phase]??-1)||(b.weight-a.weight)||(b.count-a.count)})[0];
  var sev=t.slice().sort(function(a,b){return (b.weight-a.weight)||(b.count-a.count)})[0],v=V(c.verdict);
  var src=(D.roles.client||0)>=(D.roles.server||0);
  var s1=top.phase?'It reached <b>'+esc(top.phase)+'</b> because of <b>'+esc(top.name)+'</b> ('+(top.tactic?esc(top.tactic)+', ':'')+esc(top.severity)+', '+num(top.count)+'×)':'Its alerts have no MITRE stage';
  if(SIMPLE)return '<div class="why" style="--vc:'+v.color+'">'+ic(c.verdict,20)+'<div><b>'+esc(v.label)+'.</b> '+s1+'.'+ii("The score, its terms and every alert are in All details.")+'</div></div>';
  var sc=D.score||{},s2;
  if(sc.strict)s2='; strict stages: it stays in the '+esc(top.phase||"first")+' band, its severity only orders it inside.';
  else if(sc.severity_source==="stage")s2='; the stage is scaled by that alert\'s own severity.';
  else s2=sev.name!==top.name?'; the severity that scales the stage, <b>'+esc(c.severity_max)+'</b>, comes from <b>'+esc(sev.name)+'</b> ('+esc(sev.phase||"no stage")+'), another alert.':', which is also its most severe alert.';
  var s3=' The host is the <b>'+(src?"source":"target")+'</b> of '+num(src?D.roles.client:D.roles.server)+' of '+num(c.alert_count)+' alerts'+(c.critical_host?' and is a <b>crown jewel</b> (+6000)':'')+'.';
  return '<div class="why" style="--vc:'+v.color+'">'+ic(c.verdict,20)+'<div><b>Priority '+num(c.priority)+' · '+esc(v.label)+'.</b> '+s1+s2+s3+'</div></div>'}
function kv(l,v){return '<div><span class="mut">'+esc(l)+'</span>'+v+'</div>'}
function detailHtml(k){var D=S.details[k];if(!D)return '<div class="mut">Loading…</div>';if(D.gone)return '<div class="mut">'+(k.slice(0,2)==="ct"?"This entry is no longer in Under attack.":"This cluster is no longer on the board (its alerts left the retention window, or it merged into an older one).")+' Refresh the page.</div>';
  if(D.kind==="target")return targetHtml(k,D);
  if(SIMPLE)return whyHtml(D)+workHtml(k,D)+'<div class="alld"><button type="button" class="b2" data-alld="1" title="Switch to the Full view: every table, number and filter">All details</button></div>';
  var c=D.cluster,s=D.score,sum=function(t){return t.reduce(function(a,x){return a+x.value},0)};
  var terms=function(list,total,name){return '<table class="terms"><tr><th>Term</th><th>Expression</th><th>Value</th></tr>'+list.map(function(t){return '<tr><td>'+esc(t.term)+'</td><td class="mono">'+esc(t.expr)+'</td><td>'+num(t.value,1)+'</td></tr>'}).join("")
    +(s.chain_bonus!==1?'<tr><td>chain bonus</td><td class="mono">× '+esc(s.chain_bonus)+'</td><td></td></tr>':"")+'<tr class="tot"><td>'+esc(name)+'</td><td class="mono">'+(s.chain_bonus!==1?"(Σ) × "+esc(s.chain_bonus):"Σ")+'</td><td>'+num(total,1)+'</td></tr></table>'};
  var sevd=["critical","high","medium","low","info"].map(function(x){return c["sev_"+x]?'<span class="badge b-'+x+'" style="margin-right:4px">'+x+" "+num(c["sev_"+x])+'</span>':""}).join("");
  var roles=Object.keys(D.roles||{}).map(function(r){return r+" in "+num(D.roles[r])}).join(", ");
  var burst=c.burstiness==null?nul():num(c.burstiness,2)+' <span class="mut">'+(c.burstiness>0.3?"bursts (exploit-like)":c.burstiness<-0.3?"even rhythm (beacon-like)":"mixed")+'</span>';
  var prog=c.killchain_progression_score==null?nul()+' <span class="mut">one phase only</span>':num(c.killchain_progression_score,3)+' <span class="mut">'+(c.killchain_progression_score>=0.8?"moves forward":c.killchain_progression_score<0.5?"goes backwards":"mixed order")+'</span>';
  var M=s.model,bonus=M.chain_bonus||1,chs=(D.chains||[]).map(function(x){return x.id+" "+x.title}).join(", ");
  var mt=function(){var raw=M.raw_priority,clamp=raw!==M.priority;
    return '<table class="terms"><tr><th>Term</th><th>Expression</th><th>Value</th></tr>'+M.rows.map(function(t){return '<tr><td>'+esc(t.term)+'</td><td class="mono">'+esc(t.expr)+'</td><td>'+num(t.value,1)+'</td></tr>'}).join("")
    +(bonus!==1?'<tr><td>chain bonus</td><td class="mono">'+num(M.subtotal,1)+' × '+esc(bonus)+(chs?' ('+esc(chs)+')':'')+'</td><td>'+num(M.score,1)+'</td></tr>':"")
    +'<tr class="tot"><td>score → priority</td><td class="mono">'+num(M.score,1)+' / '+num(s.full)+' × 100</td><td>'+num(raw)+'</td></tr>'
    +(clamp?'<tr><td>capped at '+(raw>M.priority?"100":"0")+'</td><td class="mono">'+num(raw)+' → '+num(M.priority)+'</td><td>'+num(M.priority)+'</td></tr>':"")+'</table>'};
  var R=s.ref;
  var refh=R?'<details class="desc" style="margin-top:8px"><summary>Reference model A = '+num(R.ref_a_total,1)+'</summary>'+terms(R.ref_a,R.ref_a_total,"reference A")+'</details>'
    +'<details class="desc" style="margin-top:6px"><summary>Reference model B = '+num(R.ref_b_total,1)+'</summary>'+terms(R.ref_b,R.ref_b_total,"reference B")+'</details>'
    +'<p class="mut" style="font-size:12px;margin:8px 0 0">Blend (both scaled 0-100 over all clusters in memory, averaged): <b>'+num(c.blend_score,1)+'</b> · A 0-100: '+num(c.ref_a_norm,1)+' · B 0-100: '+num(c.ref_b_norm,1)+'</p>':"";
  var h=whyHtml(D)+workHtml(k,D)+actions(c)+'<div class="cols2"><div><h3>Score'+(R?': '+esc(s.model_label)+' <a href="scoring" style="text-transform:none;letter-spacing:0;margin-left:6px">change the model</a>':'')+'</h3>'+mt()+refh+'</div>'
    +'<div><h3>Cluster</h3><div class="kv" style="grid-template-columns:repeat(2,minmax(0,1fr))">'
    +kv("Anchor IP",'<code>'+esc(c.anchor_ip)+'</code>'+(c.critical_host?' <span class="crown">&#9733; critical host</span>':"")+'<span class="mut">'+esc(roles)+'</span>')
    +kv("Type",'<span class="tdot" style="background:'+tcol(c.cluster_type)+'"></span>'+esc(c.cluster_type)+" "+esc(c.cluster_label)+((c.secondary_types||[]).length?'<span class="mut">also '+esc(c.secondary_types.join(", "))+'</span>':""))
    +kv("Window",rng(c.start_ms,c.end_ms)+'<span class="mut">'+dur(c.duration_s)+', id '+esc(c.cluster_id)+'</span>')
    +kv("Alerts",num(c.alert_count)+' <span class="mut">'+num(c.n_alert_types)+' types, peak '+num(c.alerts_per_minute_peak)+'/min</span>')
    +kv("Severity",sevd||nul())+kv("Tactics",esc((c.tactics||[]).join(", "))+' <span class="mut">'+num(c.n_techniques)+' techniques</span>')
    +kv("Kill-chain progression",prog)+kv("Burstiness",burst)
    +kv("Mean gap",dur(c.mean_gap_s)+' <span class="mut">max '+dur(c.max_gap_s)+'</span>')+kv("Type entropy",num(c.alert_type_entropy,2)+' <span class="mut">bits</span>')
    +kv("Impact × Certainty",num(c.impact_score,1)+" × "+num(c.certainty_score,1))+'</div></div></div>';
  h+='<h3>Alert types</h3><div class="grid"><table><tr><th>Alert</th><th>Cluster type</th><th>ATT&amp;CK</th><th>Phase</th><th>Template tag</th><th>Max severity</th><th>Alerts</th><th>First</th><th>Last</th></tr>'
    +D.types.map(function(t){return '<tr><td>'+esc(t.name)+'</td><td><span class="tdot" style="background:'+tcol(t.cluster_type)+'"></span>'+esc(t.cluster_type)+'</td><td>'+esc(t.attack||"")+'</td><td>'+phb(t.phase)+'</td><td class="mut">'+esc(t.tpl_tag||"")+'</td><td>'+sevb(t.severity)+'</td><td>'+num(t.count)+'</td><td>'+tm(t.first_ms,"dhm")+'</td><td>'+tm(t.last_ms,"dhm")+'</td></tr>'}).join("")+'</table></div>';
  if(D.related.length)h+='<h3>Related IPs (click to search)</h3><div class="ipch">'+D.related.map(function(r){return '<button type="button" data-ip="'+esc(r.ip)+'">'+esc(r.ip)+'<em>'+num(r.count)+'</em></button>'}).join("")+'</div>';
  if((D.buckets||[]).length)h+='<h3>Findings ('+num(D.buckets.length)+')</h3><div class="grid" style="max-height:300px;overflow:auto"><table><tr><th>Rule</th><th>Counterpart</th><th>Port</th><th>Alerts</th><th>First</th><th>Last</th></tr>'
    +D.buckets.map(function(b){return '<tr><td>'+rn(b.rule)+'</td><td class="mono">'+(b.counterpart?esc(b.counterpart):nul())+'</td><td>'+(b.port==null?nul():esc(b.port))+'</td><td>'+num(b.n)+'</td><td>'+tm(b.first,"dhm")+'</td><td>'+tm(b.last,"dhm")+'</td></tr>'}).join("")+'</table></div>';
  if(D.alerts.length)h+='<h3>Newest alerts of this host ('+num(D.alerts_shown)+' of '+num(D.alerts_total)+' in the cluster)</h3><div class="grid" style="max-height:340px;overflow:auto"><table><tr><th>Time</th><th>Alert</th><th>Severity</th><th>ATT&amp;CK</th><th>Template tag</th><th>Client IP</th><th>Server IP</th><th>Port</th>'+(C.rawdata?'<th>Flows</th>':'')+(D.recorder&&D.recorder.on?'<th>PCAP</th>':'')+'</tr>'
    +D.alerts.map(function(a){var me=function(ip){return ip===c.anchor_ip?'<b>'+esc(ip)+'</b>':ip?esc(ip):nul()};return '<tr><td>'+tm(a.t)+'</td><td>'+rn(a.name)+'</td><td>'+sevb(a.severity)+'</td><td>'+esc(a.attack||"")+'</td><td class="mut">'+esc(a.tpl_tag||"")+'</td><td class="mono">'+me(a.client)+'</td><td class="mono">'+me(a.server)+'</td><td>'+(a.port==null?nul():esc(a.port))+'</td>'
      +(C.rawdata?'<td>'+flowLink(a)+'</td>':'')+(D.recorder&&D.recorder.on?'<td>'+pcapCell(a,D)+'</td>':'')+'</tr>'}).join("")+'</table></div>';
  return h}
// ---- pivots: Sycope Raw Data and the recorder's PCAP ----
var IPRE=/^[0-9A-Fa-f:.]{2,45}$/;
function isoOff(ms){var d=new Date(ms),o=-d.getTimezoneOffset(),sg=o>=0?"+":"-";o=Math.abs(o);
  return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())+"T"+p2(d.getHours())+":"+p2(d.getMinutes())+":"+p2(d.getSeconds())+sg+p2(Math.floor(o/60))+":"+p2(o%60)}
function rawUrl(nql,from,to){var gq={query:{source:"netflow",nql:nql,advanced:false},timerange:{from:isoOff(from),to:isoOff(to),roundTo:"minute"}};
  return C.sycopeUi+"/panel/raw-data/list?source=netflow&gq="+encodeURIComponent(JSON.stringify(gq))+"&direction=-1&groupType=all"}
function flowLink(a){var t=[];if(a.client&&IPRE.test(a.client))t.push('clientIp = "'+a.client+'"');if(a.server&&IPRE.test(a.server))t.push('serverIp = "'+a.server+'"');
  if(a.port!=null&&/^\d{1,5}$/.test(String(a.port)))t.push("serverPort = "+a.port);if(!t.length)return nul();
  return '<a href="'+esc(rawUrl(t.join(" and "),a.t-5*60000,a.t+60000))+'" target="_blank" rel="noopener">flows ↗</a>'}
function actions(c){var b=[];if(C.rawdata&&IPRE.test(c.anchor_ip))b.push('<a class="bact" target="_blank" rel="noopener" href="'+esc(rawUrl('clientIp = "'+c.anchor_ip+'" or serverIp = "'+c.anchor_ip+'"',c.start_ms-5*60000,c.end_ms+60000))+'">'+ic("layers",16)+'&nbsp;Show all flows of this host in Sycope ↗</a>');
  b.push('<button type="button" class="bact" style="background:var(--panel2)" data-ip="'+esc(c.anchor_ip)+'">Search this IP</button>');
  return '<div class="acts">'+b.join("")+'</div>'}
var PCAPREQ={};
function pcapCell(a,D){var j=(D.pcap||{})[a.id];if(j){var st=j.state||"?",cls=st==="done"?"b-done":st==="miss"?"b-miss":st==="failed"?"b-failed":"b-queued";
    return '<a href="'+esc(C.recorderUrl+"/"+encodeURIComponent(a.id))+'" target="_blank" rel="noopener"><span class="badge '+cls+'">'+esc(st)+'</span></a>'}
  if(PCAPREQ[a.id])return '<span class="mut">'+esc(PCAPREQ[a.id])+'</span>';
  return D.recorder.request?'<button type="button" class="lnk" data-pcap="'+esc(a.id)+'">Get PCAP</button>':'<span class="null">none</span>'}
function reqPcap(id,key){PCAPREQ[id]="asking Sycope…";$$('[data-dk="'+cssq(key)+'"]').forEach(function(el){el.innerHTML=detailHtml(key)});
  fetch("pcap-request",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-SC-Action":"1"},body:JSON.stringify({id:id})})
  .then(function(r){return r.json().then(function(j){return [r.ok,j]})}).then(function(x){PCAPREQ[id]=x[0]?"sent to the recorder":"refused: "+(x[1].error||"?");
    setTimeout(function(){delete S.details[key];fetchDetail(key)},x[0]?4000:0);$$('[data-dk="'+cssq(key)+'"]').forEach(function(el){el.innerHTML=detailHtml(key)})})
  .catch(function(e){PCAPREQ[id]="failed: "+e.message})}
// ---- new hosts and notifications (per browser) ----
var SEEN=null,FIRST=false,PREV_ACT=null;
try{var raw=localStorage.getItem("sc-seen");if(raw)SEEN=new Set(JSON.parse(raw));else{SEEN=new Set();FIRST=true}}catch(x){SEEN=new Set();FIRST=true}
function noteSeen(d){var hosts=new Set((d.clusters||[]).filter(function(c){return c.verdict==="act"||c.verdict==="investigate"}).map(function(c){return c.anchor_ip}));
  var act=new Set((d.clusters||[]).filter(function(c){return c.verdict==="act"}).map(function(c){return c.anchor_ip}));
  if(PREV_ACT){var fresh=Array.from(act).filter(function(ip){return !PREV_ACT.has(ip)});if(fresh.length)notify(fresh)}PREV_ACT=act;
  S.newHosts=FIRST?new Set():new Set(Array.from(hosts).filter(function(ip){return !SEEN.has(ip)}));
  hosts.forEach(function(ip){SEEN.add(ip)});try{localStorage.setItem("sc-seen",JSON.stringify(Array.from(SEEN).slice(-5000)))}catch(x){}}
function notifyOn(){try{return localStorage.getItem("sc-notify")==="1"&&window.Notification&&Notification.permission==="granted"}catch(x){return false}}
function beep(){try{var a=new (window.AudioContext||window.webkitAudioContext)(),o=a.createOscillator(),g=a.createGain();o.frequency.value=880;g.gain.value=.08;o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+.25)}catch(x){}}
function notify(ips){if(!notifyOn())return;beep();try{new Notification("Sycope clusters: "+ips.length+" new Act now host"+(ips.length>1?"s":""),{body:ips.slice(0,5).join(", ")+(ips.length>5?" …":""),tag:"sc-act"})}catch(x){}}
function bellBtn(){var b=$("#bell");if(!b)return;var on=notifyOn();b.classList.toggle("on",on);b.title=on?"Notifications on: a new Act now host plays a sound and shows a notification. Click to turn off.":"Notify me when a new host becomes Act now";
  b.onclick=function(){if(notifyOn()){try{localStorage.setItem("sc-notify","0")}catch(x){}bellBtn();return}
    if(!window.Notification){alert("This browser has no notifications.");return}Notification.requestPermission().then(function(p){try{localStorage.setItem("sc-notify",p==="granted"?"1":"0")}catch(x){}bellBtn();if(p==="granted")beep()})}}
// ---- headline: the noise the board removed ----
// what the board shows: handled clusters are left out while "hide handled" is on, and say so
function counts(d){var all=d.clusters||[],cl=all.filter(function(c){return !(S.hideh&&c.state&&c.state.handled)}),v={},h={},best={};
  cl.forEach(function(c){v[c.verdict]=(v[c.verdict]||0)+1;var b=best[c.anchor_ip];if(!b||(c.score||0)>(b.score||0))best[c.anchor_ip]=c});
  Object.keys(best).forEach(function(ip){var k=best[ip].verdict;h[k]=(h[k]||0)+1});
  return {clusters:cl.length,hosts:Object.keys(best).length,v:v,h:h,handled:all.length-cl.length}}
function headline(d){var K=counts(d),n=K.clusters,hosts=K.hosts,act=K.h.act||0,step=function(v,l,t){return '<span'+(t?' title="'+esc(t)+'"':"")+'><b>'+v+'</b> '+l+'</span>'};
  $("#headline").innerHTML=step(num(d.alerts_in_range),"alerts in "+esc((C.presets[S.t]||S.t).replace("Last ","the last ")))+'<i>→</i>'+step(num(n),"clusters","Time-chained clusters of alerts. One host can have several")+'<i>→</i>'+step(num(hosts),"hosts with a cluster","Distinct hosts across those clusters, each counted once at the verdict of its best cluster")+'<i>→</i>'
    +'<span class="hl-act"><b>'+num(act)+'</b> hosts to act on now</span>'+(K.handled?'<span class="mut hl-r" title="Seen and closed clusters are hidden: untick hide handled to see them">+'+num(K.handled)+' handled</span>':"")+(d.lean?'<span class="mut hl-r">Clusters: hygiene findings left out (memory)</span>':"")+(d.alerts_in_range?'<span class="mut hl-r">'+(d.alerts_in_range/Math.max(1,act||hosts)).toFixed(0)+' alerts per host that needs action</span>':"")}
function sparkSvg(arr){if(!arr||arr.filter(function(v){return v>0}).length<3)return "";var mx=Math.max.apply(null,arr)||1,n=arr.length,W=n*10,h=24,out='<line x1="0" y1="23.5" x2="'+W+'" y2="23.5"/>';
  arr.forEach(function(v,i){if(!v)return;var bh=Math.max(2,v/mx*(h-3));out+='<rect x="'+(i*10+1.5)+'" y="'+(h-1-bh).toFixed(1)+'" width="7" height="'+bh.toFixed(1)+'"/>'});
  return '<svg class="spk" width="100%" height="'+h+'" viewBox="0 0 '+W+' '+h+'" preserveAspectRatio="none" aria-hidden="true">'+out+'</svg>'}
// ---- verdict bar + Threat Board (the default view: one card per host, plain words) ----
function ic(name,px){return '<svg class="ic" width="'+px+'" height="'+px+'" viewBox="0 0 24 24" aria-hidden="true">'+(C.icons[name]||"")+'</svg>'}
function V(k){return C.verdicts.find(function(v){return v.key===k})||C.verdicts[C.verdicts.length-1]}
function vhelp(d,k){var b=(d.model||{}).bands||{},t=k==="act"?"Priority "+b.act+" or more (of 100). ":k==="investigate"?"Priority "+b.investigate+" to "+b.act+". ":k==="review"?"Priority "+b.review+" to "+b.investigate+". ":"Priority below "+b.review+", or no kill-chain phase. ";return t+V(k).help}
function bound(d,k){var b=(d.model||{}).bands||{};return k==="act"?"≥ "+b.act:k==="investigate"?"≥ "+b.investigate:k==="review"?"≥ "+b.review:"< "+b.review}
function vbar(d){var K=counts(d),cnt=S.perhost?K.h:K.v;
  $("#vbar").innerHTML=C.verdicts.map(function(v){return '<button type="button" class="vt'+(S.vd.has(v.key)?" on":"")+'" data-vd="'+v.key+'" style="--vc:'+v.color+'">'+ic(v.key,34)
    +'<span><b>'+num(cnt[v.key]||0)+'</b><span class="vl">'+esc(v.label)+' <span class="mut" style="font-size:12px">'+(S.perhost?"hosts":"clusters")+', priority '+bound(d,v.key)+'</span></span><span class="vh2">'+esc(SIMPLE?v.help:vhelp(d,v.key))+'</span></span></button>'}).join("")}
function groups(v){if(!S.perhost)return v.map(function(c){return {c:c,all:[c]}});var m=new Map();v.forEach(function(c){var g=m.get(c.anchor_ip);if(g)g.all.push(c);else m.set(c.anchor_ip,{c:c,all:[c]})});return Array.from(m.values())}
var HOSTS={};
function kchain(c){var seen=new Set(c.phases_seen||[]),names=["Recon","Foothold","Lateral","Objectives"];
  return '<div><div class="kc">'+names.map(function(p){var on=seen.has(p);return '<span class="'+(on?"on":"")+(p===c.highest_phase?" hi":"")+'"><i style="'+(on?"background:"+C.phaseColors[p]:"")+'"></i>'+p+'</span>'}).join("")+'</div>'
    +'<div class="kcap">'+(c.killchain_progression_score==null?"one stage only":c.killchain_progression_score>=0.8?"moves forward through the stages":c.killchain_progression_score<0.5?"stages out of order":"stages partly in order")+'</div></div>'}
function hostTags(ip){var h=(S.data.hosts||{})[ip];if(!h)return "";return (h.name?'<span class="hn">'+esc(h.name)+'</span>':"")+(h.loc?'<span class="pill">'+esc(h.loc)+'</span>':"")+(h.fn?'<span class="pill">'+esc(h.fn)+'</span>':"")}
// Simple: verdict, host, what it did, when it last alerted; no scores, chips, strips or work row
function cardSimple(g){var c=g.c,v=V(c.verdict),h=(S.data.hosts||{})[c.anchor_ip]||{};
  var what=esc(c.cluster_label||c.cluster_type)+' <em>reached</em> <b style="color:'+(C.phaseColors[c.highest_phase]||"#fff")+'">'+esc(c.highest_phase||"no stage")+'</b>'+(c.lead_alert?' <em>with</em> <q>'+esc(c.lead_alert)+'</q>':"");
  return '<div class="bc v-'+esc(c.verdict)+(S.open.has(c.key)?" open":"")+((c.state||{}).handled?" handled":"")+'" style="--vc:'+v.color+'" data-k="'+esc(c.key)+'" data-host="'+esc(c.anchor_ip)+'"><div class="bc-main" title="Click for the details">'
    +'<div class="bc-sc"><span class="vp '+esc(c.verdict)+'" style="--vc:'+v.color+'">'+esc(v.label)+'</span></div>'
    +'<div style="min-width:0"><div class="bc-ip"><span class="cp" title="Copy">'+esc(c.anchor_ip)+'</span>'+(c.critical_host?'<span class="pill jw">'+ic("jewel",13)+'crown jewel</span>':"")+(h.name?'<span class="hn">'+esc(h.name)+'</span>':"")+'</div>'
    +'<div class="bc-what">'+what+'</div><div class="bc-sub">last alert '+at(c.end_ms)+'</div></div><span class="caret"></span></div>'
    +'<div class="bc-more"'+(S.open.has(c.key)?"":" hidden")+'>'+(S.open.has(c.key)?'<div data-dk="'+esc(c.key)+'">'+detailHtml(c.key)+'</div>':"")+'</div></div>'}
function card(g){if(SIMPLE)return cardSimple(g);var c=g.c,v=V(c.verdict),src=(c.as_client||0)>=(c.as_server||0),n=g.all.length,alerts=g.all.reduce(function(a,x){return a+x.alert_count},0);
  var role=src?'<span class="pill src" title="This host is the client in '+num(c.as_client)+' of '+num(c.alert_count)+' alerts: it is the one acting">'+ic("source",13)+'source</span>'
    :'<span class="pill tgt" title="This host is the server in '+num(c.as_server)+' of '+num(c.alert_count)+' alerts: it is being targeted">'+ic("target",13)+'target</span>';
  var what=esc(c.cluster_label||c.cluster_type)+' <em>reached</em> <b style="color:'+(C.phaseColors[c.highest_phase]||"#fff")+'">'+esc(c.highest_phase||"no stage")+'</b>'+(c.lead_alert?' <em>with</em> <q>'+esc(c.lead_alert)+'</q>':"");
  var spk=sparkSvg((S.data.spark||{})[c.anchor_ip]);
  var sub=(c.top_names||[]).map(function(x,i){return esc(x)+" ×"+num((c.top_counts||[])[i])}).join(" · ");
  return '<div class="bc v-'+esc(c.verdict)+(S.open.has(c.key)?" open":"")+((c.state||{}).handled?" handled":"")+'" style="--vc:'+v.color+'" data-k="'+esc(c.key)+'" data-host="'+esc(c.anchor_ip)+'"><div class="bc-main" title="Click for the details">'
    +'<div class="bc-sc" title="Priority = score '+num(c.score)+' / '+num((S.data.model||{}).full||40000)+' × 100 ('+esc((S.data.model||{}).label||"")+')"><b>'+num(c.priority)+'</b><span>'+esc(v.label)+'</span></div>'
    +'<div style="min-width:0"><div class="bc-ip"><span class="cp" title="Copy">'+esc(c.anchor_ip)+'</span>'+role+(c.critical_host?'<span class="pill jw">'+ic("jewel",13)+'crown jewel</span>':"")+(isLive(c)?'<span class="pill live"><i></i>active</span>':"")+(S.newHosts&&S.newHosts.has(c.anchor_ip)?'<span class="pill new">new</span>':"")+hostTags(c.anchor_ip)+'</div>'
    +'<div class="bc-what">'+what+'</div><div class="bc-sub">'+sub+'</div></div>'
    +'<div>'+kchain(c)+(spk?'<div class="spkw" title="Alerts of this host in the range ('+esc(C.presets[S.t]||S.t)+')">'+spk+'</div>':"")+'</div>'
    +'<div class="bc-m"><div><b>'+ic("bell",15)+num(S.perhost?alerts:c.alert_count)+'</b><span>alerts</span></div><div><b>'+ic("clock",15)+at(c.end_ms)+'</b><span>last alert</span></div><div><b>'+dur(c.duration_s)+'</b><span>lasting</span></div></div>'
    +'<span class="caret"></span></div>'+workRow(c,true)+'<div class="bc-more"'+(S.open.has(c.key)?"":" hidden")+'>'+(S.open.has(c.key)?othersHtml(c.anchor_ip,c.key)+'<div data-dk="'+esc(c.key)+'">'+detailHtml(c.key)+'</div>':"")+'</div></div>'}
function othersHtml(ip,cur){var all=HOSTS[ip]||[];if(SIMPLE||all.length<2)return "";return '<div class="oth"><span class="mut" style="align-self:center;font-size:12px">Clusters of this host:</span>'+all.map(function(x){return '<button type="button" data-pick="'+esc(x.key)+'"'+(x.key===cur?' class="on"':"")+'><i class="sq" style="background:'+V(x.verdict).color+'"></i>'+num(x.priority)+' · '+esc(x.cluster_type)+' · '+rng(x.start_ms,x.end_ms)+' · '+num(x.alert_count)+' alerts</button>'}).join("")+'</div>'}
function chronOpen(){try{return localStorage.getItem("sc-cl-chronic")==="1"}catch(x){return false}}
function chronBind(){var c=$("#chron");if(c)c.addEventListener("toggle",function(){try{localStorage.setItem("sc-cl-chronic",c.open?"1":"0")}catch(x){}})}
var CHRONW='<span class="mut"> same rules on 3 or more of the last 6 days · out of the main list, verdict unchanged</span>';
function board(v,d){var main=v.filter(function(c){return !isChronic(c)}),chron=v.filter(isChronic),gs=groups(main),gc=groups(chron);HOSTS={};groups(v).forEach(function(g){HOSTS[g.c.anchor_ip]=g.all});
  var shown=gs.slice(0,S.limit),cs=gc.slice(0,100);
  $("#view").innerHTML=(shown.length?'<div class="board">'+shown.map(card).join("")+'</div>'
    +(gs.length>S.limit?'<button type="button" class="btn-sec bmore" id="bmore">Show '+Math.min(50,gs.length-S.limit)+' more ('+num(gs.length-S.limit)+' left)</button>':'<p class="mut" style="text-align:center;margin:12px 0 0">'+num(gs.length)+' '+(S.perhost?(gs.length===1?"host":"hosts"):(gs.length===1?"cluster":"clusters"))+'</p>')
    :gc.length?"":'<div class="card empty">Nothing here. '+(d.clusters.length?"Clear a filter or widen the time range.":"Not enough alerts in this range yet (a cluster needs 2 alerts of one IP).")+'</div>')
    +(gc.length?'<details class="chron" id="chron"'+(chronOpen()?" open":"")+'><summary><span class="caret"></span>Chronic ('+num(gc.length)+')'+CHRONW+'</summary><div class="board">'+cs.map(card).join("")+'</div>'+(gc.length>cs.length?'<p class="mut">'+num(cs.length)+' of '+num(gc.length)+' shown</p>':"")+'</details>':"");
  var b=$("#bmore");if(b)b.onclick=function(){S.limit+=50;render()};chronBind();bindIp()}
// ---- timeline (swimlanes) ----
var NS="http://www.w3.org/2000/svg";
function openInTable(k){S.view="table";S.open.add(k);var v=visible(),i=v.findIndex(function(c){return c.key===k});if(i>=0)S.page=Math.floor(i/S.size)+1;sync();render();if(!S.details[k])fetchDetail(k);
  var el=document.querySelector('.job[data-k="'+cssq(k)+'"]');if(el)el.scrollIntoView({block:"center"})}
function timeline(v,d){var top=v.slice(0,400),W=Math.max(600,$("#view").clientWidth-32),L=10,R=10,T=6,lh=13;
  var t0=(d.now-d.range_s)*1000,t1=d.now*1000,x=function(t){return L+(Math.min(Math.max(t,t0),t1)-t0)/(t1-t0)*(W-L-R)};
  var lanes=[],lane={};top.forEach(function(c){var s=x(c.start_ms),e=Math.max(x(c.end_ms),s+3),i=0;for(;i<lanes.length;i++){if(lanes[i]<s-2)break}lanes[i]=e;lane[c.key]=i});
  var H=T+Math.max(1,lanes.length)*lh+30,g="";
  var every=Math.max(1,Math.ceil(d.range_s/3600/8)),step=d.range_s<=3600?600:d.range_s<=21600?3600:d.range_s<=43200?7200:10800;
  for(var t=Math.ceil(t0/1000/step)*step;t*1000<=t1;t+=step){var X=x(t*1000);g+='<line x1="'+X+'" x2="'+X+'" y1="0" y2="'+(H-24)+'" stroke="rgba(255,255,255,.08)"/><text class="ax" x="'+X+'" y="'+(H-8)+'" text-anchor="middle">'+tm(t*1000,"hm")+'</text>'}
  top.forEach(function(c){var s=x(c.start_ms),e=Math.max(x(c.end_ms),s+3),y=T+lane[c.key]*lh;g+='<rect data-k="'+esc(c.key)+'" x="'+s+'" y="'+y+'" width="'+(e-s)+'" height="'+(lh-3)+'" rx="2" fill="'+(C.phaseColors[c.highest_phase]||"#808297")+'" opacity="'+(0.45+0.55*(c.priority||0)/100)+'"'+(c.critical_host?' stroke="#ffd700" stroke-width="1"':"")+' style="cursor:pointer"/>'});
  $("#view").innerHTML='<div class="viz"><div class="cth" style="margin-bottom:6px"><span class="mut">Each bar is one cluster from its first to its last alert; lanes are filled by score (top lanes = highest). '+(v.length>400?"Top 400 of "+num(v.length)+" shown.":num(v.length)+" clusters.")+'</span><span class="hleg">'+C.phases.map(function(p){return '<span><i class="sq" style="background:'+C.phaseColors[p]+'"></i>'+p+'</span>'}).join("")+'</span></div><svg viewBox="0 0 '+W+' '+H+'" height="'+H+'">'+g+'</svg></div>';
  var by={};top.forEach(function(c){by[c.key]=c});bindSvg(by)}
function bindSvg(by){$$("#view svg [data-k]").forEach(function(r){var c=by[r.getAttribute("data-k")];
  r.onmousemove=function(e){showTip(e,c.anchor_ip+(c.critical_host?"  ★ critical":"")+"\n"+c.cluster_type+" "+c.cluster_label+"\n"+(c.highest_phase||"no phase")+" · "+(c.severity_max||"")+" · "+c.alert_count+" alerts, "+c.n_alert_types+" types\nScore "+num(c.score)+" · Impact "+c.impact_score+" · Certainty "+c.certainty_score+"\n"+rng(c.start_ms,c.end_ms)+"\nclick: open in the table")};
  r.onmouseleave=hideTip;r.onclick=function(){hideTip();openInTable(c.key)}})}
// ---- Impact x Certainty (the quadrant: certainty >= 60 and impact >= 55 are "high") ----
function quadrant(v){var W=Math.max(600,$("#view").clientWidth-32),H=Math.min(620,Math.max(420,Math.round(W*0.5))),L=46,R=16,T=12,B=40,iW=W-L-R,iH=H-T-B;
  var xq=function(c){return L+c/100*iW},yq=function(i){return T+iH-i/100*iH},xd=xq(60),yd=yq(55),g="";
  var Z=[[xd,T,L+iW-xd,yd-T,"#e0122d","CRITICAL","high certainty, high impact: respond now",xd+10,T+18],[xd,yd,L+iW-xd,T+iH-yd,"#ff7a00","INVESTIGATE","high certainty, lower impact",xd+10,T+iH-10],
    [L,T,xd-L,yd-T,"#0f8bfd","MONITOR","high impact, low certainty: may escalate",L+10,T+18],[L,yd,xd-L,T+iH-yd,"#808297","LOW PRIORITY","",L+10,T+iH-10]];
  Z.forEach(function(z){g+='<rect x="'+z[0]+'" y="'+z[1]+'" width="'+z[2]+'" height="'+z[3]+'" fill="'+z[4]+'" opacity=".09"/><text class="zl" x="'+z[7]+'" y="'+z[8]+'" fill="'+z[4]+'">'+z[5]+'</text>'});
  g+='<line x1="'+xd+'" x2="'+xd+'" y1="'+T+'" y2="'+(T+iH)+'" stroke="#808297" stroke-dasharray="5,3"/><line x1="'+L+'" x2="'+(L+iW)+'" y1="'+yd+'" y2="'+yd+'" stroke="#808297" stroke-dasharray="5,3"/>';
  [0,25,50,75,100].forEach(function(c){g+='<text class="ax" x="'+xq(c)+'" y="'+(T+iH+16)+'" text-anchor="middle">'+c+'</text>'});
  [0,25,50,55,75,100].forEach(function(i){g+='<text class="ax" x="'+(L-8)+'" y="'+(yq(i)+4)+'" text-anchor="end">'+i+'</text>'});
  g+='<text class="ax" x="'+(L+iW/2)+'" y="'+(H-6)+'" text-anchor="middle">Certainty →</text><text class="ax" transform="translate(12,'+(T+iH/2)+') rotate(-90)" text-anchor="middle">Impact →</text>';
  var pts=v.filter(function(c){return c.impact_score!=null&&c.certainty_score!=null}).slice(0,1500).reverse();
  var by={};pts.forEach(function(c){by[c.key]=c;var h=0;for(var i=0;i<c.key.length;i++)h=(h*31+c.key.charCodeAt(i))|0;var jx=((h&255)/255-.5)*1.6,jy=(((h>>8)&255)/255-.5)*1.6;
    var r=3+Math.min(9,Math.log10(c.alert_count+1)*3);g+='<circle data-k="'+esc(c.key)+'" cx="'+xq(Math.min(100,Math.max(0,c.certainty_score+jx)))+'" cy="'+yq(Math.min(100,Math.max(0,c.impact_score+jy)))+'" r="'+r+'" fill="'+(C.phaseColors[c.highest_phase]||"#808297")+'" fill-opacity=".72"'+(c.critical_host?' stroke="#ffd700" stroke-width="2"':' stroke="#060725" stroke-width=".6"')+' style="cursor:pointer"/>'});
  $("#view").innerHTML='<div class="viz"><div class="cth" style="margin-bottom:6px"><span class="mut">Dot = cluster, size = alerts (log), colour = highest phase, gold ring = critical host. Both axes are linear, 0-100. '+num(pts.length)+' clusters.</span><span class="hleg">'+C.phases.map(function(p){return '<span><i class="sq" style="background:'+C.phaseColors[p]+'"></i>'+p+'</span>'}).join("")+'</span></div><svg viewBox="0 0 '+W+' '+H+'" height="'+H+'">'+g+'</svg></div>';
  bindSvg(by)}
//@@WORK@@
// ---- controls ----
$$(".tlr .mi").forEach(function(b){b.onclick=function(){S.t=b.dataset.t;S.page=1;b.closest("details").open=false;sync();S.data=null;$("#view").innerHTML='<div class="loading">Loading…</div>';load()}});
$$("#sortdd .mi[data-dbg]").forEach(function(b){if(!isAdmin())b.remove()});
$$("#sortdd .mi").forEach(function(b){b.onclick=function(){S.sort=b.dataset.sort;S.page=1;b.closest("details").open=false;sync();render()}});
$$(".vchips .chip").forEach(function(b){b.onclick=function(){S.view=b.dataset.view;sync();render()}});
$("#phchips").onclick=function(e){var b=e.target.closest("[data-ph]");if(!b)return;var p=b.dataset.ph;if(!p)S.ph.clear();else if(S.ph.has(p))S.ph.delete(p);else S.ph.add(p);S.page=1;sync();render()};
$$(".tchk").forEach(function(c){c.onchange=function(){if(c.checked)S.ty.add(c.value);else S.ty.delete(c.value);S.page=1;sync();render()}});
$("#tclear").onclick=function(){S.ty.clear();sync();render()};
$("#critonly").onchange=function(e){S.crit=e.target.checked;S.page=1;S.limit=50;sync();render()};
$("#perhost").onchange=function(e){S.perhost=e.target.checked;S.limit=50;sync();render()};
$("#liveonly").onchange=function(e){S.live=e.target.checked;S.page=1;S.limit=50;sync();render()};
$("#vbar").onclick=function(e){var b=e.target.closest("[data-vd]");if(!b)return;var k=b.dataset.vd;if(S.vd.has(k))S.vd.delete(k);else S.vd.add(k);S.page=1;S.limit=50;sync();render()};
(function(){var o=$("#ovw");try{o.open=localStorage.getItem("sc-ovw")==="1"}catch(x){}o.addEventListener("toggle",function(){try{localStorage.setItem("sc-ovw",o.open?"1":"0")}catch(x){}if(o.open&&S.data)render()})})();
var qt=null;$("#q").value=S.q;$("#q").oninput=function(e){clearTimeout(qt);qt=setTimeout(function(){S.q=e.target.value.trim();S.page=1;sync();render()},200)};
$("#reload").onclick=function(){load()};bellBtn();
$("#view").addEventListener("click",function(e){var b=e.target.closest("[data-pcap]");if(!b)return;e.stopPropagation();var k=b.closest("[data-dk]").dataset.dk;reqPcap(b.dataset.pcap,k)},true);$("#auto").onchange=schedule;
window.addEventListener("resize",function(){if(S.view!=="table")render()});
//@@EVENTS@@
document.addEventListener("keydown",function(e){if(e.key==="Escape")hideTip()});
$("#me").onclick=function(){if(ME.src!=="sycope")askName()};
// the Simple | Full toggle (see _VIEW_JS): redraw the board in place; the open cards, the search and the time range stay
function viewChanged(){SIMPLE=!!window.SCV.simple;simpleState();S.sel.clear();S.page=1;S.limit=50;sync();var y=window.scrollY;if(S.data){render();selBar();window.scrollTo(0,y)}}
if(window.SCV)window.SCV.on(viewChanged);
loadMe();load();
})();
"""
_LIVE_JS = _LIVE_JS.replace("//@@WORK@@", r"""function refreshAll(){load();if(S.lane==="handover")loadHandover();if(S.lane==="ended")S.endedOpen={}}
function post(body){if(CHECKING)toast("A moment: Sycope is confirming who you are (once a shift)");return (CHECKING||Promise.resolve()).then(function(){var h={"Content-Type":"application/json","X-SC-Action":"1"},p=passFor(ME.name);if(p)h["X-SC-Pass"]=p.pass;
    return fetch("action",{method:"POST",credentials:"same-origin",headers:h,body:JSON.stringify(Object.assign({product:"clusters"},body))})})
  .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})}
function getJ(u){return fetch(u,{credentials:"same-origin",headers:{Accept:"application/json"}}).catch(netErr).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})}
function toast(msg,bad){var t=document.createElement("div");t.className="toast";if(bad)t.style.borderLeftColor="var(--bad)";t.textContent=msg;document.body.appendChild(t);setTimeout(function(){t.classList.add("out")},2600);setTimeout(function(){t.remove()},3200)}
function copyText(t){if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(function(){toast("Copied")});else{var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");toast("Copied")}catch(x){}a.remove()}}
function afterMe(){if(S.data)render()}
//@@SHARED@@
// ---- what a card says about the work: status, owner, memory, chains, priority ----
var STSHORT={new:"New",investigating:"In progress",escalated:"Escalated",ack:"Seen",tp:"Closed",benign:"Closed",fp:"Closed",resolved:"Resolved"};
var CLOSEM=[["tp","True positive","An attack, handled"],["benign","Benign","Real, but allowed (pentest, backup, admin)"],["fp","False positive","The detection is wrong"]];
function VLB(k){return V(k).label}
function stPill(st,v){st=st||{status:"new"};
  if(st.status==="new"){if(st.reopened_from)return '<span class="stp st-ch" title="It was closed or marked seen at '+esc(VLB(st.reopened_from))+' and has risen since">Reopened: rose from '+esc(VLB(st.reopened_from))+(v?' to '+esc(VLB(v)):"")+' after close</span>';
    return '<span class="stp st0">New</span>'}
  var lab=STW[st.status]||st.status,own=ownerOf(st),by=own?(st.status==="escalated"?"→ ":"")+own:st.who,tip=(st.at?tm(st.at*1000,"dhm"):"")+(st.reason?" · "+st.reason:"")+(st.note?": "+st.note:"");
  return '<span class="stp st-'+esc(st.status)+(own&&own===ME.name?" mine":"")+'" title="'+esc(tip)+'">'+esc(lab)+(by?'<span class="own">'+esc(by)+'</span>':"")+'</span>'}
function dayAt(back){var t=lc(S.data?S.data.now*1000:Date.now());return new Date(Date.UTC(t.getUTCFullYear(),t.getUTCMonth(),t.getUTCDate()-back))}   // calendar days of the display zone, DST-proof
var WD=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
function dayLabel(back){var d=dayAt(back);return WD[d.getUTCDay()]+" "+ymdOf(d)+(back===0?" (today)":"")}
// memory is null when the past days could not be read: no badge, no heat. A new rule set has no badge on a card or a
// row (its status pill already says New, the heat shows the empty days); the drawer (`full`) still names it.
function memBadge(m,full){if(!m)return "";return m.badge==="recurring"?'<span class="tg rec" title="Its rule set was seen on this host on '+num(m.days)+' of the last 6 days">Recurring '+num(m.days)+'d</span>'
  :full?'<span class="tg new" title="Its rule set was not seen on this host in the last 6 days">New on this host</span>':""}
function heatLevel(v,mx){return v==null?"h-none":v?"h-"+Math.min(4,Math.max(1,Math.ceil(v/mx*4))):"h-0"}
function heatStrip(m,labels){if(!m||!m.heat)return "";var h=m.heat,n=h.length,mx=Math.max.apply(null,h.map(function(x){return x||0}))||1;
  return '<span class="heat'+(labels?" lbl":"")+'" aria-label="Alerts of its rule set on this host, last '+n+' days, today last">'+h.map(function(v,i){var back=n-1-i,lab=dayLabel(back);
    return '<span class="hc"><i class="'+heatLevel(v,mx)+(back===0?" h-today":"")+'" title="'+esc(lab+": "+(v==null?"no data kept":num(v)+" alert"+(v===1?"":"s")))+'"></i>'+(labels?'<em>'+esc(back===0?"now":WD[dayAt(back).getUTCDay()])+'</em>':"")+'</span>'}).join("")+'</span>'}
var HEATLEG='<span class="hlg"><span>fewer</span><i class="h-1"></i><i class="h-2"></i><i class="h-3"></i><i class="h-4"></i><span>more alerts</span><i class="h-0"></i><span>none</span><i class="h-none"></i><span>no data kept</span><i class="h-1 h-today"></i><span>today</span></span>';
function chainLines(c){return (c.chains||[]).map(function(x){return '<div class="chainline" title="'+esc(x.title+" · score × "+x.mult)+'"><b>Chain:</b> '+esc(x.text)+'</div>'}).join("")}
// one compact line: the applied multiplier and a chip per chain id; the chip that set the multiplier is filled
function chainChips(c){var ch=c.chains||[];if(!ch.length)return "";var top=0;ch.forEach(function(x,i){if(x.mult>ch[top].mult)top=i});
  return '<span class="chips"><span class="chl">Chains ×'+esc(ch[top].mult)+'</span>'+ch.map(function(x,i){return '<span class="chip'+(i===top?" top":"")+'" title="'+esc(x.text+" · score × "+x.mult)+'">'+esc(x.id)+'</span>'}).join("")+'</span>'}
function chainCell(c){return chainChips(c)}
function isChronic(c){return !!(c.memory&&c.memory.chronic&&(c.verdict==="act"||c.verdict==="investigate"))}
function byKey(k){var d=S.data||{},hit=null;(d.clusters||[]).forEach(function(c){if(c.key===k)hit=c});(d.targets||[]).forEach(function(t){if(t.key===k)hit=t});return hit}
function verdictOf(k){var x=byKey(k);return x?x.verdict:""}
function labelOf(k){var x=byKey(k);return x?(k.slice(0,2)==="ct"?"Under attack · "+x.ip:(x.anchor_ip||"")+" · "+(x.cluster_label||x.cluster_type||"cluster")):k}
// ---- actions: one button row for a card, a table row, the panel and the lanes ----
var KB='<button type="button" class="kb" data-act="menu" aria-label="More actions" title="More actions (or right-click the row)">⋯</button>';
var PEND=new Set();      // work objects with an action on its way: their buttons wait
function pendSet(keys,on){keys.forEach(function(k){if(on)PEND.add(k);else PEND.delete(k)});$$("[data-act][data-k]").forEach(function(b){if(keys.indexOf(b.dataset.k)>=0)b.disabled=on})}
function dialogOpen(){return !!document.querySelector(".dlg-w")}
function actBtn(a,label,k,cls,tip,v){return '<button type="button" class="b2 '+(cls||"")+'"'+(PEND.has(k)?" disabled":"")+' data-act="'+a+'" data-k="'+esc(k)+'"'+(v?' data-v="'+esc(v)+'"':"")+' title="'+esc(tip||"")+'">'+label+'</button>'}
function editing(){return !!(S.data&&S.data.edit)}
function quick(k,st,compact){if(!editing())return "";st=st||{};var mine=st.status==="investigating"&&ME.name&&ownerOf(st)===ME.name;
  if(st.handled&&st.status!=="new")return actBtn("open","Reopen",k,"","Back to New")+(compact?"":actBtn("note","Note",k,"","A note in its history; the state does not change"));
  if(SIMPLE)return (mine?"":actBtn("investigating","Take",k,"pri","In progress and assigned to you; it stays on the board"))
    +(compact?"":actBtn("escalated","Escalate",k,"","Hand it to L2 with a note; it stays on the board"))+actBtn("close","Close ▾",k,"","Close it as a true positive, benign or a false positive");
  return (mine?"":actBtn("investigating","Take",k,"pri","In progress and assigned to you; it stays on the board"))
    +(compact?"":actBtn("escalated","Escalate",k,"","Hand it to L2 with a note; it stays on the board"))
    +actBtn("ack","Seen",k,"","Nothing to do now: out of the queue until it rises to a higher verdict")+actBtn("close","Close ▾",k,"","Close it as a true positive, benign or a false positive")
    +(compact?"":actBtn("note","Note",k,"","A note in its history; the state does not change"))}
function others(c){return (HOSTS[c.anchor_ip]||[]).filter(function(x){return x.key!==c.key})}
// the open clusters of hosts that the board shows: what "all clusters of this host" acts on (never a closed outcome)
function hostOpen(ips){return visible().filter(function(c){return ips.has(c.anchor_ip)&&!(c.state&&c.state.handled)}).map(function(c){return c.key})}
function moreHtml(c){var o=others(c);if(!S.perhost||!o.length)return "";
  return '<span class="more-cl" title="'+esc(o.map(function(x){return VLB(x.verdict)+", "+num(x.alert_count)+" alerts: "+(STW[(x.state||{}).status]||"New")}).join("\n"))+'"><b>+'+o.length+' more cluster'+(o.length>1?"s":"")+'</b> '
    +o.slice(0,4).map(function(x){return '<i class="sq" style="background:'+V(x.verdict).color+'"></i>'+esc(STSHORT[(x.state||{}).status]||"New")}).join(" · ")+(o.length>4?" …":"")+'</span>'}
function workRow(c,card){var st=c.state||{};
  return '<div class="bc-work"><div class="wl">'+(editing()?'<input type="checkbox" class="selx" data-sel="'+esc(c.key)+'"'+(S.sel.has(c.key)?" checked":"")+' aria-label="Select" title="Tick several to act on them together (Action ▾)">':"")
    +'<span class="wst">'+stPill(st,c.verdict)+'</span>'+memBadge(c.memory)+heatStrip(c.memory)+priTag(c.p)
    +((c.chains||[]).length?'<span class="bc-chain">'+chainChips(c)+'</span>':"")+(card?moreHtml(c):"")+'</div><span class="btns">'+quick(c.key,st,true)+KB+'</span></div>'}
// the menu of a card: what works for it, and for all its host's clusters when the board shows one card per host
function bulkItems(keys,head,scopeTag,label,after){var a=function(st,l,cls){return {label:l,run:function(){changeState({status:st,cls:cls,keys:keys,verdicts:keys.map(verdictOf),label:label,scope:scopeTag,after:after})}}};
  return [{head:head},a("investigating","Take"),a("escalated","Escalate…"),a("ack","Seen"),a("close","Close: true positive…","tp"),a("close","Close: benign…","benign"),a("close","Close: false positive…","fp")]}
function rowItems(k){var x=byKey(k);if(!x||!editing())return null;var st=x.state||{},one=function(a,l,cls){return {label:l,run:function(){actOn(k,a,cls)}}},out=[{head:esc(labelOf(k))}];
  if(!(st.handled&&st.status!=="new")){out.push(one("investigating","Take"),one("escalated","Escalate…"),one("ack","Seen"),one("close","Close: true positive…","tp"),one("close","Close: benign…","benign"),one("close","Close: false positive…","fp"))}
  if(st.status&&st.status!=="new")out.push(one("open","Reopen"));
  out.push({label:"Add note…",run:function(){noteDialog(k)}});
  if(k.slice(0,2)==="cl"){var all=hostOpen(new Set([x.anchor_ip]));if(S.perhost&&all.length>1){out.push({sep:1});out=out.concat(bulkItems(all,"All "+all.length+" open clusters of this host","host",x.anchor_ip+" (all its open clusters)"))}}
  return out}
// ---- the one entry point for every change of state: a cluster, ticked ones, all of a host's ----
function changeState(o){if(dialogOpen()||o.keys.some(function(k){return PEND.has(k)}))return;return ensureWho().then(function(w){if(!w||dialogOpen()||o.keys.some(function(k){return PEND.has(k)}))return;
  var n=o.keys.length,many=n>1,acts=o.verdicts.filter(function(v){return v==="act"}).length,why=o.verdicts.some(function(v){return v==="act"||v==="investigate"});
  var scope=many?'<div class="scope-box">'+esc(o.label||"")+': <b>'+hp(n,"cluster")+'</b>'+(acts?' · <b style="color:#ff8b98">'+num(acts)+' at Act now</b>':"")+'</div>':(o.label?'<div class="scope-box">'+esc(o.label)+'</div>':"");
  var title=function(verb){return verb+(many?" "+hp(n,"cluster"):"")},ask=null;
  pendSet(o.keys,true);       // before the async name lookup: a second click while the dialog is on its way is ignored
  return (o.status==="escalated"?loadNames():Promise.resolve([])).then(function(){
    if(o.status==="close")ask=dlg({title:title("Close"),body:scope,ok:"Close",fields:[{name:"cls",label:"How do you close it?",type:"select",options:CLOSEW,value:o.cls||"fp"},
      {name:"reason",label:"Reason",type:"select",deps:{field:"cls",map:C.reasons}},{name:"note",label:"What did you check?",type:"textarea",required:why,placeholder:why?"Required for Act now and Investigate: it goes into the audit log and the history":"optional"}]});
    else if(o.status==="escalated")ask=dlg({title:title("Escalate"),body:scope+'<p class="mut">It stays on the board as Escalated, with the person or team named.</p>',ok:"Escalate",fields:[{name:"owner",label:"To (person or team)",value:"L2",max:40,list:KNOWN},{name:"note",label:"What should they look at?",type:"textarea",required:true}]});
    else if(o.status==="ack"&&(why||many))ask=dlg({title:title("Mark seen"),body:scope+'<p class="mut">Seen: nothing to do now. It leaves the queue and comes back as New if it rises to a higher verdict.</p>',ok:"Mark seen",fields:[{name:"note",label:"Why is there nothing to do now?",type:"textarea",required:why}]});
    else if(many)ask=dlg({title:title(o.status==="investigating"?"Take":o.status==="open"?"Reopen":"Change"),body:scope,ok:o.status==="investigating"?"Take":o.status==="open"?"Reopen":"OK",fields:[{name:"note",label:"Note",type:"textarea"}]});
    return ask||{}}).then(function(v){if(!v){pendSet(o.keys,false);return}
    var status=o.status==="close"?v.cls:o.status,body={op:"triage",keys:o.keys,status:status,who:w,note:v.note||"",reason:v.reason||"",owner:v.owner||(status==="investigating"?w:"")};
    if(many){body.scope=o.scope||"sel";body.label=o.label||""}
    return post(body).then(function(j){var msg=o.status==="escalated"?"Escalated to "+(v.owner||"L2"):DONEW[status];
      toastUndo(msg+(j.keys.length>1?" ("+hp(j.keys.length,"cluster")+")":""),j.previous,{scope:body.scope||"",label:o.label||""});
      if(o.after)o.after();setTimeout(function(){pendSet(o.keys,false);refreshAll()},250)}).catch(function(e){pendSet(o.keys,false);toast(e.message,true)})}).catch(function(e){pendSet(o.keys,false);toast(e.message,true)})})}
function actOn(k,a,cls){if(k.slice(0,2)==="r:")return reviewRecord(k.slice(2),a,cls);
  changeState({status:a,cls:cls,keys:[k],verdicts:[verdictOf(k)],label:labelOf(k)})}
function noteDialog(k){if(dialogOpen())return;ensureWho().then(function(w){if(!w)return;dlg({title:"Add a note",body:'<div class="scope-box">'+esc(labelOf(k))+'</div><p class="mut">The note goes into its history and the audit log; the state does not change.</p>',
  fields:[{name:"text",label:"Note",type:"textarea",required:true,max:1000}],ok:"Add note"}).then(function(v){if(!v)return;
  post({op:"comment",key:k,note:v.text,who:w}).then(function(){toast("Note added");setTimeout(refreshAll,250)}).catch(function(e){toast(e.message,true)})})})}
function closeMenu(btn,k){cmAt(btn,[{head:"Close it as"}].concat(CLOSEM.map(function(c){return {label:c[1]+" · "+c[2],run:function(){actOn(k,"close",c[0])}}})))}
// ended records: a cluster that went quiet with nobody looking, or that somebody took after it ended
function reviewRecord(id,a,cls){if(dialogOpen()||PEND.has("r:"+id))return;var r=(S.data.ended||[]).concat(S.data.held_records||[]).filter(function(x){return String(x.id)===String(id)})[0]||{},label=r.label||("Record #"+id);
  ensureWho().then(function(w){if(!w)return;pendSet(["r:"+id],true);var scope='<div class="scope-box">'+esc(label)+'</div><p class="mut">It ended '+(r.closed_at?tm(r.closed_at*1000,"dhm"):"")+(r.outcome==="investigating"||r.outcome==="escalated"?'; '+esc(r.outcome_by||"someone")+' took it after that.':' with nobody having looked at it.')+'</p>';
    var ask=a==="close"?dlg({title:"Close an ended cluster",body:scope,ok:"Close",fields:[{name:"cls",label:"How do you close it?",type:"select",options:CLOSEW,value:cls||"fp"},{name:"reason",label:"Reason",type:"select",deps:{field:"cls",map:C.reasons}},{name:"note",label:"What did you check?",type:"textarea",required:true}]})
      :a==="escalated"?loadNames().then(function(){return dlg({title:"Escalate an ended cluster",body:scope,ok:"Escalate",fields:[{name:"owner",label:"To (person or team)",value:"L2",max:40,list:KNOWN},{name:"note",label:"What should they look at?",type:"textarea",required:true}]})})
      :a==="ack"?dlg({title:"Mark seen",body:scope+'<p class="mut">Seen: nothing to do now. It leaves this list; the record keeps who saw it and why.</p>',ok:"Mark seen",fields:[{name:"note",label:"Why is there nothing to do now?",type:"textarea",required:true}]})
      :Promise.resolve({});
    ask.then(function(x){if(!x){pendSet(["r:"+id],false);return}var status=a==="close"?x.cls:a;
      post({op:"record",rec:+id,status:status,who:w,note:x.note||"",reason:x.reason||"",owner:a==="escalated"?x.owner||"":""}).then(function(j){
        toastUndo(a==="open"?"Released: back to Ended, not reviewed":a==="escalated"?"Escalated to "+(x.owner||"L2"):DONEW[status],null,{undo:function(){return post({op:"record",rec:+id,status:j.previous,owner:j.previous_owner||"",who:ME.name||w})}});
        setTimeout(function(){pendSet(["r:"+id],false);refreshAll()},250)}).catch(function(e){pendSet(["r:"+id],false);toast(e.message,true)})})})}
// ---- bulk: ticked cards and the Action ▾ toolbar ----
function selKeys(){var ok=new Set(visible().map(function(c){return c.key}));S.sel.forEach(function(k){if(!ok.has(k))S.sel.delete(k)});return Array.from(S.sel)}
function selBar(){var b=$("#qact"),n=$("#seln");if(!b)return;var ks=selKeys();b.hidden=!editing();b.disabled=!ks.length;b.classList.toggle("on",!!ks.length);
  var hosts=new Set(ks.map(function(k){return (byKey(k)||{}).anchor_ip}));
  if(n)n.innerHTML=ks.length?'<b>'+hp(ks.length,"cluster")+'</b> selected ('+hp(hosts.size,"host")+') · <button type="button" class="lnk" data-selnone="1">clear</button>':""}
function selMenu(btn){var ks=selKeys();if(!ks.length)return;var hosts=new Set(ks.map(function(k){return (byKey(k)||{}).anchor_ip})),all=hostOpen(hosts),
    clear=function(){S.sel.clear();selBar();render()};      // only after the action went through, not when its dialog is cancelled
  var items=bulkItems(ks,esc(hp(ks.length,"cluster"))+" ticked","sel",hp(ks.length,"cluster")+" from the board",clear);
  if(all.length>ks.length)items=items.concat([{sep:1}],bulkItems(all,"All "+all.length+" open clusters of these "+hp(hosts.size,"host"),"host",hp(hosts.size,"host")+" (all their open clusters)",clear));
  cmAt(btn,items)}
// ---- next steps, notes, same flow, memory: the panel of a cluster ----
var STEPK={check:["check","Look in Sycope or in the recorded packets"],ask:["ask","Outside Sycope: EDR, the auth logs, the host's owner"],act:["action","Containment, once a check confirms the attack"]};
function alertsUrl(nql,from,to){var gq={query:{source:"alerts",nql:nql,advanced:false},timerange:{from:isoOff(from),to:isoOff(to),roundTo:"minute"}};
  return C.sycopeUi+"/panel/alerts?source=alerts&gq="+encodeURIComponent(JSON.stringify(gq))}
var NAMERE=/^[^"\\]{1,200}$/;
function stepLink(l){if(!l)return "";
  if(l.t==="flows"){if(!C.rawdata)return "";var t=[];if(l.c&&IPRE.test(l.c))t.push('clientIp = "'+l.c+'"');if(l.s&&IPRE.test(l.s))t.push('serverIp = "'+l.s+'"');if(l.port&&/^\d{1,5}$/.test(String(l.port)))t.push("serverPort = "+l.port);if(!t.length)return "";
    return '<a href="'+esc(rawUrl(t.join(" and "),l.from-5*60000,l.to+60000))+'" target="_blank" rel="noopener">'+esc(l.label)+' ↗</a>'}
  if(l.t==="alerts"){if(!C.rawdata)return "";var q=[];if(l.rule){if(!NAMERE.test(l.rule))return "";q.push('alertName = "'+l.rule+'"')}if(l.c&&IPRE.test(l.c))q.push('clientIp = "'+l.c+'"');if(l.s&&IPRE.test(l.s))q.push('serverIp = "'+l.s+'"');if(!q.length)return "";
    return '<a href="'+esc(alertsUrl(q.join(" and "),l.from-60000,l.to+120000))+'" target="_blank" rel="noopener">'+esc(l.label)+' ↗</a>'}
  if(l.t==="host")return '<a href="#" data-ip="'+esc(l.ip)+'">'+esc(l.label)+'</a>';
  if(l.t==="url")return /^https?:\/\//i.test(l.url||"")?'<a href="'+esc(l.url)+'" target="_blank" rel="noopener noreferrer">'+esc(l.label)+' ↗</a>':"";
  return ""}
function nextHtml(D){var X=D.steps;if(!X||!X.list||!X.list.length)return "";var done=X.done||{},n=0,list=X.list,hid=0;
  if(SIMPLE&&!STEPS_ALL){list=X.list.filter(function(s){return !(done[s.id]&&done[s.id].done)}).slice(0,3);hid=X.list.length-list.length}
  var rows=list.map(function(s){var d=done[s.id],ok=!!(d&&d.done),k=STEPK[s.kind]||STEPK.check,links=(s.links||[]).map(stepLink).filter(Boolean);if(ok)n++;
    return '<li class="nx nx-'+esc(s.kind)+(ok?" ok":"")+'">'+(editing()&&X.rec?'<input type="checkbox" data-step="'+esc(s.id)+'" data-rec="'+esc(X.rec)+'"'+(ok?" checked":"")+' aria-label="Checked" title="Checked: it goes into its history">':'<span class="nxb"></span>')
      +'<div class="nxt"><span class="nxk" title="'+esc(k[1])+'">'+esc(k[0])+'</span><b>'+esc(s.title)+'</b>'+(s.stale?' <span class="note" title="'+esc("The factory text is now: "+s.factory.title+" - "+s.factory.why)+'">factory step changed, review</span>':"")+ii(esc(s.why))+(links.length?' <span class="nxl">'+links.join(" · ")+'</span>':"")
      +(ok?'<div class="nxd">checked by '+esc(d.who||"?")+' '+tm(d.at*1000,"dhm")+'</div>':"")+'</div></li>'}).join("");
  return '<h3>Next steps <span class="nxc">'+num(n)+' of '+num(X.list.length)+' checked'+(X.rec?"":" · no open record now, so checks are not kept")+'</span>'
    +ii("Built from this cluster's rule families and the chain rules it matched; the same evidence gives everyone the same list.<br><b>Check</b>: a look in Sycope. <b>Ask</b>: outside it (EDR, auth logs, the owner). <b>Action</b>: containment, once a check confirms the attack.<br>A ticked step goes into its history and the audit log.")+'</h3><ol class="nxo">'+rows+'</ol>'
    +(hid>0?'<div class="nxf"><button type="button" class="lnk" data-stepsall="1">show all '+num(X.list.length)+'</button></div>':"")}
function stepCheck(x){var host=x.closest("[data-dk]"),k=host&&host.dataset.dk,D=k&&S.details[k],X=D&&D.steps;if(!X)return;
  var s=(X.list||[]).filter(function(y){return y.id===x.dataset.step})[0],done=x.checked;if(!s)return;
  x.disabled=true;
  ensureWho().then(function(who){if(!who){x.checked=!done;x.disabled=false;return}
    post({op:"step",rec:+x.dataset.rec,step:s.id,done:done,title:s.title,who:who}).then(function(){X.done=X.done||{};X.done[s.id]={done:done,who:who,at:Date.now()/1000,title:s.title};redrawDetail(k)})
      .catch(function(e){x.checked=!done;x.disabled=false;toast(e.message,true)})})}
function redrawDetail(k){$$('[data-dk="'+cssq(k)+'"]').forEach(function(el){el.innerHTML=detailHtml(k)})}
function notesHtml(D){var T=D.timeline||[];if(!T.length)return "";
  return '<h3>Notes and history</h3><div class="tlist">'+T.map(function(r){return '<div class="tli"><span class="mono mut">'+tm(r.at*1000,"dhm")+'</span> <b>'+esc(r.who)+'</b>'+(r.verified?'<span class="vok" title="Sycope confirmed this name">✓</span>':"")+' '+esc(r.text)+(r.note?': <q>'+esc(r.note)+'</q>':"")+'</div>'}).join("")+'</div>'}
function workPanel(k,st,v){if(!editing())return '<div class="tri"><span class="st">Read-only: analyst actions are switched off.</span></div>';
  st=st||{status:"new"};var line=st.status==="new"?"":'<span class="st">'+esc(STW[st.status]||st.status)+(ownerOf(st)?(st.status==="escalated"?" to ":" · ")+esc(ownerOf(st)):"")+' · by '+esc(st.who||"?")+' '+(st.at?tm(st.at*1000,"dhm"):"")+(st.reason?' ('+esc(st.reason)+')':"")+(st.note?': “'+esc(st.note)+'”':"")+'</span>';
  return '<div class="tri wp">'+stPill(st,v)+quick(k,st,false)+(st.status!=="new"?actBtn("open","Reopen",k,"","Back to New"):"")+'</div>'+(line?'<div class="tri">'+line+'</div>':"")}
function memHtml(k){var c=byKey(k),m=c&&c.memory;if(!m)return "";
  return '<h3>Earlier days</h3><div class="memrow">'+memBadge(m,true)+heatStrip(m,true)+HEATLEG+'</div><div class="memrow"><span class="mut">'+(m.badge==="recurring"?"Its rule set was seen on this host on "+num(m.days)+" of the last 6 days":"Its rule set was not seen on this host in the last 6 days")+(m.chronic?" · chronic: every rule of it on 3 or more of them":"")+'. Memory is display only: it never changes the score.</span></div>'}
function workHtml(k,D){var c=D.cluster||{},st=D.state||{status:"new"};
  if(SIMPLE)return workPanel(k,st,c.verdict)+nextHtml(D);
  return workPanel(k,st,c.verdict)+((D.chains||[]).length?'<div class="chainbox">'+chainLines(D)+'</div>':"")+memHtml(k)
    +(D.same_flow&&D.same_flow.length?'<h3>Same flow</h3><p class="mut" style="margin:0 0 6px">Fired on the same flow in the same hour as a stronger rule, so they do not count again: '+D.same_flow.map(function(n){return '<span class="pill2">'+esc(n)+'</span>'}).join("")+'</p>':"")
    +nextHtml(D)+notesHtml(D)}
function targetHtml(k,D){var t=D.target,st=D.state;
  return workPanel(k,st,t.verdict)+'<div class="kv" style="grid-template-columns:repeat(3,minmax(0,1fr));margin:8px 0">'
    +kv("Attackers",num(t.attackers))+kv("Alerts",num(t.alerts))+kv("Top rule",esc(t.top_rule))
    +kv("Families",(t.families||[]).map(function(f){return '<span class="pill2">'+esc(f)+'</span>'}).join("")||nul())+kv("First / last",tm(t.first,"dhm")+" – "+tm(t.last,"dhm"))
    +kv("Answered",t.answered?"yes: the target replied to the attacker":"no sign of it")+'</div>'+nextHtml(D)+notesHtml(D)}
// ---- lanes: Clusters (the board), Under attack, External, Ended not reviewed, Handover ----
function laneTabs(d){var f=counts(d).h,n=(f.act||0)+(f.investigate||0),held=(d.held_records||[]).length;
  var T=[["clusters","Clusters","layers",n,f.act?"v-act":f.investigate?"v-investigate":"",(n?hp(n,"host")+": "+num(f.act||0)+" at Act now + "+num(f.investigate||0)+" at Investigate. ":"")+"Time-chained clusters, one card per host or one per cluster"],
    ["targets","Under attack","target",d.targets_total,"hot","Your hosts that others attacked (they have no cluster of their own for it). A crown jewel first"],
    ["external","External","globe",d.externals_total,"hot","Addresses outside your networks that touched your hosts: threat-list hits, TOR exits, inbound scanners"],
    ["ended","Ended, not reviewed","clock",(d.ended||[]).length,"v-investigate","Clusters that reached Act now or Investigate, went quiet and nobody looked"+(held?". "+held+" taken after they ended are below them":"")],
    ["handover","Handover","audit",0,"","What happened in the shift, to paste for the next one"]];
  $("#tabs").innerHTML=T.map(function(t){return '<button type="button" class="tab'+(S.lane===t[0]?" on":"")+'" data-lane="'+t[0]+'" title="'+esc(t[5])+'">'+ic(t[2],16)+esc(t[1])+(t[3]?'<span class="n'+(t[4]?" "+t[4]:"")+'">'+num(t[3])+'</span>':"")+'</button>'}).join("")}
function lanePass(hay,st){if(S.hideh&&st&&st.handled)return false;if(!S.q)return true;hay=hay.toLowerCase();return S.q.toLowerCase().split(/\s+/).filter(Boolean).every(function(w){return hay.indexOf(w)>=0})}
function famPills(list){return (list||[]).slice(0,4).map(function(f){return '<span class="pill2" title="'+esc((C.famNames||{})[f]||"")+'">'+esc(f)+'</span>'}).join("")}
function laneTable(head,rows,empty){return '<div class="card" style="padding:0 0 6px"><div class="grid" style="overflow-x:auto"><table class="lt"><thead><tr>'+head.map(function(h){return '<th>'+h+'</th>'}).join("")+'</tr></thead><tbody>'+(rows||'<tr><td colspan="'+head.length+'" class="empty">'+esc(empty)+'</td></tr>')+'</tbody></table></div></div>'}
function more(total,shown){return shown<total?'<button type="button" class="btn-sec bmore" id="bmore">Show '+Math.min(50,total-shown)+' more ('+num(total-shown)+' left)</button>':'<p class="mut" style="text-align:center;margin:12px 0 0">'+num(total)+' '+(total===1?"entry":"entries")+'</p>'}
function laneTargets(d){var all=(d.targets||[]).filter(function(t){var h=S.data.hosts&&S.data.hosts[t.ip];return lanePass([t.ip,(h&&h.name)||"",t.top_rule,(t.families||[]).join(" "),t.crown?"crown jewel":""].join(" "),t.state)}),shown=all.slice(0,S.limit);
  var head=["Verdict","Entry","Attackers","Alerts","Top rule","First","Last","P","Status",""];
  var rows=shown.map(function(t){var v=V(t.verdict),open=S.open.has(t.key);
    return '<tr class="lr'+((t.state||{}).handled?" handled":"")+(open?" open":"")+'" data-k="'+esc(t.key)+'" style="--vc:'+v.color+'" title="Click for the details"><td><span class="vp '+esc(t.verdict)+'" style="--vc:'+v.color+'">'+esc(v.label)+'</span></td>'
      +'<td><span class="mono cp" title="Copy">'+esc(t.ip)+'</span>'+(t.crown?' <span class="pill jw">'+ic("jewel",13)+'crown jewel</span>':"")+(t.answered?' <span class="pill src" title="The target answered the attacker">answered</span>':"")+hostTags(t.ip)+'</td>'
      +'<td>'+num(t.attackers)+'</td><td>'+num(t.alerts)+'</td><td>'+rn(t.top_rule)+'<div>'+famPills(t.families)+'</div></td><td>'+tm(t.first,"dhm")+'</td><td>'+at(t.last)+'</td><td>'+priTag(t.p)+'</td>'
      +'<td>'+stPill(t.state,t.verdict)+'</td><td class="la"><span class="btns">'+quick(t.key,t.state,true)+KB+'</span></td></tr>'
      +(open?'<tr class="lrd"><td colspan="'+head.length+'"><div class="more" data-dk="'+esc(t.key)+'">'+detailHtml(t.key)+'</div></td></tr>':"")}).join("");
  $("#view").innerHTML=laneTable(head,rows,"Nothing is under attack"+(d.targets.length?" that matches the filter":"")+".")+(shown.length?more(all.length,shown.length):"");
  bindLane()}
function laneExternal(d){var all=(d.externals||[]).filter(function(x){return lanePass([x.ip,x.top_rule,(x.families||[]).join(" "),x.ti?"threat list":""].join(" "))}),shown=all.slice(0,S.limit);
  var head=["Address","Peers","Alerts","Top rule","Threat list","First","Last"];
  var rows=shown.map(function(x){return '<tr><td><span class="mono cp" title="Copy">'+esc(x.ip)+'</span></td><td>'+num(x.peers)+'</td><td>'+num(x.alerts)+'</td><td>'+rn(x.top_rule)+'<div>'+famPills(x.families)+'</div></td>'
    +'<td>'+(x.ti?'<span class="pill src">threat list</span>':'<span class="mut">no</span>')+'</td><td>'+tm(x.first,"dhm")+'</td><td>'+at(x.last)+'</td></tr>'}).join("");
  $("#view").innerHTML='<p class="mut" style="margin:0 0 8px">Addresses outside your networks never get a card. They are listed for context and cannot be worked.</p>'+laneTable(head,rows,"No outside address touched your hosts.")+(shown.length?more(all.length,shown.length):"");
  bindLane()}
function endedRow(r,held){var rid=r.id|0,v=V(r.verdict),k="r:"+rid,acts=editing()?(held?actBtn("close","Close ▾",k,"","Close it as a true positive, benign or a false positive")+actBtn("open","Release",k,"","Nobody holds it any more: back to Ended, not reviewed")
    :actBtn("investigating","Take it",k,"pri","In progress and yours: it waits under Taken, now quiet")+actBtn("ack","Seen",k,"","Nothing to do now: it leaves this list")+actBtn("close","Close ▾",k,"","Close it as a true positive, benign or a false positive")):"";
  var open=S.endedOpen&&S.endedOpen[rid];
  return '<tr class="lr" data-rec="'+rid+'" style="--vc:'+v.color+'" title="Click for what it was and what was done"><td><span class="vp '+esc(r.verdict)+'" style="--vc:'+v.color+'">'+esc(v.label)+'</span><div class="mut">at its peak</div></td>'
    +'<td><span class="mono">'+esc(r.subject_value||"")+'</span><div class="mut">'+esc(r.label||"")+'</div></td><td>'+(r.closed_at?at(r.closed_at*1000):"")+'<div class="mut">ended</div></td><td>'+(r.last_ms?at(r.last_ms):"")+'<div class="mut">last alert</div></td>'
    +'<td>'+(held?'<span class="st-'+esc(r.outcome)+'">'+esc(STW[r.outcome]||r.outcome)+'</span> <span class="mut">'+esc(r.outcome_by||"")+'</span>':'<span class="st-unrev" title="Nobody marked it seen, took it or closed it">Not reviewed</span>')+'</td><td class="la"><span class="btns">'+acts+'</span></td></tr>'
    +(open?'<tr class="lrd"><td colspan="6"><div class="more" id="rec-'+rid+'">'+(S.recs&&S.recs[rid]?recHtml(S.recs[rid]):'<span class="mut">Loading…</span>')+'</div></td></tr>':"")}
function recHtml(D){var ev=D.events||[],st=D.steps||{list:[]},done=st.done||{};
  return (D.reason?'<p style="margin:0 0 8px">'+esc(D.reason)+'</p>':"")+((D.chains||[]).length?'<div class="chainbox">'+D.chains.map(function(x){return '<div class="chainline"><b>Chain:</b> '+esc(typeof x==="string"?x:(x.text||x.id||""))+'</div>'}).join("")+'</div>':"")
    +(ev.length?'<h3>History</h3><div class="tlist">'+ev.map(function(e){return '<div class="tli"><span class="mono mut">'+tm((e.at||0)*1000,"dhm")+'</span> '+esc(e.text||e.kind||"")+'</div>'}).join("")+'</div>':"")
    +((st.list||[]).length?'<h3>Next steps at its peak</h3><ol class="nxo">'+st.list.map(function(s){var d=done[s.id];return '<li class="nx nx-'+esc(s.kind)+(d&&d.done?" ok":"")+'"><span class="nxb"></span><div class="nxt"><b>'+esc(s.title)+'</b>'+(d&&d.done?'<div class="nxd">checked by '+esc(d.who||"?")+'</div>':"")+'</div></li>'}).join("")+'</ol>':"")}
function laneEnded(d){var E=(d.ended||[]).filter(function(r){return lanePass([r.subject_value,r.label,(r.families||[]).join(" ")].join(" "))}),H=(d.held_records||[]).filter(function(r){return lanePass([r.subject_value,r.label,r.outcome_by].join(" "))});
  var head=["Verdict","Cluster","Ended","Last alert","Status",""],sec=function(t,c,n,txt){return '<tr class="qsec"><td colspan="'+head.length+'"><span class="qsec-l" style="--vc:'+c+'">'+t+'</span> <span class="mut">'+hp(n,"cluster")+' '+txt+'</span></td></tr>'};
  var rows=(H.length?sec("Taken, now quiet","#8cc4ff",H.length,"somebody took or escalated after they ended: they stay here until someone closes or releases them")+H.map(function(r){return endedRow(r,true)}).join(""):"")
    +(E.length?sec("Ended, not reviewed","#ffcf8a",E.length,"reached Act now or Investigate and went quiet before anyone looked: they stay here until someone marks them seen or closes them")+E.map(function(r){return endedRow(r,false)}).join(""):"");
  $("#view").innerHTML=laneTable(head,rows,"Nothing ended without being looked at.");bindLane()}
// ---- handover: the shift's story, as on Triage, from the Clusters records only ----
var OUTW={ack:"Seen",tp:"True positive",benign:"Benign",fp:"False positive",resolved:"Resolved",investigating:"In progress",escalated:"Escalated",partial:"Partly handled",expired:"Ended, no action",open:"Active, new",none:"-"};
var VRK={act:3,investigate:2,review:1,watch:0};
function hoHow(st){st=st||{};return st.how==="away"?"the team was last here "+tm(st.at*1000,"dhm")+(st.who?" ("+esc(st.who)+")":""):st.how==="asked"?"the period you chose"
  :st.how==="around the clock"?"the team works around the clock: the last shift":st.how==="first"?"first activity recorded: everything of the last 14 days":"nothing recorded yet: the last 24 hours"}
function hoLabel(r){return r.headline||r.label||("cluster #"+r.id)}
function handoverText(H){var L=[],me=ME.name||"",bv=H.by_verdict||{},st=H.start||{};
  L.push("Shift handover (Clusters) · "+tm(H.since*1000,"dt")+" – "+tm(H.now*1000,"dt")+" ("+zoneLbl()+")"+(me?" · from "+me:""));
  if(st.how==="away")L.push("Since the team was last here: the last action "+(st.who?"by "+st.who+" ":"")+tm(st.at*1000,"dt"));
  var bvs=["act","investigate","review"].filter(function(v){return bv[v]}).map(function(v){return bv[v]+" "+VLB(v)});
  L.push("");L.push("NEW CLUSTERS: "+H.opened.length+(bvs.length?" ("+bvs.join(", ")+")":""));
  H.opened.filter(function(r){return r.verdict!=="review"}).slice(0,12).forEach(function(r){L.push("- ["+VLB(r.verdict)+"] "+hoLabel(r)+" · opened "+tm(r.opened_at*1000,"dt"))});
  if(H.acted.length){L.push("");L.push("WHAT THE TEAM DID: "+H.acted.length);H.acted.slice(0,20).forEach(function(r){L.push("- "+tm(r.outcome_at*1000,"dt")+" "+(r.outcome_by||"?")+": "+(OUTW[r.outcome]||r.outcome)+(r.outcome_reason?" ("+r.outcome_reason+")":"")+" · "+hoLabel(r))})}
  var still=H.still.slice().sort(function(a,b){return (VRK[b.verdict_last||b.verdict]||0)-(VRK[a.verdict_last||a.verdict]||0)});
  L.push("");L.push("STILL OPEN: "+still.length);still.slice(0,25).forEach(function(r){var held=r.now_owner&&(r.now_status==="investigating"||r.now_status==="escalated");
    L.push("- ["+VLB(r.verdict_last||r.verdict)+"] "+hoLabel(r)+" · "+(held?STW[r.now_status]+", "+r.now_owner:"nobody has it"))});
  if(still.length>25)L.push("... and "+(still.length-25)+" more on the board");
  var unr=H.ended.filter(function(r){return r.outcome==="expired"});
  if(unr.length){L.push("");L.push("ENDED, NOT REVIEWED: "+unr.length);unr.slice(0,10).forEach(function(r){L.push("- ["+VLB(r.verdict)+"] "+hoLabel(r)+" · ended "+tm(r.closed_at*1000,"dt"))})}
  if(H.notes.length){L.push("");L.push("NOTES");H.notes.slice(0,20).forEach(function(a){L.push("- "+tm(a.at*1000,"dt")+" "+a.who+" on "+a.target+": "+a.note)})}
  return L.join("\n")}
function loadHandover(){S.ho.err="";getJ("handover?product=clusters"+(S.ho.hours?"&hours="+S.ho.hours:"")).then(function(H){S.ho.data=H;if(S.lane==="handover")laneHandover()}).catch(function(e){S.ho.err=e.message;if(S.lane==="handover")laneHandover()})}
function laneHandover(){var H=S.ho.data,sel=[[0,"Since the team was last here"],[8,"Last 8 hours"],[24,"Last 24 hours"],[72,"Last 3 days"]];
  var top='<div class="tools"><label class="fld2">Period <select id="hohours">'+sel.map(function(o){return '<option value="'+o[0]+'"'+(+S.ho.hours===o[0]?" selected":"")+'>'+esc(o[1])+'</option>'}).join("")+'</select></label><span class="sp"></span>'
    +'<button type="button" class="b2" id="hocopy"'+(H?"":" disabled")+' title="The shift as plain text, to paste into the handover note">Copy as text</button></div>';
  if(S.ho.err){$("#view").innerHTML=top+'<div class="errbox">Cannot read the handover: '+esc(S.ho.err)+'</div>';return bindHandover()}
  if(!H){$("#view").innerHTML=top+'<div class="loading">Loading…</div>';return bindHandover()}
  var bv=H.by_verdict||{},list=function(rows,f){return rows.length?'<div class="tlist">'+rows.map(f).join("")+'</div>':'<p class="mut">Nothing.</p>'};
  var still=H.still.slice().sort(function(a,b){return (VRK[b.verdict_last||b.verdict]||0)-(VRK[a.verdict_last||a.verdict]||0)});
  var unr=H.ended.filter(function(r){return r.outcome==="expired"});
  $("#view").innerHTML=top+'<div class="card ho"><p class="mut" style="margin:0 0 10px">'+tm(H.since*1000,"dhm")+' – '+tm(H.now*1000,"dhm")+' · '+hoHow(H.start)+'</p>'
    +'<h3>New clusters ('+num(H.opened.length)+')'+(["act","investigate","review"].filter(function(v){return bv[v]}).length?' <span class="nxc">'+["act","investigate","review"].filter(function(v){return bv[v]}).map(function(v){return bv[v]+" "+VLB(v)}).join(", ")+'</span>':"")+'</h3>'
    +list(H.opened,function(r){return '<div class="tli"><span class="vp '+esc(r.verdict)+'" style="--vc:'+V(r.verdict).color+'">'+esc(VLB(r.verdict))+'</span> '+esc(hoLabel(r))+' <span class="mut">opened '+tm(r.opened_at*1000)+'</span></div>'})
    +'<h3>What the team did ('+num(H.acted.length)+')</h3>'+list(H.acted,function(r){return '<div class="tli"><span class="mono mut">'+tm(r.outcome_at*1000)+'</span> <b>'+esc(r.outcome_by||"?")+'</b> '+esc(OUTW[r.outcome]||r.outcome)+(r.outcome_reason?' ('+esc(r.outcome_reason)+')':"")+' · '+esc(hoLabel(r))+'</div>'})
    +'<h3>Still open ('+num(still.length)+')</h3>'+list(still,function(r){var held=r.now_owner&&(r.now_status==="investigating"||r.now_status==="escalated");return '<div class="tli"><span class="vp '+esc(r.verdict_last||r.verdict)+'" style="--vc:'+V(r.verdict_last||r.verdict).color+'">'+esc(VLB(r.verdict_last||r.verdict))+'</span> '+esc(hoLabel(r))+' <span class="mut">'+(held?esc(STW[r.now_status]+", "+r.now_owner):"nobody has it")+'</span></div>'})
    +'<h3>Ended, not reviewed ('+num(unr.length)+')</h3>'+list(unr,function(r){return '<div class="tli"><span class="vp '+esc(r.verdict)+'" style="--vc:'+V(r.verdict).color+'">'+esc(VLB(r.verdict))+'</span> '+esc(hoLabel(r))+' <span class="mut">ended '+tm(r.closed_at*1000,"dhm")+'</span></div>'})
    +'<h3>Notes ('+num(H.notes.length)+')</h3>'+list(H.notes,function(a){return '<div class="tli"><span class="mono mut">'+tm(a.at*1000)+'</span> <b>'+esc(a.who)+'</b> on '+esc(a.target)+': <q>'+esc(a.note)+'</q></div>'})+'</div>';
  bindHandover()}
function bindHandover(){var s=$("#hohours");if(s)s.onchange=function(){S.ho.hours=+s.value;S.ho.data=null;laneHandover();loadHandover()};var c=$("#hocopy");if(c)c.onclick=function(){if(S.ho.data)copyText(handoverText(S.ho.data))}}
function bindLane(){var v=$("#view"),b=$("#bmore");if(b)b.onclick=function(){S.limit+=50;render()};
  v.onclick=function(e){var cp=e.target.closest(".cp");if(cp){copy(cp.textContent,cp);return}
    var ip=e.target.closest("[data-ip]");if(ip){S.q=ip.dataset.ip;$("#q").value=S.q;sync();render();return}
    var r=e.target.closest("tr.lr[data-k]");if(r){var k=r.dataset.k;if(S.open.has(k))S.open.delete(k);else{S.open.add(k);if(!S.details[k])fetchDetail(k)}render();return}
    var rr=e.target.closest("tr.lr[data-rec]");if(rr){var id=rr.dataset.rec|0;S.endedOpen=S.endedOpen||{};S.endedOpen[id]=!S.endedOpen[id];if(S.endedOpen[id]&&!(S.recs&&S.recs[id]))loadRec(id);render()}}}
function loadRec(id){id=id|0;S.recs=S.recs||{};getJ("history-item?id="+id+"&product=clusters").then(function(D){S.recs[id]=D;var el=$("#rec-"+id);if(el)el.innerHTML=recHtml(D)}).catch(function(e){var el=$("#rec-"+id);if(el)el.textContent="Cannot read it: "+e.message})}
""").replace("//@@SHARED@@", _WORK_JS_SHARED).replace("//@@EVENTS@@", r"""// ---- work events: buttons, ticks, the menu, the lane tabs (captured first, so a card or a row does not open) ----
function workClick(e){var t=e.target,b=t.closest("[data-act]");cmClose();
  if(b){e.stopPropagation();e.preventDefault();var k=b.dataset.k,a=b.dataset.act;
    if(a==="menu"){var row=b.closest("[data-k],[data-rec]"),kk=row&&row.dataset.k;var items=kk&&rowItems(kk);if(items)cmAt(b,items);return}
    if(a==="close"&&k.slice(0,2)!=="r:"){closeMenu(b,k);return}
    if(a==="close"){cmAt(b,[{head:"Close it as"}].concat(CLOSEM.map(function(c){return {label:c[1]+" · "+c[2],run:function(){reviewRecord(k.slice(2),"close",c[0])}}})));return}
    if(a==="note")return noteDialog(k);
    return actOn(k,a)}
  var s=t.closest("[data-sel]");if(s){e.stopPropagation();if(s.checked)S.sel.add(s.dataset.sel);else S.sel.delete(s.dataset.sel);selBar();return}
  var al=t.closest("[data-alld]");if(al){e.stopPropagation();window.SCV.set("full");return}
  var sa=t.closest("[data-stepsall]");if(sa){e.stopPropagation();STEPS_ALL=true;var sh=sa.closest("[data-dk]");if(sh)redrawDetail(sh.dataset.dk);return}
  var st=t.closest("[data-step]");if(st){e.stopPropagation();stepCheck(st);return}
  var n=t.closest("[data-selnone]");if(n){e.stopPropagation();S.sel.clear();selBar();render();return}}
function menuClick(e){var x=e.target.closest(".cm-i");if(x&&CM){var it=CM._items[+x.dataset.cm];if(it&&it.run){e.preventDefault();cmClose();it.run()}else setTimeout(cmClose,0);return}
  if(CM&&!e.target.closest(".cm"))cmClose()}
$("#view").addEventListener("click",workClick,true);
document.addEventListener("click",menuClick);
$("#qact").onclick=function(e){e.stopPropagation();selMenu(this)};
$("#seln").addEventListener("click",function(e){if(e.target.closest("[data-selnone]")){S.sel.clear();selBar();render()}});
$("#tabs").onclick=function(e){var b=e.target.closest("[data-lane]");if(!b)return;S.lane=b.dataset.lane;S.limit=50;S.page=1;sync();cmClose();if(S.lane==="handover"&&!S.ho.data)loadHandover();render()};
$("#hideh").onchange=function(e){S.hideh=e.target.checked;S.page=1;S.limit=50;sync();render()};
document.addEventListener("contextmenu",function(e){if(e.shiftKey){cmClose();return}var row=e.target.closest&&e.target.closest("#view [data-k]");if(!row||e.target.closest("a,input,textarea,.cm"))return;
  var items=rowItems(row.dataset.k);if(items&&cmShow(items,e.clientX,e.clientY))e.preventDefault()});
document.addEventListener("keydown",function(e){if(!CM)return;var its=$$(".cm-i",CM),i=its.indexOf(document.activeElement);
  if(e.key==="Escape"){e.preventDefault();e.stopPropagation();cmClose()}else if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();if(!its.length)return;i=e.key==="ArrowDown"?(i+1)%its.length:(i-1+its.length)%its.length;its[i].focus()}
  else if(e.key==="Tab")cmClose()},true);
window.addEventListener("resize",cmClose);document.addEventListener("scroll",function(e){if(CM&&!(e.target&&e.target.closest&&e.target.closest(".cm")))cmClose()},true);
""")
_WORK_CSS = r"""/* ---- Simple view (1.3) on the Clusters board: body.simple. The cards and the detail panel are built in the script (SIMPLE); these rules hide the analysis tools ---- */
body.simple #tabs,body.simple #headline,body.simple #ovw{display:none!important}  /* one lane only; the noise headline; the overview tiles and histogram */
body.simple #clctl .vchips,body.simple #clctl .vsep,body.simple #clctl .sel-opt,body.simple #clctl #qact,body.simple #clctl #seln,body.simple #clctl #sortdd,body.simple #clctl>.tools+.tools{display:none!important}  /* view switches, per-host / critical / live / handled toggles, Action menu, sort, phase and type filters */
body.simple .vt .vl .mut{display:none}  /* the band bound after the count */
body.simple .bc-main{grid-template-columns:136px minmax(0,1fr) 18px}
body.simple .bc-sc{height:auto;border:0;background:none}body.simple .bc-sc .vp{height:28px;padding:0 12px;margin:0;font-size:13px;letter-spacing:.3px;color:#fff}body.simple .bc-sc .vp.review,body.simple .bc-sc .vp.investigate{color:var(--ink)}  /* a solid verdict badge, as in the Triage queue */
@media (max-width:1000px){body.simple .bc-main{grid-template-columns:84px minmax(0,1fr) 18px}}
.nxf{margin:8px 0 0;font-size:12px}.alld{margin:18px 0 6px;text-align:center}
.tabs{display:flex;flex-wrap:wrap;align-items:flex-end;margin:0 0 14px;border-bottom:1px solid #ffffff26}
.tab{display:flex;align-items:center;gap:8px;height:34px;margin:0 0 -1px;padding:0 14px;border:0;border-bottom:2px solid transparent;border-radius:6px 6px 0 0;background:none;color:#868c9b;font:inherit;font-size:14px;font-weight:500;cursor:pointer;white-space:nowrap}
.tab .ic{color:inherit;opacity:.85}
.tab:hover{color:#fff;border-bottom-color:#ffffff59}
.tab.on{color:#fff;background:#ffffff0d;border-bottom-color:var(--info)}
.tab.on .ic{color:#8cc4ff;opacity:1}
.tab .n{font:12px "Roboto Mono",monospace;padding:1px 7px;border-radius:9px;background:var(--panel2);color:#dfe3f0}
.tab .n+.n{margin-left:-4px}
.tab .n.v-act{background:#e0122d;color:#fff}
.tab .n.v-investigate{background:#ff7a00;color:var(--ink)}
.tab .n.hot{background:#7a1a2a;color:#fff}
.vp{display:inline-flex;align-items:center;justify-content:center;height:20px;padding:0 8px;border-radius:3px;background:var(--vc);color:#fff;font:400 12px/1 "Roboto Mono",ui-monospace,Menlo,monospace;letter-spacing:0;text-transform:uppercase;white-space:nowrap}
.vp.review,.vp.investigate{color:var(--ink)}
.tg,.chip,.stp{box-sizing:border-box;display:inline-flex;align-items:center;gap:5px;height:22px;padding:0 8px;border:1px solid #ffffff26;border-radius:11px;background:none;color:#cfd4e6;font:500 11px/1 "Kumbh Sans",sans-serif;letter-spacing:.2px;white-space:nowrap;vertical-align:middle}
.tg.new{color:#8cc4ff;border-color:#8cc4ff40}
.tg.rec{color:#dfe3f0;border-color:#ffffff40}
.tg.jw{color:#ffd700;border-color:#ffd70059}
.tg.st{color:#7fe0a7;border-color:#7fe0a740}
.stp{border-color:color-mix(in srgb,currentColor 38%,transparent)}
.stp.st0{color:#dfe3f0;border-color:#ffffff30}
.stp .own{color:var(--mut);font-weight:400}
.stp.st-ch{height:auto;min-height:22px;padding:3px 8px;white-space:normal;line-height:1.25}
.b2{height:28px;padding:0 11px;border:0;border-radius:4px;background:var(--panel2);color:#fff;font:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
.b2:hover{background:var(--head)}
.b2.pri{background:var(--blue)}
.b2.pri:hover{background:#3a62ff}
.b2.warn{background:#5c1a2b}
.b2:disabled{opacity:.4;cursor:default}
.pill2{display:inline-block;margin:0 4px 3px 0;padding:1px 7px;border-radius:9px;background:var(--panel2);font-size:11px;color:#dfe3f0;white-space:nowrap}
.tri{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:4px 0 6px}
.tri .st{font-size:12px;color:var(--mut)}
.st0{color:#dfe3f0}
.st-ack,.st-resolved{color:#7fe0a7}
.st-investigating{color:#8cc4ff}
.st-fp{color:#a8aec4}
.st-ch{color:#ffb3c0}
.b2.off{opacity:.35;cursor:default}
.bulk{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:4px 0 6px}
.qsec td{padding:11px 14px 8px;border-top:1px solid #ffffff12;background:#0000002b!important;box-shadow:none!important;cursor:default}
.qsec-l{color:var(--vc);font-weight:600;font-size:13px;letter-spacing:.3px}
.dlg-w{position:fixed;inset:0;z-index:90;display:flex;align-items:flex-start;justify-content:center;padding:12vh 16px 0;background:#05061acc}
.dlg{width:min(560px,100%);padding:18px 20px 16px;border:1px solid var(--panel2);border-radius:8px;background:#161740;box-shadow:0 18px 50px #000c}
.dlg h3{margin:0 0 10px;font-size:16px;font-weight:600}
.dlg-b{margin:0 0 10px;color:#cfd4e6;font-size:13px;line-height:1.5}
.dlg-b p{margin:6px 0}
.dlg-f{display:flex;flex-direction:column;gap:5px;margin:0 0 10px;color:var(--mut);font-size:12px}
.dlg-f input,.dlg-f select,.dlg-f textarea{padding:7px 9px;border:1px solid var(--panel2);border-radius:5px;background:var(--panel);color:#fff;font:inherit;font-size:13px}
.dlg-f .req{color:#ffb3c0;font-weight:400}
.dlg-err{min-height:16px;color:#ffb3c0;font-size:12px}
.dlg-a{display:flex;justify-content:flex-end;gap:8px;margin-top:6px}
.scope-box{margin:0 0 10px;padding:8px 10px;border-radius:5px;background:var(--panel)}
.st-escalated{color:#e0a8ff}
.st-tp{color:#7fe0a7}
.st-benign{color:#5fe0c4}
.mine{font-weight:600}
.me{margin-right:10px;color:var(--mut);font-size:13px;background:none;border:0;cursor:pointer}
.me.sy{color:#cfd4e6;cursor:default}
.vok{margin-left:3px;color:#7fe0a7;font-size:12px}
.nxc{margin-left:6px;color:var(--mut);font-weight:400;text-transform:none;letter-spacing:0}
.nxo{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:0}
.nx{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-start;padding:9px 12px;border-top:1px solid #ffffff10;border-left:3px solid #4aa3ff}
.nx:first-child{border-top-color:transparent}
.nx.nx-ask{border-left-color:#c9a05b}
.nx.nx-act{border-left-color:#ff5d73}
.nx input{margin:2px 0 0;width:16px;height:16px;flex:none;cursor:pointer;accent-color:#3ecf72}
.nx .nxb{width:16px;flex:none}
.nxt{min-width:0}
.nxt b{font-weight:600;color:#fff}
.nx.ok .nxt b{color:var(--mut);text-decoration:line-through;text-decoration-color:#3ecf7280}
.nxk{display:inline-block;min-width:46px;margin-right:6px;font:600 10.5px "Roboto Mono",monospace;text-transform:uppercase;letter-spacing:.4px;color:#8cc4ff}
.nx-ask .nxk{color:#e0b86a}
.nx-act .nxk{color:#ff8b98}
.nxl{font-size:13px}
.nxt .mut{font-size:12.5px;margin-top:2px}
.nxd{margin-top:2px;color:#7fe0a7;font-size:12px}
.tg.pri{color:#dfe3f0;font-weight:600}
.tg.pri.p1{background:#e0122d;border-color:#e0122d;color:#fff}
.st-unrev{color:#ffcf8a}
.ii{position:relative;display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:7px;border:1px solid #5d6290;border-radius:50%;color:#a9b0d8;font:italic 600 10px/1 Georgia,serif;text-transform:none;letter-spacing:0;vertical-align:1px;cursor:help;flex:none}
.ii:hover,.ii:focus{border-color:#8cc4ff;color:#fff;outline:none}
.iit{display:none;position:absolute;left:-12px;top:22px;z-index:65;width:max-content;max-width:min(420px,72vw);padding:10px 12px;border:1px solid var(--pop);border-radius:6px;background:var(--panel2);box-shadow:0 8px 24px #000b;color:#cfd4e6;font:400 12.5px/1.5 "Kumbh Sans",sans-serif;text-align:left;white-space:normal}
.ii.r .iit{left:auto;right:-12px}
.ii:hover .iit,.ii:focus .iit{display:block}
.iit b{color:#fff}
.cm{position:fixed;z-index:96;min-width:250px;max-width:360px;max-height:80vh;overflow:auto;padding:6px;border:1px solid #2d2e55;border-radius:8px;background:#0a061a;box-shadow:0 12px 32px #000c}
.cm-h{padding:6px 8px 3px;color:#868c9b;font-size:12px}
.cm-h .mono{color:#fff;font-size:12.5px}
.cm-i{display:flex;align-items:center;gap:8px;width:100%;padding:7px 8px;border:1px solid transparent;border-radius:8px;background:none;color:#c8ccd8;font:inherit;font-size:13px;line-height:1.3;text-align:left;cursor:pointer;white-space:nowrap;text-decoration:none}
.cm-i:hover,.cm-i:focus{outline:0;background:#ffffff0d;color:#fff;text-decoration:none}
.cm-i:focus-visible{border-color:#ffffff40}
.cm-x{margin-left:auto;padding-left:14px;color:#868c9b}
.cm-sep{margin:5px 2px;border-top:1px solid #ffffff14}
/* the work layer on the Clusters page (cards, table rows, lanes) */
.bc-work{display:flex;align-items:center;gap:12px;padding:6px 16px 8px 20px;border-top:1px solid #ffffff0b;font-size:12px}
.bc-work .wl{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px;flex:1;min-width:0}
.bc-work .btns{flex:none}
.bc-work .btns,.la .btns,.job summary .btns{display:inline-flex;align-items:center;gap:4px}
.bc-work .wst{display:inline-flex}
.bc-work .b2,.la .b2,.job .b2{height:26px;padding:0 9px}
.bc-work input[type=checkbox]{-webkit-appearance:none;appearance:none;width:18px;height:18px;border:2px solid rgba(255,255,255,.25);border-radius:4px;background:var(--panel2);cursor:pointer;position:relative;flex:none;margin:0}
.bc-work input[type=checkbox]:checked{background:var(--blue);border-color:var(--blue)}
.bc-work input[type=checkbox]:checked::after{content:"";position:absolute;left:4px;top:0;width:4px;height:9px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}
.bc.handled,.job.handled summary,.lt tr.handled{opacity:.6}
.bc-chain{display:inline-flex;align-items:center;min-width:0}
.chainline{font-size:12.5px;color:#8cc4ff;line-height:1.5}
.chainline b{font-weight:600}
.chainbox{margin:6px 0 8px;padding:6px 10px;border-left:3px solid var(--blue);background:var(--panel)}
.chips{display:inline-flex;flex-wrap:wrap;align-items:center;gap:4px 5px;font-size:11px;line-height:1}
.chips .chl{color:#868c9b;margin-right:2px;white-space:nowrap;line-height:22px}
.chip{color:#8cc4ff;border-color:#4a5a82;cursor:default}
.chip.top{background:var(--blue);border-color:var(--blue);color:#fff}
.heat{display:inline-flex;gap:3px;align-items:flex-end;vertical-align:middle}
.heat .hc{display:inline-flex;flex-direction:column;align-items:center;gap:3px}
.heat i,.hlg i{box-sizing:border-box;display:block;width:10px;height:10px;border-radius:2px}
.heat i.h-1,.hlg i.h-1{background:#22427a}.heat i.h-2,.hlg i.h-2{background:#2f62b8}.heat i.h-3,.hlg i.h-3{background:#4a8af0}.heat i.h-4,.hlg i.h-4{background:#8cc4ff}
.heat i.h-0,.hlg i.h-0{border:1px solid #454c80}
.heat i.h-none,.hlg i.h-none{border:1px dashed #5d6494}
.heat i.h-today,.hlg i.h-today{outline:1px solid #ffffffb3;outline-offset:1px}
.heat.lbl i{width:22px;height:16px}
.job summary .heat{gap:2px}.job summary .heat i{width:8px;height:8px}
.hlg{display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--mut)}.hlg span+i{margin-left:6px}
.heat em{font-style:normal;font-size:10px;color:var(--mut)}
.job summary .tg+.heat,.job summary .tg{margin-right:6px}
.more-cl{font-size:12px;color:var(--mut)}
.more-cl b{color:#fff;font-weight:600}
.more-cl .sq{margin:0 4px 0 2px}
.chron{margin-top:14px}
.chron>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:10px;padding:10px 4px;font-weight:600}
.chron>summary::-webkit-details-marker{display:none}
.chron[open]>summary .caret{transform:rotate(90deg);border-left-color:var(--info)}
.chron>summary:hover{color:#fff}
.tlist .tli{padding:3px 0;font-size:13px;line-height:1.5}
.tli .mono{margin-right:6px}
.tli .vp{margin-right:8px}
.tlist q{quotes:"\201C" "\201D";color:#fff}
.memrow{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.lt td{vertical-align:top;font-size:13px}
.lt tr.lr{cursor:pointer}
.lt tr.lr:hover td{background:var(--hover)}
.lt td.la{white-space:nowrap}
.lt tr.lrd td{background:var(--panel);padding:0}
.lt .more{white-space:normal}
.tri.wp{align-items:center}
.ho h3{font-size:12px;margin:14px 0 6px;color:var(--mut);text-transform:uppercase;letter-spacing:.6px;font-weight:400}
.bc-more h3,.more h3{display:flex;align-items:center;flex-wrap:wrap}
.bc-more,.more{min-width:0;overflow-wrap:anywhere}
.job summary>span.c-chain,.jhead>span.c-chain{white-space:normal}
.job summary>span.c-status{flex-wrap:wrap;gap:0 6px;padding-top:5px;padding-bottom:5px;white-space:normal;line-height:1.3;overflow:visible}
.job summary>span.c-chain{flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;padding-top:5px;padding-bottom:5px;overflow:visible}
"""


# ---- Scoring model ----------------------------------------------------------------------------------------

def scoring_page(settings: Settings, critical: set[str], model: scoring.Model, board=None, offset_min: int = 0) -> str:
    from sycope_clusters.ui import evidence_doc
    phase_of: dict[int, list[str]] = {}
    for tactic, idx in TACTIC_PHASE.items():
        phase_of.setdefault(idx, []).append(tactic)
    phases = _grid(["Stage", "Index", "MITRE tactics"],
                   [[f'<span class="badge ph ph-{_e(PHASE_NAMES[i])}">{_e(PHASE_NAMES[i])}</span>', str(i),
                     _e(", ".join(t))] for i, t in sorted(phase_of.items())])
    by_type: dict[str, list[str]] = {}
    for name, rule in rules.CATALOG.items():
        by_type.setdefault(rule.family, []).append(name)
    types = _grid(["Type", "Label", "Alert names"],
                  [[f'<span class="tdot" style="background:{TYPE_COLORS.get(t, "#808297")}"></span>{_e(t)}',
                    _e(rules.FAMILIES[t][0]), _e(", ".join(sorted(set(n))))] for t, n in sorted(by_type.items())])
    crit = ", ".join(sorted(critical)) or "none configured"
    presets = "".join(
        f'<label class="pset"><input type="radio" name="preset" value="{_e(scoring.wire(k))}"{" checked" if k == model.preset else ""}>'
        f'<span><b>{_e(p["label"])}</b><span class="mut">{_e(p["help"])}</span></span></label>'
        for k, p in scoring.PRESETS.items())

    def num_in(name: str, label: str, tip: str, step: str = "any") -> str:
        return (f'<label class="fld2"><span>{_e(label)}{_info(tip)}</span>'
                f'<input type="number" step="{step}" name="{name}" value="{getattr(model, name):g}"></label>')
    mult = "".join(f'<label class="fld2 sm"><span><span class="badge b-{x.lower()}">{x}</span></span>'
                   f'<input type="number" step="0.05" name="m_{x}" value="{model.multipliers.get(x, 0):g}"></label>'
                   for x in scoring.SEVERITIES)
    can = settings.scoring_edit
    save = ('<button type="button" class="btn-pri" id="save">Use this model for everyone</button>' if can else
            '<button type="button" class="btn-pri" disabled title="Saving is switched off by the administrator">Saving is off</button>'
            '<span class="mut" style="font-size:12px">The preview works; saving is switched off by the administrator.</span>')
    body = f"""
<h1 class="ptitle">Scoring model</h1>
{evidence_doc(board)}
<h1 class="ptitle" style="margin-top:28px">Clusters: how the ranking is built</h1>
<div class="card doc"><h2 class="ct">What the ranking promises, and where the default breaks it</h2>
<p>The idea of the model is that the kill-chain stage decides first: a cluster that reached a later stage outranks one
that stopped earlier, and severity, crown jewels and alert variety only order clusters <i>within</i> a stage. Each stage
is worth 10000 points so that nothing else can jump it. The default formula does not keep that promise, for two reasons:</p>
<p><b>1. The stage is scaled by a severity that may belong to another stage.</b> the default formula multiplies
<code>stage × 10000</code> by the highest severity anywhere in the cluster. Host 10.240.46.109 on the lab: a Critical
<i>Suspicious IP - Phishing</i> (Foothold), a Medium <i>LLMNR</i> alert (Lateral) and a Medium alert that reached
Objectives. The code computes
3 × 10000 × 1.0 = 30000, priority 85, Act now: the Phishing alert's severity is lent to the Objectives alert. The per-alert
variant takes the best product per alert instead (max of stage × severity): Objectives × Medium
= 3 × 10000 × 0.6 = 18000, Foothold × Critical = 10000, Lateral × Medium = 12000, so 18000, priority 55, Review.</p>
<p><b>2. Even per alert, severity and the other terms jump stages.</b> Lateral × Critical = 20000 beats Objectives × Medium
= 18000. A crown jewel adds 6000 and Σ severity × 200 has no cap (ten High types = 8000), so a Lateral cluster on a crown
jewel outranks an Objectives cluster elsewhere. That can be the right call (a brute force on the domain controller matters more
than one cleartext session), but then the promise is "severity-weighted", not "nothing jumps a stage".</p>
<p>So this is a product decision, not a bug to fix silently: <b>strict stages</b> (an analyst can trust that the top is
always the furthest attack) or <b>severity-weighted</b> (the top is the most dangerous mix). The presets below cover both;
every number is editable, and the preview shows on the live data what changes before anyone's board does.
"Stage jumps" counts clusters that outrank at least one cluster of a later stage: 0 means strict.</p></div>

<div class="card"><h2 class="ct">Model</h2>
<div class="psets">{presets}</div>
<form id="mf" class="mform" onsubmit="return false">
<div class="frow">
  <label class="fld2"><span>Severity of the stage{_info("cluster = the highest severity anywhere in the cluster. stage = each alert type's own severity at its own stage; the best stage × multiplier wins.")}</span>
    <select name="severity_source"><option value="cluster"{" selected" if model.severity_source == "cluster" else ""}>highest in the cluster</option>
    <option value="stage"{" selected" if model.severity_source == "stage" else ""}>of the alert at that stage</option></select></label>
  <label class="fld2"><span>Strict stages{_info("On: a cluster never leaves its stage's band of P points; everything after the stage is capped at P − 1 and severity adds at most B inside the band.")}</span>
    <label class="sw"><input type="checkbox" name="strict"{" checked" if model.strict else ""}><span></span></label></label>
  {num_in("stage_points", "Points per stage (P)", "stage index × P; Recon 0, Foothold 1, Lateral 2, Objectives 3.")}
  {num_in("severity_band", "Severity inside the stage (B)", "Strict only: multiplier × B points inside the band.")}
</div>
<div class="frow"><span class="flbl">Severity multiplier</span>{mult}</div>
<div class="frow">
  {num_in("crown_jewel", "Crown jewel (C)", "Added when the anchor IP is in the critical hosts file. Now: " + crit)}
  {num_in("per_type", "Per Σ severity of alert types (S)", "Σ over alert types of their highest severity weight (Critical 5 … Info 1) × S.")}
  {num_in("per_type_cap", "Cap of that term", "0 = no cap.")}
  {num_in("progression", "Kill-chain progression (G)", "progression (0-1, share of alert pairs that move forward) × G.")}
  {num_in("progression_cap", "Cap of that term", "0 = no cap.")}
</div>
<div class="frow">
  {num_in("full", "Score that reads as priority 100", "priority = score / this × 100, capped at 100. A fixed scale: the same score always shows the same priority.")}
  {num_in("act", "Act now from", "priority ≥ this", "1")}
  {num_in("investigate", "Investigate from", "priority ≥ this", "1")}
  {num_in("review", "Review from", "priority ≥ this; below = Watch", "1")}
</div>
<div class="acts" style="margin-top:14px">{save}<span id="msg" class="mut"></span></div>
</form></div>

<div class="card"><div class="cth"><h2 class="ct">Preview on the live data (last 6 hours, one row per host)</h2><span class="mut" id="pvst"></span></div>
<div id="pv"><div class="loading">…</div></div></div>

<div class="card"><h2 class="ct">Kill-chain stages</h2>{phases}<p class="mut" style="font-size:12px;margin:8px 0 0">Command
and Control sits in Foothold here and in Triage; Collection sits in Lateral.</p></div>
<div class="card doc"><h2 class="ct">How a cluster is built</h2>
<p>Every alert names a client IP and a server IP. Each is an <b>anchor</b>: the alerts of one anchor are chained in time
while the gap is at most <b>{max(settings.delta_seconds, clusters.MIN_DELTA_S) // 60} min</b>; chains of fewer than <b>{settings.min_alerts}</b> alerts
are dropped. One alert can be in two clusters. The clustering runs over the last
<b>{settings.retention_hours} h</b>, read from Sycope every <b>{settings.poll_seconds} s</b>. Alerts of the same minute are ordered by id before progression is counted (so the score does not change between
runs), progression is counted in one pass, and current Sycope alert names were added to the type map.</p></div>
<div class="card"><h2 class="ct">Alert name → cluster type</h2>{types}</div>
"""
    full = {scoring.wire(k): {**dataclasses.asdict(scoring.preset(k)), "preset": scoring.wire(k)} for k in scoring.PRESETS}
    script = "<script>" + _SCORING_JS.replace("__PRESETS__", json.dumps(full)) + "</script>"
    return _page("Scoring model · Sycope Security Clusters", body, "scoring", settings, sub="Scoring model", script=script,
                 product="clusters", offset_min=offset_min)


_SCORING_JS = r"""
(function(){
var F=document.getElementById("mf"),PV=document.getElementById("pv"),VC={act:"#e0122d",investigate:"#ff7a00",review:"#e5c100",watch:"#4aa3ff"},VL={act:"Act now",investigate:"Investigate",review:"Review",watch:"Watch"};
var PRESETS=__PRESETS__;
function esc(v){return v==null?"":String(v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function model(){var m={preset:(document.querySelector("input[name=preset]:checked")||{}).value||"custom",multipliers:{}};
  F.querySelectorAll("input[type=number]").forEach(function(i){if(i.name.indexOf("m_")===0)m.multipliers[i.name.slice(2)]=+i.value;else m[i.name]=+i.value});
  m.severity_source=F.severity_source.value;m.strict=F.strict.checked;return m}
function fill(m){Object.keys(m).forEach(function(k){if(k==="multipliers"){Object.keys(m.multipliers).forEach(function(s){var i=F["m_"+s];if(i)i.value=m.multipliers[s]})}
  else if(k==="strict")F.strict.checked=!!m.strict;else if(k==="severity_source")F.severity_source.value=m.severity_source;else if(F[k]&&F[k].type==="number")F[k].value=m[k]})}
document.querySelectorAll("input[name=preset]").forEach(function(r){r.onchange=function(){fill(PRESETS[r.value]);preview()}});
var t=null;F.addEventListener("input",function(){var c=document.querySelector("input[name=preset]:checked");if(c)c.checked=false;clearTimeout(t);t=setTimeout(preview,350)});
function counts(v){return ["act","investigate","review","watch"].map(function(k){return '<span class="vc" style="--vc:'+VC[k]+'"><b>'+(v[k]||0)+'</b>'+VL[k]+'</span>'}).join("")}
function row(r){return '<td class="mono">'+esc(r.ip)+'</td><td><b>'+esc(r.priority)+'</b> <span class="badge" style="background:'+VC[r.verdict]+';color:'+(r.verdict==="review"||r.verdict==="investigate"?"#222957":"#fff")+'">'+esc(VL[r.verdict])+'</span></td><td>'+esc(r.stage||"")+'</td><td>'+esc(r.lead||"")+'</td><td>'+esc(r.severity||"")+'</td>'}
function preview(){document.getElementById("pvst").textContent="computing…";
  fetch("scoring-preview?model="+encodeURIComponent(JSON.stringify(model())),{credentials:"same-origin"}).then(function(r){return r.json().then(function(j){return [r.ok,j]})}).then(function(x){
    var j=x[1];if(!x[0]){PV.innerHTML='<div class="errbox">'+esc(j.error)+'</div>';document.getElementById("pvst").textContent="";return}
    var a=j.current,b=j.preview,n=Math.max(a.top.length,b.top.length),rows="";for(var i=0;i<n;i++)rows+='<tr><td>'+(i+1)+'</td>'+(a.top[i]?row(a.top[i]):'<td colspan="5"></td>')+'<td class="vsp"></td>'+(b.top[i]?row(b.top[i]):'<td colspan="5"></td>')+'</tr>';
    PV.innerHTML='<div class="cmp"><div><h3>Now on the board</h3><div class="vcs">'+counts(a.verdict_hosts)+'</div><div class="mut">stage jumps: <b style="color:#fff">'+a.stage_jumps+'</b></div></div>'
      +'<div><h3>With this model</h3><div class="vcs">'+counts(b.verdict_hosts)+'</div><div class="mut">stage jumps: <b style="color:#fff">'+b.stage_jumps+'</b></div></div></div>'
      +'<div class="grid"><table><tr><th>#</th><th>Host</th><th>Priority</th><th>Stage</th><th>Lead alert</th><th>Severity max</th><th class="vsp"></th><th>Host</th><th>Priority</th><th>Stage</th><th>Lead alert</th><th>Severity max</th></tr>'+rows+'</table></div>';
    document.getElementById("pvst").textContent="left: the model in use · right: this form"})
  .catch(function(e){PV.innerHTML='<div class="errbox">'+esc(e.message)+'</div>'})}
var sv=document.getElementById("save");if(sv)sv.onclick=function(){if(!confirm("Rank everyone's board with this model?"))return;
  fetch("scoring-model",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-SC-Action":"1"},body:JSON.stringify(model())})
  .then(function(r){return r.json().then(function(j){return [r.ok,j]})}).then(function(x){document.getElementById("msg").textContent=x[0]?"Saved. The board uses it now.":"Refused: "+(x[1].error||"?");if(x[0])preview()})
  .catch(function(e){document.getElementById("msg").textContent="Failed: "+e.message})};
preview();
})();
"""


# ---- System status ----------------------------------------------------------------------------------------

def health_card(h: dict) -> str:
    """The Health card of the System page, for everyone: what Sycope sends, what is switched off and why, how the
    service is doing (health.summary). What is about the configuration (its version, whether it is modified, its
    errors, playbook warnings, suggestions waiting) is for admins: the Configuration tab shows it from /health-data."""
    cw = set(h["config_warnings"])
    ops = [w for w in h["warnings"] if w not in cw]
    warn = ("<ul>" + "".join(f"<li>{_e(w)}</li>" for w in ops) + "</ul>" if ops else
            '<p class="mut">The configuration has a problem an admin should look at (Configuration tab).</p>' if cw else
            '<p class="mut" id="hok">Nothing needs attention.</p>')
    tz = (f'<div id="tzwarn" class="cfwarn" data-off="{int(h["utc_offset_min"])}" hidden><span></span> '
          f'<button type="button" class="b2" id="tzfix" hidden></button></div>')
    fields = (_grid(["Alert field", "Filled", "State"],
                    [[f"<code>{_e(f)}</code>", f"{v * 100:.0f} %",
                      '<span class="st st-ok">OK</span>' if v >= h.get("fill_warn", 0.5) else
                      '<span class="st st-warn">LOW</span>' if v >= health.FLOOR else
                      '<span class="st st-warn" title="Your Sycope lookup assigns no host functions: not a data problem '
                      'of the alerts">NOT IN LOOKUP</span>' if f.endswith("Function") else
                      '<span class="st st-warn">MISSING</span>'] for f, v in sorted(h["fields"].items())])
              if h["fields"] else '<p class="mut">Too few alerts in the window to measure the fields yet.</p>')
    off = ("<ul>" + "".join(f"<li><b>{_e(t['term'].replace('_', ' '))}</b>: {_e(t['text'])} "
                            f"(needs {_e(', '.join(t['needs']))})</li>" for t in h["disabled"]) + "</ul>"
           if h["disabled"] else '<p class="mut">Every scoring term has the fields it needs.</p>')
    nc = h["norm_conf"]
    prof = (f"{h['profile_days']} of {profile.WANT_DAYS} days learned from, {h['dormant_days']} dormant"
            + (f"; shares {nc['share'] * 100:.0f} % confident" if nc["share"] is not None else "")
            + (f"; {nc['volume_hosts']:,} host volume norms, {nc['volume_low']:,} of low confidence"
               if nc["volume_hosts"] else "") + ("; frozen" if h["profile_frozen"] else ""))
    cov = (", ".join(f"{_e(d)}: {n}/24 h" for d, n in sorted(h["flow_coverage"].items(), reverse=True)) or
           "no netflow aggregated yet")
    rows = [
        ("Profile", _e(prof)),
        ("Alert names not in the catalog", f"{len(h['unknown_rules']):,}" + (
            ": " + ", ".join(_classify_link(r["name"]) for r in h["unknown_rules"][:12])
            + (", ..." if len(h["unknown_rules"]) > 12 else "") + ". " + UNKNOWN_HELP + " (admins)"
            if h["unknown_rules"] else "")),
        ("Hosts without a lookup row", f"{h['unmapped_hosts']:,}"),
        ("Lookup rows", f"{h['unknown_privacy']:,} with an unreadable privacy value, {h['bad_cidr']:,} with an "
                        f"unreadable network" + (f"; last read failed: {_e(h['lookup_error'])}" if h["lookup_error"]
                                                 else "")),
        ("Memory", f"about {h['mem_mb']:,.0f} of {h['mem_budget_mb']:,} MB"
                   + (f"; thinned to level {h['degrade_level']} of 3" if h["degrade_level"] else "")),
        ("Last rebuild", f"{h['rebuild_s']:.2f} s" if h["rebuild_s"] is not None else "not built yet"),
        ("Stored days", f"learning failed, the board scores without them: {_e(h['past_error'])}" if h["past_error"]
         else "being learned: the board is on the priors and writes no incidents yet" if h["provisional"]
         else "learned"),
        ("Poll", ("never succeeded" if h["poll_lag_s"] is None else f"last good poll {h['poll_lag_s']:,.0f} s ago")
                 + f"; next poll in {h['poll_wait_s']:,.0f} s"),
        ("Silence rules", f"{h.get('silence_rules', 0):,} in force, {h.get('silenced_alerts', 0):,} alerts silenced in "
                          f"the last 24 hours" + ("; hiding a spike: " + "; ".join(_e(x["text"]) for x in h["silence_spikes"])
                                                  if h.get("silence_spikes") else "")),
        ("Last backup", _ts(h["last_backup"]) if h["last_backup"] else "none yet"),
        ("Webhook", _webhook_line(h.get("webhook") or {})),
        ("Netflow coverage", cov + (f"; last error: {_e(h['flowagg_error'])}" if h["flowagg_error"] else "")),
    ]
    kv = "".join(f'<div><span class="mut">{_e(k)}</span>{v}</div>' for k, v in rows)
    return (f'<div class="card"><h2 class="ct">Health</h2>{warn}{tz}<div class="kv">{kv}</div>'
            f'<h3 class="ct" style="margin-top:14px">Switched off for missing data</h3>{off}'
            f'<h3 class="ct" style="margin-top:14px">Fields Sycope sends</h3>{fields}</div>')


_SYSTEM_JS = r"""
(function(){var p=null;try{p=JSON.parse(localStorage.getItem("sc-pass")||"null")}catch(x){}
function e(v){return String(v==null?"":v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function ul(m){var s=m<0?"-":"+",a=Math.abs(m),h=Math.floor(a/60),r=a%60;return "UTC"+s+h+(r?":"+(r<10?"0":"")+r:"")}
// the calendar offset against the browser's: said to everyone, fixed by an admin through the configuration plane
var tw=document.getElementById("tzwarn");
if(tw){var br=-new Date().getTimezoneOffset(),cf=+tw.dataset.off;
  if(br!==cf){tw.hidden=false;tw.querySelector("span").textContent="Weekday and weekend learning uses "+ul(cf)+" but your browser is "+ul(br)+": days are cut at the wrong hour and holidays can land on the wrong weekday.";
    var ok=document.getElementById("hok");if(ok)ok.hidden=true;
    if(p&&p.pass){var fx=document.getElementById("tzfix");fx.hidden=false;fx.textContent="Use "+ul(br);
      fx.onclick=function(){if(!confirm("Publish a configuration that sets the calendar offset to "+ul(br)+"? The profile is learned again with it."))return;
        var H={Accept:"application/json","X-SC-Pass":p.pass},A={"Content-Type":"application/json","X-SC-Action":"1","X-SC-Pass":p.pass};
        function act(b){return fetch("action",{method:"POST",credentials:"same-origin",headers:A,body:JSON.stringify(Object.assign({product:PRODUCT},b))}).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})}
        fx.disabled=true;
        fetch("config",{credentials:"same-origin",headers:H}).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})}).then(function(c){
          var b=JSON.parse(JSON.stringify(c.body||{params:{},catalog:{},playbook:[],internal:{}}));b.params=b.params||{};b.params["calendar.utc_offset_min"]=br;
          return act({op:"config:draft",body:b,note:"Calendar offset set to "+ul(br)+" (the browser's)"})}).then(function(d){return act({op:"config:publish",id:d.id})})
        .then(function(){location.reload()}).catch(function(x){fx.disabled=false;alert("Refused: "+x.message)})}}}}
if(!p||!p.pass)return;
fetch("system-config",{credentials:"same-origin",headers:{Accept:"application/json","X-SC-Pass":p.pass}}).then(function(r){return r.ok?r.json():null}).then(function(d){
  if(!d)return;
  // two columns: Setting (label and an (i)) and Value; the meaning, the environment variable and the file path are in
  // a detail row under the setting, closed until the (i) or the label is clicked
  var rows=d.rows.map(function(r){return '<tr class="cfgr"><td style="white-space:nowrap"><span class="cfgl" style="cursor:pointer">'+e(r.label)+'</span><span class="info" tabindex="0" role="button" aria-expanded="false" aria-label="What '+e(r.label)+' means" style="cursor:pointer">i</span></td><td style="overflow-wrap:anywhere"><code style="white-space:normal;overflow-wrap:anywhere">'+e(r.value)+'</code></td></tr>'
    +'<tr class="cfgd" style="display:none"><td colspan="2" class="mut" style="font-size:12.5px;overflow-wrap:anywhere">'+e(r.help)+(r.tip?'<div class="mono" style="margin-top:3px">'+e(r.tip)+'</div>':'')+'</td></tr>'}).join("");
  var box=document.getElementById("cfgbody");
  box.innerHTML='<div class="grid"><table><tr><th>Setting</th><th>Value</th></tr>'+rows+'</table></div>';
  function cfgSet(tr,open){var d2=tr.nextElementSibling,i=tr.querySelector(".info");d2.style.display=open?"":"none";i.setAttribute("aria-expanded",open?"true":"false")}
  function cfgFlip(tr){cfgSet(tr,tr.nextElementSibling.style.display==="none")}
  box.querySelectorAll("tr.cfgr").forEach(function(tr){
    tr.querySelector(".cfgl").onclick=function(){cfgFlip(tr)};
    var i=tr.querySelector(".info");i.onclick=function(){cfgFlip(tr)};
    i.onkeydown=function(ev){if(ev.key==="Enter"||ev.key===" "){ev.preventDefault();cfgFlip(tr)}}});
  var all=document.getElementById("cfgall");
  if(all)all.onclick=function(ev){ev.preventDefault();var open=all.dataset.open!=="1";
    box.querySelectorAll("tr.cfgr").forEach(function(tr){cfgSet(tr,open)});all.dataset.open=open?"1":"";all.textContent=open?"Collapse all":"Expand all"};
  document.getElementById("cfgcard").style.display=""}).catch(function(){})})();
"""


def _webhook_line(w: dict) -> str:
    if not w.get("on"):
        return "not configured"
    out = f"{w['delivered']:,} delivered, {w['failed']:,} failed"
    if w.get("dropped"):
        out += f", {w['dropped']:,} dropped (queue full)"
    out += f"; {w['queued']:,} waiting"
    if w.get("last_error_at") and (w.get("last_ok_at") or 0) < w["last_error_at"]:
        out += f"; last delivery failed at {_ts(w['last_error_at'])}: {_e(w['last_error'])}"
    return out


def system_config(settings: Settings, live) -> dict:
    """The Configuration rows of the System page, for admins only (/system-config): a human label, the value and the
    meaning; the environment variable name and, for the state directory, the database file go in the tooltip."""
    rows = []
    for k in HELP:
        v = getattr(settings, k)
        path = k == "state_dir" or k.endswith("_file")
        secret = k in ("sycope_password", "webhook_secret")
        v = ("•••• (set)" if v else "(not set)") if secret else (
            "set" if v else "not set") if path or k == "webhook_url" else v   # the URL may carry a token
        tip = f"SC_{k.upper()}" + (f" · {getattr(settings, k)}" if path and getattr(settings, k) else "") \
            + (f" · database {live.store.path}" if k == "state_dir" and live.store else "")
        rows.append({"label": k.replace("_", " ").capitalize(), "value": str(v),
                     "help": re.sub(r"SC_[A-Z_]+", "the setting", HELP[k]), "tip": tip})
    return {"rows": rows}


def system_page(settings: Settings, live, version: str = VERSION, product: str = "triage") -> str:
    snap, last = (live.cboard.snapshot if live.cboard else None), live.last
    st = ('<span class="st st-ok">&#9650; OK</span>' if last.ok else
          '<span class="st st-warn">&#9632; WAITING</span>' if not last.at else '<span class="st st-fail">&#9660; FAIL</span>')
    hist = _grid(["Poll", "Result", "Window", "Read", "New", "Took"],
                 [[_ts(p.at), ('<span class="st st-ok">OK</span> ' if p.ok else '<span class="st st-fail">FAIL</span> ')
                   + _e(p.message), _ts(p.window[0]) + " – " + _ts(p.window[1]), f"{p.fetched:,}",
                   f"{p.new:,}", f"{p.took_s:.1f} s"] for p in live.history])
    unk = snap.unknown_names if snap else {}
    unknown = (_grid(["Alert name", "Alerts"], [[_classify_link(n), f"{c:,}"] for n, c in unk.items()])
               + f'<p class="mut" style="font-size:12px">{UNKNOWN_HELP}</p>' if unk else
               '<p class="mut">Every alert name is in the rule catalog.</p>')
    snap_line = (_e(f"{pipeline.alert_total(snap.alerts):,} alerts of acting hosts, {len(snap.clusters):,} clusters, "
                    f"engine {snap.took_s:.2f} s, built ") + _ts(snap.built_at) if snap else "no snapshot yet")
    b, bf = live.board, live.backfill
    board_line = (f"{b.findings:,} findings, {b.counts['actors']:,} acting hosts, {len(b.stories)} stories, "
                  f"built in {b.took_s:.2f} s" if b else "not built yet")
    w = live.window.stats()
    window_line = (f"{w['alerts']:,} alerts in {w['buckets']:,} hourly buckets over {w['hours']} hours, raw alerts of "
                   f"{w['hosts']:,} hosts; memory about {live.mem_bytes() / 2**20:,.0f} of {settings.memory_mb:,} MB "
                   f"(window {w['mem_bytes'] / 2**20:,.0f} MB, the rest scoring)"
                   + (f"; thinned to level {w['level']} of 3 (class A and B never)" if w["level"] else ""))
    days = live.store.days()
    day_rows = [[_e(d), f"{v['alerts'] or 0:,}", f"{v['findings'] or 0:,}", _ts(v["fetched_at"])]
                for d, v in sorted(days.items(), reverse=True)]
    hist_grid = (_grid(["Day (UTC)", "Alerts", "Findings", "Read from Sycope"], day_rows) if day_rows else
                 '<p class="mut">No day stored yet: the backfill reads past days from Sycope in the background.</p>')
    unknown_tri = (", ".join(_classify_link(n) for n in b.unknown_rules)
                   + f'<div class="mut" style="font-size:12px">{UNKNOWN_HELP}</div>'
                   if b and b.unknown_rules else "none: every alert name is in the rule catalog")
    body = f"""
<h1 class="ptitle">System status</h1>
<div class="card"><div class="cth"><h2 class="ct">Sycope feed</h2>{st}</div>
<div class="kv"><div><span class="mut">Sycope</span><code>{_e(settings.sycope_url or "(not set)")}</code></div>
<div><span class="mut">Last poll</span>{_ts(last.at)} · {_e(last.message)}</div>
<div><span class="mut">Snapshot</span>{snap_line}</div>
<div><span class="mut">Window</span>{_e(window_line)}</div>
<div><span class="mut">Running since</span>{_ts(live.started)} · v{_e(version)}</div></div></div>
<div class="card"><h2 class="ct">Triage</h2>
<div class="kv"><div><span class="mut">Board</span>{_e(board_line)}</div>
<div><span class="mut">State database</span>{"kept" if live.store and live.store.path else "none"}</div>
<div><span class="mut">History backfill</span>{_e(bf.message)}{" (running)" if bf.running else ""}</div>
<div><span class="mut">Analyst actions</span>{"on" if settings.triage_edit else "off: read-only triage"}</div>
<div><span class="mut">Alert names not in the rule catalog</span>{unknown_tri}</div></div>
<h2 class="ct" style="margin-top:14px">Stored days</h2>{hist_grid}</div>
{health_card(health.summary(live))}
<div class="card"><h2 class="ct">Recent polls</h2>{hist}</div>
<div class="card"><h2 class="ct">Clusters: alert names not in the rule catalog</h2>{unknown}</div>
<div class="card" id="cfgcard" style="display:none"><h2 class="ct">Configuration</h2>
<p class="mut" style="font-size:12px">For admins. Click (i) for what a setting means, its environment variable and file path. <a href="#" id="cfgall">Expand all</a></p>
<div id="cfgbody"></div></div>
<script>var PRODUCT={json.dumps("clusters" if product == "episodes" else product)};{_SYSTEM_JS}</script>
"""
    return _page(f"System status · Sycope Security {_pname(product, settings.clusters_compare)}", body, "system",
                 settings, sub="System status", product=product, offset_min=int(live.params["calendar.utc_offset_min"]))
