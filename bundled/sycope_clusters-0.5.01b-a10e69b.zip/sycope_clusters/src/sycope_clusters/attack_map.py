"""The product's own MITRE ATT&CK mapping of the rule catalog (ATT&CK v14 and later ids).

The Sycope templates carry a MITRE tag each, written for template coverage and wrong or too strong for a number of
rules (an SSH protocol change tagged Adversary-in-the-Middle, a P2P port tagged Drive-by Compromise, remote desktop
across the internet edge tagged Lateral Movement). This table is what Triage and Clusters show instead; the template
tag only appears in detail views, labelled "template tag".

Rules of the table (docs/mitre-mapping-1.2.md lists every row with its reason):
  - an id is given only when the rule's flow signal (ports, volume, interval, number of hosts, direction) shows the
    technique; ATT&CK techniques that need endpoint or content visibility are never given;
  - the direction decides (inbound from the internet, outbound to the internet, internal): the same port is Initial
    Access at the edge, Lateral Movement inside, and policy when it goes out;
  - hygiene, asset and policy rules (class D) and weak volume anomalies carry no technique;
  - a rule with a tactic and no id says what the flow shows without naming a technique: a command-and-control address
    contact (the list does not give the protocol), a large upload out (the channel is not shown), an exposed service.
"""

from __future__ import annotations

import re

from sycope_clusters.aliases import extend

TACTICS = ("Reconnaissance", "Resource Development", "Initial Access", "Execution", "Persistence",
           "Privilege Escalation", "Defense Evasion", "Credential Access", "Discovery", "Lateral Movement",
           "Collection", "Command and Control", "Exfiltration", "Impact")

# The ids the shipped table uses, with their ATT&CK names. An id an administrator types that is not here is kept (the
# format is checked) and shown without a name.
TECHNIQUES: dict[str, str] = {
    "T1595": "Active Scanning",
    "T1595.001": "Scanning IP Blocks",
    "T1046": "Network Service Discovery",
    "T1133": "External Remote Services",
    "T1190": "Exploit Public-Facing Application",
    "T1566": "Phishing",
    "T1021": "Remote Services",
    "T1021.001": "Remote Desktop Protocol",
    "T1110": "Brute Force",
    "T1071": "Application Layer Protocol",
    "T1090": "Proxy",
    "T1090.002": "External Proxy",
    "T1090.003": "Multi-hop Proxy",
    "T1571": "Non-Standard Port",
    "T1572": "Protocol Tunneling",
    "T1041": "Exfiltration Over C2 Channel",
    "T1048": "Exfiltration Over Alternative Protocol",
    "T1048.003": "Exfiltration Over Unencrypted Non-C2 Protocol",
    "T1567.002": "Exfiltration to Cloud Storage",
    "T1074.002": "Remote Data Staging",
    "T1498": "Network Denial of Service",
    "T1498.001": "Direct Network Flood",
    "T1498.002": "Reflection Amplification",
    "T1499.001": "OS Exhaustion Flood",
    "T1496": "Resource Hijacking",
}

ID_FORMAT = re.compile(r"^T\d{4}(\.\d{3})?$")

RECON, IA, DISC, LAT, COLL, C2, CRED, EXF, IMPACT = (
    "Reconnaissance", "Initial Access", "Discovery", "Lateral Movement", "Collection", "Command and Control",
    "Credential Access", "Exfiltration", "Impact")
NONE = ("", "")        # no technique: for a direction it clears what the rule says otherwise

# rule name -> {"base": (tactic, technique), "inbound": ..., "outbound": ..., "internal": ...}. The base is what the
# rule says when the direction is unknown or has no entry of its own; an entry of a direction replaces it. Every
# rule of the catalog has a row: {} is a decision (no mapping), not an omission (tests/test_attack_map.py).
_BEACON = {"base": (C2, "T1071"), "inbound": NONE}
_EXFIL_OUT = {"outbound": (EXF, "")}                 # a large upload out: the flow does not show the channel
_C2_ADDRESS = {"outbound": (C2, "")}                 # the listed address is a command channel; the protocol is unknown
_COVERT_OUT = {"inbound": NONE}                      # an outside host reaching our server is not our tunnel
_FLOOD = {"base": (IMPACT, "T1498.001")}

MAP: dict[str, dict[str, tuple[str, str]]] = {
    # CL-01 threat intel
    "Suspicious IP - Malicious": _C2_ADDRESS,
    "Suspicious IP - Sycope Community": _C2_ADDRESS,
    "Suspicious IP - Cryptomining": {"outbound": (IMPACT, "T1496")},
    "Suspicious IP - Phishing": {"base": (IA, "")},           # a lure address: delivery or the click, not shown by flow
    "Suspicious Domain - DNS": _C2_ADDRESS,
    "Suspicious Domain - HTTP": _C2_ADDRESS,
    "Suspicious JA3": _C2_ADDRESS,
    "Botnet via DNS": _C2_ADDRESS,
    "Botnet Attack via DNS": _C2_ADDRESS,
    "Suspicious IP - Spam": {},
    "Suspicious IP - Scanner": {"inbound": (RECON, "T1595")},
    "Suspicious IP - User Lookup": {},
    "Suspicious IP - Open DNS": {},
    # CL-02 beacons (interval regularity), IRC by port, long sessions by duration only
    "Repeated Connection": _BEACON,
    "C2 Polling": _BEACON,
    "Small Payload Beaconing": _BEACON,
    "IRC Traffic": _BEACON,
    "Long-Duration Session": {},
    # CL-03 covert channels
    "Suspicious IP - TOR": {"outbound": (C2, "T1090.003"), **_COVERT_OUT},
    "Suspicious IP - Proxy": {"outbound": (C2, "T1090.002"), **_COVERT_OUT},
    "Protocol Mixing": {"base": (C2, ""), **_COVERT_OUT},       # several carriers in a few minutes: tunnelling not shown
    "Suspicious Protocol Mixing": {"base": (C2, ""), **_COVERT_OUT},
    "Proxy/SOCKS": {"base": (C2, "T1090"), **_COVERT_OUT},
    "Suspicious Port - Blocklist": {"base": (C2, "T1571"), **_COVERT_OUT},
    "SSH Protocol Change": {"base": (C2, "T1571"), **_COVERT_OUT},
    "Suspicious SSH Protocol Change": {"base": (C2, "T1571"), **_COVERT_OUT},
    # CL-04 scanning: internal Discovery, from or to the internet Reconnaissance
    "Horizontal Scan": {"base": (DISC, "T1046"), "inbound": (RECON, "T1595.001"), "outbound": (RECON, "T1595.001")},
    "Vertical Scan": {"base": (DISC, "T1046"), "inbound": (RECON, "T1595"), "outbound": (RECON, "T1595")},
    "Potential Virus Outbreak": {"base": (DISC, "T1046")},
    "High Connection Failure Rate": {"base": (DISC, "T1046"), "inbound": (RECON, "T1595"),
                                     "outbound": (RECON, "T1595")},
    "Multiple Protocols Same Dest": {},
    "Excessive ICMP": {},
    "Abnormal flows ratios": {},
    "Only SYN Client TCP Flag": {},
    "Only SYN Server TCP Flag": {},
    # CL-05 credentials
    "Brute Force": {"base": (CRED, "T1110")},
    "Brute Force Attack": {"base": (CRED, "T1110")},
    "RDP Brute Force Slow": {"base": (CRED, "T1110")},
    "SSH Brute Force Slow": {"base": (CRED, "T1110")},
    "Kerberos External": {},
    "LDAP External": {},
    "LLMNR/NetBIOS": {},
    "Unauthorized LLMNR/NetBIOS Activity": {},
    # CL-10 lateral movement
    "Possible Lateral Movement": {"base": (LAT, "T1021")},
    "Rogue RDP Access": {"base": (LAT, "T1021.001"), "inbound": (IA, "T1133"), "outbound": NONE},   # as the RDP rule
    "Suspicious Host": {},
    # CL-11 remote access across the edge
    "Unauthorized RDP from/to the Internet": {"internal": (LAT, "T1021.001"), "inbound": (IA, "T1133"),
                                              "outbound": NONE},
    # CL-06 exfiltration: only an upload that leaves the network
    "Large Data Upload": _EXFIL_OUT,
    "Large Data Upload to External": _EXFIL_OUT,
    "Abnormal Upload/Download Ratio": _EXFIL_OUT,
    "Abnormal Upload/Download Ratio1": _EXFIL_OUT,
    "FTP Exfil": {"outbound": (EXF, "T1048.003")},
    "DNS Transfer Limit": {"outbound": (EXF, "T1048.003")},
    "High Data Transfer": {},
    "High Data Transfer (Int<-> Ext)": {},
    "Google Drive Upload": {"outbound": (EXF, "T1567.002")},
    "Large Google Drive Upload Traffic": {"outbound": (EXF, "T1567.002")},
    "SMB External": {"outbound": (EXF, "T1048"), "inbound": (IA, "")},
    "SMB Traffic to External Networks": {"outbound": (EXF, "T1048"), "inbound": (IA, "")},
    # CL-12 internal staging
    "High Data Transfer (Int)": {},
    "Data Staging Detection": {"base": (COLL, "T1074.002")},
    # CL-07 anomalies (weak, no technique)
    "Unexpected increase in number of bytes": {},
    "Unexpected decrease in number of bytes": {},
    "Unexpected increase in BPS": {},
    "Unexpected decrease in BPS": {},
    "Unexpected increase in PPS": {},
    "Unexpected decrease in PPS": {},
    "Unexpected increase in numbe of packets": {},
    "Unexpected increase in number of packets": {},
    "Unexpected decrease in number of packets": {},
    "Unexpected increase in number of flows": {},
    "Unexpected decrease in number of flows": {},
    "Abnormal DNS Query Limit": {},
    "Abnormal DNS Response Limit": {},
    "After-Hours Traffic": {},
    "Frequent Short-Lived Connections": {},
    # CL-08 floods
    "DDoS Attack": _FLOOD,
    "DNS Amplification": {"base": (IMPACT, "T1498.002")},
    "DNS Reflection": {"base": (IMPACT, "T1498.002")},
    "Protocol Flood": _FLOOD,
    "DoS": _FLOOD,
    "SYN Flood": {"base": (IMPACT, "T1499.001")},               # ATT&CK names SYN floods under OS Exhaustion Flood
    # CL-09 asset changes, hygiene and policy: no technique
    "Unknown Device": {},
    "Watch Device": {},
    "High IP Count": {},
    "IoT/OT Device Discovered": {},
    "IoT/OT Discovered": {},
    "IP Address Conflict": {},
    "APIPA": {},
    "APIPA address assignment": {},
    "Suspicious Port - Allowlist": {},
    "Cleartext Application": {},
    "Unauthorized DNS Activity": {},
    "Unauthorized DHCP Activity": {},
    "Unauthorized LDAP Activity": {"inbound": (IA, "")},
    "Unauthorized NFS Export Data": {"outbound": (EXF, "T1048"), "inbound": (IA, "")},
    "Unprotected Docker Daemon": {"inbound": (IA, "T1133")},    # the exposed Docker API is an external remote service
    "P2P Activity": {},
    "Unauthorized Internet Access": {},
    "Cleartext Internal Traffic": {},
    "Multicast DNS from Internet": {},
    # templates of Sycope 3.3 (0.5.01b)
    "Crypto Mining Pool Connection": {"outbound": (IMPACT, "T1496")},     # a mining-pool port, as the listed-address rule
    "Web Shell Activity Pattern": {},                                      # a technique that needs content, not flows
    "Database Port Exposed to Internet": {"inbound": (IA, "T1133")},       # an exposed service, as the Docker API
    "Telnet to External": {"outbound": (C2, "")},                          # cleartext remote shell out: the channel, not the protocol
    "Email Worm": {},
    "NetBIOS/SMB Discovery": {"base": (DISC, "T1046")},
    "Possible SPAM activity": {},
    "Large Size ICMP Packets": {"base": (C2, "")},                         # a possible ICMP tunnel: not shown by flow
    "Large Size TCP Packets": {},
    "Large Size UDP Packets": {},
    "Ingress from High-Risk Countries": {},
}
extend(MAP)         # the official names of the rules above that have a short one (aliases.py)


def technique_name(technique: str) -> str:
    return TECHNIQUES.get(technique, "")


def why_none(*, known: bool = True, family: str = "", cls: str = "", kind: str = "") -> str:
    """Why a rule has no ATT&CK reading: "policy", "indicator match", "behavioural anomaly" or "rule not classified"."""
    if not known:
        return "rule not classified"
    if cls == "D" or family in ("POL", "HYG", "CL-09") or kind in ("policy", "port", "asset", "remote"):
        return "policy"
    if kind == "ti":
        return "indicator match"
    return "behavioural anomaly"


def label(tactic: str, technique: str, why: str = "") -> str:
    """What the analyst reads for one rule in one direction: "T1133 External Remote Services (Initial Access)", a
    tactic alone ("Command and Control, technique not determined"), or why there is nothing to show."""
    if technique:
        text = f"{technique} {technique_name(technique)}".strip()
        return text + (f" ({tactic})" if tactic else "")
    if tactic:
        return f"{tactic}, technique not determined"
    return f"no ATT&CK mapping ({why or 'behavioural anomaly'})"


def key(tactic: str, technique: str, why: str = "") -> str:
    """The reading as one short text a frame column can hold: "tactic|technique|why" (why only when both are empty)."""
    return f"{tactic}|{technique}|{'' if tactic or technique else why}"


def read_key(text: str) -> tuple[str, str, str]:
    """(tactic, technique, label) of a key."""
    tactic, technique, why = (str(text).split("|") + ["", "", ""])[:3]
    return tactic, technique, label(tactic, technique, why)


def tpl_tag(mitre_id: str, technique: str, tactic: str) -> str:
    """The Sycope template's own MITRE tag of an alert as one text, "T1021 Remote Services (Lateral Movement)": the
    only form it appears in (detail views, labelled "template tag"); "" when the alert carries none."""
    text = " ".join(x for x in (mitre_id, technique) if x)
    return text + (f" ({tactic})" if text and tactic else "")
