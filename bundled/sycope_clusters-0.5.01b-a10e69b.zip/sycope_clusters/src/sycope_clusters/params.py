"""The parameter registry: every number the triage model uses, with its factory value, bounds and a line of help.

One table, one place. A `Params` resolves each parameter from four layers, the strongest first:

    admin     a value an administrator set (rejected at write time when `validate` says no)
    learned   a value measured from this customer's own history; only for parameters marked learnable
    env       an SC_* setting of the deployment (`env_layer`); used as given, outside the bounds only a warning
    factory   the value the model shipped with

The factory values are exactly the constants the model used before the registry existed; modules that imported
those constants keep their names, which now point here.
"""

from __future__ import annotations

import ipaddress
import logging
import math
from dataclasses import dataclass
from typing import Any

log = logging.getLogger(__name__)
_WARNED: set = set()
SCOPES = ("global", "role", "host", "segment")


@dataclass(frozen=True)
class Param:
    id: str
    factory: Any
    lo: float | None
    hi: float | None
    unit: str
    help: str
    learnable: bool
    scope: str  # "global" | "role" | "host" | "segment"


@dataclass(frozen=True)
class Value:
    value: Any
    source: str  # "factory" | "env" | "learned" | "admin"
    n: int = 0
    conf: float = 1.0
    note: str = ""


REGISTRY: dict[str, Param] = {}


def _reg(pid: str, factory: Any, lo: float | None, hi: float | None, unit: str, help: str, learnable: bool = False,
         scope: str = "global") -> None:
    assert pid not in REGISTRY and scope in SCOPES, pid
    REGISTRY[pid] = Param(pid, factory, lo, hi, unit, help, learnable, scope)


def factory(pid: str) -> Any:
    """The factory value of a parameter (what the old module constants were)."""
    return REGISTRY[pid].factory


# Counterparts whose IPs are shared by thousands of sites or tenants: a threat-intel hit or a "beacon" to them is
# weak evidence (stale lists, CDN edges). Hosting providers are not here: attackers rent them.
CLOUD_ASN_NAMES = {8075: "Microsoft", 8068: "Microsoft", 8069: "Microsoft", 16509: "Amazon", 14618: "Amazon",
                   15169: "Google", 396982: "Google Cloud", 13335: "Cloudflare", 20940: "Akamai", 16625: "Akamai",
                   54113: "Fastly", 2906: "Netflix", 40027: "Netflix", 32934: "Meta", 714: "Apple", 6185: "Apple"}

# chain rule -> factory bonus in bits (the titles and texts stay with the chain table in evidence.py)
CHAIN_BONUS = {"CR-01": 4.0, "CR-02": 4.0, "CR-03": 3.0, "CR-04": 3.0, "CR-05": 3.0, "CR-06": 3.0, "CR-08": 2.0,
               "CR-09": 1.5, "CR-10": 1.0}

_CLASS_HELP = {"A": "indicator match (threat intel, known-bad TLS client)", "B": "attack behaviour",
               "C": "weak or ambiguous signal", "D": "hygiene, asset or policy finding"}
for _c, _v in (("A", 5.0), ("B", 3.0), ("C", 1.5), ("D", 0.0)):
    _reg(f"class_bits.{_c}", _v, 0, 10, "bits", f"Most evidence one alert of class {_c} can carry: {_CLASS_HELP[_c]}.")
for _s, _v in ((1, -1.0), (2, -0.5), (3, 0.0), (4, 0.5), (5, 1.0)):
    _reg(f"sev_adj.{_s}", _v, -3, 3, "bits",
         f"Bits added to or taken from an alert of Sycope severity {_s} (1 = Info, 5 = Critical).")
for _t, _v in ((1, 0.0), (2, 0.5), (3, 1.0)):
    _reg(f"thr_adj.{_t}", _v, 0, 3, "bits",
         f"Bits added when the alert's threshold level is {_t} (1 = Minor, 3 = Critical).")
_reg("confirm_bits", 2.0, 0.5, 6, "bits", "Evidence one finding needs to confirm its kill-chain stage.")
_reg("prior_bits", 8.0, 2, 16, "bits", "Prior log-odds of a compromise: 8 bits is 1 host in 256.")
for _k, _v in (("none", 0.2), ("0", 0.3), ("1", 0.5), ("2", 0.7), ("3", 1.0)):
    _reg(f"impact.{_k}", _v, 0, 1, "", "Impact of the highest confirmed stage "
         + ("(0 = Recon ... 3 = Objectives; a confirmed command channel weighs at least stage 3)." if _k != "none" else "(no stage confirmed)."))
_reg("crown_mult", 1.5, 1, 5, "x", "Impact multiplier for a crown jewel.")
for _c, _v in CHAIN_BONUS.items():
    _reg(f"chain.{_c}.bonus", _v, 0, 10, "bits", f"Bits a confirmed {_c} chain rule adds to a host's evidence.")
_reg("chain.CR-08.same_hosts_bonus", 1.0, 0, 5, "bits",
     "Extra bits when the lateral movement of CR-08 hits a host the credential attack touched.")
_reg("chain.CR-09.same_hosts_bonus", 1.5, 0, 5, "bits",
     "Extra bits when the attack of CR-09 goes after a host the scan touched.")
_reg("act_chains", ("CR-01", "CR-02", "CR-04", "CR-05"), None, None, "",
     "Chain rules that mean a compromise on their own: Act now.")
_reg("p1_chains", ("CR-01", "CR-02", "CR-04", "CR-05", "CR-06", "CR-08"), None, None, "",
     "Chain rules that make an Act now ticket P1.")
_reg("wording.conf_low", 0.2, 0, 1, "", "Confidence below this is called low in lists and reasons.")
_reg("wording.conf_high", 0.6, 0, 1, "",
     "Confidence from this on is called high, and a stage may be called confirmed in a reason; between the two it is medium.")
_reg("verdict.act_chain_conf", 0.6, 0, 1, "", "Confidence an act chain rule needs for Act now.")
_reg("verdict.linked_conf", 0.9, 0, 1, "",
     "Confidence CR-08 or CR-09 with the second step on a touched host needs for Act now.")
_reg("verdict.impact_conf", 0.8, 0, 1, "", "Confidence a confirmed command channel or Objectives needs for Act now.")
_reg("verdict.crown_stage_conf", 0.8, 0, 1, "", "Confidence a crown jewel at Lateral needs for Act now.")
_reg("verdict.investigate_risk", 0.15, 0, 1, "", "Risk (confidence x impact) from which a host is Investigate.")
_reg("verdict.review_risk", 0.03, 0, 1, "", "Risk (confidence x impact) from which a host is Review.")
_reg("verdict.ti_new_bits", 3.0, 0, 10, "bits", "Bits a first contact with a listed IP needs to be Investigate.")
_reg("exfil_floor_bytes", 10_000_000, 1e6, 1e11, "bytes",
     "An upload below this cannot confirm exfiltration, whatever the host's normal upload is. Above it, an upload "
     "confirms exfiltration from the host's own normal daily upload on; 10x that adds 1 bit, 100x adds 2.")
_reg("answer_floor_bytes", 1_000_000, 1e4, 1e10, "bytes",
     "A victim that sent this much back to an outside attacker may have let it in (or more, when the service "
     "normally sends more per client).")
_reg("persist_days", 5, 2, 7, "days",
     "Days of the last week with the same channel before it counts as persistent, not habit.")
_reg("recurrence.days", 14, 3, 90, "days",
     "Days back the incidents of a host that ended with nobody deciding are counted for recurrence.")
_reg("recurrence.min1", 3, 2, 20, "incidents",
     "Incidents (Review or above) of one host that ended without an analyst's decision, within the recurrence window, "
     "before recurrence adds evidence.")
_reg("recurrence.bits1", 1.0, 0, 5, "bits", "Bits recurrence adds from recurrence.min1 incidents on.")
_reg("recurrence.min2", 5, 3, 40, "incidents", "Incidents without a decision from which recurrence adds more.")
_reg("recurrence.bits2", 2.0, 0, 8, "bits", "Bits recurrence adds from recurrence.min2 incidents on.")
_reg("hysteresis.step_h", 24, 1, 168, "hours",
     "Without an analyst's action a host's verdict falls at most one level in this time.")
_reg("hysteresis.act_hold_h", 72, 1, 720, "hours",
     "A host that was Act now stays at least Investigate until an analyst acts on it, or this long has passed with "
     "nothing above Watch.")
_reg("week_share", 0.05, 0, 1, "", "Share of hosts under which a rule counts as uncommon for the 7-day kill chain.")
_reg("cloud_asns", tuple(CLOUD_ASN_NAMES), None, None, "",
     "AS numbers of shared cloud and CDN networks: contact with them is weaker evidence.")
EDGE_FORBIDDEN = ("SMB External", "SMB Traffic to External Networks", "Unauthorized NFS Export Data")
_reg("edge_forbidden_rules", EDGE_FORBIDDEN, None, None, "",
     "Rules for protocols that must not cross the internet edge (SMB, NFS): going out, they weigh whatever the "
     "volume, with no 'under its normal daily upload' discount. Alert names.")
_reg("shared_infra_extra", (), None, None, "",
     "Networks (CIDR) of shared infrastructure to add to the shipped list: with no ASN in the alerts, a threat-intel "
     "or beacon match to an address in them is weaker evidence, like a shared cloud address.")
_reg("health.fill_warn", 0.5, 0.05, 1, "",
     "A field the scoring reads that is filled in less than this share of the alerts that should carry it is a "
     "Health warning, with what it costs.")
_reg("health.coverage_min", 0.9, 0.1, 1, "",
     "Share of the 24 hours of a stored day that must have netflow; a day below it is a Health warning.")
_reg("health.suggestion_days", 7, 1, 90, "days",
     "A configuration suggestion that has waited this long for an answer needs attention.")
_reg("campaign_k_min", 5, 3, 50, "hosts",
     "Fewest hosts of one network segment at Investigate or above, with the same kind of intrusion, that can make a "
     "campaign. A campaign also needs that many to be improbable for the segment's size (campaign_p).")
_reg("campaign_p", 1e-4, 1e-12, 0.05, "",
     "How improbable the number of hosts at Investigate or above in one segment must be, given the segment's size "
     "and the usual daily share of such hosts, before they count as one campaign.")
_reg("chain_days", 3, 1, 3, "days",
     "Days back a two-step chain rule looks for its first step (1 = only the 24 h window).")
_reg("quiet_h", 6, 1, 48, "hours", "No alerts this long: the incident sorts lower inside its verdict and stage.")
_reg("grace_min", 15, 1, 240, "minutes", "Off the board this long: the incident is closed.")
_reg("shift_gap_h", 6.0, 4, 16, "hours", "No team activity this long: the team was away and the next shift starts.",
     learnable=True)
_reg("shift_h", 8, 4, 12, "hours", "Length of a shift for a team that never stops.")
# SLA of an incident, by its peak verdict (sla.py). The clock starts when the incident first shows that verdict; the
# first analyst action is the ack, a close with an outcome or an escalation is handled. Review has no SLA.
_reg("sla.act.ack_min", 30, 1, 1440, "minutes", "Act now: time from the incident showing it to the first analyst action.")
_reg("sla.act.handle_h", 4.0, 0.25, 720, "hours",
     "Act now: time from the incident showing it to a close with an outcome or an escalation.")
_reg("sla.investigate.ack_h", 4.0, 0.25, 720, "hours",
     "Investigate: time from the incident showing it to the first analyst action.")
_reg("sla.investigate.handle_h", 24.0, 0.25, 720, "hours",
     "Investigate: time from the incident showing it to a close with an outcome or an escalation.")
_reg("sla.unowned_min", 30, 1, 1440, "minutes",
     "An Act now incident nobody has taken or escalated after this long raises the actnow.unowned webhook event once.")
# An exception that would hide more than this on the board (alerts of the last 24 hours, or distinct hosts) is a
# policy decision: an admin adds and approves it (triage.exception_scope).
_reg("exception.big_alerts", 1000, 1, 1000000, "alerts",
     "An exception covering more alerts than this in the last 24 hours needs an admin to add or approve it.")
_reg("exception.big_hosts", 20, 1, 100000, "hosts",
     "An exception covering more hosts than this in the last 24 hours needs an admin to add or approve it.")
# Silence rules (silence.py): a rule that suddenly takes far more than it usually does is still honoured, but it is
# reported (Health, the bell, the audit): what it hides may no longer be what the analyst meant to hide.
_reg("silence.spike_x", 10, 2, 1000, "x",
     "A silence rule whose matches in the last hour exceed this many times its mean hourly matches over the previous "
     "7 days (and silence.spike_min) is reported as hiding a spike. It keeps silencing.")
_reg("silence.spike_min", 50, 1, 1000000, "alerts",
     "The fewest alerts in the last hour for the spike warning of a silence rule.")
_reg("silence.remove_days", 30, 1, 90, "days",
     "A silence rule with no match for this many days is suggested for removal.")
_reg("unreviewed_days", 14, 1, 90, "days", "Days an unreviewed ended incident stays in the queue.")
_reg("own_public_min_clients", 50, 5, 10000, "clients",
     "A public IP that this many different internal hosts talked to in one hour is offered as probably yours "
     "(a public service of your own, not an outside site).")
_reg("calendar.utc_offset_min", 0, -840, 840, "minutes",
     "Your local time as minutes from UTC (Warsaw winter 60, summer 120). Stored days are UTC days; this decides "
     "which local weekday a day belongs to, so weekends and holidays are told apart correctly.")
_reg("calendar.off_ratio", 0.5, 0.1, 0.9, "",
     "A weekday whose usual number of acting hosts is under this share of the typical weekday is a day off "
     "(learns Fri-Sat weekends).")
_reg("calendar.dormant_ratio", 0.3, 0.05, 0.9, "",
     "A day with fewer acting hosts than this share of the typical day of its kind (holiday, outage) is dormant: "
     "it is left out of novelty and rarity.")
_reg("calendar.min_weeks", 3, 2, 12, "weeks",
     "Weeks of history needed before weekdays off are learned; until then Monday to Friday are work days.")
_reg("profile.alpha_share", 50, 1, 10000, "host-days",
     "How strongly the shipped expectation of how common a rule is holds against your own history: a network needs "
     "about this many acting host-days before its own numbers count as much as the expectation.")
_reg("profile.prior_floor_share", 0.001, 1e-6, 0.1, "",
     "The smallest expected share of hosts a rule is given before your history is counted, so a rule the shipped "
     "table calls almost unheard of cannot claim near-certain rarity on its own.")
_reg("profile.host_norm_ceiling", 4, 1, 20, "x",
     "A host's learned normal upload is never more than this many times the normal of its role, so a slow "
     "exfiltration cannot teach the system that its volume is normal.")
_reg("profile.drift_day", 2.0, 1, 10, "x",
     "A learned volume (normal upload, normal answer size) moves at most this many times up or down from one "
     "day's profile to the next. A learned share of hosts moves at most 2x (1 bit of rarity) a day.")
_reg("profile.drift_week", 4.0, 1, 100, "x",
     "A learned volume or share moves at most this many times up or down within a week.")
_reg("segment_min_hosts", 8, 2, 256, "hosts",
     "A learned network segment grows (a /24 to a /23 and so on, up to /16; IPv6 /64 up to /48) until it holds this "
     "many active hosts. A lookup subnet is a segment when it holds this many.")
_reg("ti_min_cap_bits", 2.0, 0, 10, "bits",
     "However common a threat-intel or other indicator match is on your network, its rarity limit never goes "
     "below this.")

# SC_* setting (Settings field) -> parameter
ENV_MAP = {"campaign_min": "campaign_k_min", "chain_days": "chain_days", "unreviewed_days": "unreviewed_days"}
_CHAIN_LISTS = ("act_chains", "p1_chains")
_SETS = ("cloud_asns",)
_TEXT_LISTS = ("edge_forbidden_rules", "shared_infra_extra")


def validate(pid: str, value: Any) -> str | None:
    """Error text when `value` is not allowed for the parameter, else None."""
    p = REGISTRY.get(pid)
    if p is None:
        return f"unknown parameter {pid}"
    if pid in _CHAIN_LISTS:
        if not isinstance(value, (tuple, list)) or not all(isinstance(c, str) for c in value):
            return f"{pid} is a list of chain rule ids"
        bad = sorted(set(value) - set(CHAIN_BONUS))
        return f"{pid}: unknown chain rule {', '.join(bad)}" if bad else None
    if pid == "shared_infra_extra":
        if not isinstance(value, (tuple, list)):
            return "shared_infra_extra is a list of networks (CIDR)"
        for c in value:
            try:
                if not isinstance(c, str) or ipaddress.ip_network(c.strip(), strict=True).prefixlen == 0:
                    raise ValueError
            except ValueError:
                return f"shared_infra_extra: {c!r} is not a network in CIDR form (for example 203.0.113.0/24)"
        return None
    if pid in _TEXT_LISTS:
        ok = isinstance(value, (tuple, list)) and all(isinstance(a, str) and a.strip() and len(a) <= 120
                                                      for a in value)
        return None if ok else f"{pid} is a list of alert names"
    if pid == "cloud_asns":
        ok = isinstance(value, (tuple, list)) and all(isinstance(a, int) and not isinstance(a, bool) and a > 0
                                                      for a in value)
        return None if ok else "cloud_asns is a list of AS numbers"
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return f"{pid} must be a number"
    try:
        finite = math.isfinite(value)
    except OverflowError:       # a JSON integer too big for a float (10**400)
        finite = False
    if not finite:
        return f"{pid} must be a finite number"
    if isinstance(p.factory, int) and value != int(value):
        return f"{pid} must be a whole number"
    if (p.lo is not None and value < p.lo) or (p.hi is not None and value > p.hi):
        return f"{pid} must be between {p.lo:g} and {p.hi:g}"
    return None


def _clamp(p: Param, value: Any) -> Any:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return value
    if p.lo is not None:
        value = max(p.lo, value)
    if p.hi is not None:
        value = min(p.hi, value)
    return value


def _norm(p: Param, value: Any) -> Any:
    """Lists are kept as tuples; a number takes the type of the factory (floats for a float parameter, a whole
    number for an integer parameter when the value is whole)."""
    if isinstance(value, list):
        return tuple(value)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return value
    if isinstance(p.factory, float):
        return float(value)
    if isinstance(p.factory, int) and value == int(value):
        return int(value)
    return value


def _env_value(p: Param, value: Any) -> Any:
    """An SC_* setting is used as given (the deployment has always been trusted): the type is coerced and a value
    outside the registry bounds only logs a warning, once. None for a value that is not usable at all."""
    if p.id in _CHAIN_LISTS or p.id in _TEXT_LISTS or p.id == "cloud_asns":
        return _norm(p, value) if isinstance(value, (list, tuple)) else None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    value = _norm(p, value)
    if ((p.lo is not None and value < p.lo) or (p.hi is not None and value > p.hi)) and (p.id, value) not in _WARNED:
        _WARNED.add((p.id, value))
        log.warning("%s=%s from the environment is outside the usual range %s..%s; used as given", p.id, value, p.lo,
                    p.hi)
    return value


class Params:
    """The resolved value of every parameter. Immutable: with_learned / with_admin return a new one."""

    _FACTORY: Params | None = None

    def __init__(self, admin: dict | None = None, env: dict | None = None, learned: dict[str, Value] | None = None):
        self._admin = dict(admin or {})
        self._env = dict(env or {})
        self._learned = dict(learned or {})
        self._v: dict[str, Value] = {}
        for pid, p in REGISTRY.items():
            v = Value(p.factory, "factory")
            env = _env_value(p, self._env[pid]) if pid in self._env else None
            if env is not None:
                v = Value(env, "env")
            ln = self._learned.get(pid)
            if p.learnable and ln is not None:
                v = Value(_norm(p, _clamp(p, ln.value)), "learned", ln.n, ln.conf, ln.note)
            if pid in self._admin and validate(pid, self._admin[pid]) is None:
                v = Value(_norm(p, self._admin[pid]), "admin")
            if pid in _SETS:   # looked up for every finding: a set, and its order means nothing
                v = Value(frozenset(v.value), v.source, v.n, v.conf, v.note)
            self._v[pid] = v

    @classmethod
    def factory(cls) -> Params:
        if cls._FACTORY is None:
            cls._FACTORY = cls()
        return cls._FACTORY

    def __getitem__(self, pid: str) -> Any:
        return self._v[pid].value

    def explain(self, pid: str) -> Value:
        return self._v[pid]

    def modified(self) -> list[str]:
        """Parameters an admin set to something other than the factory value (learnable ones excluded: they are
        meant to move)."""
        def same(pid: str, v: Any) -> bool:
            f = REGISTRY[pid].factory
            return frozenset(v) == frozenset(f) if pid in _SETS else v == f

        return sorted(pid for pid, v in self._v.items()
                      if v.source == "admin" and not REGISTRY[pid].learnable and not same(pid, v.value))

    def with_learned(self, learned: dict[str, Value] | None) -> Params:
        return Params(self._admin, self._env, learned)

    def with_admin(self, admin: dict | None) -> Params:
        return Params(admin, self._env, self._learned)


def env_layer(settings) -> dict[str, Any]:
    """The SC_* settings that were changed from their default, as parameter values."""
    default = type(settings)()
    return {pid: getattr(settings, name) for name, pid in ENV_MAP.items()
            if getattr(settings, name) != getattr(default, name)}


FACTORY = Params.factory()   # the default of every `p: Params` argument
