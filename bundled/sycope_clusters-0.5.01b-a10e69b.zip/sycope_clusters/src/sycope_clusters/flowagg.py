"""Netflow, one hour at a time: what the internal services and hosts moved, kept per UTC day.

Two small aggregate queries per complete hour (the lab keeps only ~2.5 h of netflow, so a daily query would find
nothing at the rollover):

    NQL_SRV   per (serverIp, serverPort): distinct clients and bytes each way
    NQL_CLI   per clientIp, only towards servers outside our networks: distinct outside peers and bytes each way

Outside clients are kept too (ext = 1) when they talk to at least own_public_min_clients outside peers in the hour.

Multicast and broadcast (224.0.0.0/4, 255.255.255.255/32, ff00::/8) are nobody's outside peer: the filter leaves them
out, and so does the Python path.

Each hour is merged into its day (Store.merge_flow_hour): bytes add up, distinct counts are the maximum of the hours
(dc() is not additive, so a day's count is a lower bound), ext is OR-ed. An hour merged once is never merged again.

NQL facts, probed on the lab Sycope (3.x): a subnet test is `inSubnet(serverIp, "10.0.0.0/8")`; negation only as
`not (...)` (`!`, `= false`, `not in` and `matches cidr` answer HTTP 400); the distinct count is `dc(field)`; an
aggregate row comes back as a dict with the aggregate names plus `_id`, the list of the group-by values in order,
e.g. {"clients": 1341, "up": 9, "down": 8, "_id": ["10.240.0.20", 53]}. Sycope keeps at most RESULT_CAP records of a
job, so a window whose total reaches it is split in half and the halves are merged.
"""

from __future__ import annotations

import ipaddress
import time
from collections.abc import Iterable
from functools import lru_cache

from sycope_clusters.addresses import AddressBook
from sycope_clusters.params import Params
from sycope_clusters.store import Store
from sycope_clusters.sycope import RESULT_CAP, Sycope

NQL_SRV = ('src stream="netflow" | aggr clients=dc(clientIp), up=sum(clientBytes), down=sum(serverBytes) '
           'by serverIp, serverPort | sort clients desc | limit 100000')
# Too many internal networks for one filter (a bank with thousands of lookup rows): ask for the pairs and decide
# in Python, with the book, which servers are outside.
NQL_PAIRS = ('src stream="netflow" | aggr up=sum(clientBytes), down=sum(serverBytes) by clientIp, serverIp '
             '| sort up desc | limit 100000')
SPECIAL_NETS = ("224.0.0.0/4", "255.255.255.255/32", "ff00::/8")    # multicast and broadcast: never an outside peer
MAX_CIDRS = 64          # more internal networks than this: NQL_PAIRS
MIN_INTERNAL_CLIENTS = 2    # an internal service needs at least this many clients in the hour to be kept
SETTLE_S = 120          # an hour is read this long after it ended (flows are written a little late)
PROBE_KEY = "flow_probe"   # meta: the newest hour asked while the network had no netflow at all
LOOKBACK_H = 24         # how far back a first start tries; retention usually holds less
_MIN_WINDOW_S = 60


@lru_cache(maxsize=4096)
def is_special(ip: str) -> bool:
    """A multicast or broadcast address."""
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_multicast or a == ipaddress.ip_address("255.255.255.255")


def nql_cli(book: AddressBook) -> str | None:
    """The per-client query towards servers outside the book's internal networks, or None when there are more
    than MAX_CIDRS of them."""
    cidrs = book.internal_cidrs()
    if len(cidrs) > MAX_CIDRS:
        return None
    outside = " or ".join(f'inSubnet(serverIp, "{n}")' for n in (*cidrs, *SPECIAL_NETS))
    return ('src stream="netflow" | where not (' + outside + ') | aggr peers=dc(serverIp), up_ext=sum(clientBytes), '
            'down_ext=sum(serverBytes) by clientIp | limit 100000')


def _window(client: Sycope, start: float, end: float, nql: str) -> list[dict]:
    rows, total = client.query_rows(start, end, nql)
    if total < RESULT_CAP or end - start <= _MIN_WINDOW_S:
        return rows
    mid = start + (end - start) / 2
    return _window(client, start, mid, nql) + _window(client, mid, end, nql)


def _merged(rows: Iterable[dict], depth: int, add: tuple[str, ...], top: tuple[str, ...]) -> dict[tuple, dict]:
    """Rows of the same group (`_id`, `depth` values) from several windows as one: `add` fields are summed, `top`
    fields (distinct counts) take the maximum."""
    out: dict[tuple, dict] = {}
    for r in rows:
        ident = r.get("_id")
        if not isinstance(ident, list) or len(ident) < depth:
            continue
        key = tuple(str(x) if x is not None else "" for x in ident[:depth])
        m = out.setdefault(key, dict.fromkeys((*add, *top), 0))
        for f in add:
            m[f] += int(r.get(f) or 0)
        for f in top:
            m[f] = max(m[f], int(r.get(f) or 0))
    return out


def fetch_hour(client: Sycope, start_s: int, book: AddressBook,
               min_clients: int | None = None) -> tuple[list[tuple], list[tuple]]:
    """One complete hour from `start_s` (epoch seconds, on the hour).

    Server rows (ip, port, clients, up, down, ext): internal servers with at least MIN_INTERNAL_CLIENTS clients,
    and outside servers with at least `min_clients` (parameter own_public_min_clients) as ext = 1, candidates for
    "looks like one of yours". Client rows (ip, peers, up_ext, down_ext, ext) towards servers outside the book's
    networks: internal hosts as ext = 0, and outside clients with at least `min_clients` outside peers as ext = 1
    (the other half of "looks like one of yours": a public IP that serves our hosts and also talks to the internet).
    Both sorted by address."""
    if min_clients is None:
        min_clients = Params.factory()["own_public_min_clients"]
    end = start_s + 3600
    srv: list[tuple] = []
    for (ip, port), m in sorted(_merged(_window(client, start_s, end, NQL_SRV), 2, ("up", "down"),
                                        ("clients",)).items()):
        external = not book.internal(ip)
        if external and is_special(ip):
            continue
        if m["clients"] >= (min_clients if external else MIN_INTERNAL_CLIENTS):
            srv.append((ip, port, m["clients"], m["up"], m["down"], int(external)))
    cli: list[tuple] = []
    nql = nql_cli(book)
    if nql is not None:
        for (ip,), m in sorted(_merged(_window(client, start_s, end, nql), 1, ("up_ext", "down_ext"),
                                       ("peers",)).items()):
            if book.internal(ip):
                cli.append((ip, m["peers"], m["up_ext"], m["down_ext"], 0))
            elif m["peers"] >= min_clients:
                cli.append((ip, m["peers"], m["up_ext"], m["down_ext"], 1))
    else:
        peers: dict[str, set[str]] = {}
        sums: dict[str, list[int]] = {}
        for (c, s), m in _merged(_window(client, start_s, end, NQL_PAIRS), 2, ("up", "down"), ()).items():
            if not book.internal(s) and not is_special(s):
                peers.setdefault(c, set()).add(s)
                t = sums.setdefault(c, [0, 0])
                t[0] += m["up"]
                t[1] += m["down"]
        for c in sorted(sums):
            ours = book.internal(c)
            if ours or len(peers[c]) >= min_clients:
                cli.append((c, len(peers[c]), *sums[c], 0 if ours else 1))
    return srv, cli


def probing(store: Store, now: float, lookback: int = LOOKBACK_H) -> bool:
    """True when no hour of the last `lookback` had any netflow: Sycope has none (or none that this account can
    read), and the catch-up walk would only ask empty hours."""
    first = int((now - SETTLE_S) // 3600) * 3600 - 3600 - (lookback - 1) * 3600
    newest = store.flow_newest_data()
    return newest is None or newest < first


def pending_hours(store: Store, now: float, lookback: int = LOOKBACK_H) -> list[int]:
    """Start (epoch) of the complete hours not asked yet, newest first, at most `lookback` back. An hour is complete
    SETTLE_S after it ended. While no hour of the window has netflow (`probing`) only the newest complete hour is
    returned, and only once: the next one is asked an hour later; as soon as an hour has data the walk catches up."""
    last = int((now - SETTLE_S) // 3600) * 3600 - 3600
    first = last - (lookback - 1) * 3600
    done = store.flow_hours_done(first)
    todo = [h for h in range(last, first - 1, -3600) if h not in done]
    if todo and probing(store, now, lookback):
        return [] if last in done or store.meta(PROBE_KEY) == str(last) else [last]
    return todo


def run(store: Store, client: Sycope, book: AddressBook, hours: list[int], min_clients: int | None = None,
        pause: float = 0.0, stop=None) -> int:
    """Aggregate the given hours (newest first) into the store; returns how many were asked. An hour already
    merged is skipped without a query. Flows are written late, so an hour that answers nothing is not recorded as
    empty (it is asked again next time) unless it is behind the newest hour that had flows AND the hour after it
    (the next older one) is empty too: two empty hours in a row behind data are the edge of Sycope's retention, so
    they and the older hours given are recorded as empty and the walk ends. A Sycope error propagates: the hour
    stays unasked and is tried again next time."""
    asked = 0
    done = store.flow_hours_done(min(hours)) if hours else set()
    newest = store.flow_newest_data()      # the newest hour that ever had flows (None: none yet)
    empties: list[int] = []                # the empty hours just walked, newest first, not recorded
    for i, h in enumerate(hours):
        if stop is not None and stop.is_set():
            break
        if h in done:
            continue
        srv, cli = fetch_hour(client, h, book, min_clients)
        asked += 1
        if srv or cli:
            store.merge_flow_hour(h, srv, cli)
            newest = h if newest is None else max(newest, h)
            empties = []
        else:
            if h == hours[0]:
                store.meta(PROBE_KEY, str(h))
            empties.append(h)
            if newest is not None and empties[0] < newest and len(empties) >= 2:
                for hole in (*empties, *hours[i + 1:]):
                    store.merge_flow_hour(hole, [], [])
                break
        if pause:
            time.sleep(pause)
    return asked
