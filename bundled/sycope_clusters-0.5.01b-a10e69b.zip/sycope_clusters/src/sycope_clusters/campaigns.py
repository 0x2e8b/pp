"""Campaigns: more hosts of one network segment at Investigate or above, with a shared intrusion family, than the
segment's size and the usual daily share explain. One campaign, not N unrelated hosts (a worm, a red team, an
attacker spreading; generalises CR-07 worm propagation). Spec 5.4, calls 3-4.

    N   active hosts of a segment: profile.segment_hosts, which is inclusive (a segment's count covers every host
        under it), plus today's hosts the profile does not know. Without a profile N is the hosts with alerts, and
        the campaign says so.
    k   hosts at Investigate or above whose segment lies inside it that share a family
    b   the learned daily share of hosts at Investigate or above (profile.base_rate)

A segment trips when k >= campaign_k_min and P(X >= k | Binomial(N, b)) < campaign_p. The passes:

    1  every segment that holds a candidate host, and every segment, lookup subnet or /16 (/48) above one, is
       evaluated on all the candidates under it
    2  the most specific tripping segments are the campaigns; two or more of them under the same parent that share
       a family are one campaign at their nearest common parent
    3  going up, a tripping parent with candidates of its own that share the family absorbs the campaigns below it;
       a tripping parent whose own candidates trip without them is a campaign of its own

A host is in at most one campaign.
"""

from __future__ import annotations

import bisect
import ipaddress
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from sycope_clusters import priors as _priors
from sycope_clusters.addresses import AddressBook, prefix
from sycope_clusters.params import Params
from sycope_clusters.profile_roles import segments

UP = ("act", "investigate")
WIDEST = {4: 16, 6: 48}   # a campaign never spans more than a /16 (IPv6 /48), as segments do not


def binom_tail(k: int, n: int, b: float) -> float:
    """P(X >= k) for X ~ Binomial(n, b), summed in log space (math.lgamma) so 50,000 hosts do not underflow."""
    if k <= 0:
        return 1.0
    if k > n or b <= 0:
        return 0.0
    if b >= 1:
        return 1.0
    lb, lq, lgn = math.log(b), math.log1p(-b), math.lgamma(n + 1)
    mode = (n + 1) * b
    top, acc = None, 0.0
    for i in range(k, n + 1):
        t = lgn - math.lgamma(i + 1) - math.lgamma(n - i + 1) + i * lb + (n - i) * lq
        if top is None:
            top = t
        elif t > top:          # below the mode the terms still grow: rescale to the largest so far
            acc *= math.exp(top - t)
            top = t
        acc += math.exp(t - top)
        if i > mode and t - top < -40:   # past the mode the terms only shrink: the rest is below 1e-17
            break
    return min(1.0, math.exp(top + math.log(acc)))


def net_of(cidr: str):
    try:
        return ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return None


def top_of(net):
    """The /16 (IPv6 /48) around a network, or the network itself when it is that wide or wider."""
    top = WIDEST[net.version]
    return net if net.prefixlen <= top else net.supernet(new_prefix=top)


def common(nets: list):
    """The smallest network holding all of them (same IP version)."""
    n = nets[0]
    while not all(x.subnet_of(n) for x in nets):
        n = n.supernet()
    return n


def inside(x, net) -> bool:
    return x.version == net.version and x.subnet_of(net)


@dataclass
class Camp:
    net: object
    members: list
    n: int
    q: float
    fams: set
    src: str


@dataclass
class Tree:
    """The candidate hosts' segments, every network above them, and what N counts in each."""
    seg: dict                                   # candidate ip -> its segment (a network)
    nodes: list                                 # every network evaluated, most specific first
    parent: dict                                # node -> the node right above it (None at the top)
    known: dict = field(default_factory=dict)   # top -> [(profile segment, inclusive hosts)]
    unknown: dict = field(default_factory=dict)  # top -> sorted addresses (ints) of today's hosts the profile lacks
    ups: dict = field(default_factory=dict)     # segment -> every node holding it (tree's `above`)
    _idx: tuple = (None, {})                    # (the candidate list, node -> its candidates in that list's order)

    def members(self, node, cand: list) -> list:
        """The candidates under a node, in `cand` order. Indexed once per candidate list through each segment's
        nodes above (a scan of every candidate per node was O(nodes x candidates) under a wide outbreak)."""
        if self._idx[0] is not cand:
            idx: dict = defaultdict(list)
            for e in cand:
                s = self.seg[e.ip]
                idx[s].append(e)
                for y in self.ups.get(s, ()):
                    if inside(s, y):
                        idx[y].append(e)
            self._idx = (cand, idx)
        return list(self._idx[1].get(node, ()))

    def size(self, node) -> int:
        """Active hosts under a network: the outermost profile segments inside it (their counts are inclusive)
        plus today's hosts the profile does not know."""
        outer: list = []
        for x, n in sorted(self.known.get(top_of(node), ()), key=lambda xn: xn[0].prefixlen):
            if inside(x, node) and not any(inside(x, y) for y, _ in outer):
                outer.append((x, n))
        ints = self.unknown.get(top_of(node), ())
        lo, hi = int(node.network_address), int(node.broadcast_address)
        unknown = bisect.bisect_right(ints, hi) - bisect.bisect_left(ints, lo)
        return sum(n for _, n in outer) + unknown

    def source(self, node) -> str:
        return "profile" if any(inside(x, node) for x, _ in self.known.get(top_of(node), ())) else \
            "hosts with alerts"


def _index(nets) -> dict:
    by_len: dict[tuple, dict[int, object]] = defaultdict(dict)
    for x in nets:
        by_len[(x.version, x.prefixlen)][int(x.network_address) >> (x.max_prefixlen - x.prefixlen)] = x
    return by_len


def _containing(by_len: dict, version: int, value: int, bits: int, below: int, at_least: int) -> list:
    """Indexed networks holding the address `value`, with prefix lengths in [at_least, below), longest first."""
    out = []
    for (v, pl), d in sorted(by_len.items(), key=lambda kv: -kv[0][1]):
        if v == version and at_least <= pl < below:
            x = d.get(value >> (bits - pl))
            if x is not None:
                out.append(x)
    return out


def assign(cand: list, hosts, profile, book: AddressBook, min_hosts: int) -> tuple[dict, list[str]]:
    """(candidate ip -> its segment, today's internal hosts the profile does not know). Unknown hosts join the most
    specific profile segment holding them, else get segments of their own (profile_roles.segments)."""
    seg_of, seg_n = getattr(profile, "segment_of", {}), getattr(profile, "segment_hosts", {})
    alerted = set(hosts or ()) | {e.ip for e in cand}
    new = sorted(h for h in alerted if h not in seg_of and book.internal(h))
    by_len = _index(x for x in map(net_of, seg_n) if x is not None)
    fb_of, rest = {}, []
    for h in new:
        try:
            a = ipaddress.ip_address(h)
        except ValueError:
            continue
        hit = _containing(by_len, a.version, int(a), a.max_prefixlen, a.max_prefixlen + 1, 0)
        if hit:
            fb_of[h] = str(hit[0])
        else:
            rest.append(h)
    if rest:
        fb_of.update(segments(set(rest), book, min_hosts)[0])
    out = {}
    for e in cand:
        x = net_of(seg_of.get(e.ip) or fb_of.get(e.ip) or "")
        if x is not None:
            out[e.ip] = x
    return out, new


def tree(seg: dict, unknown: list[str], profile, book: AddressBook) -> Tree:
    """Pass 1's networks: the candidates' segments and, above each, the profile segments, lookup subnets (no wider
    than /16 or /48) and the /16 (/48) that hold it."""
    seg_n = getattr(profile, "segment_hosts", {})
    tops = {top_of(x) for x in seg.values()}
    known: dict = defaultdict(list)
    for s, n in seg_n.items():
        x = net_of(s)
        if x is not None and top_of(x) in tops:
            known[top_of(x)].append((x, n))
    unk: dict = defaultdict(list)
    for h in unknown:
        try:
            a = ipaddress.ip_address(h)
        except ValueError:
            continue
        t = top_of(ipaddress.ip_network(f"{a}/{a.max_prefixlen}"))
        if t in tops:
            unk[t].append(int(a))
    by_len = _index([x for xs in known.values() for x, _ in xs] + list(seg.values()))
    ups: dict = {}

    def above(x) -> list:
        if x in ups:
            return ups[x]
        lo = WIDEST[x.version]
        got = _containing(by_len, x.version, int(x.network_address), x.max_prefixlen, x.prefixlen, lo)
        if book.entries:
            got += [e.net for e in book.covering(str(x.network_address)) if lo <= e.net.prefixlen < x.prefixlen]
        if x.prefixlen > lo:
            got.append(top_of(x))
        ups[x] = sorted(set(got), key=lambda y: -y.prefixlen)
        return ups[x]

    nodes = set(seg.values())
    for x in list(nodes):
        nodes.update(above(x))
    parent = {x: (above(x)[0] if above(x) else None) for x in nodes}
    order = sorted(nodes, key=lambda x: (-x.prefixlen, x.version, x))
    return Tree(seg, order, parent, dict(known), {t: sorted(v) for t, v in unk.items()},
                {x: [y for y in above(x) if y != x] for x in set(seg.values())})


def trip(es: list, n: int, b: float, kmin: int, limit: float):
    """(members sharing a tripping family, those families, the smallest tail) or None."""
    by_fam: dict[str, list] = defaultdict(list)
    for e in es:
        for f in e.pattern:
            if not f.startswith("CR-"):
                by_fam[f].append(e)
    hit = {f: binom_tail(len(m), n, b) for f, m in by_fam.items() if len(m) >= kmin}
    hit = {f: q for f, q in hit.items() if q < limit}
    if not hit:
        return None
    members = {e.ip: e for f in hit for e in by_fam[f]}
    return sorted(members.values(), key=lambda e: e.ip), set(hit), min(hit.values())


def specific(t: Tree, cand: list, b: float, kmin: int, limit: float) -> tuple[list[Camp], set]:
    """Pass 2: the most specific tripping networks, siblings with a family in common merged at their nearest common
    parent. Returns the campaigns and the networks that tripped."""
    got = {}
    for node in t.nodes:
        ms = t.members(node, cand)
        if len(ms) >= kmin:
            r = trip(ms, max(t.size(node), len(ms)), b, kmin, limit)
            if r:
                got[node] = r
    tripped = set(got)
    least = [x for x in t.nodes if x in got and not any(y != x and inside(y, x) for y in tripped)]
    groups: dict = defaultdict(list)
    for x in least:
        groups[t.parent.get(x) or x].append(x)
    out = []
    for key in sorted(groups, key=lambda x: (x.version, x)):
        xs = sorted(groups[key], key=lambda x: (x.version, x))
        while xs:
            fams, pick = set(got[xs[0]][1]), [xs[0]]
            for x in xs[1:]:
                if got[x][1] & fams:
                    pick.append(x)
                    fams |= got[x][1]
            xs = [x for x in xs if x not in pick]
            members = sorted({e.ip: e for x in pick for e in got[x][0]}.values(), key=lambda e: e.ip)
            net = pick[0] if len(pick) == 1 else common(pick)
            n = max(t.size(net), len(members))
            q = got[net][2] if len(pick) == 1 else binom_tail(len(members), n, b)
            out.append(Camp(net, members, n, q, fams, t.source(net)))
    return out, tripped


def upward(t: Tree, cand: list, out: list[Camp], b: float, kmin: int, limit: float) -> list[Camp]:
    """Pass 3: networks above the campaigns, most specific first. A tripping network with candidates of its own
    (not in a campaign yet) that share the tripping family takes the campaigns below it with that family; its own
    candidates alone make a campaign when they trip by themselves."""
    out = list(out)
    for node in t.nodes:
        taken = {e.ip for c in out for e in c.members}
        ms = t.members(node, cand)
        if not ms or all(e.ip in taken for e in ms):
            continue
        n = max(t.size(node), len(ms))
        r = trip(ms, n, b, kmin, limit)
        if not r:
            continue
        mine = [e for e in r[0] if e.ip not in taken]
        below = [c for c in out if inside(c.net, node) and c.fams & r[1]]
        if mine and below:
            members = sorted({e.ip: e for e in [*mine, *(e for c in below for e in c.members)]}.values(),
                             key=lambda e: e.ip)
            out = [c for c in out if all(c is not d for d in below)]
            out.append(Camp(node, members, n, binom_tail(len(members), n, b), r[1] | {f for c in below for f in c.fams},
                            t.source(node)))
        elif len(mine) >= kmin:
            r2 = trip(mine, n, b, kmin, limit)
            if r2:
                out.append(Camp(node, r2[0], n, r2[2], r2[1], t.source(node)))
    return out


def campaigns(entities: dict, stories: dict, profile=None, params: Params | None = None, *,
              min_hosts: int | None = None, hosts: set | None = None, book: AddressBook | None = None) -> list[dict]:
    """The campaigns of a board (see the module text); dict keys as the board has always shown them plus `segment`,
    `p`, `n`, `k`, `base_rate`, `n_source` and `why`."""
    p = params or Params.factory()
    cand = sorted((e for e in entities.values() if e.verdict in UP), key=lambda e: e.ip)
    kmin = p["campaign_k_min"] if min_hosts is None else min_hosts
    if len(cand) < max(1, kmin):
        return []
    book = book if book is not None else AddressBook()
    b = profile.base_rate.p if profile is not None else _priors.load().investigate_rate
    limit = p["campaign_p"]
    seg, unknown = assign(cand, hosts, profile, book, p["segment_min_hosts"])
    t = tree(seg, unknown, profile, book)
    cand = [e for e in cand if e.ip in seg]
    out, _tripped = specific(t, cand, b, kmin, limit)
    out = upward(t, cand, out, b, kmin, limit)
    recs = [record(str(c.net), c.members, c.n, c.q, b, c.src) for c in out]
    recs.sort(key=lambda c: (-c["hosts"], c["net"]))
    return recs


def campaign_reason(k: int, new: int, acts: int) -> str:
    """Why a campaign is Act now or Investigate, naming only the conditions that fired with their numbers."""
    if k <= 0:
        return "no hosts"
    fired = []
    if new * 2 >= k:
        fired.append(f"{new} of {k} hosts ({new * 100 / k:.0f}%) do something new")
    if acts:
        fired.append(f"{acts} of {k} hosts at Act now")
    if fired:
        return " and ".join(fired) + ": one attack, not " + f"{k} separate ones"
    return f"{k} hosts of one network segment at Investigate or above, more than chance explains"


def record(net: str, es: list, n: int, q: float, b: float, src: str) -> dict:
    fams = Counter(f for e in es for f in e.pattern if not f.startswith("CR-"))
    chains = Counter(c for e in es for c in e.pattern if c.startswith("CR-"))
    keys = Counter(e.story for e in es if e.story)
    new = sum(1 for e in es if e.novelty == "new")
    acts = sum(1 for e in es if e.verdict == "act")
    why = (f"{len(es)} of {n} active hosts at Investigate or above where {b * 100:.1f}% a day is usual: chance "
           f"{q:.1e}" + ("" if src == "profile" else " (N = the hosts with alerts: the profile does not know them yet)"))
    return {"net": net, "segment": net, "reason": campaign_reason(len(es), new, acts), "p": q, "n": n, "k": len(es), "base_rate": b, "n_source": src, "why": why,
            "hosts": len(es), "act": acts,
            # mostly new behaviour, or already hosts to act on: the campaign itself is to act on
            "verdict": "act" if new * 2 >= len(es) or acts else "investigate",
            "families": fams.most_common(5), "chains": chains.most_common(4),
            "stories": [k for k, _ in keys.most_common()], "first": min(e.first for e in es),
            "last": max(e.last for e in es), "nets24": Counter(prefix(e.ip) for e in es).most_common(4),
            "new": new, "members": sorted(e.ip for e in es)}
