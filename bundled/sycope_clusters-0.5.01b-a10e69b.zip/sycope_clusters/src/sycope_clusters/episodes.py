"""The Episodes view (1.2): what /clusters shows unless SC_CLUSTERS_COMPARE is on.

The same episodes the Clusters board builds (alerts chained in time on one host), shown as a timeline per host: when
each began and ended, which kill-chain stages it reached, which alert types it holds. It carries no priority, verdict,
quadrant or work of its own. The verdict and the status of a host are Triage's, read from the Triage board and its
stored state, and the row links to the Triage incident."""
from __future__ import annotations

import json
import time

import polars as pl

from sycope_clusters import entities, pages
from sycope_clusters import evidence as ev
from sycope_clusters.config import Settings
from sycope_clusters.engine.mitre import PHASE_NAMES
from sycope_clusters.fmt import FMT_JS, tz_switch

HOSTS_MAX = 400        # hosts in one answer (the page says how many there are in all)
EPISODES_MAX = 20      # newest episodes of one host in the answer
TYPES_MAX = 12         # alert types listed per episode

STATUS_WORDS = {"open": "Open", "investigating": "In progress", "escalated": "Escalated", "ack": "Seen",
                "tp": "Closed: true positive", "benign": "Closed: benign", "fp": "Closed: false positive",
                "resolved": "Resolved"}


def _triage(live, ip: str, tri: dict, ended: dict | None = None) -> dict | None:
    """The host's Triage verdict and status, or None when Triage has no incident for it. A host that is not on the
    board but has an incident that ended with nobody reviewing it ("Ended, not reviewed" in Triage) shows that record's
    peak verdict, and the link opens the record."""
    b = live.board
    if b is None:
        return None
    e = b.entities.get(ip) or b.target_inc.get(ip)
    if e is None:
        rec = (ended or {}).get(ip)
        if rec is None:
            return None
        return {"verdict": rec["verdict_peak"], "status": "ended", "status_word": "Ended, not reviewed", "owner": None,
                "changed": False, "record": rec["id"]}
    ov = ev.overlay(e, tri.get(ip)) or {}
    status = ov.get("status") or "open"
    return {"verdict": e.verdict, "status": status, "status_word": STATUS_WORDS.get(status, status.capitalize()),
            "owner": ov.get("owner"), "changed": bool(ov.get("changed")), "record": None}


def _types(snap) -> dict[int, list[list]]:
    """Per cluster id: its alert types with the alerts of each, most first."""
    if snap.empty or snap.cluster_alerts.is_empty():
        return {}
    w = "_w" in snap.alerts.columns
    al = snap.alerts.select("alert_id", "Alert Name", *(["_w"] if w else []))
    g = (snap.cluster_alerts.join(al, on="alert_id").group_by("cluster_id", "Alert Name")
         .agg((pl.col("_w").sum() if w else pl.len()).alias("n"))
         .sort(["cluster_id", "n", "Alert Name"], descending=[False, True, False]))
    out: dict[int, list[list]] = {}
    for cid, name, n in g.iter_rows():
        lst = out.setdefault(cid, [])
        if len(lst) < TYPES_MAX:
            lst.append([name, int(n)])
    return out


def _stage_order(p: str | None) -> int:
    return PHASE_NAMES.index(p) if p in PHASE_NAMES else -1


def data(live, now: float | None = None) -> dict:
    """The page's data: hosts, each with its Triage verdict and status and its episodes, Act now first then the
    most recent activity."""
    now = time.time() if now is None else now
    cb = live.cboard
    snap = cb.snapshot if cb else None
    base = {"ready": snap is not None, "now": now, "hosts": [], "hosts_total": 0, "episodes_total": 0,
            "alerts_total": 0, "stages": list(PHASE_NAMES), "poll_ok": live.last.ok, "poll_msg": live.last.message}
    if snap is None or snap.empty:
        return base
    tri = live.store.triage()
    p = live.scoring_params()
    ended = {entities.parse(o["subject"])[1]: o
             for o in reversed(live.store.unreviewed(now - p["unreviewed_days"] * 86400)) if o["kind"] == "entity"}
    types = _types(snap)
    hosts: dict[str, dict] = {}
    cols = ["cluster_id", "key", "anchor_ip", "start_ms", "end_ms", "alert_count", "highest_phase", "phases_seen",
            "killchain_progression_score", "cluster_label", "lead_alert"]
    for r in snap.clusters.select([c for c in cols if c in snap.clusters.columns]).sort(
            "end_ms", descending=True).iter_rows(named=True):
        h = hosts.setdefault(r["anchor_ip"], {"ip": r["anchor_ip"], "name": live.names.get(r["anchor_ip"]),
                                              "episodes": [], "episodes_n": 0, "alerts": 0, "first": r["start_ms"],
                                              "last": r["end_ms"], "stages": set()})
        seen = list(r.get("phases_seen") or [])
        h["episodes_n"] += 1
        h["alerts"] += int(r["alert_count"] or 0)
        h["first"] = min(h["first"], r["start_ms"])
        h["last"] = max(h["last"], r["end_ms"])
        h["stages"].update(seen)
        if len(h["episodes"]) < EPISODES_MAX:
            h["episodes"].append({"key": r["key"], "start": r["start_ms"], "end": r["end_ms"],
                                  "alerts": int(r["alert_count"] or 0), "stages": seen,
                                  "top": r.get("highest_phase"), "progress": r.get("killchain_progression_score"),
                                  "label": r.get("cluster_label"), "types": types.get(r["cluster_id"], [])})
    rank = ev.VRANK
    out = []
    for h in hosts.values():
        t = _triage(live, h["ip"], tri, ended)
        h["stages"] = sorted(h["stages"], key=_stage_order)
        h["triage"] = t
        h["sort"] = 2 * rank.get(t["verdict"], 0) + (0 if t["record"] else 1) if t else -1   # an ended record after a live one
        out.append(h)
    out.sort(key=lambda h: (-h["sort"], -h["last"], h["ip"]))
    for h in out:
        del h["sort"]
    return {**base, "hosts": out[:HOSTS_MAX], "hosts_total": len(out),
            "episodes_total": sum(h["episodes_n"] for h in out), "alerts_total": sum(h["alerts"] for h in out)}


_CSS = r"""
.ep-h{display:grid;grid-template-columns:minmax(150px,230px) 110px 150px minmax(0,1fr) 120px 110px;gap:12px;align-items:center;padding:12px 16px;border-top:1px solid #ffffff12}
.ep-h:first-child{border-top:0}.ep-ip{font:500 14px "Roboto Mono",monospace;color:#fff}.ep-n{display:block;font-size:12px;color:var(--mut)}
.ep-st{font-size:13px;color:#dfe3f0}.ep-t{width:100%;border-collapse:collapse;margin:0 0 6px}
.ep-t th{padding:6px 10px;text-align:left;font:500 12px "Kumbh Sans",sans-serif;color:var(--mut);text-transform:none;letter-spacing:0;border-bottom:1px solid #ffffff26}
.ep-t td{padding:8px 10px;border-top:1px solid #ffffff12;font-size:13px;vertical-align:top}
.ep-b{padding:0 16px 14px}.ep-ty{margin:0;padding:0;list-style:none}.ep-ty li{display:flex;justify-content:space-between;gap:12px;max-width:420px}
.ep-ty li span:last-child{font:12px "Roboto Mono",monospace;color:var(--mut)}
.ep-c{margin-top:14px;border-radius:6px;background:var(--panel)}.ep-c>summary{list-style:none;cursor:pointer}.ep-c>summary::-webkit-details-marker{display:none}
.ep-c[open]>summary{border-bottom:1px solid #ffffff12}.ep-more{margin:14px 0}
.ep-sum{margin:0 0 12px;color:var(--mut);font-size:13px}
/* Simple view (1.3): the alert types of an episode are left out; host, verdict, stages and time span stay */
body.simple .ep-t th:nth-child(4),body.simple .ep-t td:nth-child(4){display:none}
@media (max-width:1000px){.ep-h{grid-template-columns:minmax(0,1fr) auto}.ep-h>:nth-child(n+3){grid-column:1 / -1}}
"""

_JS = r"""
(function(){
var C=window.SC,$=function(s){return document.querySelector(s)},S={data:null,q:"",st:new Set(),limit:25,open:new Set()},busy=false,timer=null;
function esc(v){return v==null?"":String(v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function nul(){return '<span class="null">&lt;null&gt;</span>'}
//@@FMT@@
function dur(a,b){var s=Math.max(0,Math.round((b-a)/1000));if(s<60)return s+" s";if(s<3600)return Math.round(s/60)+" min";var h=Math.floor(s/3600),m=Math.round(s%3600/60);return h+" h"+(m?" "+m+" min":"")}
var VL={},VC={};C.verdicts.forEach(function(v){VL[v.key]=v.label;VC[v.key]=v.color});
function badge(t){return t?'<span class="vp '+esc(t.verdict)+'" style="--vc:'+VC[t.verdict]+'" title="'+(t.record?"The peak verdict of its incident that ended with nobody reviewing it":"The verdict of this host in Triage")+'">'+esc(VL[t.verdict])+'</span>':'<span class="mut" title="Triage has no incident for this host">No incident</span>'}
function kchain(e){var seen=new Set(e.stages||[]);
  return '<div class="kc">'+C.phases.map(function(p){var on=seen.has(p);return '<span class="'+(on?"on":"")+(p===e.top?" hi":"")+'"><i style="'+(on?"background:"+C.phaseColors[p]:"")+'"></i>'+esc(p)+'</span>'}).join("")+'</div>'
  +'<div class="mut" style="font-size:12px;margin-top:4px">'+(e.progress==null?(seen.size>1?"stages in no clear order":seen.size?"one stage only":"no kill-chain stage"):e.progress>=0.8?"moves forward through the stages":e.progress<0.5?"stages out of order":"stages partly in order")+'</div>'}
function ep(e){return '<tr><td>'+tm(e.start)+'</td><td>'+tm(e.end)+'<span class="ep-n">'+esc(dur(e.start,e.end))+'</span></td><td style="min-width:300px">'+kchain(e)+'</td>'
  +'<td><ul class="ep-ty">'+e.types.map(function(t){return '<li><span>'+esc(t[0])+'</span><span>'+num(t[1])+'</span></li>'}).join("")+'</ul></td><td>'+hp(e.alerts,"alert")+'</td></tr>'}
function passes(h){if(S.st.size){var ok=false;h.stages.forEach(function(s){if(S.st.has(s))ok=true});if(!h.stages.length&&S.st.has("none"))ok=true;if(!ok)return false}
  if(S.q){var q=S.q.toLowerCase(),hay=(h.ip+" "+(h.name||"")+" "+h.episodes.map(function(e){return e.types.map(function(t){return t[0]}).join(" ")+" "+(e.label||"")}).join(" ")).toLowerCase();if(hay.indexOf(q)<0)return false}
  return true}
function host(h){var t=h.triage,st=t?esc(t.status_word)+(t.owner?'<span class="ep-n">'+esc(t.owner)+'</span>':"")+(t.changed?'<span class="ep-n">new evidence since</span>':""):'<span class="mut">No status</span>';
  var more=h.episodes_n>h.episodes.length?'<p class="mut" style="margin:6px 0 0">Newest '+hp(h.episodes.length,"episode")+' of '+num(h.episodes_n)+'.</p>':"";
  return '<details class="ep-c" data-ip="'+esc(h.ip)+'"'+(S.open.has(h.ip)?" open":"")+'><summary><div class="ep-h"><div><span class="ep-ip">'+esc(h.ip)+'</span>'+(h.name?'<span class="ep-n">'+esc(h.name)+'</span>':"")+'</div>'
    +'<div>'+badge(t)+'</div><div class="ep-st">'+st+'</div>'
    +'<div class="mut">'+hp(h.episodes_n,"episode")+', '+hp(h.alerts,"alert")+(h.stages.length?' · '+esc(h.stages.join(", ")):"")+'</div>'
    +'<div class="mut" title="Last alert">'+tm(h.last)+'</div>'
    +'<div>'+(t?'<a class="b2" href="incident?'+(t.record?"history="+t.record:"ip="+encodeURIComponent(h.ip))+'" title="The incident of this host in Triage">Open in Triage</a>':"")+'</div></div></summary>'
    +'<div class="ep-b"><table class="ep-t"><thead><tr><th>Start</th><th>End</th><th>Kill chain</th><th>Alert types (alerts)</th><th>Alerts</th></tr></thead><tbody>'+h.episodes.map(ep).join("")+'</tbody></table>'+more+'</div></details>'}
function render(){var d=S.data;if(!d)return;
  if(!d.ready){$("#view").innerHTML='<div class="loading">Reading alerts from Sycope…</div>';return}
  var all=d.hosts.filter(passes),shown=all.slice(0,S.limit);
  $("#sum").textContent=hp(d.hosts_total,"host")+", "+hp(d.episodes_total,"episode")+", "+hp(d.alerts_total,"alert")+" in the stored window. Sorted by the Triage verdict, then by the latest alert."+(all.length!==d.hosts.length?" Showing "+hp(all.length,"host")+" that match.":"")+(d.hosts_total>d.hosts.length?" The first "+num(d.hosts.length)+" are listed.":"");
  $("#view").innerHTML=(shown.length?shown.map(host).join(""):'<p class="mut">No host matches.</p>')+(all.length>shown.length?'<button type="button" class="b2 ep-more" id="more">Show '+Math.min(25,all.length-shown.length)+' more hosts</button>':"");
  var m=$("#more");if(m)m.onclick=function(){S.limit+=25;render()};
  Array.prototype.forEach.call(document.querySelectorAll(".ep-c"),function(el){el.addEventListener("toggle",function(){if(el.open)S.open.add(el.dataset.ip);else S.open.delete(el.dataset.ip)})})}
function chips(){$("#stch").innerHTML=C.phases.concat(["none"]).map(function(p){return '<button type="button" class="chip'+(S.st.has(p)?" on":"")+'" data-st="'+esc(p)+'">'+(p==="none"?"No stage":esc(p))+'</button>'}).join("")}
function load(){if(busy)return;busy=true;fetch("episodes-data",{credentials:"same-origin",headers:{Accept:"application/json"}}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json()})
  .then(function(d){S.data=d;$("#err").innerHTML="";$("#asof").textContent="as of "+tm(d.now*1000);render()}).catch(function(e){$("#err").innerHTML='<div class="err">'+esc(e.message)+'</div>'})
  .then(function(){busy=false;clearTimeout(timer);timer=setTimeout(load,(S.data&&S.data.ready?C.poll:5)*1000)})}
$("#stch").onclick=function(e){var b=e.target.closest("[data-st]");if(!b)return;var k=b.dataset.st;if(S.st.has(k))S.st.delete(k);else S.st.add(k);S.limit=25;chips();render()};
$("#q").oninput=function(){S.q=this.value.trim();S.limit=25;render()};
$("#reload").onclick=function(){load()};
chips();load();
})();
"""


def page(settings: Settings, offset_min: int = 0, simple: bool = False) -> str:
    body = """
<div id="err"></div>
<p class="ep-sum" id="sum">Each host's episodes: alerts chained in time on one host, with the stages they reached. The
verdict and the status are the host's in Triage.</p>
<div class="tools">
  <div class="chips" id="stch" style="margin:0"></div>
  <span class="sp"></span>
  <form class="srch" onsubmit="return false"><label class="vh" for="q">Search</label>
    <input type="search" id="q" placeholder="Search IP, name, alert type…" autocomplete="off"></form>
</div>
<div id="view"><div class="loading">Reading alerts from Sycope…</div></div>
"""
    topctl = (f'{tz_switch()}<span class="mut" id="asof">loading…</span><form class="rf" onsubmit="return false"><button type="button" '
              f'id="reload" title="Read the newest snapshot now" aria-label="Refresh">{pages._REFRESH}</button></form>')
    cfg = {"poll": settings.poll_seconds, "phases": PHASE_NAMES, "phaseColors": pages.PHASE_COLORS,
           "verdicts": [{"key": k, "label": v, "color": pages.VERDICT_COLORS[k]}
                        for k, v in pages.VERDICT_LABELS.items()]}
    script = f"<script>window.SC={json.dumps(cfg).replace('<', chr(92) + 'u003c')};</script><script>{_JS.replace('//@@FMT@@', FMT_JS)}</script>"
    return pages._page("Sycope Security Episodes", body, "live", settings, topctl=topctl, script=script,
                       product="episodes", css=pages._WORK_CSS + _CSS, offset_min=offset_min,
                       simple=simple, view_toggle="episodes")
