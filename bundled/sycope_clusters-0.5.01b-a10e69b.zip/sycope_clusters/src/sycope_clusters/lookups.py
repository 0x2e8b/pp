"""Sycope Lookups as address entries (spec 5.2).

Verified on the lab Sycope (2026-10-19, GET only):
- `GET config-elements?offset=0&limit=500&filter=` + urlencoded `category = "lookup.lookup"` lists the lookups: a dict
  with a "data" list, each element has "id" and "config" with "name" and "type". Only type "subnet" is read (the
  subnet6 system databases answer 404).
- `GET config-element-lookup/subnet/<id>` answers {"file": {"columns": [...], "rows": [[...]], "hasMoreRows": bool}}.
  "hosts & subnets" has the columns cidr, name, description, privacy, locationName, countryCode, longitude, latitude,
  networkFunction, trafficPolicy, service, businessUnit, severity. Lab privacy values: "Private" only.
- Paging with `?offset=N&limit=M` while hasMoreRows is true was not seen on a lookup that big; the reader therefore
  stops, with a warning, when a page repeats the previous page's first row or adds no rows (the parameters may be
  ignored by that Sycope version).
"""

from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import re
import time
from urllib.parse import quote

from sycope_clusters.addresses import Entry
from sycope_clusters.sycope import Sycope, SycopeError

log = logging.getLogger("sycope_clusters.lookups")

PAGE_ROWS = 2000
MAX_PAGES = 2000          # a runaway guard: 4 million rows
_LIST = "config-elements?offset={}&limit=500&filter=" + quote('category = "lookup.lookup"', safe="")
_COLUMNS = {"cidr": "net", "name": "name", "privacy": "privacy", "locationname": "location",
            "networkfunction": "function", "service": "service", "businessunit": "business_unit",
            "severity": "severity"}


def names(text: str) -> tuple[str, ...]:
    """The lookup names of the setting (comma or semicolon separated)."""
    return tuple(n.strip() for n in re.split(r"[,;]", text or "") if n.strip())


def _elements(client: Sycope) -> list[dict]:
    out: list[dict] = []
    for page in range(20):
        ans = client.get_json(_LIST.format(page * 500))
        data = ans.get("data") if isinstance(ans, dict) else None
        if not isinstance(data, list):
            raise SycopeError("Sycope answered the lookup list in an unexpected shape")
        out.extend(e for e in data if isinstance(e, dict))
        if len(data) < 500:
            break
    return out


def _entries(file: dict, stats: dict) -> list[Entry]:
    cols = [str(c).lower() for c in file.get("columns") or []]
    where = {_COLUMNS[c]: i for i, c in enumerate(cols) if c in _COLUMNS}
    out = []
    for r in file.get("rows") or []:
        cell = {k: str(r[i]).strip() if i < len(r) and r[i] is not None else "" for k, i in where.items()}
        try:
            net = ipaddress.ip_network(cell.pop("net", ""), strict=False)
        except ValueError:
            stats["bad_cidr"] = stats.get("bad_cidr", 0) + 1
            continue
        out.append(Entry(net, source="sycope-lookup", **cell))
    return out


def _rows(client: Sycope, lookup_id: str, label: str, stats: dict) -> list[Entry]:
    out: list[Entry] = []
    first = None
    for page in range(MAX_PAGES):
        ans = client.get_json(f"config-element-lookup/subnet/{lookup_id}?offset={page * PAGE_ROWS}&limit={PAGE_ROWS}")
        file = ans.get("file") if isinstance(ans, dict) else None
        if not isinstance(file, dict):
            raise SycopeError(f"Sycope answered lookup {label} in an unexpected shape")
        rows = file.get("rows") or []
        if page and (not rows or rows[0] == first):
            log.warning("lookup %s: paging does not advance (offset %d), keeping the %d entries read so far",
                        label, page * PAGE_ROWS, len(out))
            break
        first = rows[0] if rows else None
        out.extend(_entries(file, stats))
        if not file.get("hasMoreRows"):
            break
    else:
        log.warning("lookup %s: stopped after %d pages", label, MAX_PAGES)
    return out


_CSV_ADDRESS = ("cidr", "ip", "ipaddress", "ip address", "address", "network", "subnet", "host")


def _csv_rows(client: Sycope, lookup_id: str, label: str, stats: dict) -> list[Entry]:
    """A csvFile lookup read as addresses: the column named cidr/ip/address/..., else the first one. The answer is
    taken to have the subnet lookup's shape ({"file": {"columns", "rows"}}); one page only (not verified on a lab)."""
    ans = client.get_json(f"config-element-lookup/csvFile/{lookup_id}")
    file = ans.get("file") if isinstance(ans, dict) and isinstance(ans.get("file"), dict) else ans
    if not isinstance(file, dict) or not isinstance(file.get("rows"), list):
        raise SycopeError(f"Sycope answered lookup {label} in an unexpected shape")
    if file.get("hasMoreRows"):
        log.warning("lookup %s: only the first page of the csvFile is read", label)
    cols = [str(c).strip().lower() for c in file.get("columns") or []]
    at = next((i for i, c in enumerate(cols) if c in _CSV_ADDRESS), 0)
    out = []
    for r in file["rows"]:
        cell = str(r[at]).strip() if isinstance(r, (list, tuple)) and at < len(r) and r[at] is not None else ""
        try:
            out.append(Entry(ipaddress.ip_network(cell, strict=False), source="sycope-lookup"))
        except ValueError:
            stats["bad_cidr"] = stats.get("bad_cidr", 0) + 1
    return out


def read(client: Sycope, wanted: tuple[str, ...], stats: dict | None = None,
         types: tuple[str, ...] = ("subnet",)) -> list[Entry]:
    """The entries of the named lookups of the given types (subnet; csvFile for a list of addresses), in the order
    of the names. `stats["bad_cidr"]` counts the rows skipped for an unparseable cidr."""
    stats = stats if stats is not None else {}
    stats["bad_cidr"] = 0
    found = [e for e in _elements(client) if isinstance(e.get("config"), dict)]
    out: list[Entry] = []
    for want in wanted:
        hits = sorted((e for e in found if str(e["config"].get("name", "")).strip().lower() == want.strip().lower()
                       and e["config"].get("type") in types), key=lambda e: str(e.get("id")))
        if not hits:
            log.warning("lookup %r not found among the %s lookups", want, "/".join(types))
        for e in hits:
            rows = _rows if e["config"].get("type") == "subnet" else _csv_rows
            out.extend(rows(client, str(e["id"]), want, stats))
    return out


def digest(entries: list[Entry]) -> str:
    """sha256 of the lookup entries as a set (row order does not count)."""
    rows = sorted(json.dumps([str(e.net), e.name, e.privacy, e.location, e.function, e.service, e.business_unit,
                              e.severity]) for e in entries)
    return hashlib.sha256("\n".join(rows).encode()).hexdigest()


class LookupCache:
    """The lookup entries, read again every `refresh_s` seconds; the last good read is kept when Sycope fails."""

    def __init__(self, refresh_s: int = 900, wanted: tuple[str, ...] = ("hosts & subnets",),
                 types: tuple[str, ...] = ("subnet",)) -> None:
        self.refresh_s, self.wanted, self.types = refresh_s, wanted, types
        self.entries: list[Entry] = []
        self.error = ""
        self.read_at = 0.0
        self.bad_cidr = 0
        self.digest = digest([])
        self.change: dict = {}     # the last change: digest, was, now, added, removed
        self._tried: float | None = None

    def get(self, client: Sycope | None, now: float | None = None) -> list[Entry]:
        now = time.time() if now is None else now
        if client is not None and self.wanted and (self._tried is None or now - self._tried >= self.refresh_s):
            self._tried = now
            stats: dict = {}
            try:
                got = read(client, self.wanted, stats, self.types)
            except SycopeError as exc:
                self.error = str(exc)
            except Exception as exc:  # a changed answer shape must not stop the board
                log.exception("lookup read failed")
                self.error = f"{type(exc).__name__}: {exc}"
            else:
                d = digest(got)
                if d != self.digest:
                    old, new = set(self.entries), set(got)
                    self.change = {"digest": d, "was": len(self.entries), "now": len(got),
                                   "added": len(new - old), "removed": len(old - new)}
                    log.info("lookups changed: %d entries (was %d)", len(got), len(self.entries))
                    self.digest = d
                self.entries, self.error, self.read_at, self.bad_cidr = got, "", now, stats["bad_cidr"]
        return self.entries
