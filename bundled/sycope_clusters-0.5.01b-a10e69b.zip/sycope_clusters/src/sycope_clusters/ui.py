"""The Triage page: the queue of incidents in order and why; the lanes around it; one page per incident.

One work object, the incident, with an explicit size: one host, a group of hosts with the same pattern (a story), or
a campaign (many hosts of one network, with its incidents inside it). The queue is a table: verdict, what happened,
scope, how far the attack got (confirmed stages filled, suspected ones hollow), confidence, last activity, status.
A row opens the incident's own page (/incident?ip=|story=|campaign=), with a breadcrumb back and Previous / Next in
the order of the queue; a side panel stays as a quick look. Bulk actions name their hosts one by one. Data comes from
/board, /host, /story, /campaign and /lane as JSON (GET); analyst actions go to /action (POST, same guard as the other
writes). Every value put into innerHTML is escaped.
"""

from __future__ import annotations

import json
import re

from sycope_clusters import cluster_work, confui, fmt, helpdoc, triage
from sycope_clusters.config import Settings
from sycope_clusters.look import _REFRESH
from sycope_clusters.pages import _WORK_JS_SHARED, ICONS, PHASE_COLORS, _page, _svg
from sycope_clusters.rules import CATALOG, DISPLAY_NAMES, FAMILIES, STAGES
from sycope_clusters.store import EXC_MAX_DAYS

VERDICT = {"act": ("Act now", "#e0122d"), "investigate": ("Investigate", "#ff7a00"), "review": ("Review", "#e5c100"),
           "watch": ("Watch", "#4aa3ff")}
STAGE_COLORS = [PHASE_COLORS["Recon"], PHASE_COLORS["Foothold"], PHASE_COLORS["Lateral"],
                PHASE_COLORS["Objectives"]]

_CSS = """
.hl2{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 8px;margin:0;font-size:13px;color:var(--mut);white-space:normal;min-width:0;cursor:help}.hl2[hidden]{display:none}
.hl2 b{font-size:15px;font-weight:600;color:#fff}.hl2 i{font-style:normal;color:var(--nul)}
.hl2 .hlact b{color:#ff4d5e}.hl2 .chgd b{color:#ffb3c0}
.nt{display:inline-flex;align-items:center;height:20px;padding:0 5px;border-radius:3px;font:13px "Kumbh Sans",sans-serif;color:var(--mut)}
.nt:hover{color:#fff;background:var(--panel2);text-decoration:none}a.b2{display:inline-flex;align-items:center;color:#fff;text-decoration:none}
.incident{max-width:1280px;margin:0 auto}.incbar{display:flex;align-items:center;gap:14px;margin:0 0 12px;font-size:13px}
.why3{font-size:12.5px;margin:0 0 3px;color:#cfd4e6}.why3.w3{margin-bottom:8px}.why3 a{color:#8cc4ff}.rsn2.w1{margin-bottom:8px}
.ap{padding:2px 0 0}.ap svg{display:block;width:100%;overflow:visible}
.ap .ln{fill:var(--mut);font:11px "Kumbh Sans",sans-serif}.ap .lb{fill:#e6e8f0;font:11.5px "Kumbh Sans",sans-serif}
.ap .ax{fill:var(--mut);font:10.5px "Roboto Mono",monospace}
.ap .hit{cursor:default}.ap .hit:hover rect.bar{filter:brightness(1.25)}
.apleg{display:flex;flex-wrap:wrap;gap:6px 16px;margin:6px 0 2px;font-size:11.5px;color:var(--mut)}.apleg span{display:inline-flex;align-items:center;gap:6px}
.apleg i{display:inline-block;width:18px;height:8px;border-radius:4px}
.hist{list-style:none;margin:0;padding:0;border-left:2px solid var(--panel2)}
.hist li{position:relative;margin:0 0 8px;padding:0 0 0 16px;line-height:1.45;font-size:13px}
.hist li::before{content:"";position:absolute;left:-6px;top:6px;width:10px;height:10px;border-radius:50%;background:var(--hc,#808297)}
.hist li.sys{color:#cfd4e6}.hist .tm{font:12px "Roboto Mono",monospace;color:var(--mut);margin-right:8px}.hist b{font-weight:600}
.afl{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 10px}.afl select,.afl input[type=search]{height:32px;padding:0 8px;border-radius:5px;border:1px solid var(--panel2);background:var(--panel);color:#fff;font:inherit;font-size:13px}
.afl label{font-size:12px;color:var(--mut);display:flex;align-items:center;gap:5px}
.hsum{position:relative;margin:0 0 10px;padding:12px 14px 10px 18px;border-radius:6px;background:var(--panel)}
.hsum::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;border-radius:6px 0 0 6px;background:var(--vc)}
.hsum .dh{margin:0 0 4px}.hsum .dh .sp{flex:1}.hsum .dsum{font-size:16px;margin:6px 0 4px;color:#fff}
.rsn2{font-size:13px;color:#cfd4e6;margin:0 0 8px}.rsn2 b{color:var(--vc)}
.facts{display:flex;flex-wrap:wrap;align-items:center;gap:6px 14px;font-size:12px;color:var(--mut)}.facts .kcs{width:300px}
.facts .track{display:inline-block;width:120px;height:7px;border-radius:4px;background:#1c1d3b;overflow:hidden;vertical-align:middle;margin-left:6px}.facts .track i{display:block;height:100%;background:var(--vc)}
.pcl{display:flex;flex-wrap:wrap;align-items:center;gap:6px 10px;margin:8px 0 0;font-size:13px}.tg.pc{background:#0e3b35;color:#5fe0c4}
tr.hasp td{background:#13302e}
.tabs{display:flex;flex-wrap:wrap;align-items:flex-end;margin:0 0 14px;border-bottom:1px solid #ffffff26}
.tgp{display:flex;align-items:flex-end;gap:2px}.tgp+.tgp::before{content:"";align-self:center;width:1px;height:22px;margin:0 10px;background:#ffffff26}.tgp.end{margin-left:auto}.tgp.end::before{display:none}
.tab{display:flex;align-items:center;gap:8px;height:34px;margin:0 0 -1px;padding:0 14px;border:0;border-bottom:2px solid transparent;border-radius:6px 6px 0 0;background:none;color:#868c9b;font:inherit;font-size:14px;font-weight:500;cursor:pointer;white-space:nowrap}
.tab .ic{color:inherit;opacity:.85}.tab:hover{color:#fff;border-bottom-color:#ffffff59}.tab.on{color:#fff;background:#ffffff0d;border-bottom-color:var(--info)}.tab.on .ic{color:#8cc4ff;opacity:1}
.tab .n{font:12px "Roboto Mono",monospace;padding:1px 7px;border-radius:9px;background:var(--panel2);color:#dfe3f0}.tab .n+.n{margin-left:-4px}
.tab .n.v-act{background:#e0122d;color:#fff}.tab .n.v-investigate{background:#ff7a00;color:var(--ink)}.tab .n.hot{background:#7a1a2a;color:#fff}
.qbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:0 0 10px}
.vch{display:inline-flex;align-items:center;gap:8px;height:32px;padding:0 12px;border-radius:5px;border:1px solid transparent;background:var(--panel2);color:var(--mut);font:inherit;font-size:13px;cursor:pointer}
.vch i{width:9px;height:9px;border-radius:50%;background:var(--vc)}.vch b{color:#fff;font-weight:400;font-family:"Roboto Mono",monospace;font-size:12px}
.vch.on{border-color:var(--vc);color:#fff;background:color-mix(in srgb,var(--vc) 16%,var(--panel2))}
.qbar .sp{flex:1}.qbar input[type=search]{height:32px;width:280px;padding:0 10px 0 34px;border-radius:5px;border:1px solid var(--panel2);background:var(--panel);color:#fff;font:inherit;font-size:13px}
.qbar label{font-size:12px;color:var(--mut);display:flex;align-items:center;gap:5px;cursor:pointer}
.vp{display:inline-flex;align-items:center;justify-content:center;height:20px;padding:0 8px;border-radius:3px;background:var(--vc);color:#fff;font:400 12px/1 "Roboto Mono",ui-monospace,Menlo,monospace;letter-spacing:0;text-transform:uppercase;white-space:nowrap}
.vp.review,.vp.investigate{color:var(--ink)}
.tg{display:inline-flex;align-items:center;gap:4px;height:19px;padding:0 7px;border-radius:10px;background:var(--panel2);color:#cfd4e6;font:500 10.5px/1 "Kumbh Sans",sans-serif;letter-spacing:.3px;text-transform:uppercase;white-space:nowrap}
.tg.new{background:#123a5c;color:#8cc4ff}.tg.rec{background:#34344f;color:#a8aec4}.tg.jw{background:#423812;color:#ffd700}
.tg.ch{background:#5c1a2b;color:#ffb3c0}.tg.st{background:#1f3b2e;color:#7fe0a7}.tg.lv{background:#14382a;color:var(--ok)}
.tg.svc{background:#283458;color:#a9bdff}.tg.nm{background:none;color:#dfe3f0;padding:0;font:13px "Kumbh Sans",sans-serif;text-transform:none;letter-spacing:0}
.kcs{display:grid;grid-template-columns:repeat(4,1fr);gap:3px}
.kcs span{display:flex;flex-direction:column;gap:4px;font-size:10.5px;color:var(--nul);text-align:left;overflow:hidden;white-space:nowrap}
.kcs span i{display:block;height:7px;border-radius:2px;background:#1c1d3b;border:1px solid #2f3060}
.kcs span.c{color:#fff}.kcs span.c i{background:var(--sc);border-color:var(--sc)}
.kcs span.s{color:#cfd4e6}.kcs span.s i{background:transparent;border:1px dashed var(--sc)}
.b2{height:28px;padding:0 11px;border:0;border-radius:4px;background:var(--panel2);color:#fff;font:inherit;font-size:12px;cursor:pointer;white-space:nowrap}
.b2:hover{background:var(--head)}.b2.pri{background:var(--blue)}.b2.pri:hover{background:#3a62ff}.b2.warn{background:#5c1a2b}.b2:disabled{opacity:.4;cursor:default}
.more2{display:block;margin:12px auto 0}
.empty2{padding:28px;text-align:center;color:var(--mut);background:var(--panel);border-radius:5px}
.drw{position:fixed;top:48px;right:0;bottom:0;z-index:40;width:min(1180px,76vw);background:#14153a;border-left:1px solid var(--panel2);box-shadow:-12px 0 32px #0009;display:flex;flex-direction:column}
.drw[hidden]{display:none}.drw-grip{position:absolute;left:-5px;top:0;bottom:0;z-index:5;width:10px;cursor:col-resize}
.drw-grip:hover,.drw.rs .drw-grip{background:linear-gradient(90deg,transparent 4px,var(--info) 4px,var(--info) 6px,transparent 6px)}.drw-h{display:flex;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--panel2)}
.drw-h .sp{flex:1}.drw-b{overflow:auto;padding:14px 18px 40px}.drw-b th,.drw-b .qt th{top:-14px}
.dh{display:flex;align-items:center;flex-wrap:wrap;gap:8px 12px;margin:0 0 6px}.dh .ip{font:22px "Roboto Mono",monospace}
.dsum{font-size:15px;line-height:1.45;margin:4px 0 10px}.dsum b{font-weight:600}
.cbar{display:flex;align-items:center;gap:10px;margin:6px 0 12px;font-size:12px;color:var(--mut)}
.cbar .track{flex:1;max-width:320px;height:8px;border-radius:4px;background:#1c1d3b;overflow:hidden}.cbar .track i{display:block;height:100%;background:var(--vc)}
.sec{margin:14px 0 0;padding:0 16px 14px;border-radius:6px;background:var(--panel)}
.sec>h3{display:flex;align-items:center;gap:8px;margin:0 -16px;padding:10px 16px;border-bottom:1px solid #ffffff12;color:#fff;font-size:14.5px;font-weight:500;letter-spacing:0;text-transform:none;cursor:pointer;user-select:none}
.sec>h3>.lnk{margin-left:auto}.secb{padding-top:12px}.secb>.qwrap,.secb>.grid,.secb>.card{margin-left:-16px;margin-right:-16px}
.secx{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;margin:0 0 0 -6px;padding:0;border:0;border-radius:4px;background:none;color:var(--mut);font-size:12px;cursor:pointer;transition:transform .15s}
.sec>h3:hover .secx{color:#fff;background:#ffffff12}.sec.shut .secx{transform:rotate(-90deg)}.sec.shut{padding-bottom:0}.sec.shut>h3{border-bottom-color:transparent}.sec.shut>.secb{display:none}
.steps{list-style:none;margin:0;padding:0;border-left:2px solid var(--panel2)}
.steps li{position:relative;margin:0 0 9px 0;padding:0 0 0 16px;line-height:1.45}
.steps li::before{content:"";position:absolute;left:-6px;top:5px;width:10px;height:10px;border-radius:50%;background:var(--sc,#808297)}
.steps li.sus::before{background:#14153a;border:2px solid var(--sc,#808297);width:6px;height:6px}
.steps .tm{font:12px "Roboto Mono",monospace;color:var(--mut);margin-right:8px}.steps .fam{font-size:11px;color:var(--mut);margin-left:6px}
.steps .note{color:#ffb020;font-size:12px;margin-left:6px}
.bg{font-size:12.5px;color:var(--mut);line-height:1.5}.bg b{color:#cfd4e6;font-weight:400}
.math{font:12px/1.7 "Roboto Mono",monospace;background:#0000002e;border-radius:5px;padding:10px 12px;overflow-x:auto;white-space:pre-wrap}
.math b{color:#fff;font-weight:400}.math .v{color:var(--vc)}
.tr td{vertical-align:top}.tr tr.off td{opacity:.5}.tr tr.ex td{opacity:.45;text-decoration:line-through}
.gl{border-bottom:1px dotted var(--mut);cursor:help}.tr .bits{font:12px "Roboto Mono",monospace;white-space:nowrap}.tr .bits u{display:block;height:4px;margin-top:3px;border-radius:2px;background:var(--info);text-decoration:none}
.tr .w{color:var(--mut);font-size:11.5px;line-height:1.45}.tr .w div{white-space:normal}
.heat td,.heat th{text-align:center;padding:4px 6px;font-size:11px;min-width:44px}.heat td:first-child,.heat th:first-child{text-align:left;min-width:170px}
.heat td.z{color:var(--nul)}.heat table{min-width:0}
.ln td{cursor:pointer}.ln tr:hover td{background:var(--hover)}.ln table{min-width:900px}
.hb{display:inline-flex;align-items:center;height:20px;padding:0 8px;border-radius:3px;font:400 12px/1 "Roboto Mono",ui-monospace,Menlo,monospace;text-transform:uppercase;white-space:nowrap}
.hb.hot,.hb.hostile{background:var(--red);color:#fff}.hb.warm,.hb.suspicious{background:var(--orange);color:var(--ink)}
.hb.service{background:var(--bar);color:#fff}.hb.noted,.hb.context{background:var(--panel2);color:#cfd4e6}
.pill2{display:inline-block;margin:0 4px 3px 0;padding:1px 7px;border-radius:9px;background:var(--panel2);font-size:11px;color:#dfe3f0;white-space:nowrap}
.note2{width:100%;max-width:520px;height:30px;padding:0 10px;border-radius:4px;border:1px solid var(--panel2);background:var(--panel);color:#fff;font:inherit;font-size:13px}
.tri{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:4px 0 6px}.tri .st{font-size:12px;color:var(--mut)}
.mbr td{cursor:pointer}.mbr tr:hover td{background:var(--hover)}
.hl2 .hm{font-size:13px;color:var(--mut)}.vch .hn{margin-left:-3px;color:var(--mut);font:12px "Roboto Mono",monospace}
.qwrap,.grid{overflow:visible}th{position:sticky;top:0;z-index:3}
.qt{width:100%;min-width:980px;border-collapse:collapse;border-spacing:0}
.qt th{position:sticky;top:0;z-index:3;height:38px;padding:0 10px;border:0;border-left:1px solid #ffffff14;border-bottom:1px solid #ffffff26;background:#353664;color:#fff;font:500 12.5px "Kumbh Sans",sans-serif;letter-spacing:0;text-transform:none;white-space:nowrap;text-align:left}
.qt th:first-child{border-left:0}
.qt td{padding:9px 10px;border:0;border-top:1px solid #ffffff12;background:transparent;font-size:13px;vertical-align:middle}
.qt tr.qr td:first-child{box-shadow:inset 4px 0 0 var(--vc);padding-left:16px}
.qt tr.qr{cursor:pointer}.qt tr.qr:hover td{background:#ffffff0d}.qt tr.qr.sel td{background:#1c3b6e}
.qt tr.child td{background:#00000024}.qt tr.child td.c-v{padding-left:30px}.qt tr.handled td{opacity:.55}
.qt .c-i{min-width:260px}.qt .qt-t{margin-right:6px;color:#fff;font-size:14px;line-height:1.35}
.qt .qt-s{display:-webkit-box;margin-top:3px;overflow:hidden;color:var(--mut);font-size:12px;-webkit-line-clamp:1;-webkit-box-orient:vertical}
.qt .c-s,.qt .c-l,.qt .c-st,.qt .c-sla{white-space:nowrap}.sla{font:12px "Roboto Mono",monospace;color:var(--mut)}.sla.warn{color:var(--warn,#ffb020)}.sla.bad{color:var(--bad,#ff6b6b);font-weight:600}.qt .c-c{white-space:nowrap;font:13px "Roboto Mono",monospace}.qt .c-a{white-space:nowrap;text-align:right}
.qt .sub{margin-right:6px;color:var(--mut)}.qt .c-x{width:30px}.btns{display:inline-flex;align-items:center;gap:6px}.qt .c-a .btns{gap:4px}.qt .c-a .b2{height:26px;padding:0 9px}.qt .c-c .mut{display:block;max-width:110px;white-space:normal;font:11px "Kumbh Sans",sans-serif}.qt.ht .c-p{max-width:440px;font-size:12.5px}
.exp{height:22px;margin-right:8px;padding:0 8px;border:1px solid var(--panel2);border-radius:11px;background:none;color:#dfe3f0;font:12px "Roboto Mono",monospace;cursor:pointer}.exp:hover{background:var(--panel2)}
.kc4{display:inline-grid;grid-template-columns:repeat(4,14px);gap:2px;margin-right:8px;vertical-align:middle}
.kc4 i{display:block;height:8px;border:1px solid #2f3060;border-radius:2px;background:#1c1d3b}.kc4 i.c{border-color:var(--sc);background:var(--sc)}.kc4 i.s{border:1px dashed var(--sc);background:transparent}
.kcn{color:#cfd4e6;font-size:12px}
.kcl{display:grid;grid-template-columns:repeat(4,14px);gap:2px;margin-top:1px;color:var(--mut);font:10px/12px "Roboto Mono",monospace}.kcl i{font-style:normal;text-align:center}
.qt .tip{font-family:"Roboto Mono",monospace;font-size:.93em;color:#fff}.qt .tar{color:var(--nul)}
.st0{color:#dfe3f0}.st-ack,.st-resolved{color:#7fe0a7}.st-investigating{color:#8cc4ff}.st-fp{color:#a8aec4}.st-ch{color:#ffb3c0}
.ldot{display:inline-block;width:7px;height:7px;margin-right:6px;border-radius:50%;background:var(--ok);vertical-align:middle}
.nsince{color:#8cc4ff;font-size:11px}.jw{color:#ffd700;vertical-align:middle}
.b2.peek{display:inline-flex;align-items:center;padding:0 8px}.b2.peek svg{display:block}.qt .c-a .btns{align-items:center}.qt .c-k{white-space:nowrap}.b2.off{opacity:.35;cursor:default}
.keys{margin:8px 0 0;color:var(--nul);font-size:11.5px;text-align:center}
.crumbs{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin:0 0 12px;font-size:13px}.crumbs .sep{color:var(--nul)}.crumbs b{color:#fff;font-weight:400}.crumbs .sp{flex:1}.crumbs .b2{display:inline-flex;align-items:center}
.bulk{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:4px 0 6px}.bscope{margin-right:6px;color:var(--mut);font-size:12.5px}.bscope b{color:#fff;font-weight:600}
.partof{margin:8px 0 0;color:#cfd4e6;font-size:13px}
.qsec td{padding:11px 14px 8px;border-top:1px solid #ffffff12;background:#0000002b!important;box-shadow:none!important;cursor:default}.qsec-l{color:var(--vc);font-weight:600;font-size:13px;letter-spacing:.3px}.tab .n2{margin-left:3px;color:var(--mut);font:12px "Roboto Mono",monospace}.pend{position:fixed;right:20px;bottom:18px;z-index:55;max-width:min(560px,calc(100vw - 40px));padding:6px 14px;border:1px solid var(--info);border-radius:16px;background:#26285a;box-shadow:0 6px 20px #0008;font-size:13px}.stale{margin:0 0 10px;padding:8px 12px;border-radius:5px;background:#4a3a12;color:#ffd98a;font-size:13px}.wfs{display:inline-flex;gap:4px;margin-left:6px}.wf{height:32px;padding:0 10px;border:1px solid transparent;border-radius:5px;background:var(--panel2);color:var(--mut);font:inherit;font-size:13px;cursor:pointer}.wf b{color:#fff;font:12px "Roboto Mono",monospace;margin-left:3px}.wf.on{border-color:var(--info);color:#fff}.qt tr.nk{cursor:default}.qt tr.nk:hover td{background:transparent}.qt.lt td{font-size:12.5px}.qt td.empty{color:var(--mut);text-align:center}.qt tr.agi td{background:#00000024;padding-top:5px;padding-bottom:5px}.qt tr.hasp td{background:#13302e}
.dlg-w{position:fixed;inset:0;z-index:90;display:flex;align-items:flex-start;justify-content:center;padding:12vh 16px 0;background:#05061acc}.dlg{width:min(560px,100%);padding:18px 20px 16px;border:1px solid var(--panel2);border-radius:8px;background:#161740;box-shadow:0 18px 50px #000c}.dlg h3{margin:0 0 10px;font-size:16px;font-weight:600}.dlg-b{margin:0 0 10px;color:#cfd4e6;font-size:13px;line-height:1.5}.dlg-b p{margin:6px 0}.dlg-f{display:flex;flex-direction:column;gap:5px;margin:0 0 10px;color:var(--mut);font-size:12px}.dlg-f input,.dlg-f select,.dlg-f textarea{padding:7px 9px;border:1px solid var(--panel2);border-radius:5px;background:var(--panel);color:#fff;font:inherit;font-size:13px}.dlg-f .req{color:#ffb3c0;font-weight:400}.dlg-err{min-height:16px;color:#ffb3c0;font-size:12px}.dlg-a{display:flex;justify-content:flex-end;gap:8px;margin-top:6px}.scope-box{margin:0 0 10px;padding:8px 10px;border-radius:5px;background:var(--panel)}
.st-investigating{color:#8cc4ff}.st-escalated{color:#e0a8ff}.st-tp{color:#7fe0a7}.st-benign{color:#5fe0c4}.mine{font-weight:600}.b2.bk{box-shadow:inset 0 0 0 1px #c9a05b88}.me{margin-right:10px;color:var(--mut);font-size:13px}.me.sy{color:#cfd4e6;cursor:default}.vok{margin-left:3px;color:#7fe0a7;font-size:12px}.tz{margin-right:8px;font-size:12px}
.ekind{display:inline-block;padding:1px 6px;border-radius:4px;background:var(--panel2);color:#cfd4e6;font:600 10px/1.5 "Kumbh Sans",sans-serif;letter-spacing:.4px;text-transform:uppercase;vertical-align:1px}.ekind-ip{background:#1d3557;color:#8cc4ff}.ekind-host,.ekind-asset{background:#173d3a;color:#5fe0c4}.ekind-user{background:#4a2d14;color:#ffcf8a}.ekind-mac{background:#3a3a1a;color:#e5d96a}.ekind-subnet{background:#3a2a55;color:#d0b3ff}.ekind-pattern{background:#2c3b2f;color:#9fe0b0}.ekind-tgt{background:#4a1d2a;color:#ffa3b5}.ekind.qk{margin-right:7px;vertical-align:2px}
.st-exp{color:#c9a05b}.st-open{color:#8cc4ff}.hstat{display:flex;flex-wrap:wrap;gap:6px 22px;margin:2px 0 10px;font-size:13px;color:var(--mut)}.hstat b{color:#fff;font-weight:600}
.nxc{margin-left:6px;color:var(--mut);font-weight:400;text-transform:none;letter-spacing:0}.nxo{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:0}
.nx{display:flex;gap:10px;align-items:flex-start;padding:9px 12px;border-top:1px solid #ffffff10;border-left:3px solid #4aa3ff}.nx:first-child{border-top-color:transparent}.nx.nx-ask{border-left-color:#c9a05b}.nx.nx-act{border-left-color:#ff5d73}
.nx input{margin:2px 0 0;width:16px;height:16px;flex:none;cursor:pointer;accent-color:#3ecf72}.nx .nxb{width:16px;flex:none}.nxt{min-width:0}.nxt b{font-weight:600;color:#fff}.nx.ok .nxt b{color:var(--mut);text-decoration:line-through;text-decoration-color:#3ecf7280}
.nxk{display:inline-block;min-width:46px;margin-right:6px;font:600 10.5px "Roboto Mono",monospace;text-transform:uppercase;letter-spacing:.4px;color:#8cc4ff}.nx-ask .nxk{color:#e0b86a}.nx-act .nxk{color:#ff8b98}
.nxl{font-size:13px}.nxt .mut{font-size:12.5px;margin-top:2px}.nxd{color:#7fe0a7}.nxf{font-size:12px;margin:8px 0 0}
.tg.pri{background:#2a2f63;color:#fff;font-weight:600;letter-spacing:.3px}tr.held .hw,tr.unrev .hw,tr.heldrec .hw{font-size:11px;margin-top:3px}.st-unrev{color:#ffcf8a}tr.unrev .tg.back,tr.heldrec .tg.back{background:#3b2f12;color:#ffd98a}.awy b{color:#fff}
.gs{position:relative;flex:0 1 250px;min-width:110px;margin-right:4px}.top .hlp,.top .bell,.top .me,.top .rfg,.top .modb{flex:none}@media (max-width:1400px){.top .tzl{display:none}}.gs svg{position:absolute;left:10px;top:9px;color:var(--mut);pointer-events:none}.gs input{width:100%;min-width:0;height:32px;padding:0 10px 0 30px;border:1px solid transparent;border-radius:4px;background:var(--panel2);color:var(--fg);font:inherit;font-size:13px}
.gs input:focus{outline:none;border-color:var(--blue)}.gsr{position:absolute;right:0;top:40px;width:min(580px,92vw);max-height:72vh;overflow:auto;z-index:90;padding:6px;border:1px solid var(--pop);border-radius:6px;background:var(--panel2);box-shadow:0 10px 30px #000b}
.gsh{padding:8px 8px 4px;color:var(--mut);font-size:11px;text-transform:uppercase;letter-spacing:.5px}.gsh span{text-transform:none;letter-spacing:0}.gsi{display:flex;align-items:center;gap:10px;padding:6px 8px;border-radius:4px;color:var(--fg)}.gsi:hover{background:var(--head);text-decoration:none}
.gsl{display:flex;flex-direction:column;min-width:0}.gsl .mut{font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.gsv{display:inline-block;width:86px;flex:none}.gse{padding:12px;color:var(--mut)}
[hidden]{display:none!important}
.ii{position:relative;display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;margin-left:7px;border:1px solid #5d6290;border-radius:50%;color:#a9b0d8;font:italic 600 10px/1 Georgia,serif;text-transform:none;letter-spacing:0;vertical-align:1px;cursor:help;flex:none}
.ii:hover,.ii:focus{border-color:#8cc4ff;color:#fff;outline:none}.iit{display:none;position:absolute;left:-12px;top:22px;z-index:65;width:max-content;max-width:min(420px,72vw);padding:10px 12px;border:1px solid var(--pop);border-radius:6px;background:var(--panel2);box-shadow:0 8px 24px #000b;color:#cfd4e6;font:400 12.5px/1.5 "Kumbh Sans",sans-serif;text-align:left;white-space:normal}
.ii.r .iit{left:auto;right:-12px}.ii:hover .iit,.ii:focus .iit{display:block}.iit b{color:#fff}.apl{display:flex;align-items:center;gap:8px;margin:2px 0}.apl i{display:inline-block;width:22px;height:8px;border-radius:4px}
.fold{margin:6px 0 0}.fold summary{display:inline-block;list-style:none;cursor:pointer;color:var(--mut);font-size:12.5px}.fold summary::-webkit-details-marker{display:none}.fold summary::before{content:"▸ "}.fold[open] summary::before{content:"▾ "}.fold .bg{margin-top:4px}
.lead1{margin:0 0 10px;color:#cfd4e6;font-size:13.5px;display:flex;align-items:center}.nxd{margin-top:2px;color:#7fe0a7;font-size:12px}
.hlp{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;margin-right:8px;padding:0;border:0;border-radius:50%;background:var(--panel2);color:#cfd4e6;font:600 14px "Kumbh Sans",sans-serif;cursor:pointer}.hlp:hover{background:var(--head)}.hlp.on{background:var(--blue);color:#fff}
.hlpp{position:fixed;top:48px;right:0;bottom:0;z-index:46;display:flex;flex-direction:column;width:min(480px,100vw);background:#11123a;border-left:1px solid var(--panel2);box-shadow:-12px 0 32px #0009}
.hlpp-h{display:flex;align-items:center;gap:14px;padding:10px 16px;border-bottom:1px solid var(--panel2)}.hlpp-t{color:#fff;font-size:17px}.hlpx{font-size:24px;line-height:1;padding:0 4px;color:#cfd4e6}.hlppin{color:var(--mut)}.hlppin.on{color:#ffc83d}
.hlpp-b{overflow:auto;padding:14px 22px 60px}.hlpt{margin:2px 0 12px;font-size:32px;font-weight:400;color:#fff;letter-spacing:.2px;text-transform:none}.hlpp-b h3{margin:18px 0 6px;font-size:14px;font-weight:600;color:#fff;text-transform:none;letter-spacing:0}
.hlpp-b p,.hlpp-b li,.hlpp-b dd{color:#cfd4e6;font-size:13.5px;line-height:1.55}.hlpp-b ul,.hlpp-b ol{padding-left:18px}.hin{font-size:14px!important}
.hf{margin:12px 0 4px}.hf img{display:block;width:100%;border:1px solid var(--panel2);border-radius:4px;cursor:zoom-in}.hf figcaption{margin-top:4px;color:var(--mut);font-size:12px}
.hlg{list-style:none;margin:6px 0 16px;padding:0!important}.hlg li{display:flex;gap:9px;margin:0 0 8px}.hlg li b{color:#fff;font-weight:600;margin-right:3px}.hlg .hn{display:inline-flex;flex:none;align-items:center;justify-content:center;width:20px;height:20px;margin-top:1px;border-radius:50%;background:#ffc83d;color:#0c0e2e;font-size:12px;font-weight:700}
.hdl dt{margin-top:9px;color:#fff;font-weight:600;font-size:13.5px}.hdl dd{margin:2px 0 0}.htb{width:100%;margin:6px 0;border-collapse:collapse;font-size:12.5px}.htb th,.htb td{padding:6px;border-bottom:1px solid var(--panel2);text-align:left;vertical-align:top;color:#cfd4e6}.htb th{color:var(--mut);font-weight:600}
.hsee{font-size:13px}.hall{margin-top:26px;padding-top:10px;border-top:1px solid var(--panel2)}.hall a{display:inline-block;margin:0 12px 7px 0;font-size:13px}.hall a.on{color:#fff;font-weight:600}
.vdot{display:inline-block;width:10px;height:10px;margin-right:8px;border-radius:50%}.vdot[data-v=act]{background:#e0122d}.vdot[data-v=investigate]{background:#ff7a00}.vdot[data-v=review]{background:#e5c100}.vdot[data-v=watch]{background:#4aa3ff}
body.help-on .wrap{margin-right:480px}body.help-on .drw{right:480px}body.help-on .pend{right:500px}
.lbx{position:fixed;inset:0;z-index:95;display:flex;align-items:center;justify-content:center;padding:28px;background:#05061aee;cursor:zoom-out}.lbx img{max-width:100%;max-height:100%;border-radius:4px;box-shadow:0 10px 40px #000}
@media (max-width:1100px){body.help-on .wrap{margin-right:0}body.help-on .drw{right:0}}
.pvb{height:24px;padding:0 8px;font-size:12px;margin-top:4px}
.hfb{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px}.hfb input{width:260px;height:30px;padding:0 10px;border:1px solid var(--panel2);border-radius:4px;background:var(--panel);color:var(--fg);font:inherit;font-size:13px}.hfb select{height:30px}
.qsb{position:sticky;top:0;z-index:6;display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:0 0 8px;padding:8px 10px;border:1px solid #c9a05b66;border-radius:6px;background:#1d1e4a}.qx{margin:0 8px 0 0;vertical-align:middle;cursor:pointer}.qt td.c-v{white-space:nowrap}
th.srt{cursor:pointer;user-select:none}th.srt:hover,th.srt.on{color:#fff}.srtn{margin:0 0 8px;font-size:12.5px;color:var(--mut)}
.nx{flex-wrap:wrap}.nx>.flx{flex-basis:100%;margin:0 0 0 26px;min-width:0}.flw{margin:8px 0 4px}.flx td{padding:0 8px 8px!important;background:none!important;box-shadow:none!important}.flt td,.flt th{font-size:12.5px}.flh{margin:12px 0 6px;font-size:13px;font-weight:600;color:var(--mut)}.flb{margin-top:8px}
@media (max-width:1180px){.gs{flex-basis:170px}}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}
@media (max-width:1000px){.drw{width:100vw}.cols{grid-template-columns:1fr}}
.hact{margin:12px -14px -10px -18px;padding:10px 14px 4px 18px;border-top:1px solid #ffffff12}.hact .tri,.hact .bulk{margin:0 0 6px}.pvt{font-size:13px}
.drwt{color:#fff;font-size:15px}.drwx{width:32px;height:32px;padding:0;border:0;border-radius:5px;background:none;color:#c8ccd8;font-size:24px;line-height:1;cursor:pointer}.drwx:hover{background:var(--panel2);color:#fff}
.tcard{margin:0 0 14px;border-radius:6px;background:var(--panel);overflow:clip}
.qtb{position:sticky;top:0;z-index:6;display:flex;flex-wrap:wrap;align-items:center;gap:4px 10px;min-height:52px;padding:6px 12px;background:var(--panel)}.qtb .sp{flex:1}
.qtb label{display:flex;align-items:center;gap:5px;font-size:12px;color:var(--mut);cursor:pointer}.qq th{top:52px}
.abtn{display:inline-flex;align-items:stretch;height:33px;padding:0;border:0;border-radius:5px;background:#1a318e;color:#9899b3;font:inherit;font-size:14px;cursor:default}
.abtn .al{display:flex;align-items:center;padding:0 18px 0 20px}.abtn .chev{display:flex;align-items:center;padding:0 11px;border-left:1px solid #112473;border-radius:0 5px 5px 0;background:#18287d;font-size:11px}
.abtn.on{background:var(--blue);color:#fff;cursor:pointer}.abtn.on .chev{background:var(--blue2);border-left-color:#1a26a8}.abtn.on:hover{background:#3a62ff}
.qsn{font-size:13px;color:var(--mut)}.qsn b{color:#fff;font-weight:600}.tfoot{padding:10px 14px 8px;color:var(--mut);font-size:12px;text-align:right}
/* ---- silence rules (1.4) ---- */
.sch{display:inline-block;margin:1px 4px 1px 0;padding:1px 7px;border-radius:4px;background:var(--panel2);font-size:12px;white-space:nowrap}.sch i{margin-right:4px;color:var(--mut);font-style:normal}
.sct{white-space:nowrap}.sct .lnk{font:inherit}.ssp{display:block;width:84px;height:22px}.ssp rect{fill:#5a6aa8}.ssp line{stroke:#ffffff24;stroke-width:1;vector-effect:non-scaling-stroke}
.slt{min-width:0!important}.slt td.rs{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.slt td.sc-a .btns{display:flex;flex-direction:column;gap:3px}.slt td.sc-x{white-space:nowrap}.sil-warn{margin:0 0 12px;padding:8px 12px;border-radius:5px;background:#3a2a14;color:#ffcf8a}
.sil .sil-r{display:grid;grid-template-columns:130px 1fr;align-items:center;gap:6px 10px;margin:0 0 7px;font-size:13px}.sil .sil-r label{display:flex;align-items:center;gap:6px;color:var(--fg)}
.sil .sil-r input[type=text],.sil .sil-r select{padding:6px 8px;border:1px solid var(--panel2);border-radius:5px;background:var(--panel);color:#fff;font:inherit;font-size:13px;min-width:0;width:100%}
.sil .sil-r input:disabled,.sil .sil-r select:disabled{opacity:.45}.sil .sil-w{display:flex;flex-wrap:wrap;align-items:center;gap:4px 10px}.sil .sil-w label{gap:3px;font-size:12px;color:var(--mut)}
.sil .sil-w input[type=time]{padding:5px 6px;border:1px solid var(--panel2);border-radius:5px;background:var(--panel);color:#fff;font:inherit;font-size:13px}.sil .sil-w input:disabled{opacity:.45}.sil .sil-h{grid-column:2;color:var(--mut);font-size:12px}
.sil .sil-pick{position:relative}.sil .sil-pk-b{display:flex;align-items:center;justify-content:space-between;gap:8px;width:100%;padding:6px 8px;border:1px solid var(--panel2);border-radius:5px;background:var(--panel);color:#fff;font:inherit;font-size:13px;text-align:left;cursor:pointer}
.sil .sil-pk-b:hover,.sil .sil-pk-b[aria-expanded=true]{border-color:#5a6aa8}.sil .sil-pk-b span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sil .sil-pk-b span.mut{color:var(--mut)}.sil .sil-pk-b i{flex:none;width:7px;height:7px;margin:-3px 2px 0 0;border:solid var(--mut);border-width:0 2px 2px 0;transform:rotate(45deg)}
.sil .sil-r.off .sil-pk-b{opacity:.55}.sil .sil-pk-p{position:absolute;z-index:5;left:0;right:0;top:calc(100% + 4px);padding:6px;border:1px solid var(--panel2);border-radius:6px;background:#1b1c46;box-shadow:0 10px 28px #000b}.sil .sil-pk-p[hidden]{display:none!important}
.sil .sil-pk-q{display:block;margin:0 0 6px}.sil .sil-pk-l{max-height:260px;overflow:auto}.sil .sil-pk-g{padding:6px 8px 3px;color:var(--mut);font-size:11px;letter-spacing:.2px}
.sil .sil-pk-i{display:flex;align-items:baseline;justify-content:space-between;gap:10px;padding:5px 8px;border-radius:4px;cursor:pointer}.sil .sil-pk-i:hover{background:var(--hover)}.sil .sil-pk-i.sel{background:var(--panel2)}
.sil .sil-pk-i .n{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.sil .sil-pk-i .m{flex:none;color:var(--mut);font-size:12px;white-space:nowrap}.sil .sil-pk-e{padding:10px 8px;color:var(--mut)}.sil .sil-pk-i.off .n{color:var(--mut)}.sil .sil-pk-n{padding:6px 8px 2px;color:var(--mut);font-size:12px}.sil .sil-pk-n[hidden]{display:none}
.sil-pv{min-height:44px;margin:4px 0 10px;padding:8px 10px;border-radius:5px;background:var(--panel);font-size:13px;line-height:1.5}.sil-pv .bad{color:#ffb3c0}.sil-pv .note{color:var(--mut)}.sil-pv .warn{color:#ffcf8a}
.sil-sec td{padding:0}.sil-sec .nm{color:var(--mut)}
.ra{display:inline-flex;align-items:center;gap:2px;white-space:nowrap;opacity:0;pointer-events:none}.qt .c-a .ra .b2{padding:0 6px;font-size:12px}
.qt td.c-a{padding-left:2px}.qt .c-a .btns{gap:2px}.qt .c-a .kb{margin:0;vertical-align:middle}.qt .c-k{padding-right:4px}.qt .kc4{margin-right:5px}
/* The actions column always reserves its width, so Scope and the confidence sub-line wrap where space is short: narrow windows, and always inside the drawer (its width does not follow the viewport). */
@media (max-width:1400px){.qt .c-s{white-space:normal;max-width:150px}.qt .c-c .mut{display:block;max-width:90px;white-space:normal}}
#drwb .qt .c-s{white-space:normal;max-width:150px}#drwb .qt .c-c .mut{display:block;max-width:90px;white-space:normal}
#drwb .qwrap{overflow-x:auto;max-width:100%}#drwb .qt{min-width:760px}#drwb .qt .c-a{position:sticky;right:0;background:var(--panel);box-shadow:-8px 0 8px -8px #000a}
.qt tr:hover .ra,.qt tr:focus-within .ra{opacity:1;pointer-events:auto}
.srcl{margin-top:2px;font-size:11.5px;color:var(--mut)}.srcl .tg{height:17px;font-size:10px}
.qt.compact td{padding-top:5px;padding-bottom:5px}.qt.compact .qt-s,.qt.compact td div.mut,.qt.compact .nsince{display:none}
#view table:not(.qt) th,#drwb table:not(.qt) th{height:36px;background:#353664;border-left:1px solid #ffffff14;border-bottom:1px solid #ffffff26;color:#fff;font-weight:500;font-size:12.5px}
#view table:not(.qt) th:first-child,#drwb table:not(.qt) th:first-child{border-left:0}#view table:not(.qt) td,#drwb table:not(.qt) td{background:transparent;border-left:0;border-top:1px solid #ffffff12}
#view table:not(.qt) tr:hover td,#drwb table:not(.qt) tr:hover td{background:#ffffff0d}#view table:not(.qt) tr.hasp td,#drwb table:not(.qt) tr.hasp td{background:#13302e}
.cm{position:fixed;z-index:96;min-width:250px;max-width:360px;max-height:80vh;overflow:auto;padding:6px;border:1px solid #2d2e55;border-radius:8px;background:#0a061a;box-shadow:0 12px 32px #000c}
.cm-h{padding:6px 8px 3px;color:#868c9b;font-size:12px}.cm-h .mono{color:#fff;font-size:12.5px}
.cm-i{display:flex;align-items:center;gap:8px;width:100%;padding:7px 8px;border:1px solid transparent;border-radius:8px;background:none;color:#c8ccd8;font:inherit;font-size:13px;line-height:1.3;text-align:left;cursor:pointer;white-space:nowrap;text-decoration:none}
.cm-i:hover,.cm-i:focus{outline:0;background:#ffffff0d;color:#fff;text-decoration:none}.cm-i:focus-visible{border-color:#ffffff40}.cm-x{margin-left:auto;padding-left:14px;color:#868c9b}.cm-sep{margin:5px 2px;border-top:1px solid #ffffff14}
/* ---- Simple view (1.3), per scope since 1.4.4: body.simple is the page's own scope (the queue, or the incident page); the quick look drawer has its own class (.drw.simple, the incident scope), so a Simple queue can have a Full quick look and the other way round. Full is no class. Columns and lines that differ are built in the script (SM()); these rules hide what is only a control or a detail. ---- */
body.simple .qbar .wfs,body.simple .qbar label{display:none!important}  /* queue: Mine / Unassigned / Escalated, changed only, show handled, Watch hosts */
body.simple #view .qtb .abtn,body.simple #view .qtb .qsn,body.simple #view .qtb .hl2,body.simple #view .qtb label,body.simple #view .qtb [data-pause],.drw.simple .qtb .abtn,.drw.simple .qtb .qsn,.drw.simple .qtb .hl2,.drw.simple .qtb label,.drw.simple .qtb [data-pause]{display:none!important}  /* Action menu, headline, compact, Pause updates */
body.simple #pbn,body.simple .srtn{display:none!important}  /* the profile-learning banner; the "sorted by" line */
body.simple #view .qt,.drw.simple #drwb .qt{min-width:0}  /* five columns need no 980 px */
body.simple #view .qt .qt-s,body.simple #view .qt .c-l .mut,body.simple #view .qt .nsince,.drw.simple .qt .qt-s,.drw.simple .qt .c-l .mut,.drw.simple .qt .nsince{display:none!important}  /* the grey second line; "quiet for", "N active", "new since your visit" */
body.simple #view .qt .c-s,.drw.simple .qt .c-s{white-space:nowrap;max-width:none}body.simple #view .qt .tip,.drw.simple .qt .tip{white-space:nowrap}
body.simple #view .afl a[download],.drw.simple .afl a[download]{display:none!important}  /* History: no CSV export */
body.simple #view .facts .kcs,body.simple #view .facts .track,body.simple #view .facts .stl,.drw.simple .facts .kcs,.drw.simple .facts .track,.drw.simple .facts .stl{display:none!important}  /* record pages: no kill-chain bar, no confidence bar */
.vsw-s{margin:0 0 0 12px;vertical-align:middle}.vsw-s button{height:22px;padding:0 9px;font-size:12px}
.sl{display:flex;align-items:baseline;gap:12px;margin:7px 0;font-size:14px;line-height:1.45}
.slk{flex:none;width:42px;color:var(--mut);font:600 11px "Kumbh Sans",sans-serif;letter-spacing:.5px;text-transform:uppercase}
.slv{min-width:0;color:#e6e8f0}.slv.dsum{margin:0;font-size:16px;color:#fff}.sl-do{display:inline-flex;align-items:center;gap:8px;cursor:pointer}.sl-do input{width:16px;height:16px;margin:0;accent-color:#3ecf72;cursor:pointer}.sl-do b{font-weight:600;color:#fff}
.alld{margin:18px 0 6px;text-align:center}
"""


_DRAWER = ('<aside class="drw" id="drawer" hidden><div class="drw-grip" id="drwg" title="Drag to resize"></div>'
           '<div class="drw-h"><span id="drwt" class="drwt"></span><span class="sp"></span>'
           '<button type="button" class="drwx" id="drwx" title="Close (Esc)" aria-label="Close">×</button></div>'
           '<div class="drw-b" id="drwb"></div></aside>'
           # help, as Sycope shows it: the part for the view on screen, with its annotated screenshots
           '<aside class="hlpp" id="helpp" hidden><div class="hlpp-h"><button type="button" class="lnk hlpx" id="hlpx" '
           'title="Close help" aria-label="Close help">›</button><span class="hlpp-t">Help</span><span class="sp"></span>'
           '<a class="lnk" href="help" target="_blank" rel="noopener" title="Every part on one page">All help ↗</a>'
           '<button type="button" class="lnk hlppin" id="hlppin" title="Keep help open on every page" aria-label="Pin">'
           '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M10 1.5 14.5 6l-2 .5-2.8 2.8.3 3.2-1.5 '
           '1.5-2.6-2.6L2 15l-1-1 3.6-3.9L2 7.5 3.5 6l3.2.3L9.5 3.5z" fill="none" stroke="currentColor" stroke-width="1.3" '
           'stroke-linejoin="round"/></svg></button></div><div class="hlpp-b" id="hlpb"></div></aside>'
           '<div class="lbx" id="lbx" hidden></div>')


def _pivots(raw: str) -> list[list[str]]:
    """SC_TI_PIVOTS 'Name|https://...{ip}' items separated by ';': only https links that take the address."""
    out = []
    for part in (raw or "").split(";"):
        name, _, url = part.partition("|")
        name, url = name.strip()[:30], url.strip()
        if name and url.startswith("https://") and "{ip}" in url and len(url) <= 300:
            out.append([name, url])
    return out[:8]


def _cfg(settings: Settings, inc: dict | None = None) -> str:
    sycope = (settings.sycope_ui_url or settings.sycope_url).rstrip("/")
    cfg = {"poll": settings.poll_seconds, "edit": settings.triage_edit, "inc": inc,
           "verdicts": [{"key": k, "label": v[0], "color": v[1]} for k, v in VERDICT.items()],
           "stages": list(STAGES), "stageColors": STAGE_COLORS, "icons": ICONS,
           "families": {k: [v[0], v[1], v[2]] for k, v in FAMILIES.items()}, "ruleNames": DISPLAY_NAMES,
           "actionWords": {**triage.ACTION_WORDS, **cluster_work.ACTION_WORDS}, "sycopeUi": sycope,
           "rawdata": bool(sycope), "reasons": triage.REASONS, "stageWords": helpdoc.STAGE_WORDS,
           "approval": settings.exception_approval, "excMaxDays": EXC_MAX_DAYS, "pivots": _pivots(settings.ti_pivots),
           "internal": [n.strip() for n in settings.internal_nets.split(",") if n.strip()][:50],
           "recorderUrl": (sycope + "/npm/api/v1/passthrough/" + settings.recorder_passthrough)
           if settings.recorder_passthrough else ""}
    # "<" escaped: a value can never close the <script> element it sits in
    return (f"<style>{_CSS}{confui.CSS}</style><script>window.TC={json.dumps(cfg).replace('<', chr(92) + 'u003c')};</script>"
            f"<script>{_JS}</script>")


def _topctl(bell: bool = True) -> str:
    return ((f'<button type="button" class="bell" id="bell" aria-label="Notifications">{_svg("bell", 20)}</button>'
             if bell else "")
            + '<div class="gs"><svg width="14" height="14" viewBox="0 0 16 16" aria-hidden="true"><circle cx="6.5" cy="6.5" r="5" '
              'fill="none" stroke="currentColor" stroke-width="1.6"/><path d="m10.5 10.5 4 4" stroke="currentColor" '
              'stroke-width="1.6" stroke-linecap="round"/></svg><input type="search" id="gsq" autocomplete="off" '
              'placeholder="Search IP, host, subnet, rule…" aria-label="Search everything"><div class="gsr" id="gsr" hidden>'
              '</div></div>'
            + '<button type="button" class="hlp" id="hlpo" title="Help for this view" aria-label="Help">?</button>'
            + '<button type="button" class="modb" id="modb" hidden>modified</button>'
            + '<button type="button" class="lnk me" id="me"></button>' + fmt.tz_switch()
            + f'<span class="mut" id="asof">loading…</span>'
            f'<span class="rfg"><form class="rf" onsubmit="return false"><button type="button" id="reload" '
            f'title="Read the newest data now" aria-label="Refresh">{_REFRESH}</button></form></span>')


STORY_RE = re.compile(r"^(act|investigate|review|watch):[A-Za-z0-9+-]{1,180}$")


def incident_page(settings: Settings, ip: str = "", story: str = "", campaign: str = "", history: str = "",
                  offset_min: int = 0, simple: bool = False) -> str:
    """One incident on its own page, with its own address: a host (?ip=), a group of hosts with the same pattern
    (?story=), a campaign in one network (?campaign=) or a record of the incident history (?history=). The breadcrumb
    leads back to the queue."""
    import ipaddress

    kind = value = ""
    try:
        if ip:
            kind, value = "h", str(ipaddress.ip_address(ip))
        elif story and STORY_RE.match(story):
            kind, value = "s", story
        elif campaign:
            kind, value = "c", str(ipaddress.ip_network(campaign, strict=False))
        elif history.isdigit() and 0 < len(history) <= 12:
            kind, value = "i", str(int(history))
    except ValueError:
        kind = ""
    if not kind:
        return _page("Incident · Sycope Security Triage", '<div class="empty2">Not an incident address. Open one from the '
                     '<a href="./">triage queue</a>.</div>', "triage", settings, sub="Incident")
    sub = {"h": f"Host {value}", "s": "Incident", "c": f"Campaign {value}", "i": f"History record #{value}"}[kind]
    body = ('<div id="err"></div><div id="stale" class="stale" hidden></div><div id="pend" class="pend" hidden></div><div id="crumbs"></div>'
            '<div id="view" class="incident"><div class="loading">Loading…</div></div>' + _DRAWER)
    return _page(f"{sub} · Sycope Security Triage", body, "triage", settings, topctl=_topctl(False), sub=sub,
                 script=_cfg(settings, {"k": kind, "v": value}), offset_min=offset_min,
                 simple=simple, view_toggle="incident")


def triage_page(settings: Settings, offset_min: int = 0, simple: bool = False) -> str:
    topctl = _topctl()
    body = """
<div id="err"></div><div id="stale" class="stale" hidden></div><div id="pbn" class="pbn" hidden></div><div id="pend" class="pend" hidden></div>
<div class="tabs" id="tabs"></div>
<div id="view"><div class="loading">Reading alerts from Sycope…</div></div>
""" + _DRAWER
    return _page("Sycope Security Triage", body, "triage", settings, topctl=topctl, sub="", script=_cfg(settings),
                 offset_min=offset_min, simple=simple, view_toggle="list")


_JS_BASE = r"""
(function(){
"use strict";
var C=window.TC, $=function(s,r){return (r||document).querySelector(s)}, $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
var P=new URLSearchParams(location.search);
var S={tab:P.get("tab")||"queue", vd:new Set((P.get("v")||"act,investigate,review").split(",").filter(Boolean)), q:P.get("q")||"",
  handled:P.get("handled")==="1", changes:false, open:P.get("open")||"", data:null, lanes:{}, det:{}, limit:60, pending:{}, pcapreq:{}, exp:new Set(), pk:"", dstack:[], paused:false, wf:P.get("w")||"", col:new Set(), gopen:{}, alertsFlat:false, lastHover:0};
try{JSON.parse(sessionStorage.getItem("sc-col")||"[]").forEach(function(k){S.col.add(k)});S.paused=sessionStorage.getItem("sc-paused")==="1"}catch(x){}
var R={view:{sel:new Set(),hall:false,bulk:null},drwb:{sel:new Set(),hall:false,bulk:null}},CTX="view";
var DENSE=false;try{DENSE=localStorage.getItem("sc-dense")==="1"}catch(x){}
function rootOf(el){var r=el&&el.closest&&(el.closest("#drwb")||el.closest("#view"));return r?r.id:"view"}
function ilink(k,label,cls){return '<a class="'+(cls||"mono")+'" href="'+esc(keyUrl(k))+'" data-peek="'+esc(k)+'" title="Quick look (⌘/Ctrl-click: new tab)">'+esc(label)+'</a>'}
try{JSON.parse(sessionStorage.getItem("sc-exp")||"[]").forEach(function(k){S.exp.add(k)})}catch(x){}
var VC={}, VL={};C.verdicts.forEach(function(v){VC[v.key]=v.color;VL[v.key]=v.label});
var INC=C.inc||null;
// ---- Simple view (1.3, per scope since 1.4.4): body.simple from pages.py (SCV). LISTS is the queue's scope, INCS the incident scope: the
// quick look drawer and the incident page follow INCS. SM() is the flag for what is being drawn now (CTX: "drwb" is the drawer). ----
var INCS=!!(window.SCV&&window.SCV.inc),LISTS=INC?INCS:!!(window.SCV&&window.SCV.simple),SAVE=null;
function SMw(w){return w==="drwb"||INC?INCS:LISTS}
function SM(){return SMw(CTX)}
function simpleState(){
  if(LISTS&&!SAVE){SAVE={handled:S.handled,wf:S.wf,changes:S.changes,watch:S.vd.has("watch")};S.handled=false;S.wf="";S.changes=false;S.vd.delete("watch")}
  else if(!LISTS&&SAVE){S.handled=SAVE.handled;S.wf=SAVE.wf;S.changes=SAVE.changes;if(SAVE.watch)S.vd.add("watch");SAVE=null}}
simpleState();
function newTab(ip,label){return '<a class="'+(label?"b2":"nt")+'" href="incident?ip='+encodeURIComponent(ip)+'" target="_blank" rel="noopener" title="Open this host on its own page in a new tab">'+(label||"↗")+'</a>'}
function esc(v){return v==null?"":String(v).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function nul(){return '<span class="null">&lt;null&gt;</span>'}
var NOCONF="A target has no confidence of its own";
function cw(x){if(x.conf==null&&!x.conf_word)return '<span class="mut" title="'+esc(NOCONF)+'">n/a</span>';return x.conf_word?'<span title="'+esc(pc(x.conf))+'">'+esc(x.conf_word)+'</span>':pc(x.conf)}
function pc(x){return x==null?"":(x>=0.995?"99":x<0.01&&x>0?"<1":Math.round(x*100))+"%"}
function bytes(n){n=+n||0;var u=["B","KB","MB","GB","TB"],i=0;while(n>=1000&&i<4){n/=1000;i++}return (i&&n<100?n.toFixed(1):Math.round(n))+" "+u[i]}
function ic(name,px){return '<svg class="ic" width="'+px+'" height="'+px+'" viewBox="0 0 24 24" aria-hidden="true">'+(C.icons[name]||"")+'</svg>'}
function fam(k){return (C.families[k]||[k])[0]}
function vok(v){return v===1?'<span class="vok" title="Sycope confirmed this name">✓</span>':""}
function vp(v){return '<span class="vp '+esc(v)+'" style="--vc:'+VC[v]+'">'+esc(VL[v]||v)+'</span>'}
function sync(){if(INC)return;var u=new URLSearchParams();if(S.tab!=="queue")u.set("tab",S.tab);var vd=Array.from(S.vd).sort().join(",");if(vd!=="act,investigate,review")u.set("v",vd);
  if(S.q)u.set("q",S.q);if(S.wf)u.set("w",S.wf);if(S.handled)u.set("handled","1");if(S.open)u.set("open",S.open);var s=u.toString();try{history.replaceState(null,"",location.pathname+(s?"?"+s:""))}catch(e){}}
function getJ(u){return fetch(u,{credentials:"same-origin",headers:{Accept:"application/json"}}).catch(netErr).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})}
function post(body){if(CHECKING)toast("A moment: Sycope is confirming who you are (once a shift)");return (CHECKING||Promise.resolve()).then(function(){var h={"Content-Type":"application/json","X-SC-Action":"1"},p=passFor(ME.name);if(p)h["X-SC-Pass"]=p.pass;
    return fetch("action",{method:"POST",credentials:"same-origin",headers:h,body:JSON.stringify(body)})})
  .then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.error||("HTTP "+r.status));return j})})}
function toast(msg,bad){var t=document.createElement("div");t.className="toast";if(bad)t.style.borderLeftColor="var(--bad)";t.textContent=msg;document.body.appendChild(t);setTimeout(function(){t.classList.add("out")},2600);setTimeout(function(){t.remove()},3200)}
function copy(t){if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(t).then(function(){toast("Copied")});else{var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");toast("Copied")}catch(x){}a.remove()}}
// ---- Sycope pivots ----
var IPRE=/^[0-9A-Fa-f:.]{2,45}$/;
function isoOff(ms){var d=new Date(ms),o=-d.getTimezoneOffset(),sg=o>=0?"+":"-";o=Math.abs(o);
  return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())+"T"+p2(d.getHours())+":"+p2(d.getMinutes())+":"+p2(d.getSeconds())+sg+p2(Math.floor(o/60))+":"+p2(o%60)}
function rawUrl(nql,from,to){var gq={query:{source:"netflow",nql:nql,advanced:false},timerange:{from:isoOff(from),to:isoOff(to),roundTo:"minute"}};
  return C.sycopeUi+"/panel/raw-data/list?source=netflow&gq="+encodeURIComponent(JSON.stringify(gq))+"&direction=-1&groupType=all"}
function nqlOf(c,s,port){var t=[];if(c&&IPRE.test(c))t.push('clientIp = "'+c+'"');if(s&&IPRE.test(s))t.push('serverIp = "'+s+'"');if(port&&/^\d{1,5}$/.test(String(port)))t.push("serverPort = "+port);return t.join(" and ")}
function flows(c,s,port,from,to,label){if(!C.rawdata)return "";var q=nqlOf(c,s,port);if(!q)return "";return '<a href="'+esc(rawUrl(q,from-5*60000,to+60000))+'" target="_blank" rel="noopener" title="'+esc(q)+'">'+(label||"flows ↗")+'</a>'}
// Sycope's alert list takes the same link: NQL on the alerts stream (an alert's id selects exactly that alert)
function alertsUrl(nql,from,to){var gq={query:{source:"alerts",nql:nql,advanced:false},timerange:{from:isoOff(from),to:isoOff(to),roundTo:"minute"}};
  return C.sycopeUi+"/panel/alerts?source=alerts&gq="+encodeURIComponent(JSON.stringify(gq))}
var AIDRE=/^[0-9A-Fa-f-]{8,64}$/,NAMERE=/^[^"\\]{1,200}$/;
function alertLink(a){if(!C.rawdata||!AIDRE.test(a.id||""))return "";return '<a href="'+esc(alertsUrl('id = "'+a.id+'"',a.t-60000,a.t+120000))+'" target="_blank" rel="noopener" title="This alert in Sycope">alert ↗</a>'}
function alertsOf(rule,c,s,from,to,label){if(!C.rawdata)return "";var t=[];if(rule){if(!NAMERE.test(rule))return "";t.push('alertName = "'+rule+'"')}
  if(c&&IPRE.test(c))t.push('clientIp = "'+c+'"');if(s&&IPRE.test(s))t.push('serverIp = "'+s+'"');if(!t.length)return "";
  return '<a href="'+esc(alertsUrl(t.join(" and "),from-60000,to+120000))+'" target="_blank" rel="noopener" title="'+esc(t.join(" and "))+'">'+(label||"alerts ↗")+'</a>'}
function hostAlerts(ip,from,to,label){if(!C.rawdata||!IPRE.test(ip))return "";var q='clientIp = "'+ip+'" or serverIp = "'+ip+'"';
  return '<a href="'+esc(alertsUrl(q,from-60000,to+120000))+'" target="_blank" rel="noopener" title="'+esc(q)+'">'+(label||"alerts ↗")+'</a>'}
// ---- data ----
var timer=null;
function histUrl(fmt){var u=new URLSearchParams({days:S.hf.days,kind:S.hf.kind,verdict:S.hf.verdict,outcome:S.hf.outcome,q:S.hf.q,offset:S.hf.offset,limit:100});if(S.hf.hours)u.set("hours",S.hf.hours);if(fmt)u.set("format",fmt);return "history?"+u.toString()}
function auditUrl(fmt){var u=new URLSearchParams({who:S.af.who,action:S.af.action,q:S.af.q,days:S.af.days,bulk:S.af.bulk,offset:S.af.offset,limit:100});if(fmt)u.set("format",fmt);return "audit?"+u.toString()}
S.af={who:"",action:"",q:"",days:7,bulk:0,offset:0};S.hf={days:30,hours:0,kind:"",verdict:"",outcome:"",q:"",offset:0};
function loadLane(name,quiet){if(name==="config")return;getJ(name==="audit"?auditUrl():name==="history"?histUrl():"lane?name="+encodeURIComponent(name)).then(function(d){S.lanes[name]=d;if(S.tab===name&&!(quiet&&busyNow()))renderLane()}).catch(function(e){if(!quiet)toast(e.message,true)})}
// ---- since your last visit (this browser) ----
var LAST=0;try{LAST=+localStorage.getItem("sc-tri-last")||0}catch(x){}
function markVisit(){try{localStorage.setItem("sc-tri-last",String(Date.now()))}catch(x){}}
document.addEventListener("visibilitychange",function(){if(document.visibilityState==="hidden")markVisit()});window.addEventListener("pagehide",markVisit);
function isNewSince(it){return LAST&&it.first>LAST}
// ---- render ----
function countSince(items){var n=0;items.forEach(function(it){if(it.type==="campaign")(it.children||[]).forEach(function(c){if(isNewSince(c))n++});else if(isNewSince(it))n++});return n}
function headline(d){var el=$("#headline");if(!el)return;var f=d.funnel;
  var since=LAST?countSince(d.items||[]):0,hl=function(n,w){return num(n)+" "+(n===1?w:w+"s")};
  var tr=(d.trend||[]).concat([["24 h",f.alerts]]);
  var tip=[num(f.alerts)+" alerts in 24 h"+(tr.length>1?" (per day: "+tr.map(function(x){return x[0]+" "+num(x[1])}).join(", ")+")":""),num(f.findings)+" findings"
    +(f.services?", "+pc(f.service_alerts/Math.max(1,f.alerts))+" of the alerts are "+hl(f.services,"busy service")+" (see the Tuning tab)":""),
    hp(f.incidents,"incident")+" in "+hp(f.incident_hosts,"host"),
    num(f.act_items)+" to act on now ("+hp(f.act,"host")+"), "+num(f.investigate_items)+" to investigate ("+hp(f.investigate,"host")+")"];
  if(d.handled)tip.push(hp(d.handled,"host")+" handled"+(d.changed?", "+num(d.changed)+" changed since":""));
  if(LAST)tip.push(since?num(since)+" new since your last visit ("+tm(LAST,"dhm")+")":"nothing new since your last visit ("+tm(LAST,"dhm")+")");
  if(d.history&&d.history.depth<3)tip.push("learning history: "+num((d.history||{}).depth||0)+" of 7 days");
  var aw=d.away,awn=0,un=(d.unreviewed||[]).length;
  if(aw&&aw.how==="away"){var sm=aw.since*1000;(d.items||[]).forEach(function(it){if(it.type==="campaign")(it.children||[]).forEach(function(c){if(c.first>sm)awn++});else if(it.first>sm)awn++});
    tip.push("The team was last here "+tm(sm,"dhm")+(aw.who?" ("+aw.who+")":"")+": "+num(awn)+" new incidents since, "+num(un)+" ended with nobody having looked at them")}
  el.title=tip.join("\n");
  el.innerHTML='<span><b>'+num(f.incidents)+'</b> incident'+(f.incidents===1?"":"s")+' <span class="hm">('+hp(f.incident_hosts,"host")+')</span></span>'
    +'<i>·</i><span class="hlact"><b>'+num(f.act_items)+'</b> act now</span>'
    +'<i>·</i><span><b>'+num(f.investigate_items)+'</b> investigate</span>'
    +(d.changed?'<i>·</i><span class="chgd"><b>'+num(d.changed)+'</b> changed since</span>':"")
    +(aw&&aw.how==="away"?'<i>·</i><span class="awy" title="The last thing anyone in the team did before a pause of '+(+(d.shift_gap_h||6).toFixed(1))+' hours or more (a night, a weekend)">since '+esc(tm(aw.since*1000,"dhm"))+': <b>'+num(awn)+'</b> new'+(un?', <b>'+num(un)+'</b> ended unreviewed':"")+'</span>':un?'<i>·</i><span class="awy"><b>'+num(un)+'</b> ended unreviewed</span>':"")}
// the work, the tuning and the records, as groups; a count only where it means something, its colour how urgent
function tabs(d){var L=d.lanes||{},f=d.funnel,top=f.act_items>0?"v-act":f.investigate_items>0?"v-investigate":"",n=f.act_items+f.investigate_items;
  var G=[[["queue","Queue","list",n,top,f.review_items,num(n)+" to act on or investigate"+(f.review_items?", "+num(f.review_items)+" to review":"")],
      ["targets","Under attack","target",L.targets,"hot",0,(L.targets?num(L.targets)+" with high exposure: attackers on a threat list, across the internet edge, or a crown jewel under real attack. ":"")+"Your hosts attacked by others"],
      ["external","External","globe",L.external,"hot",0,(L.external?num(L.external)+" hostile. ":"")+"Addresses outside your networks that touched your hosts"]],
    [["tuning","Noise & tuning","sliders",L.tuning,"",0,(L.tuning?num(L.tuning)+" busy services not accepted yet. ":"")+"Busy services, what each rule is worth, suggestions from closures, exceptions"],
      ["hygiene","Hygiene","shield",L.hygiene,"",0,"Policy and hygiene findings: the list to clean up"]].concat(S.admin?[["config","Configuration","gear",0,"",0,"For admins: the profile, crown jewels, silenced hosts, scoring, playbooks and the rule catalog. Every change is previewed before it is published"]]:[]),
    [["history","History","clock",0,"",0,"Every incident the queue showed, kept as it was"],["audit","Audit","audit",0,"",0,"Every analyst action"]]];
  $("#tabs").innerHTML=G.map(function(g,i){return '<div class="tgp'+(i===G.length-1?" end":"")+'" role="group">'+g.map(function(t){
    return '<button type="button" class="tab'+(S.tab===t[0]?" on":"")+'" data-tab="'+t[0]+'" title="'+esc(t[6])+'">'+ic(t[2],16)+esc(t[1])+(t[3]?'<span class="n'+(t[4]?" "+t[4]:"")+'">'+num(t[3])+'</span>':"")+(t[5]?'<span class="n">'+num(t[5])+'</span>':"")+'</button>'}).join("")+'</div>'}).join("")}
// ---- queue: one table of incidents (a host, a group of hosts, a campaign with its incidents inside) ----
function incUrl(it){return it.type==="campaign"?"incident?campaign="+encodeURIComponent(it.net||it.key):it.type==="story"?"incident?story="+encodeURIComponent(it.key):"incident?ip="+encodeURIComponent(it.ip||it.key)}
function keyUrl(k){var t=k.slice(0,1),v=k.slice(2);return t==="c"?"incident?campaign="+encodeURIComponent(v):t==="i"?"incident?history="+encodeURIComponent(v):t==="s"?"incident?story="+encodeURIComponent(v):"incident?ip="+encodeURIComponent(v)}
function itKey(it){return (it.type==="campaign"?"c:":it.type==="story"?"s:":"h:")+it.key}
function itLabel(it){return it.type==="campaign"?it.title:it.type==="story"?it.title+" ("+it.count+" hosts)":"Host "+it.ip}
function hay(it){return [it.ip,it.name,it.title,it.headline,it.reason,it.net,(it.families||[]).map(fam).join(" "),(it.tags||[]).join(" "),it.loc,(it.nets||[]).map(function(n){return n[0]}).join(" "),(it.top||[]).join(" "),(it.sample||[]).join(" ")].join(" ").toLowerCase()}
function qmatch(it){if(!S.q)return true;var h=hay(it);return S.q.toLowerCase().split(/\s+/).filter(Boolean).every(function(w){return h.indexOf(w)>=0})}
function passes(it){if(!S.vd.has(it.verdict))return false;if(S.changes&&!it.changed)return false;if(!wpass(it))return false;return qmatch(it)}
function stTip(n,m){var w=(C.stageWords||{})[n];return n+(m==="c"?": evidence of 2 bits or more":m==="s"?": suspected (weak evidence)":": no evidence")+(w?"\n"+n+" = "+w[0]+"\nMITRE: "+w[1]:"")}
function kc(st){return '<div class="kcs">'+C.stages.map(function(n,i){var m=st&&st[i]||"";return '<span class="'+esc(m)+'" style="--sc:'+C.stageColors[i]+'" title="'+esc(stTip(n,m))+'"><i></i>'+esc(n)+'</span>'}).join("")+'</div>'}
function kc4(st,stage){return '<span class="kc4" title="'+esc(C.stages.map(function(n,i){var m=st&&st[i]||"";return n+": "+(m==="c"?"evidence":m==="s"?"suspected":"no evidence")}).join("\n")+(stage!=null&&(C.stageWords||{})[C.stages[stage]]?"\n\n"+C.stages[stage]+" = "+C.stageWords[C.stages[stage]][0]:""))+'">'
  +C.stages.map(function(n,i){return '<i class="'+esc(st&&st[i]||"")+'" style="--sc:'+C.stageColors[i]+'"></i>'}).join("")+'</span><span class="kcn">'+esc(stage!=null?C.stages[stage]:"no stage")+'</span>'}
function tagsHtml(it){var t="",isNew=it.type==="host"||!it.type?it.novelty==="new":it.new>0,pcn=it.type==="host"||!it.type?(it.pcap&&it.pcap.done):it.pcap_hosts;
  if(isNew)t+='<span class="tg new" title="'+esc(it.type==="host"||!it.type?"At least one finding this host never had in the last "+(it.depth||7)+" days":num(it.new)+" of the hosts behave in a way they never did before")+'">new</span>';
  if(pcn)t+='<span class="tg pc" title="'+esc(it.type==="host"||!it.type?"The recorder has packets for "+hp(pcn,"alert")+" of this host":"Hosts with recorded packets: "+pcn)+'">PCAP</span>';return t}
// what kind of incident a row is, in the History's colours: one host, a host attacked from outside, a group, a campaign
function typeBadge(it){if(it.type==="campaign")return '<span class="ekind ekind-subnet qk" title="A campaign: many hosts of one network at Investigate or above, with their incidents inside">Campaign · '+num(it.count)+'</span>';
  if(it.type==="story")return '<span class="ekind ekind-pattern qk" title="A group: hosts with the same verdict and pattern, one incident for all of them">Group · '+num(it.count)+'</span>';
  if(it.target)return '<span class="ekind ekind-tgt qk" title="A host attacked from outside that answered: an incident about the victim">Target</span>';
  return '<span class="ekind ekind-ip qk" title="One host and what it did">Host</span>'}
function hiTitle(s){return esc(s).replace(/(\d{1,3}(?:\.\d{1,3}){3}(?:\/\d{1,2})?(?::\d{1,5})?)|(^|[^\w.:])(:\d{1,5})(?!\d)|→/g,function(m,ip,pre,port){
  if(ip)return '<span class="tip">'+ip+'</span>';if(port)return pre+'<span class="tip">'+port+'</span>';return '<span class="tar">→</span>'})}
function titleHtml(it){
  if(SM()){if(it.type==="campaign")return typeBadge(it)+'<span class="qt-t">'+hiTitle(it.title)+'</span>';
    if(it.type==="story")return typeBadge(it)+'<span class="qt-t">'+hiTitle(it.title)+'</span>';
    return typeBadge(it)+'<span class="qt-t"><span class="tip">'+esc(it.ip)+'</span>'+(it.name?' <span class="mut">'+esc(it.name)+'</span>':"")+' '+hiTitle(it.headline)+'</span>'}
  if(it.type==="campaign")return typeBadge(it)+'<span class="qt-t">'+hiTitle(it.title)+'</span>'+tagsHtml(it)+'<div class="qt-s">'+esc((it.families||[]).map(fam).join(", "))+'</div>';
  if(it.type==="story")return typeBadge(it)+'<span class="qt-t">'+hiTitle(it.title)+'</span>'+tagsHtml(it)+(it.why?'<div class="qt-s" title="'+esc("e.g. "+((it.sample||[])[0]||""))+'">Only Review: '+esc(it.why)+'</div>':'<div class="qt-s">e.g. '+esc((it.sample||[])[0]||"")+'</div>');
  return typeBadge(it)+'<span class="qt-t">'+hiTitle(it.headline)+'</span>'+tagsHtml(it)+'<div class="qt-s">'+esc(it.reason)+'</div>'}
// several incidents ticked in the queue: one action on all their hosts, with the same scope dialog
S.qsel=new Map();
function qselItems(){var d=S.data||{},byK={};(d.items||[]).forEach(function(it){byK[itKey(it)]=it;(it.children||[]).forEach(function(c){byK[itKey(c)]=c})});
  var out=[];S.qsel.forEach(function(v,k){if(byK[k])out.push(byK[k]);else S.qsel.delete(k)});return out}
function qselIps(items){var ips=[],vs=[];items.forEach(function(it){var list=it.type==="host"?[it.ip]:(it.ips||[]);list.forEach(function(ip){if(ips.indexOf(ip)<0){ips.push(ip);vs.push(it.verdict)}})});return {ips:ips,verdicts:vs}}
function qselBar(){var b=$("#qact"),n=$("#qsn"),hl=$("#headline");if(!b)return;var items=qselItems();if(hl)hl.hidden=items.length>0;
  if(!items.length){b.disabled=true;b.classList.remove("on");if(n)n.innerHTML="";return}var x=qselIps(items);
  b.disabled=false;b.classList.add("on");if(n)n.innerHTML='<b>'+hp(items.length,"incident")+'</b> selected ('+hp(x.ips.length,"host")+') · <button type="button" class="lnk" data-qnone="1">clear</button>'}
function qselMenu(btn){var items=qselItems();if(!items.length)return;var x=qselIps(items),a=function(st,l){return {label:l,run:function(){qselAct(st)}}};
  cmAt(btn,[{head:esc(hp(items.length,"incident")+" · "+hp(x.ips.length,"host"))},a("investigating","Take"),a("assign","Assign…"),a("escalated","Escalate…"),a("ack","Seen"),a("close","Close…")])}
function qselAct(a){var items=qselItems();if(!items.length)return;var x=qselIps(items);
  changeState({status:a,ips:x.ips,verdicts:x.verdicts,scope:"sel",label:hp(items.length,"incident")+" from the queue",where:"view",key:"",after:function(){S.qsel.clear();$$("[data-qsel]").forEach(function(c){c.checked=false});qselBar()}})}
// Simple queue: Verdict | Incident | Hosts | Last activity | Open ›  (the same five cells in every kind of row)
var SHEAD='<thead><tr><th title="From the decision table (How to read this, ?): Act now, Investigate, Review">Verdict</th><th>Incident</th><th>Hosts</th><th>Last activity</th><th></th></tr></thead>';
function sHosts(it){return it.type==="campaign"||it.type==="story"?'<b>'+hp(it.count,"host")+'</b>':""}
function sCells(v,i,h,l,a){return '<td class="c-v">'+v+'</td><td class="c-i">'+i+'</td><td class="c-s">'+h+'</td><td class="c-l">'+l+'</td><td class="c-a"><span class="btns">'+a+'</span></td>'}
function lowWhy(it){if(!it.low_why)return "";
  return '<div class="mut" title="'+esc("The verdict is not the confidence alone: "+(it.reason||""))+'">low, but '+esc(it.low_why)+'</div>'}
function rowHtml(r){var it=r.it,u=incUrl(it),k=itKey(it);
  var lead=it.type==="campaign"?'<button type="button" class="exp" data-exp="'+esc(it.key)+'" aria-expanded="'+(r.open?"true":"false")+'" title="'+(r.open?"Hide":"Show")+' its incidents here">'+(r.open?"▾ ":"▸ ")+num(r.nk==null?it.children_n:r.nk)+'</button>':"";
  var quick="";if(it.type==="host"&&C.edit){var t=it.triage,v=it.verdict;quick=t&&t.handled?actBtn("open","Reopen",k,v,"","Back to New")
    :(ownerOf(t)===ME.name&&ME.name?"":actBtn("investigating","Take",k,v,"","In progress and assigned to you"))+actBtn("ack","Seen",k,v,"","Nothing to do now: out of the queue until it shows something new")+actBtn("close","Close…",k,v,"","Close as a true positive, benign or a false positive")}
  var acts=(quick?'<span class="ra">'+quick+'</span>':"")+KB+'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="The incident on its own page, in a new tab">Open ›</a>';
  var handled=it.type==="host"?(it.triage&&it.triage.handled):it.open===0;
  if(SM())return '<tr class="qr'+(r.child?" child":"")+(handled?" handled":"")+(S.open===k?" sel":"")+'" style="--vc:'+VC[it.verdict]+'" data-k="'+esc(k)+'" title="Quick look">'
    +sCells(vp(it.verdict),(r.child?'<span class="sub">↳</span>':"")+lead+titleHtml(it),sHosts(it),lastHtml(it),'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="The incident on its own page, in a new tab">Open ›</a>')+'</tr>';
  return '<tr class="qr'+(r.child?" child":"")+(handled?" handled":"")+(S.open===k?" sel":"")+'" style="--vc:'+VC[it.verdict]+'" data-k="'+esc(k)+'" title="Quick look">'
    +'<td class="c-v">'+(C.edit&&!INC&&CTX==="view"&&it.type!=="campaign"?'<input type="checkbox" class="qx" data-qsel="'+esc(k)+'"'+(S.qsel.has(k)?" checked":"")+' aria-label="Select" title="Select for an action on several incidents">':"")+vp(it.verdict)+'</td><td class="c-i">'+(r.child?'<span class="sub">↳</span>':"")+lead+titleHtml(it)+'</td><td class="c-k">'+kc4(it.stages,it.stage)+'</td><td class="c-s">'+scopeHtml(it)+'</td>'
    +'<td class="c-c">'+(it.target?'<span class="mut" title="'+esc(NOCONF+": it is attacked from outside and shows no sign of acting itself. "+(it.reason||""))+'">n/a</span>':cw(it)+(it.type==="host"?lowWhy(it):'<div class="mut" title="The highest confidence among its hosts">highest</div>'))+'</td><td class="c-l">'+lastHtml(it)+'</td><td class="c-sla">'+slaHtml(it)+'</td><td class="c-st">'+statusHtml(it)+'</td><td class="c-a"><span class="btns">'+acts+'</span></td></tr>'}
var SORTK={stage:function(x){var r=x.rank!=null?x.rank:x.stage;return r==null?-1:r},conf:function(x){return x.conf||0},last:function(x){return x.last||0},hosts:function(x){return x.count||1}};
try{S.sort=JSON.parse(sessionStorage.getItem("sc-sort")||"null")}catch(x){S.sort=null}
function sortItems(list){if(SM()||!S.sort||!SORTK[S.sort.k])return list;var f=SORTK[S.sort.k],d=S.sort.d,out=list.slice();
  out.sort(function(a,b){var va=VRK[a.verdict]||0,vb=VRK[b.verdict]||0;return va!==vb?vb-va:d*(f(b)-f(a))});return out}
function KCTIP(){return "Stages, left to right: "+C.stages.map(function(n){return n.charAt(0)+" = "+n}).join(", ")+". "}
function KCL(){return '<div class="kcl" aria-hidden="true">'+C.stages.map(function(n){return '<i>'+esc(n.charAt(0))+'</i>'}).join("")+'</div>'}
function sth(k,label,tip,extra){var on=S.sort&&S.sort.k===k;return '<th class="srt'+(on?" on":"")+'" data-sort="'+k+'" title="'+esc(tip+" · click to sort inside each verdict")+'">'+label+(on?(S.sort.d>0?" ▾":" ▴"):"")+(extra||"")+'</th>'}
var SLATH='<th title="Time left to the next SLA deadline of an Act now or Investigate incident: the first action, then a close or an escalation. The limits are the sla.* parameters (Configuration)">SLA</th>';
function slaHtml(it){var d=S.data&&S.data.sla,s=d&&d[itKey(it)];if(!s||!s.next)return '<span class="mut">-</span>';
  var w=s.next==="ack"?"First action":"Close or escalate",left=s.due-(S.data.now||0);
  if(left<0)return '<span class="sla bad" title="'+esc(w+" is overdue by "+dur(-left)+" (due "+tm(s.due*1000,"dhm")+"; limit "+dur(s.limit)+" from "+tm(s.start*1000,"dhm")+")")+'">breached</span>';
  return '<span class="sla'+(left<s.limit*0.25?" warn":"")+'" title="'+esc(w+" due "+tm(s.due*1000,"dhm")+" (limit "+dur(s.limit)+" from "+tm(s.start*1000,"dhm")+")")+'">'+esc((s.next==="ack"?"ack ":"close ")+dur(left))+'</span>'}
function qhead(){if(SM())return SHEAD;return '<thead><tr><th title="From the decision table (How to read this, ?): Act now, Investigate, Review">Verdict</th><th>Incident</th>'
  +sth("stage","Kill chain",KCTIP()+"The highest stage with evidence. Filled: a finding of 2 bits or more (the host page calls it confirmed at high confidence); dashed: suggested by weaker evidence",KCL())+sth("hosts","Scope","Hosts in it")
  +sth("conf","Confidence","How sure the evidence makes us. The verdict weighs the stage too: a command channel or an Objectives finding at low confidence is still Investigate")+sth("last","Last activity","The newest alert")+SLATH+'<th>Status</th><th></th></tr></thead>'}
var QHEAD='<thead><tr><th title="From the decision table (How to read this, ?): Act now, Investigate, Review">Verdict</th><th>Incident</th><th title="'+esc(KCTIP())+'The highest stage with evidence. Filled: a finding of 2 bits or more (the host page calls it confirmed at high confidence); dashed: suggested by weaker evidence">Kill chain'+KCL()+'</th><th>Scope</th><th title="How sure the evidence makes us. The verdict weighs the stage too: a command channel or an Objectives finding at low confidence is still Investigate">Confidence</th><th>Last activity</th>'+SLATH+'<th>Status</th><th></th></tr></thead>';
// ---- lanes ----
function renderLane(){var L=S.lanes[S.tab];if(!L){$("#view").innerHTML='<div class="loading">Loading…</div>';loadLane(S.tab);return}
  if(S.tab==="audit")return laneAudit(L);if(S.tab==="history")return laneHistory(L);
  if(S.tab==="targets")return laneTargets(L);if(S.tab==="external")return laneExternal(L);if(S.tab==="tuning")return laneTuning(L);if(S.tab==="hygiene")return laneHygiene(L)}
function famPills(list){return (list||[]).slice(0,4).map(function(f){return '<span class="pill2">'+esc(fam(f))+'</span>'}).join("")}
function laneAudit(L){var W=L.words||{},F=L.facets||{who:[],actions:[]},isIp=function(t){return IPRE.test(t||"")&&/[.:]/.test(t)};
  var opt=function(list,cur,lbl,map){return '<option value="">'+esc(lbl)+'</option>'+list.map(function(v){return '<option value="'+esc(v)+'"'+(v===cur?" selected":"")+'>'+esc(map?(map[v]||v):v)+'</option>'}).join("")};
  var bar='<div class="afl"><select id="afw">'+opt(F.who,S.af.who,"everyone")+'</select><select id="afa">'+opt(F.actions,S.af.action,"every action",W)+'</select>'
    +'<select id="afd">'+[[1,"last 24 h"],[7,"last 7 days"],[30,"last 30 days"],[0,"all time"]].map(function(o){return '<option value="'+o[0]+'"'+(+S.af.days===o[0]?" selected":"")+'>'+o[1]+'</option>'}).join("")+'</select>'
    +'<input type="search" id="afq" placeholder="host, note, analyst…" value="'+esc(S.af.q)+'"><label><input type="checkbox" id="afb"'+(S.af.bulk?" checked":"")+'> per-host lines of story actions</label>'
    +'<span class="sp" style="flex:1"></span><a class="b2" href="'+esc(auditUrl("csv"))+'" download>Export CSV</a></div>';
  var rows=L.rows.map(function(r){var d=r.detail||{};return '<tr class="qr nk" style="--vc:#2f3060"><td>'+tm(r.at*1000)+'</td><td>'+esc(r.who)+vok(r.verified)+'</td><td>'+aw(r.action,W)+(r.product==="clusters"?' <span class="pill2">Clusters</span>':"")+'</td>'
    +'<td class="mono">'+(isIp(r.target)?'<a href="#" data-open="h:'+esc(r.target)+'">'+esc(r.target)+'</a> '+newTab(r.target):tgt(r.target))+(d.hosts?' <span class="mut">('+num(d.hosts)+' hosts)</span>':"")+'</td><td>'+esc(r.note||"")+'</td></tr>'}).join("");
  var more=L.total>S.af.offset+L.rows.length,pg=S.af.offset>0||more?'<div class="qbar" style="margin-top:8px"><span class="mut">'+num(L.rows.length?S.af.offset+1:0)+'–'+num(S.af.offset+L.rows.length)+' of '+num(L.total)+'</span><span class="sp"></span>'
    +(S.af.offset>0?'<button type="button" class="b2" data-afp="-1">Newer</button>':"")+(more?'<button type="button" class="b2" data-afp="1">Older</button>':"")+'</div>':"";
  $("#view").innerHTML='<p class="lead1">Every analyst action.'+ii("Kept in the state database of this service (clusters.db, table audit). The system's own decisions about each host (entered the queue, escalated, came back after being handled) are in each host's history.")+'</p>'
    +bar+tcard(laneTable(["When","Who","Action","Target","Note"],rows,"No actions match."))+pg;
  var re=function(){S.af.offset=0;loadLane("audit")};
  $("#afw").onchange=function(e){S.af.who=e.target.value;re()};$("#afa").onchange=function(e){S.af.action=e.target.value;re()};
  $("#afd").onchange=function(e){S.af.days=+e.target.value;re()};$("#afb").onchange=function(e){S.af.bulk=e.target.checked?1:0;re()};
  var qq=$("#afq"),tmr=null;qq.oninput=function(){clearTimeout(tmr);tmr=setTimeout(function(){S.af.q=qq.value;S.afFocus=true;re()},350)};
  if(S.afFocus){S.afFocus=false;qq.focus();try{qq.setSelectionRange(qq.value.length,qq.value.length)}catch(x){}}
  $$("[data-afp]").forEach(function(b){b.onclick=function(){S.af.offset=Math.max(0,S.af.offset+100*(+b.dataset.afp));loadLane("audit")}})}
// ---- where the analyst is: sequences for Previous / Next, the breadcrumb, the queue's scroll position ----
function saveSeq(ctx,label,items){try{sessionStorage.setItem("sc-seq:"+ctx,JSON.stringify({label:label,items:items.slice(0,3000)}))}catch(x){}}
function getSeq(ctx){try{return JSON.parse(sessionStorage.getItem("sc-seq:"+ctx)||"null")}catch(x){return null}}
function here(){return "incident"+location.search}
function seqNav(ctxs){for(var i=0;i<ctxs.length;i++){if(!ctxs[i])continue;var s=getSeq(ctxs[i]);if(!s||!s.items)continue;
    for(var j=0;j<s.items.length;j++){if(s.items[j].u===here())return {label:s.label,at:j,n:s.items.length,prev:s.items[j-1],next:s.items[j+1]}}}return null}
var NAV=null;
function crumbsHtml(parts,nav){var h='<nav class="crumbs" aria-label="Where you are"><a href="./">Queue</a>';
  parts.forEach(function(p){h+='<span class="sep">›</span>'+(p.u?'<a href="'+esc(p.u)+'">'+esc(p.l)+'</a>':'<b>'+esc(p.l)+'</b>')});
  h+='<span class="sp"></span>';
  if(nav)h+=(nav.prev?'<a class="b2" href="'+esc(nav.prev.u)+'" title="'+esc(nav.prev.l)+'">‹ Previous</a>':'<span class="b2 off">‹ Previous</span>')
    +'<span class="mut">'+num(nav.at+1)+' of '+num(nav.n)+' in '+esc(nav.label)+'</span>'
    +(nav.next?'<a class="b2" href="'+esc(nav.next.u)+'" title="'+esc(nav.next.l)+'">Next ›</a>':'<span class="b2 off">Next ›</span>');
  return h+'<span class="mut">refreshes every '+C.poll+' s</span></nav>'}
function crumbsFor(k,D){var t=k.slice(0,1),parts=[],ctxs=[];
  if(t==="h"){var P=D.parents||{};
    if(P.campaign)parts.push({l:"Campaign "+P.campaign.net,u:keyUrl("c:"+P.campaign.net)});
    if(P.story)parts.push({l:P.story.title+" ("+hp(P.story.count,"host")+")",u:keyUrl("s:"+P.story.key)});
    parts.push({l:"Host "+D.ip});ctxs=[P.story?"s:"+P.story.key:null,P.campaign?"c:"+P.campaign.net:null,"queue"]}
  else if(t==="s"){if(D.campaign)parts.push({l:"Campaign "+D.campaign.net,u:keyUrl("c:"+D.campaign.net)});
    parts.push({l:D.title+" ("+hp(D.count,"host")+")"});ctxs=[D.campaign?"c:"+D.campaign.net:null,"queue"];
    saveSeq("s:"+D.key,D.title+" ("+hp(D.count,"host")+")",D.members.map(function(m){return {u:keyUrl("h:"+m.ip),l:"Host "+m.ip}}))}
  else if(t==="i"){parts.push({l:"History",u:"./?tab=history"});parts.push({l:"Incident #"+D.id+(D.label?" · "+D.label:"")});ctxs=["history"]}
  else{parts.push({l:"Campaign "+D.net});ctxs=["queue"];
    saveSeq("c:"+D.net,"campaign "+D.net,D.children.map(function(c){return {u:incUrl(c),l:itLabel(c)}}))}
  NAV=seqNav(ctxs);return crumbsHtml(parts,NAV)}
function saveScroll(){if(INC)return;try{sessionStorage.setItem("sc-qscroll",JSON.stringify({y:window.scrollY,u:location.search,tab:S.tab}))}catch(x){}}
var RESTORED=false;function restoreScroll(){if(RESTORED)return;RESTORED=true;try{var s=JSON.parse(sessionStorage.getItem("sc-qscroll")||"null");if(s&&s.u===location.search&&s.tab===S.tab)window.scrollTo(0,s.y)}catch(x){}}
// ---- quick look: the side panel, over the queue and over the incident pages ----
function drwTitle(k){$("#drwt").innerHTML=(S.dstack.length?'<button type="button" class="b2" data-dback="1" title="Back to the previous quick look">‹ Back</button> ':"")
  +'Quick look <a class="b2 pri" style="margin-left:10px" href="'+esc(keyUrl(k))+'" target="_blank" rel="noopener" title="The incident on its own page, in a new tab">Open incident ›</a>'+dvsw()}
// the quick look's own Simple | Full: it changes the incident scope (the incident pages and every quick look), not the page under the drawer
function dvsw(){var b=function(v,l){return '<button type="button" data-dv="'+v+'" aria-pressed="'+((v==="simple")===INCS)+'">'+l+'</button>'};
  return '<span class="vsw vsw-s" id="dvsw" role="group" aria-label="Quick look view" title="Simple or Full for incidents; the other pages keep their own">'+b("simple","Simple")+b("full","Full")+'</span>'}
function openDetail(k,quiet,deeper){if(!quiet&&S.open&&S.open!==k){if(deeper)S.dstack.push(S.open);else if(deeper===false)S.dstack=[]}
  S.open=k;sync();var dr=$("#drawer");if(!dr)return;dr.hidden=false;$$(".qr.sel").forEach(function(x){x.classList.remove("sel")});var el=document.querySelector('.qr[data-k="'+k.replace(/["\\]/g,"\\$&")+'"]');if(el)el.classList.add("sel");
  var body=$("#drwb");if(!quiet||!S.det[k]){body.innerHTML='<div class="loading">Loading…</div>';R.drwb={sel:new Set(),hall:false,bulk:null}}
  drwTitle(k);var t=k.slice(0,1),v=encodeURIComponent(k.slice(2)),url=t==="h"?"host?ip="+v:t==="s"?"story?key="+v:t==="i"?"history-item?id="+v:"campaign?net="+v;
  getJ(url).then(function(d){S.det[k]=d;if(S.open!==k)return;var note=body.querySelector(".note2");
      // a refresh never eats what the analyst is typing, and keeps the scroll position
      if(quiet&&note&&(note.value||document.activeElement===note))return;var top=quiet?body.scrollTop:0;
      body.dataset.k=k;CTX="drwb";body.innerHTML=detailHtml(k,d);CTX="view";body.scrollTop=top;updateBulk("drwb");if(!quiet){HELP.manual=false;helpFollow()}})
    .catch(function(e){if(S.open===k)body.innerHTML='<div class="empty2">'+esc(e.message)+'</div>'})}
function closeDetail(){S.open="";S.dstack=[];sync();var dr=$("#drawer");if(dr)dr.hidden=true;$$(".qr.sel").forEach(function(x){x.classList.remove("sel")});HELP.manual=false;helpFollow()}
function refreshAll(){S.force=true;if(S.open)openDetail(S.open,true);if(INC)loadIncident(true);else load()}
// ---- the incident page: one host, a group of hosts, or a campaign, with its own address ----
function incKey(){return INC.k+":"+INC.v}
function loadIncident(quiet){var k=incKey(),url=INC.k==="h"?"host?ip="+encodeURIComponent(INC.v):INC.k==="s"?"story?key="+encodeURIComponent(INC.v):INC.k==="i"?"history-item?id="+encodeURIComponent(INC.v):"campaign?net="+encodeURIComponent(INC.v);S.pk=k;
  getJ(url).then(function(d){S.det[k]=d;var body=$("#view");staleBar(d.fresh);
      tzPaint();
      if(quiet&&!S.force&&busyNow()){S.pendInc=true;pendShow();return}S.force=false;S.pendInc=false;pendShow();var top=window.scrollY;
      $("#crumbs").innerHTML=crumbsFor(k,d);body.dataset.k=k;CTX="view";body.innerHTML=detailHtml(k,d);updateBulk("view");if(!quiet&&helpPinned()&&$("#helpp").hidden)helpOpen(helpCtx());else helpFollow();
      if(quiet)window.scrollTo(0,top);$("#asof").innerHTML="as of "+tm(d.fresh&&d.fresh.built_at?d.fresh.built_at*1000:Date.now(),"hm");$("#err").innerHTML=""})
    .catch(function(e){var msg=e.net?readErr(e,"","Triage")+'<div class="empty2"><a href="./">Back to the queue</a></div>':'<div class="empty2">'+esc(e.message)+'. <a href="./">Back to the queue</a></div>';if(quiet&&S.det[k])$("#err").innerHTML='<div class="errbox">'+esc(e.message)+'</div>';else{$("#view").innerHTML=msg;$("#crumbs").innerHTML=crumbsHtml([{l:INC.k==="h"?"Host "+INC.v:INC.k==="c"?"Campaign "+INC.v:INC.k==="i"?"History record #"+INC.v:"Incident"}],null)}})
    .then(function(){clearTimeout(timer);timer=setTimeout(function(){loadIncident(true)},C.poll*1000)})}
function detailHtml(k,D){var t=k.slice(0,1),h=t==="h"?hostHtml(D):t==="s"?groupHtml(D):t==="i"?historyHtml(D):campaignHtml(D);return SM()?h+allDetails():h}
// Simple ends every incident view with this one button: it switches the incident scope to Full (1.4.4), so Full is one click away and stays
function allDetails(){return '<div class="alld"><button type="button" class="b2" data-alld="1" title="Switch to the Full view: every section, number and filter">All details</button></div>'}
function stepsHtml(steps){return '<ol class="steps">'+steps.map(function(s){var sc=s.stage!=null?C.stageColors[s.stage]:"#808297";
  return '<li class="'+(s.confirmed?"":"sus")+'" style="--sc:'+sc+'"><span class="tm">'+tm(s.t,"dhm")+'</span>'+esc(s.text)+'<span class="fam" title="'+esc(num(s.bits,1)+" bits of evidence")+'">'+esc(s.label)+(s.stage!=null?" · "+esc(C.stages[s.stage]):"")+'</span>'+(s.new?' <span class="tg new">new</span>':"")+(s.note?'<span class="note">'+esc(s.note)+'</span>':"")+'</li>'}).join("")+'</ol>'}
function bgHtml(list){if(!list.length)return "";var one=function(b){return '<b>'+rn(b.rule)+'</b> ×'+num(b.n)+(b.cps.length?" ("+esc(b.cps.join(", "))+")":"")+(b.excepted?" [exception]":"")};
  var hab=list.filter(function(b){return b.habit}),oth=list.filter(function(b){return !b.habit});
  var n=hab.length+oth.length;return '<details class="fold"><summary>Background: '+hp(n,"rule")+' that count little or nothing</summary>'
    +(hab.length?'<div class="bg">As on most days, so it counts little: '+hab.slice(0,4).map(function(b){return one(b)+" on "+num(b.days)+" of "+num(b.looked)+" days"+(b.skipped?" ("+num(b.skipped)+" "+(b.skipped===1?"day":"days")+" not counted: incidents nobody decided)":"")}).join(" · ")+'</div>':"")
    +(oth.length?'<div class="bg">Also seen, weak or excepted: '+oth.slice(0,4).map(one).join(" · ")+'</div>':"")+'</details>'}
// bits and prior in plain words, next to their first use on the host page (the Help glossary says the same)
function glBits(){return '<span class="gl" title="'+esc("A bit is one doubling of the odds that this host is under an attacker's control: each extra bit makes it twice as likely. The more bits, the stronger the evidence.")+'">bits</span>'}
function glPrior(a){var n=Math.pow(2,a.prior==null?8:a.prior);return '<span class="gl" title="'+esc("The starting assumption before any evidence: about 1 host in "+num(n)+" is under attack. Evidence has to beat that: with "+num(a.prior==null?8:a.prior)+" bits the host is a coin toss (50%), with more bits it is likelier than not.")+'">prior</span> of 1 in '+num(n)+' hosts'}
function mathHtml(a){var fams=a.families.map(function(f){return '<b>'+num(f.bits,1)+'</b> '+esc(f.label)}).join(" + ");
  var ch=a.chains.map(function(c){return '<b>'+num(c.bits,1)+'</b> '+esc(c.id)+' '+esc(c.title)}).join(" + ");
  return '<div class="math" style="--vc:'+VC[a.verdict]+'">evidence  = '+(fams||"0")+(a.progression?' + <b>'+num(a.progression,0)+'</b> kill-chain progression':"")+(ch?' + '+ch:"")+(a.recurring?' + <b>'+num(a.recurring.bits,1)+'</b> recurring':"")+'\n          = <b>'+num(a.E,1)+' '+glBits()+'</b>   ('+num(a.prior==null?8:a.prior)+' bits = 50%: '+glPrior(a)+')\nconfidence = 1 / (1 + 2^-('+num(a.E,1)+' - '+num(a.prior==null?8:a.prior)+')) = <b class="v">'+pc(a.conf)+'</b>\nrisk       = confidence × impact '+num(a.impact,2)+' ('+(a.stage!=null?esc(C.stages[a.stage])+(a.stage_confirmed?" confirmed":"-stage evidence"):"no stage confirmed")+(a.impact_why?"; "+esc(a.impact_why):"")+') = <b>'+num(a.risk,3)+'</b>\nverdict    = <b class="v">'+esc(VL[a.verdict])+'</b>: '+esc(a.reason)+'</div>'
    +(a.recurring?'<div class="bg" style="margin-top:6px">recurring '+num(a.recurring.n)+'× without decision: +'+num(a.recurring.bits,1)+' '+(a.recurring.bits===1?"bit":"bits")+' <span class="tg s-learned" title="Counted from the incidents of this host in the last days that ended with nobody deciding">learned</span></div>':"")
    +(a.held?'<div class="bg" style="margin-top:6px">'+esc(a.held.text)+'. The evidence alone says '+esc(VL[a.held.raw])+(a.held.raw_reason?": "+esc(a.held.raw_reason):"")+'.</div>':"")
    +(a.act_needs&&a.act_needs.length?'<div class="bg" style="margin-top:6px">Act now would need one of: '+a.act_needs.map(esc).join("; ")+'.</div>':"")}
function srcLines(f){return (f.sources||[]).map(function(s){var low=s.conf!=null&&s.conf<0.5;
    return '<div class="srcl" title="'+esc(s.text||"")+'"><span>'+esc(s.term)+'</span> <span class="tg s-'+esc(String(s.source||"").replace(/[^a-z]/g,""))+'">'+esc(s.source)+'</span>'
      +(low?' <span class="tg ch" title="Few observations behind this norm ('+esc(s.conf)+' of 1): shipped norms fill the gap">low norm confidence</span>':"")+'</div>'}).join("")}
function traceHtml(a,D){var rows=a.trace.map(function(f){var why=[];
    if(f.excepted)why.push(silLine(f.excepted));
    f.notes.forEach(function(n){why.push(n)});f.caps.forEach(function(c){if(c.limit<f.base)why.push("≤ "+num(c.limit,1)+": "+c.why)});f.deds.forEach(function(x){why.push("−"+num(x.value,1)+": "+x.why)});
    if(!f.counted&&f.bits>0&&!f.excepted)why.push("not counted: a stronger finding of the same family counts");
    var w=Math.max(2,Math.min(100,f.bits/6*100));
    return '<tr class="'+(f.excepted?"ex":f.counted?"":"off")+'"><td class="bits">'+num(f.bits,2)+'<u style="width:'+w+'%;background:'+(f.stage!=null?C.stageColors[f.stage]:"#808297")+'"></u></td>'
      +'<td>'+rn(f.rule)+(f.new?' <span class="tg new">new</span>':"")+'<div class="mut mono">'+esc(f.cp_label||"")+(f.ntargets>1?" · "+num(f.ntargets)+" targets":"")+'</div></td>'
      +'<td>'+esc(f.flabel)+'<div class="mut">class '+esc(f.cls)+(f.stage!=null?" · "+esc(C.stages[f.stage]):"")+'</div><div class="mut" title="The ATT&amp;CK technique for this rule and this direction">ATT&amp;CK: '+esc(f.attack)+'</div>'+(f.tpl_tag?'<div class="mut">template tag: '+esc(f.tpl_tag)+'</div>':"")+'</td>'
      +'<td class="mono">'+num(f.base,1)+'</td><td class="w">'+why.map(function(x){return '<div>'+esc(x)+'</div>'}).join("")+(f.days_looked>=3?'<div>seen '+num(f.days_seen)+' of '+num(f.days_looked)+' days'+'</div>':"")+srcLines(f)+'</td>'
      +'<td>'+num(f.n)+'<div class="mut">'+rng(f.first,f.last)+'</div></td><td style="white-space:nowrap">'+[alertsOf(f.rule,f.client,f.server,f.first,f.last),flows(f.client,f.server,f.port,f.first,f.last)].filter(Boolean).join(" · ")+exBtns(f,D)+'</td></tr>'}).join("");
  return '<div class="card tr" style="padding:0"><div class="grid"><table style="min-width:820px"><tr><th>Bits</th><th>Finding</th><th>Family</th><th>Weight</th><th>Why this much</th><th>Alerts</th><th>Sycope</th></tr>'+rows+'</table></div></div>'
    +(a.findings>a.trace.length?'<p class="mut" style="font-size:12px">'+num(a.trace.length)+' of '+num(a.findings)+' findings shown (strongest first).</p>':"")}
function exBtns(f,D){if(!C.edit||f.excepted||f.base<=0)return "";var b='<div style="margin-top:6px;display:flex;flex-direction:column;gap:4px">';
  b+='<button type="button" class="lnk" data-ex="host-rule" data-rule="'+esc(f.rule)+'" data-actor="'+esc(D.ip)+'" title="This host may do this (a scanner, a backup job): its alerts of this rule stop counting">Allow on this host</button>';
  if(f.cp&&f.server&&f.cls!=="A"&&/^(10|172|192|169|100)\./.test(f.server))b+='<button type="button" class="lnk" data-ex="service" data-rule="'+esc(f.rule)+'" data-server="'+esc(f.server)+'" data-port="'+esc(f.port||"")+'" title="This server:port is a known service: alerts of this rule to it stop counting for every host">Known service</button>';
  return b+'</div>'}
// ---- the ticket: built by the service (ticket.py) and sent with the page data; the page only makes a relative link absolute ----
function ticketText(D){return String((D&&D.ticket)||"").replace(/^(Incident page: )(incident\?\S+)$/m,function(m,a,b){return a+new URL(b,location.href).href})}
// ---- attack path: what the host did, on the kill-chain lanes, in time order ----
function apTip(lines){return esc(lines.filter(Boolean).join("\n"))}
// a label that always fits inside the plot: on the right of the dot, else on its left, else wrapped in two lines
// (the ATT&CK id and the count drop out of the wrapped text; the tooltip has the full name and both)
function apLabel(txt,short,x0,W,R){var cw=6.3,right=W-R-x0-9,left=x0-9-130,wrap=function(t,room){var lines=[""];t.split(" ").forEach(function(w){var cur=lines[lines.length-1];
    if(!cur)lines[lines.length-1]=w;else if((cur+" "+w).length*cw<=room)lines[lines.length-1]=cur+" "+w;else lines.push(w)});return lines};
  if(txt.length*cw<=right)return {side:"start",x:x0+9,lines:[txt]};
  if(txt.length*cw<=left)return {side:"end",x:x0-9,lines:[txt]};
  var side=right>=left?"start":"end",room=Math.max(right,left),l=wrap(txt,room);if(l.length>2)l=wrap(short,room);
  return {side:side,x:side==="start"?x0+9:x0-9,lines:l}}
function pathSvg(a){
  // the steps of "What happened" (built from every finding, not the capped trace): a family's bar starts at its step's time
  var steps={};(a.narrative||[]).forEach(function(s){steps[s.family]=s});
  var groups={};a.trace.forEach(function(f){if(f.stage==null||f.bits<=0||f.excepted)return;var k=f.family+"|"+f.stage,g=groups[k];
    if(!g)g=groups[k]={family:f.family,stage:f.stage,label:f.flabel,first:f.first,last:f.last,bits:0,lead:f,n:0,alerts:0,ticks:[]};
    g.first=Math.min(g.first,f.first);g.last=Math.max(g.last,f.last);g.n++;g.alerts+=f.n;if(f.bits>g.bits){g.bits=f.bits;g.lead=f}if(g.ticks.length<40)g.ticks.push(f.first)});
  var items=Object.keys(groups).map(function(k){var g=groups[k],s=steps[g.family];g.conf=!!(s&&s.confirmed);
    if(s&&s.stage===g.stage){g.first=s.t;g.last=Math.max(g.last,s.t);g.ticks=g.ticks.filter(function(t){return t>=s.t});g.ticks.push(s.t)}return g}).sort(function(x,y){return x.first-y.first});
  if(!items.length)return "";
  var t0=Math.min.apply(null,items.map(function(g){return g.first})),t1=Math.max.apply(null,items.map(function(g){return g.last}));
  if(t1-t0<10*60000){var mid=(t0+t1)/2;t0=mid-5*60000;t1=mid+5*60000}var pad=(t1-t0)*0.03;t0-=pad;t1+=pad;
  var box=$("#"+CTX),W=Math.max(560,((box&&box.clientWidth)||900)-24),L=96,R=24,top=6,rowH=38,laneGap=6;
  var X=function(t){return L+(t-t0)/(t1-t0)*(W-L-R)};
  var rows=[[],[],[],[]];items.forEach(function(g){var x0=X(g.first),x1=Math.max(X(g.last),x0+10),txt=g.label+(g.lead.attack_id?" · "+g.lead.attack_id:"")+(g.n>1?" · "+g.n:""),lab=apLabel(txt,g.label,x0,W,R);
    var w=Math.max.apply(null,lab.lines.map(function(t){return t.length*6.3})),a0=lab.side==="end"?lab.x-w:x0-6,a1=lab.side==="end"?x1+6:Math.max(x1,lab.x+w)+6,r=rows[g.stage],i=0;
    while(i<r.length&&r[i]>a0-4)i++;if(i>3)i=3;r[i]=Math.max(r[i]||0,a1);g.row=i;g.lab=lab});
  var laneY=[],y=top;for(var st=0;st<4;st++){var n=Math.max(1,rows[st].length);laneY.push([y,n*rowH+8]);y+=n*rowH+8+laneGap}
  var H=y+22,out=[];
  out.push('<defs><marker id="aph" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#aab3cc"/></marker>'
    +'<marker id="apn" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#ffb020"/></marker></defs>');
  for(st=0;st<4;st++){var ly=laneY[st];out.push('<rect x="0" y="'+ly[0]+'" width="'+W+'" height="'+ly[1]+'" rx="4" fill="'+(st%2?"#1d1e41":"#191a3a")+'"/>'
    +'<circle cx="12" cy="'+(ly[0]+16)+'" r="4.5" fill="'+C.stageColors[st]+'"/><text class="ln" x="24" y="'+(ly[0]+20)+'">'+esc(C.stages[st])+'</text>')}
  var span=t1-t0,steps2=[60e3,300e3,600e3,900e3,1800e3,3600e3,7200e3,10800e3,21600e3,43200e3,86400e3],step=steps2.find(function(s){return span/s<=6})||86400e3;
  for(var tt=Math.ceil(t0/step)*step;tt<=t1;tt+=step){var tx=X(tt);out.push('<line x1="'+tx+'" x2="'+tx+'" y1="'+top+'" y2="'+(y-laneGap)+'" stroke="#2a2b55" stroke-width="1"/>'
    +'<text class="ax" x="'+tx+'" y="'+(H-6)+'" text-anchor="middle">'+esc(tm(tt,span>20*3600e3?"dhm":"hm"))+'</text>')}
  var cont={};(a.narrative||[]).forEach(function(s){if(s.note)cont[s.family]=s.note});
  var pts=[];
  items.forEach(function(g){var by=laneY[g.stage][0]+8+g.row*rowH,x0=X(g.first),x1=Math.max(X(g.last),x0+10),col=C.stageColors[g.stage],conf=g.conf,f=g.lead,lab=g.lab;
    var tip=apTip([g.label+" · "+C.stages[g.stage]+(conf?" (confirmed)":" (suspected)"),f.rule,"ATT&CK: "+f.attack,f.tpl_tag?"template tag: "+f.tpl_tag:"",
      f.cp_label?"counterpart: "+f.cp_label:"",tm(g.first,"dhm")+" – "+tm(g.last,"dhm")+" · "+g.alerts+" alerts in "+g.n+" finding"+(g.n>1?"s":""),num(g.bits,1)+" bits"+(f.new?" · new for this host":""),cont[g.family]?"⤷ "+cont[g.family]:""]);
    out.push('<g class="hit" data-tip="'+tip+'">');
    out.push('<rect class="bar" x="'+x0+'" y="'+(by+17)+'" width="'+(x1-x0)+'" height="10" rx="5" fill="'+(conf?col:"none")+'" stroke="'+col+'" stroke-width="'+(conf?0:2)+'"'+(conf?"":' stroke-dasharray="4 3"')+'/>');
    g.ticks.forEach(function(t){var tx=X(t);if(tx>x0+3&&tx<x1-3)out.push('<line x1="'+tx+'" x2="'+tx+'" y1="'+(by+17)+'" y2="'+(by+27)+'" stroke="#14153a" stroke-width="1.5"/>')});
    out.push('<circle cx="'+x0+'" cy="'+(by+22)+'" r="5.5" fill="'+col+'" stroke="#14153a" stroke-width="2"/>');
    var ly0=by+(lab.lines.length>1?2:10);
    out.push('<text class="lb" text-anchor="'+lab.side+'" x="'+lab.x+'" y="'+ly0+'">'+lab.lines.map(function(t,i){return '<tspan x="'+lab.x+'"'+(i?' dy="12"':"")+'>'+esc(t)+'</tspan>'}).join("")+'</text></g>');
    pts.push({x:x0,y:by+22,fam:g.family})});
  for(var i=0;i+1<pts.length;i++){var p=pts[i],q=pts[i+1],nt=cont[q.fam],dx=Math.max(24,(q.x-p.x)/2);
    out.push('<path d="M'+p.x+','+p.y+' C'+(p.x+dx)+','+p.y+' '+(q.x-dx)+','+q.y+' '+(q.x-7)+','+q.y+'" fill="none" stroke="'+(nt?"#ffb020":"#aab3cc")+'" stroke-width="'+(nt?2:1.5)+'" marker-end="url(#'+(nt?"apn":"aph")+')" opacity=".9"/>')}
  return '<div class="ap"><svg viewBox="0 0 '+W+' '+H+'" height="'+H+'" role="img" aria-label="Attack path of this host over time">'+out.join("")+'</svg>'
    +'<div class="apleg"><span><i style="background:#ff7a00"></i>solid = confirmed</span><span><i style="border:2px dashed #ff7a00;height:6px"></i>dashed = suspected</span></div></div>'}
// Sycope's severity, and the threshold level the alert crossed (alertFlagThresholdLevel) said as such, not "High Minor"
function sevHtml(sev,thr){return esc(sev||"")+(thr?' <span class="mut" title="The threshold level of the rule the alert crossed in Sycope">· '+esc(thr)+' threshold</span>':"")}
function histHtml(T){if(!T||!T.length)return "";var VW={entered:"entered the queue as",escalated:"escalated to","de-escalated":"de-escalated to"};
  return '<div class="sec" data-sec="hist"><h3>History of this incident</h3><ol class="hist">'+T.map(function(x){
    if(x.who==="system"){var c=x.kind==="left"?"#808297":x.kind==="reopened"?"#ffb3c0":(VC[x.verdict]||"#808297"),head;
      if(x.kind==="reopened")head="came back to the queue: "+esc(x.text);else if(x.kind==="left")head="left the 24 h window (no new alerts)";
      else if(x.kind==="held")head=vp(x.verdict)+' <span class="mut">'+esc(x.text)+'</span>';
      else head=esc(VW[x.kind]||x.kind)+" "+vp(x.verdict)+' <span class="mut">'+esc(x.text)+(x.detail&&x.detail.first?" · first evidence "+tm(x.detail.first,"dhm"):"")+'</span>';
      return '<li class="sys" style="--hc:'+c+'"><span class="tm">'+tm(x.at*1000,"dhm")+'</span><b>system</b> '+head+'</li>'}
    return '<li style="--hc:#8cc4ff"><span class="tm">'+tm(x.at*1000,"dhm")+'</span><b>'+esc(x.who)+'</b>'+vok(x.verified)+' '+esc(x.text)+(x.story?' <span class="mut">(with the whole incident)</span>':"")+(x.note?': “'+esc(x.note)+'”':"")+'</li>'}).join("")+'</ol></div>'}
function heatHtml(h){if(!h||!h.rows.length)return "";var mx=1;h.rows.forEach(function(r){r.cells.forEach(function(c){if(c>mx)mx=c})});
  var lane={a:"",t:"targeted: ",h:"hygiene: ",x:"outside only: "};
  return '<div class="card heat" style="padding:0"><div class="grid"><table><tr><th>Family</th>'+h.days.map(function(d,i){return '<th>'+(i===h.days.length-1?"today":esc(d.slice(5)))+'</th>'}).join("")+'</tr>'
    +h.rows.map(function(r){var col=(C.families[r.family]||[0,0,"#808297"])[2];return '<tr><td>'+esc(lane[r.lane]||"")+esc(r.label)+'</td>'+r.cells.map(function(c){if(!c)return '<td class="z">·</td>';var a=0.18+0.82*Math.log(1+c)/Math.log(1+mx);
      return '<td style="background:color-mix(in srgb,'+col+' '+Math.round(a*100)+'%,var(--row))">'+num(c)+'</td>'}).join("")+'</tr>'}).join("")+'</table></div></div>'}
function alertsFlat(D){if(!D.alerts.length)return "";var rec=D.recorder&&D.recorder.on,P=D.pcap||{};
  var list=S.pcapOnly?D.alerts.filter(function(a){return P[a.id]}):D.alerts;
  var rows=list.map(function(a){var me=function(ip){return ip===D.ip?'<b>'+esc(ip)+'</b>':ip?esc(ip):nul()},has=P[a.id]&&P[a.id].state==="done";
    return '<tr'+(has?' class="hasp"':"")+' data-sl="1" data-rule="'+esc(a.name)+'" data-c="'+esc(a.client||"")+'" data-s="'+esc(a.server||"")+'" data-port="'+esc(a.port==null?"":a.port)+'" data-proto="'+esc(a.proto||"")+'" data-t0="'+esc(a.t)+'" data-t1="'+esc(a.t)+'"><td>'+tm(a.t)+'</td><td>'+rn(a.name)+'</td><td>'+sevHtml(a.severity,a.thr)+'</td><td class="mono">'+me(a.client)+'</td><td class="mono">'+me(a.server)+'</td><td>'+(a.port==null?nul():esc(a.port))+'</td>'
      +'<td style="white-space:nowrap">'+[alertLink(a),flows(a.client,a.server,a.port,a.t,a.t),silBtn()].filter(Boolean).join(" · ")+'</td>'+(rec?'<td>'+pcapCell(a,D)+'</td>':"")+'</tr>'}).join("");
  return '<div class="sec" data-sec="alerts" data-fold="1"><h3>Alerts naming this host: '+num(D.alerts.length)+' newest of '+num(D.alerts_total)+(S.pcapOnly?' · only those with a PCAP ('+num(list.length)+')':"")+((D.alert_groups||[]).length?' <button type="button" class="lnk" data-aflat="0" style="text-transform:none;letter-spacing:0">group by alert</button>':"")+'</h3>'+pcapLine(D,true)+pcapAllBtn(D)+'<div class="card" style="padding:0"><div class="grid" style="max-height:420px;overflow:auto"><table><tr><th>Time</th><th>Alert</th><th>Severity</th><th>Client</th><th>Server</th><th>Port</th><th>Sycope</th>'+(rec?"<th>PCAP</th>":"")+'</tr>'
    +(rows||'<tr><td colspan="8" class="empty">No alert of this host has a recording yet.</td></tr>')+'</table></div></div></div>'}
var PCAPT={done:"Packets recorded: open them",miss:"No packets: the recorder's buffer had been overwritten by then, or no packet matched the alert's filter (its page says which)",failed:"The extraction failed: its page says why",queued:"Waiting for the recorder",running:"Being extracted now"};
function pastBuffer(a,D){var B=(D.recorder||{}).buffer||{};return B.minutes!=null&&!B.stale&&a.t&&(Date.now()-a.t)>B.minutes*60000}
function pcapCell(a,D){var j=(D.pcap||{})[a.id];if(j){var st=j.state||"?",cls=st==="done"?"b-done":st==="miss"?"b-miss":st==="failed"?"b-failed":"b-queued";return '<a href="'+esc(C.recorderUrl+"/"+encodeURIComponent(a.id))+'" target="_blank" rel="noopener" title="'+esc(PCAPT[st]||st)+'"><span class="badge '+cls+'">'+esc(st)+'</span></a>'}
  if(pastBuffer(a,D))return '<span class="mut" title="The recorder keeps the last '+esc(dur(D.recorder.buffer.minutes*60))+'; this alert is older, its packets are gone">past the buffer</span>';
  if(S.pcapreq[a.id])return '<span class="mut">'+esc(S.pcapreq[a.id])+'</span>';return D.recorder.request?'<button type="button" class="lnk" data-pcap="'+esc(a.id)+'">Get PCAP</button>':'<span class="null">none</span>'}
function pcapLine(D,inAlerts){var P=D.pcap_summary;if(!D.recorder||!D.recorder.on||!P)return "";
  var B=D.recorder.buffer||{},keeps=B.minutes!=null?' The recorder keeps the last <b>'+esc(dur(B.minutes*60))+'</b>'+(B.stale?" (as it last reported)":"")+': older alerts have no packets left.':"";
  if(!P.done&&!P.queued)return D.recorder.request&&inAlerts?'<div class="pcl mut">No PCAP for this host yet: ask for one on an alert (Get PCAP).'+keeps+'</div>':"";
  if(inAlerts)return "";
  var links=(P.jobs||[]).filter(function(j){return j.state==="done"}).slice(0,3).map(function(j){return '<a href="'+esc(C.recorderUrl+"/"+encodeURIComponent(j.id))+'" target="_blank" rel="noopener">'+esc(tm(j.t,"dhm"))+' '+esc(j.name||"")+' ↗</a>'}).join(" · ");
  return '<div class="pcl"><span class="tg pc">PCAP</span><span><b style="color:#fff">'+num(P.done)+'</b> alert'+(P.done===1?"":"s")+' with a recording'+(P.queued?', '+num(P.queued)+' queued':"")+'</span>'+(links?'<span>'+links+'</span>':"")
    +'<button type="button" class="lnk" data-pconly="1">'+(S.pcapOnly?"show all alerts":"only alerts with PCAP")+'</button></div>'}
// "Why <verdict>" under the host header: the three biggest terms of the math below, in its own words and numbers
function whyTerms(a){var t=[];(a.families||[]).forEach(function(f){t.push({bits:f.bits,text:f.label})});
  if(a.progression)t.push({bits:a.progression,text:"kill-chain progression",dec:0});
  (a.chains||[]).forEach(function(c){t.push({bits:c.bits,text:c.id+" "+c.title})});
  if(a.recurring)t.push({bits:a.recurring.bits,text:"recurring"});
  return t.map(function(x,i){x.i=i;return x}).sort(function(x,y){return y.bits-x.bits||x.i-y.i})}
function whyHtml(a){return '<div class="rsn2 w1"><b>Why '+esc(VL[a.verdict])+'</b>: '+esc(a.reason)+(a.held?' · <span class="mut">'+esc(a.held.text)+'</span>':"")+' · <a href="#why" data-gowhy="1" style="color:#8cc4ff">the math ↓</a></div>'}
function factsHtml(a){var low=a.low_why||"";
  return '<div class="facts">'+kc(a.stages)+'<span class="stl">'+esc(a.stage_line||"")+'</span><span>confidence <b style="color:#fff" title="'+esc(pc(a.conf))+'">'+esc(a.conf_word||pc(a.conf))+'</b><span class="track"><i style="width:'+Math.round(a.conf*100)+'%"></i></span>'+(low?' <span class="mut" title="'+esc("The verdict is not the confidence alone: "+a.reason)+'">low, but '+esc(low)+'</span>':"")+'</span>'
  +(a.novelty==="new"?'<span class="tg new">new behaviour</span>':a.novelty==="recurring"?'<span class="tg rec">recurring</span>':"")+(a.active?'<span class="tg lv">active</span>':"")
  +'<span title="Alerts this host sent as the source, and the findings the triage built from them. Alerts that only name it (as the target, or as the other side) are in the Alerts section below.">'+num(a.alerts)+' alerts it sent · '+num(a.findings)+' findings · '+rng(a.first,a.last)+'</span></div>'}
function partOf(D){var P=D.parents||{};if(!P.story&&!P.campaign)return "";
  return '<div class="partof">Part of '+(P.story?'the incident '+ilink("s:"+P.story.key,P.story.title+" ("+hp(P.story.count,"host")+")",""):"")
    +(P.campaign?(P.story?" in ":"")+ilink("c:"+P.campaign.net,"campaign "+P.campaign.net,""):"")+ii("The actions on this page apply to this host only; the group's and the campaign's are on their pages.")+'</div>'}
function hostHtml(D){if(SM())return hostSimple(D);var a=D.actor,t=D.triage,h="",T=D.target,X=D.external,TI=D.target_inc;
  // 1. the summary: who, the verdict and why, what happened in one line, the facts, the PCAP
  var vc=a?VC[a.verdict]:TI?VC[TI.verdict]:T?"#ff7a00":"#808297";
  h+='<div class="hsum" style="--vc:'+vc+'"><div class="dh">'+(a?vp(a.verdict):TI?vp(TI.verdict):"")+priTag(D.priority)+'<span class="ip">'+esc(D.ip)+'</span>'+(D.name?'<span class="tg nm"'+((D.ctx||{}).name_src?' title="'+esc("Name from "+D.ctx.name_src)+'"':"")+'>'+esc(D.name)+'</span>':"")
    +(D.crown?'<span class="tg jw">crown jewel</span>':"")+(D.loc?'<span class="tg" title="'+esc((D.ctx||{}).loc_tip||"")+'">'+esc(D.loc)+'</span>':"")+ctxTags(D)+(D.internal?"":'<span class="tg">external</span>')
    +'<span class="sp"></span><button type="button" class="b2" data-copy="'+esc(D.ip)+'">Copy IP</button><button type="button" class="b2" data-ticket="1" title="A plain-text summary for a ticket, chat or e-mail">Copy as ticket</button></div>';
  if(a)h+='<div class="dsum">'+esc(a.headline)+'</div>'+whyHtml(a)+factsHtml(a);
  else if(TI)h+='<div class="dsum">'+esc(TI.headline)+'</div><div class="rsn2"><b>'+esc(VL[TI.verdict])+'</b>: '+esc(TI.reason)+'</div><div class="facts"><span class="tg">attacked from outside</span><span>'+hp(TI.attackers.length,"outside address","outside addresses")+(TI.ti.length?' · threat list: <b style="color:#fff">'+esc(TI.ti.join(", "))+'</b>':"")+' · it answered <b style="color:#fff">'+bytes(TI.answered)+'</b></span><span>'+rng(TI.first,TI.last)+'</span></div>';
  else if(T)h+='<div class="dsum">Target of '+num(T.attackers_total)+' host'+(T.attackers_total===1?"":"s")+(T.heat?' · <span class="hb '+esc(T.heat)+'" title="How exposed it is to attackers; the verdict is the only severity scale">'+esc(HEATW[T.heat]||T.heat)+'</span>':"")+'</div><div class="rsn2">It does not act itself: it is in the queue only when it starts acting. Its attackers are listed below.</div>';
  else if(X)h+='<div class="dsum">External IP'+(X.ti.length?' on a threat list: <b>'+esc(X.ti.join(", "))+'</b>':"")+'</div><div class="rsn2">'+esc(X.asn||"")+' · '+num(X.n)+' alerts · '+rng(X.first,X.last)+'</div>'+(pivotLinks(D.ip)?'<div class="rsn2">'+pivotLinks(D.ip)+'</div>':"");
  h+=pcapLine(D)+partOf(D);
  // 2. what to do: triage and the pivots into Sycope, in the same card
  var span=a||T,acts=[];if(C.rawdata&&IPRE.test(D.ip)&&span)acts.push(hostAlerts(D.ip,span.first,span.last,"Alerts of this host in Sycope ↗"),flows(D.ip,null,null,span.first,span.last,"Flows of this host as client ↗"),flows(null,D.ip,null,span.first,span.last,"as server ↗"));
  h+='<div class="hact">'+triPanel("h",D.ip,t,a?a.verdict:TI?TI.verdict:"")+(acts.length?'<div class="tri pvt">'+acts.join(" · ")+'</div>':"")+'</div></div>';
  h+=nextHtml(D,D.ip);
  // 3. the attack: in one picture, then in words
  if(a){if(a.trace.some(function(f){return f.stage!=null&&f.bits>0}))h+='<div class="sec" data-sec="path"><h3>Attack path'+ii(APLEG)+'</h3>'+pathSvg(a)+'</div>';
    h+='<div class="sec" data-sec="what"><h3>What happened</h3>'+(a.narrative.length?stepsHtml(a.narrative):'<p class="mut">No strong evidence: only background signals.</p>')+bgHtml(a.background)+'</div>'}
  if(X)h+='<div class="sec"><h3>Your hosts it touched</h3>'+(X.in_hosts.length?'<p>Targeted: '+X.in_hosts.map(function(ip){return ilink("h:"+ip,ip)}).join(", ")+'</p>':"")
    +(X.out_hosts.length?'<p>Contacted it: '+X.out_hosts.map(function(ip){return ilink("h:"+ip,ip)}).join(", ")+'</p>':"")+'<p class="mut">'+X.rules.map(function(r){return esc(r[0])+" ×"+num(r[1])}).join(" · ")+'</p></div>';
  // 4. the alerts, open: newest first, recordings visible
  h+=alertsHtml(D)+talkHtml(D);
  // 5. context: who attacks it, the last days, hygiene, the history of the incident
  if(T){h+='<div class="sec"><h3>Targeted by '+num(T.attackers_total)+' host'+(T.attackers_total===1?"":"s")+'</h3><div class="card mbr" style="padding:0"><div class="grid"><table style="min-width:640px"><tr><th>Attacker</th><th>Rules</th><th>Alerts</th><th>It answered</th><th>Last</th></tr>'
    +T.attackers_list.map(function(x){return '<tr data-open="h:'+esc(x.ip)+'"><td class="mono">'+esc(x.ip)+(x.internal?"":' <span class="tg">external</span>')+(x.verdict?" "+vp(x.verdict):"")+(x.ti.length?' <span class="pill2" style="background:#5c1a2b">'+esc(x.ti.join(", "))+'</span>':"")+'</td><td>'+x.rules.map(function(r){return esc(r[0])+' <span class="mut">×'+num(r[1])+'</span>'}).join("<br>")+'</td><td>'+num(x.n)+'</td><td>'+bytes(x.down)+'</td><td>'+at(x.last)+'</td></tr>'}).join("")+'</table></div></div></div>'}
  if(D.heat&&D.heat.rows.length)h+='<div class="sec" data-sec="days"><h3>Last days'+ii("Its families per day: the stored days before and today (the current 24 hours). "+(D.depth<3?"History is still being read from Sycope; novelty counts once 3 days are in.":"A family every day is a habit; one only today is new."))+'</h3>'+heatHtml(D.heat)+'</div>';
  if(D.hygiene&&D.hygiene.length)h+='<div class="sec"><h3>Hygiene</h3><p class="mut">'+D.hygiene.slice(0,8).map(function(x){return rn(x.rule)+' ×'+num(x.n)+(x.cp?" ("+esc(x.cp)+(x.port?":"+esc(x.port):"")+")":"")}).join(" · ")+'</p></div>';
  h+=histHtml(D.timeline)+earlierHtml(D.earlier,D.ip);
  // 6. the reasoning, folded: the math of the verdict and every piece of evidence
  if(a)h+='<div class="sec" data-sec="why" data-fold="1"><h3>Why '+esc(VL[a.verdict])+': the math and the evidence, term by term</h3>'+mathHtml(a)+'<div style="margin-top:12px">'+traceHtml(a,D)+'</div></div>';
  return h+silencedHtml(D)}
// silenced findings are not dropped: a folded list with the rule that took each (Full view only)
function silencedHtml(D){var Z=D.silenced;if(!Z||!Z.total)return "";
  var rows=Z.findings.map(function(f){return '<tr><td>'+rn(f.rule)+'<div class="mut mono">'+esc(f.cp||"")+(f.port&&!String(f.cp||"").endsWith(":"+f.port)?":"+esc(f.port):"")+'</div></td><td>'+num(f.n)+'<div class="mut">'+rng(f.first,f.last)+'</div></td><td>'+esc(silLine(f.excepted))+'</td></tr>'}).join("");
  return '<div class="sec" data-sec="silenced" data-fold="1"><h3>Silenced ('+num(Z.total)+')'+ii("Findings of this host that a silence rule took the weight off: "+num(Z.n)+" alerts. They are still in Sycope and in every count; they add nothing to the verdict.")+'</h3><div class="card" style="padding:0"><div class="grid"><table style="min-width:640px"><tr><th>Finding</th><th>Alerts</th><th>By</th></tr>'+rows+'</table></div></div>'
    +(Z.total>Z.findings.length?'<p class="mut" style="font-size:12px">'+num(Z.findings.length)+' of '+num(Z.total)+' shown.</p>':"")+'</div>'}
// ---- Simple view: what happened, why and how sure, what to do (the same data, fewer words; the (i) leads to the reasoning) ----
function simpleLine(k,v,cls){return '<div class="sl"><span class="slk">'+k+'</span><span class="slv'+(cls?" "+cls:"")+'">'+v+'</span></div>'}
// the strongest reasons of the verdict, in words (the order of the math below them, without the bits)
function whyWords(a){var seen={},out=[];whyTerms(a).forEach(function(x){if(!(x.bits>0))return;var t=x.text.replace(/^[A-Z]{1,3}-\d+\s+/,"");
    if(t==="kill-chain progression")t="attack steps in order";else if(t==="recurring")t="it keeps coming back";if(!seen[t]){seen[t]=1;out.push(t)}});return out.slice(0,3)}
function certWord(word,low,upto){return word?' · Certainty: '+(upto?"up to ":"")+'<b>'+esc(word)+'</b>'+(low?' <span class="mut">(low, but '+esc(low)+')</span>':""):""}
// the first next step nobody has checked yet, with the same check box as the Next steps section
function doLine(D,ip){var X=D.steps;if(!X||!X.list||!X.list.length)return "";var done=X.done||{},s=X.list.filter(function(y){return !(done[y.id]&&done[y.id].done)})[0];
  if(!s)return simpleLine("Do",'<span class="mut">every next step is checked</span>');
  return simpleLine("Do",'<label class="sl-do">'+(C.edit&&X.rec?'<input type="checkbox" data-step="'+esc(s.id)+'" data-rec="'+esc(X.rec)+'"'+(ip?' data-ip="'+esc(ip)+'"':"")+' aria-label="Checked" title="Checked: it goes into the incident\'s history"> ':"")+'<b>'+esc(s.title)+'</b></label>'+ii(esc(s.why)))}
function pcapChip(D){var P=D.pcap_summary;if(!D.recorder||!D.recorder.on||!P||!P.done)return "";var j=(P.jobs||[]).filter(function(j){return j.state==="done"})[0],txt="PCAP: "+hp(P.done,"recording");
  return '<div class="pcl">'+(j&&C.recorderUrl?'<a class="tg pc" href="'+esc(C.recorderUrl+"/"+encodeURIComponent(j.id))+'" target="_blank" rel="noopener" title="Open the newest recording">'+txt+' ↗</a>':'<span class="tg pc">'+txt+'</span>')+'</div>'}
function hostSimple(D){var a=D.actor,t=D.triage,T=D.target,X=D.external,TI=D.target_inc,h="",vv=a?a.verdict:TI?TI.verdict:"",vc=vv?VC[vv]:T?"#ff7a00":"#808297";
  h+='<div class="hsum" style="--vc:'+vc+'"><div class="dh">'+(vv?vp(vv):"")+'<span class="ip">'+esc(D.ip)+'</span>'+(D.name?'<span class="tg nm">'+esc(D.name)+'</span>':"")+(D.crown?'<span class="tg jw">crown jewel</span>':"")+'</div>';
  if(a){var w=whyWords(a);h+=simpleLine("What",esc(a.headline),"dsum")
    +simpleLine("Why",esc(w.length?w.join(", "):"only background signals")+certWord(a.conf_word,a.low_why||"",false)+ii(esc(a.reason)))+doLine(D,D.ip)}
  else if(TI)h+=simpleLine("What",esc(TI.headline),"dsum")+simpleLine("Why",'<b>'+esc(VL[TI.verdict])+'</b>: '+esc(TI.reason)+' · attacked from outside, it answered')+doLine(D,D.ip);
  else if(T)h+=simpleLine("What",'Target of '+hp(T.attackers_total,"host"),"dsum")+simpleLine("Why","It does not act itself: it is in the queue only when it starts acting")+doLine(D,D.ip);
  else if(X)h+=simpleLine("What",'External IP'+(X.ti.length?' on a threat list: <b>'+esc(X.ti.join(", "))+'</b>':""),"dsum")+simpleLine("Why",esc(X.asn||"")+' · '+hp(X.n,"alert")+' · '+rng(X.first,X.last));
  h+=pcapChip(D)+'<div class="hact">'+triPanel("h",D.ip,t,vv)+'</div></div>'+nextHtml(D,D.ip);
  if(a&&a.trace.some(function(f){return f.stage!=null&&f.bits>0}))h+='<div class="sec" data-sec="path"><h3>Attack path'+ii(APLEG)+'</h3>'+pathSvg(a)+'</div>';
  if(X)h+='<div class="sec"><h3>Your hosts it touched</h3>'+(X.in_hosts.length?'<p>Targeted: '+X.in_hosts.slice(0,8).map(function(ip){return ilink("h:"+ip,ip)}).join(", ")+(X.in_hosts.length>8?' <span class="mut">+'+num(X.in_hosts.length-8)+' more</span>':"")+'</p>':"")
    +(X.out_hosts.length?'<p>Contacted it: '+X.out_hosts.slice(0,8).map(function(ip){return ilink("h:"+ip,ip)}).join(", ")+(X.out_hosts.length>8?' <span class="mut">+'+num(X.out_hosts.length-8)+' more</span>':"")+'</p>':"")+'</div>';
  if(T)h+='<div class="sec"><h3>Targeted by '+hp(T.attackers_total,"host")+'</h3><div class="card mbr" style="padding:0"><div class="grid"><table style="min-width:0"><tr><th>Attacker</th><th>What it did</th><th>Last</th></tr>'
    +T.attackers_list.slice(0,5).map(function(x){return '<tr data-open="h:'+esc(x.ip)+'"><td class="mono">'+esc(x.ip)+(x.internal?"":' <span class="tg">external</span>')+(x.verdict?" "+vp(x.verdict):"")+(x.ti.length?' <span class="pill2" style="background:#5c1a2b">'+esc(x.ti.join(", "))+'</span>':"")+'</td><td>'+x.rules.slice(0,2).map(function(r){return esc(r[0])}).join("<br>")+'</td><td>'+at(x.last)+'</td></tr>'}).join("")+'</table></div></div>'
    +(T.attackers_list.length>5?'<p class="mut">+'+num(T.attackers_list.length-5)+' more in All details</p>':"")+'</div>';
  return h}
function groupWhy(D){var w=[];(D.chain_words||[]).forEach(function(c){w.push(c.title)});if(!w.length)(D.path||[]).forEach(function(p){w.push(p.label)});if(!w.length)w=(D.families||[]).map(fam);return esc(w.slice(0,3).join(", ")||"the same evidence on every host")}
function groupSimple(D){var ips=D.members.map(function(m){return m.ip}),lead=D.members[0],vmap={},h="";D.members.forEach(function(m){vmap[m.ip]=m.verdict});
  h+='<div class="hsum" style="--vc:'+VC[D.verdict]+'"><div class="dh">'+vp(D.verdict)+'<span class="ip" style="font-family:inherit">'+esc(D.title)+'</span><span class="tg">Incident · '+hp(D.count,"host")+'</span></div>'
    +simpleLine("What",hp(D.count,"host")+' show the same pattern: '+esc(D.families.map(fam).join(", ")),"dsum")+simpleLine("Why",groupWhy(D)+certWord(D.conf_word,"",true)+ii(esc(lead?lead.reason:"")))+doLine(D,"")
    +'<div class="hact">'+bulkBar("s:"+D.key,D.title+" ("+D.count+" hosts)",ips,vmap,D.members.length)+'</div></div>'+nextHtml(D)+connectHtml(D)
    +'<div class="sec"><h3>Hosts ('+num(D.count)+')</h3>'+hostsTable(D.members,R[CTX].hall?0:200)+'</div>';
  return h}
function campaignSimple(D){var ips=D.hosts.map(function(m){return m.ip}),vmap={},h="";D.hosts.forEach(function(m){vmap[m.ip]=m.verdict});
  h+='<div class="hsum" style="--vc:'+VC[D.verdict]+'"><div class="dh">'+vp(D.verdict)+'<span class="ip" style="font-family:inherit">'+esc(D.title)+'</span><span class="tg">Campaign · '+hp(D.count,"host")+' in '+hp(D.children_n,"incident")+'</span></div>'
    +simpleLine("What",hp(D.count,"host")+' of '+esc(D.net)+' at Investigate or above: '+esc(D.families.map(fam).join(", ")),"dsum")+simpleLine("Why",groupWhy(D)+certWord(D.conf_word,"",true)+ii(esc(D.reason||"")))+doLine(D,"")
    +'<div class="hact">'+bulkBar("c:"+D.net,"Campaign "+D.net,ips,vmap,D.hosts.length)+'</div></div>'+nextHtml(D)
    +'<div class="sec"><h3>Incidents in this campaign ('+num(D.children.length)+')</h3><div class="qwrap"><table class="qt">'+SHEAD+'<tbody>'+(R[CTX].hall?D.children:D.children.slice(0,20)).map(function(c){return rowHtml({it:c,child:false})}).join("")+'</tbody></table></div>'
    +(D.children.length>20&&!R[CTX].hall?'<button type="button" class="b2 more2" data-hall="1">show all '+num(D.children.length)+'</button>':"")+'</div>';
  return h}
// ---- next steps: what to check, in order, from the evidence (playbook.py); a check goes into the incident's history ----
var STEPK={check:["check","Look in Sycope or in the recorded packets"],ask:["ask","Outside Sycope: EDR, the auth logs, the host's owner"],act:["action","Containment, once a check confirms the attack"]};
function stepLink(l,D){if(!l)return "";
  if(l.t==="flows"){var fa=flows(l.c,l.s,l.port,l.from,l.to,esc(l.label)+" ↗");return fa?fa+' <button type="button" class="lnk" data-fl="'+esc([l.c||"",l.s||"",l.port||"",l.from-300000,l.to+60000].join("|"))+'" title="The newest flows of this pair from Sycope, here">show here</button>':""}
  if(l.t==="alerts")return alertsOf(l.rule,l.c,l.s,l.from,l.to,esc(l.label)+" ↗");
  if(l.t==="host")return '<a href="'+esc(keyUrl("h:"+l.ip))+'" data-open="h:'+esc(l.ip)+'">'+esc(l.label)+'</a>';
  if(l.t==="key")return '<a href="'+esc(keyUrl(l.key))+'" data-open="'+esc(l.key)+'">'+esc(l.label)+'</a>';
  if(l.t==="url")return /^https?:\/\//i.test(l.url||"")?'<a href="'+esc(l.url)+'" target="_blank" rel="noopener noreferrer">'+esc(l.label)+' ↗</a>':"";
  if(l.t==="pcap"){var j=(((D||{}).pcap_summary||{}).jobs||[]).filter(function(j){return j.state==="done"})[0];
    return j&&C.recorderUrl?'<a href="'+esc(C.recorderUrl+"/"+encodeURIComponent(j.id))+'" target="_blank" rel="noopener">'+esc(l.label)+' ↗</a>':""}
  return ""}
function nextHtml(D,ip){var X=D.steps;if(!X||!X.list||!X.list.length)return "";var done=X.done||{},n=0,list=X.list,hid=0;
  if(SM()&&!S.stepsAll){list=X.list.filter(function(s){return !(done[s.id]&&done[s.id].done)}).slice(0,3);hid=X.list.length-list.length}
  var rows=list.map(function(s){var d=done[s.id],ok=!!(d&&d.done),k=STEPK[s.kind]||STEPK.check,links=(s.links||[]).map(function(l){return stepLink(l,D)}).filter(Boolean);if(ok)n++;
    return '<li class="nx nx-'+esc(s.kind)+(ok?" ok":"")+'">'+(C.edit&&X.rec?'<input type="checkbox" data-step="'+esc(s.id)+'" data-rec="'+esc(X.rec)+'"'+(ip?' data-ip="'+esc(ip)+'"':"")+(ok?" checked":"")+' aria-label="Checked" title="Checked: it goes into the incident\'s history">':'<span class="nxb"></span>')
      +'<div class="nxt"><span class="nxk" title="'+esc(k[1])+'">'+esc(k[0])+'</span><b>'+esc(s.title)+'</b>'+(s.stale?' <span class="note" title="'+esc("The factory text is now: "+s.factory.title+" - "+s.factory.why)+'">factory step changed, review</span>':"")+ii(esc(s.why))+(links.length?' <span class="nxl">'+links.join(" · ")+'</span>':"")
      +(ok?'<div class="nxd">checked by '+esc(d.who||"?")+' '+tm(d.at*1000,"dhm")+'</div>':"")+'</div></li>'}).join("");
  return '<div class="sec nxs" data-sec="steps"><h3>Next steps <span class="nxc">'+num(n)+' of '+num(X.list.length)+' checked'+(X.rec?"":" · not an open incident now, so checks are not kept")+'</span>'
    +ii("Built from this incident's evidence: its chain rules first, then its strongest families. The same evidence gives everyone the same list.<br><b>Check</b>: a look in Sycope. <b>Ask</b>: outside it (EDR, auth logs, the owner). <b>Action</b>: containment, once a check confirms the attack.<br>A ticked step goes into the incident's history and the audit log.")+'</h3><ol class="nxo">'+rows+'</ol>'
    +(hid>0?'<div class="nxf"><button type="button" class="lnk" data-stepsall="1">show all '+num(X.list.length)+'</button></div>':"")+'</div>'}
function stepCheck(x){var w=rootOf(x),root=$("#"+w),k=root&&root.dataset.k,D=k&&S.det[k],X=D&&D.steps;if(!X)return;
  var s=(X.list||[]).filter(function(y){return y.id===x.dataset.step})[0],done=x.checked;if(!s)return;
  ensureWho().then(function(who){if(!who){x.checked=!done;return}
    post({op:"step",rec:+x.dataset.rec,step:s.id,done:done,title:s.title,ip:x.dataset.ip||"",who:who}).then(function(){X.done=X.done||{};X.done[s.id]={done:done,who:who,at:Date.now()/1000,title:s.title};redrawRoot(w)})
      .catch(function(e){x.checked=!done;toast(e.message,true)})})}
// ---- taken, now quiet: hosts an analyst holds that the board no longer shows; they stay until someone closes them ----
function heldWho(x,f){if(f==="mine")return !!ME.name&&(x.owner||x.who)===ME.name;if(f==="free")return false;if(f==="esc")return x.status==="escalated";return true}
function heldPass(x){if(!heldWho(x,S.wf))return false;if(!S.q)return true;var h=[x.ip,x.name,x.headline,x.owner,x.who,x.net].join(" ").toLowerCase();
  return S.q.toLowerCase().split(/\s+/).filter(Boolean).every(function(w){return h.indexOf(w)>=0})}
function heldRow(x){var k="h:"+x.ip,qk=x.rec?"i:"+x.rec:k,u=keyUrl(qk),t={status:x.status,owner:x.owner,who:x.who,at:x.at,note:x.note,changed:false,handled:false};
  if(SM())return '<tr class="qr held'+(S.open===qk?" sel":"")+'" style="--vc:'+VC[x.verdict]+'" data-k="'+esc(qk)+'" data-hk="'+esc(k)+'" data-v="'+esc(x.verdict)+'" title="Quick look">'
    +sCells(vp(x.verdict)+'<div class="mut hw">when taken</div>','<span class="qt-t"><span class="tip">'+esc(x.ip)+'</span>'+(x.name?' <span class="mut">'+esc(x.name)+'</span>':"")+' '+esc(x.headline||"")+'</span>',"",
      (x.last?'<span title="Last alert: '+esc(fullTime(x.last))+'">'+at(x.last)+'</span>':'<span class="mut">-</span>')+'<div class="mut">quiet</div>',
      '<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="'+(x.rec?"Its incident record":"The host")+' on its own page, in a new tab">Open ›</a>')+'</tr>';
  var acts=C.edit?'<span class="ra">'+actBtn("close","Close…",k,x.verdict,"","Close it as a true positive, benign or a false positive")+actBtn("open","Release",k,x.verdict,"","Nobody holds it any more: back to New, and off this list")+'</span>':"";
  acts+=KB+'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="'+(x.rec?"Its incident record":"The host")+' on its own page, in a new tab">Open ›</a>';
  return '<tr class="qr held'+(S.open===qk?" sel":"")+'" style="--vc:'+VC[x.verdict]+'" data-k="'+esc(qk)+'" data-hk="'+esc(k)+'" data-v="'+esc(x.verdict)+'" title="Quick look">'
    +'<td class="c-v">'+vp(x.verdict)+'<div class="mut hw">when taken</div></td>'
    +'<td class="c-i"><span class="qt-t">'+esc(x.headline||("Host "+x.ip))+'</span><div class="qt-s">'+esc(x.now?"Now at "+VL[x.now]+": below Review, so the sections above no longer show it":"No alerts in the last 24 hours")+'</div></td>'
    +'<td class="c-k"></td>'
    +'<td class="c-s"><span class="mono">'+esc(x.ip)+'</span>'+(x.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(x.name?'<div class="mut">'+esc(x.name)+'</div>':x.net?'<div class="mut">'+esc(x.net)+'</div>':"")+'</td>'
    +'<td class="c-c"></td><td class="c-l">'+(x.last?'<span title="Last alert: '+esc(fullTime(x.last))+'">'+at(x.last)+'</span>':'<span class="mut">-</span>')+'<div class="mut">quiet</div></td>'
    +'<td class="c-sla"></td><td class="c-st">'+statusHtml({type:"host",triage:t})+'</td><td class="c-a"><span class="btns">'+acts+'</span></td></tr>'}
function heldSec(n){return '<tr class="qsec"><td colspan="9"><span class="qsec-l" style="--vc:#8cc4ff">Taken, now quiet</span> <span class="mut">'+hp(n,"incident")+' in progress or escalated that the board no longer shows: they stay here until someone closes or releases them</span></td></tr>'}
// an ended incident that was taken or escalated: a record, shaped for the same filters as a held host
function recHeld(r){return {ip:r.subject_kind==="ip"?r.subject_value:"",name:r.name,headline:r.headline||r.label,owner:r.outcome_by,who:r.outcome_by,status:r.outcome,net:r.label}}
function recHeldRow(r){var qk="i:"+r.id,u=keyUrl(qk),ip=r.kind==="entity"&&r.subject_kind==="ip"?r.subject_value:"",t={status:r.outcome,owner:r.outcome_by,who:r.outcome_by,at:r.outcome_at,changed:false,handled:false};
  if(SM())return recSimple(r,qk,u,ip,"heldrec",true);
  var acts=C.edit?'<span class="ra">'+actBtn("close","Close…",qk,r.verdict,"","Close it as a true positive, benign or a false positive")+actBtn("open","Release",qk,r.verdict,"","Nobody holds it any more: back to Ended, not reviewed")+'</span>':"";
  acts+=KB+'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="Its incident record, as it was at its peak, in a new tab">Open ›</a>';
  var back=r.back?' <span class="tg back" title="The same host is in the queue again now">back now · '+esc(VL[r.back_verdict]||"in the queue")+'</span>':"";
  return '<tr class="qr heldrec'+(S.open===qk?" sel":"")+'" style="--vc:'+VC[r.verdict]+'" data-k="'+esc(qk)+'"'+(ip?' data-hk="h:'+esc(ip)+'"':"")+' data-v="'+esc(r.verdict)+'" title="Quick look">'
    +'<td class="c-v">'+vp(r.verdict)+'<div class="mut hw">at its peak</div></td>'
    +'<td class="c-i"><span class="qt-t">'+esc(r.headline||r.label||"")+'</span>'+back+'<div class="qt-s">Taken after it ended · last alert '+(r.last_ms?at(r.last_ms):"unknown")+'</div></td>'
    +'<td class="c-k"></td>'
    +'<td class="c-s">'+(ip?'<span class="mono">'+esc(ip)+'</span>'+(r.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(r.name?'<div class="mut">'+esc(r.name)+'</div>':""):'<span class="mut">'+esc(r.kind==="group"?scopeN(r):r.kind==="campaign"?"campaign · "+scopeN(r):"")+'</span>'+scopeSub(r))+'</td>'
    +'<td class="c-c">'+(r.conf!=null?cw(r):"")+'</td><td class="c-l">'+(r.last_ms?'<span title="Last alert: '+esc(fullTime(r.last_ms))+'">'+at(r.last_ms)+'</span>':'<span class="mut">-</span>')+'<div class="mut">quiet</div></td>'
    +'<td class="c-sla"></td><td class="c-st">'+statusHtml({type:"host",triage:t})+'</td><td class="c-a"><span class="btns">'+acts+'</span></td></tr>'}
// ---- ended, not reviewed: incidents that reached Act now or Investigate, went quiet and nobody looked at them ----
function unrevPass(r){if(S.wf==="mine"||S.wf==="esc")return false;if(!S.vd.has(r.verdict))return false;if(!S.q)return true;
  var h=[r.subject_value,r.label,r.name,r.headline,(r.families||[]).join(" ")].join(" ").toLowerCase();
  return S.q.toLowerCase().split(/\s+/).filter(Boolean).every(function(w){return h.indexOf(w)>=0})}
function isUnrev(r){return r&&r.status==="closed"&&r.outcome==="expired"&&r.end_reason==="quiet"&&!r.parent&&(r.verdict==="act"||r.verdict==="investigate")}
function isTaken(r){return r&&r.status==="closed"&&r.end_reason==="quiet"&&!r.parent&&(r.outcome==="investigating"||r.outcome==="escalated")&&(r.outcome_at||0)>(r.closed_at||0)}
// an ended record as a Simple row: peak verdict, what it was (the IP first), how many hosts, when it went quiet
function recSimple(r,qk,u,ip,cls,taken){var back=r.back?' <span class="tg back" title="The same host is in the queue again now">back now · '+esc(VL[r.back_verdict]||"in the queue")+'</span>':"";
  return '<tr class="qr '+cls+(S.open===qk?" sel":"")+'" style="--vc:'+VC[r.verdict]+'" data-k="'+esc(qk)+'"'+(ip?' data-hk="h:'+esc(ip)+'"':"")+' data-v="'+esc(r.verdict)+'" title="Quick look">'
    +sCells(vp(r.verdict)+'<div class="mut hw">at its peak</div>','<span class="qt-t">'+(ip?'<span class="tip">'+esc(ip)+'</span>'+(r.name?' <span class="mut">'+esc(r.name)+'</span>':"")+' ':"")+esc(r.headline||r.label||"")+'</span>'+back,
      r.kind==="entity"?"":'<b>'+scopeN(r)+'</b>',(r.last_ms?'<span title="Last alert: '+esc(fullTime(r.last_ms))+'">'+at(r.last_ms)+'</span>':'<span class="mut">-</span>')+'<div class="mut">'+(taken?"quiet":"ended "+(r.closed_at?tm(r.closed_at*1000,"dhm"):""))+'</div>',
      '<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="Its incident record, as it was at its peak, in a new tab">Open ›</a>')+'</tr>'}
function unrevRow(r){var qk="i:"+r.id,u=keyUrl(qk),ip=r.kind==="entity"&&r.subject_kind==="ip"?r.subject_value:"";
  if(SM())return recSimple(r,qk,u,ip,"unrev",false);
  var acts=C.edit?'<span class="ra">'+actBtn("investigating","Take it",qk,r.verdict,"","In progress and yours: it waits under Taken, now quiet")+actBtn("ack","Seen",qk,r.verdict,"","Nothing to do now: it leaves this list")+actBtn("close","Close…",qk,r.verdict,"","Close it as a true positive, benign or a false positive")+'</span>':"";
  acts+=KB+'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="Its incident record, as it was at its peak, in a new tab">Open ›</a>';
  var back=r.back?' <span class="tg back" title="The same host is in the queue again now">back now · '+esc(VL[r.back_verdict]||"in the queue")+'</span>':"";
  return '<tr class="qr unrev'+(S.open===qk?" sel":"")+'" style="--vc:'+VC[r.verdict]+'" data-k="'+esc(qk)+'"'+(ip?' data-hk="h:'+esc(ip)+'"':"")+' data-v="'+esc(r.verdict)+'" title="Quick look">'
    +'<td class="c-v">'+vp(r.verdict)+'<div class="mut hw">at its peak</div></td>'
    +'<td class="c-i"><span class="qt-t">'+esc(r.headline||r.label||"")+'</span>'+back+'<div class="qt-s" title="'+esc(fullTime(r.closed_at*1000))+'">ended '+tm(r.closed_at*1000,"dhm")+'</div></td>'
    +'<td class="c-k"></td>'
    +'<td class="c-s">'+(ip?'<span class="mono">'+esc(ip)+'</span>'+(r.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(r.name?'<div class="mut">'+esc(r.name)+'</div>':""):'<span class="mut">'+esc(r.kind==="group"?scopeN(r):r.kind==="campaign"?"campaign · "+scopeN(r):"")+'</span>'+scopeSub(r))+'</td>'
    +'<td class="c-c">'+(r.conf!=null?cw(r):"")+'</td><td class="c-l">'+(r.last_ms?'<span title="Last alert: '+esc(fullTime(r.last_ms))+'">'+at(r.last_ms)+'</span>':'<span class="mut">-</span>')+'<div class="mut">quiet</div></td>'
    +'<td class="c-sla"></td><td class="c-st"><span class="st-unrev" title="Nobody marked it seen, took it or closed it">Not reviewed</span></td><td class="c-a"><span class="btns">'+acts+'</span></td></tr>'}
// the section folds: open by default, shut when the queue has Review items (the analyst's own choice is remembered in this browser)
var UNREV=null;try{var uv=localStorage.getItem("sc-unrev");UNREV=uv==="1"?true:uv==="0"?false:null}catch(x){UNREV=null}
function unrevIsOpen(){var c=((S.data||{}).counts||{}).review;return UNREV!==null?UNREV:!(c&&c.items>0)}
function unrevSec(n,open){return '<tr class="qsec"><td colspan="9"><button type="button" class="exp" data-unrev="1" aria-expanded="'+(open?"true":"false")+'" title="'+(open?"Fold":"Show")+' the incidents that ended unreviewed">'+(open?"▾ ":"▸ ")+'</button><span class="qsec-l" style="--vc:#ffcf8a">Ended, not reviewed</span> <b>'+num(n)+'</b> <span class="mut">'+(n===1?"incident":"incidents")+' reached Act now or Investigate and went quiet: their strong alerts left the 24 h window before anyone looked. They stay here until someone marks them seen or closes them</span></td></tr>'}
function reviewRecord(id,a,v,where){var D=S.det["i:"+id],pick=function(L){return (L||[]).filter(function(x){return String(x.id)===String(id)})[0]},
    r=(S.data&&(pick(S.data.unreviewed)||pick(S.data.held_records)))||D||{},label=r.headline||r.label||("Incident #"+id);
  ensureWho().then(function(w){if(!w)return;var scope='<div class="scope-box">'+esc(label)+'</div><p class="mut">It ended '+(r.closed_at?tm(r.closed_at*1000,"dhm"):"")+(isTaken(r)?'; '+esc(r.outcome_by||"someone")+' took it after that.':' with nobody having looked at it.')+'</p>';
    var ask=a==="close"?dlg({title:"Close an ended incident",body:scope,ok:"Close",fields:[{name:"cls",label:"How do you close it?",type:"select",options:CLOSEW,value:"fp"},{name:"reason",label:"Reason",type:"select",deps:{field:"cls",map:C.reasons}},{name:"note",label:"What did you check?",type:"textarea",required:true}]})
      :a==="escalated"?loadNames().then(function(){return dlg({title:"Escalate an ended incident",body:scope+'<p class="mut">It waits under Taken, now quiet as Escalated, with the person or team named.</p>',ok:"Escalate",fields:[{name:"owner",label:"To (person or team)",value:"L2",max:40,list:KNOWN},{name:"note",label:"What should they look at?",type:"textarea",required:true}]})})
      :a==="ack"?dlg({title:"Mark seen",body:scope+'<p class="mut">Seen: nothing to do now. It leaves this list; the record keeps who saw it and why.</p>',ok:"Mark seen",fields:[{name:"note",label:"Why is there nothing to do now?",type:"textarea",required:true}]})
      :Promise.resolve({});
    ask.then(function(x){if(!x)return;var status=a==="close"?x.cls:a;
      post({op:"record",rec:+id,status:status,who:w,note:x.note||"",reason:x.reason||"",owner:a==="escalated"?x.owner||"":""}).then(function(j){
        toastUndo(a==="open"?"Released: back to Ended, not reviewed":a==="escalated"?"Escalated to "+(x.owner||"L2"):DONEW[status],null,{undo:function(){return post({op:"record",rec:+id,status:j.previous,owner:j.previous_owner||"",who:ME.name||w})}});
        delete S.det["i:"+id];if(where==="drwb"&&!INC&&S.open==="i:"+id&&a!=="investigating"&&a!=="escalated"&&a!=="open")closeDetail();setTimeout(refreshAll,250)}).catch(function(e){toast(e.message,true)})})})}
// ---- one search over everything: the queue, every host with alerts, targets, outside addresses, the history ----
var GS={t:null,seq:0,first:null};
function gsRender(d){var r=$("#gsr");if(!r)return;GS.first=null;
  if(!d.groups.length){r.innerHTML='<div class="gse">Nothing for “'+esc(d.q)+'” on the board (24 h) or in the history.</div>';r.hidden=false;return}
  r.innerHTML=d.groups.map(function(g){return '<div class="gsg"><div class="gsh">'+esc(g.name)+(g.more?' <span>+'+num(g.more)+' more</span>':"")+'</div>'+g.rows.map(function(x){if(!GS.first)GS.first=x.key;
    return '<a href="'+esc(keyUrl(x.key))+'" class="gsi" data-open="'+esc(x.key)+'">'+(x.verdict?vp(x.verdict):'<span class="gsv"></span>')+'<span class="gsl"><span>'+esc(x.label)+'</span><span class="mut">'+esc(x.sub||"")+'</span></span></a>'}).join("")+'</div>'}).join("");r.hidden=false}
function gsHide(){var r=$("#gsr");if(r)r.hidden=true}
// ---- shift handover: what happened since the shift began, to paste for the next one ----
var VRK={act:3,investigate:2,review:1,watch:0};
function handoverText(H){var L=[],me=ME.name||"",bv=H.by_verdict||{};
  var st=H.start||{};L.push("Shift handover · "+tm(H.since*1000,"dt")+" – "+tm(H.now*1000,"dt")+" ("+zoneLbl()+")"+(me?" · from "+me:""));
  if(st.how==="away")L.push("Since the team was last here: the last action "+(st.who?"by "+st.who+" ":"")+tm(st.at*1000,"dt"));
  var bvs=["act","investigate","review"].filter(function(v){return bv[v]}).map(function(v){return bv[v]+" "+VL[v]});
  L.push("");L.push("NEW INCIDENTS: "+H.opened.length+(bvs.length?" ("+bvs.join(", ")+")":""));
  H.opened.filter(function(r){return r.verdict!=="review"}).slice(0,12).forEach(function(r){L.push("- ["+VL[r.verdict]+"] "+r.headline+" · opened "+tm(r.opened_at*1000,"dt"))});
  if(H.acted.length){L.push("");L.push("WHAT THE TEAM DID: "+H.acted.length);H.acted.slice(0,20).forEach(function(r){
    L.push("- "+tm(r.outcome_at*1000,"dt")+" "+(r.outcome_by||"?")+": "+(OUTW[r.outcome]||r.outcome)+(r.outcome_reason?" ("+r.outcome_reason+")":"")+" · "+(r.kind==="entity"?"host "+r.subject_value:r.label))})}
  var still=H.still.slice().sort(function(a,b){return (VRK[b.verdict_last||b.verdict]||0)-(VRK[a.verdict_last||a.verdict]||0)});
  L.push("");L.push("STILL OPEN: "+still.length);still.slice(0,25).forEach(function(r){var held=r.now_owner&&(r.now_status==="investigating"||r.now_status==="escalated");
    L.push("- ["+VL[r.verdict_last||r.verdict]+"] "+(r.kind==="entity"?"Host "+r.subject_value+": ":"")+r.headline+" · "+(held?STW[r.now_status]+", "+r.now_owner:r.now_status==="partial"?"partly handled":"nobody has it"))});
  if(still.length>25)L.push("... and "+(still.length-25)+" more in the queue");
  var unr=H.ended.filter(function(r){return r.outcome==="expired"});
  if(unr.length){L.push("");L.push("ENDED, NOT REVIEWED (still in the queue): "+unr.length);unr.slice(0,10).forEach(function(r){L.push("- ["+VL[r.verdict]+"] "+r.headline+" · ended "+tm(r.closed_at*1000,"dt"))})}
  if(H.notes.length){L.push("");L.push("NOTES");H.notes.slice(0,20).forEach(function(a){L.push("- "+tm(a.at*1000,"dt")+" "+a.who+" on "+a.target+": "+a.note)})}
  L.push("");L.push("History: "+new URL("./?tab=history",location.href).href);
  return L.join("\n")}
// lookups of an outside address in the services the operator chose (SC_TI_PIVOTS, none by default: each link sends it)
function pivotLinks(ip){if(!(C.pivots||[]).length||!IPRE.test(ip||""))return "";return '<button type="button" class="b2 pvb" data-pivot="'+esc(ip)+'" title="Look this address up in outside services (it leaves your network)">Check externally ▾</button>'}
// ---- flows from Sycope on the page: a pair's newest records, a host's counterparts summed ----
function tcpf(n){if(!n)return "-";var s="";if(n&2)s+="S";if(n&16)s+="A";if(n&8)s+="P";if(n&1)s+="F";if(n&4)s+="R";if(n&32)s+="U";return s}
function proto(n){return n===6?"TCP":n===17?"UDP":n===1?"ICMP":n==null?"":String(n)}
function flowTable(rows){if(!rows.length)return '<p class="mut">No flows of this pair in the window (Sycope may keep flows for less time than alerts).</p>';
  return '<div class="qwrap"><table class="qt lt flt"><thead><tr><th>Start</th><th>Client</th><th>Server</th><th>Proto</th><th>Bytes ↑ / ↓</th><th>Packets ↑ / ↓</th><th>Lasted</th><th title="TCP flags seen, client / server: S SYN, A ACK, P PSH, F FIN, R RST. S alone: nobody answered">Flags</th></tr></thead><tbody>'
    +rows.map(function(r){return '<tr class="nk"><td title="'+esc(fullTime(r.t))+'">'+tm(r.t,"dhm")+'</td><td class="mono">'+esc(r.c||"")+':'+esc(r.cp==null?"":r.cp)+'</td><td class="mono">'+esc(r.s||"")+':'+esc(r.sp==null?"":r.sp)+'</td><td>'+proto(r.proto)+'</td><td>'+bytes(r.up)+' / '+bytes(r.down)+'</td><td>'+num(r.pkc||0)+' / '+num(r.pks||0)+'</td><td>'+(r.end&&r.t&&r.end>=r.t?dur((r.end-r.t)/1000):"")+'</td><td class="mono">'+esc(tcpf(r.fc))+' / '+esc(tcpf(r.fs))+'</td></tr>'}).join("")+'</tbody></table></div>'}
function showFlows(x){var key=x.dataset.fl,tr=x.closest("tr"),host=tr||x.closest(".nxt")||x.parentNode,nxt=host.nextElementSibling;
  if(nxt&&nxt.classList.contains("flx")&&nxt.dataset.fl===key){nxt.remove();return}
  var p=key.split("|"),el;if(tr){el=document.createElement("tr");el.innerHTML='<td colspan="'+tr.children.length+'"><div class="flw"><div class="loading">Asking Sycope…</div></div></td>'}else{el=document.createElement("div");el.innerHTML='<div class="flw"><div class="loading">Asking Sycope…</div></div>'}
  el.className="flx nk";el.dataset.fl=key;host.parentNode.insertBefore(el,host.nextSibling);var box=el.querySelector(".flw");
  getJ("flows?"+new URLSearchParams({c:p[0],s:p[1],port:p[2]||0,from:Math.round(+p[3]),to:Math.round(+p[4]),mode:"raw",limit:30}).toString())
    .then(function(d){box.innerHTML=flowTable(d.rows||[])}).catch(function(e){box.innerHTML='<p class="mut">'+esc(e.message)+'</p>'})}
function talkHtml(D){if(!C.rawdata)return "";var a=D.actor||D.target;if(!a||!a.first||!a.last)return "";var t=a.last+60000,f=Math.max(a.first-300000,t-26*3600000+60000);
  return '<div class="sec flwd" data-sec="talk" data-fold="1" data-flh="'+esc(D.ip+"|"+f+"|"+t)+'"><h3>Where it talked: its flows in Sycope, summed by counterpart</h3><div class="flb"><div class="loading">Asking Sycope…</div></div></div>'}
function peerTable(d,title,ip,asClient){if(d.error)return '<h4 class="flh">'+esc(title)+'</h4><p class="mut">'+esc(d.error)+'</p>';var rows=d.rows||[];
  return '<h4 class="flh">'+esc(title)+'</h4>'+(rows.length?'<div class="qwrap"><table class="qt lt flt"><thead><tr><th>Counterpart</th><th>Port</th><th>Flows</th><th>Bytes ↑ / ↓</th><th>First – last</th><th></th></tr></thead><tbody>'
    +rows.map(function(r){var c=asClient?ip:r.peer,sv=asClient?r.peer:ip;return '<tr class="nk"><td class="mono">'+(IPRE.test(r.peer||"")?ilink("h:"+r.peer,r.peer):esc(r.peer||"?"))+'</td><td>'+esc(r.port==null?"":r.port)+'</td><td>'+num(r.n||0)+'</td><td>'+bytes(r.up)+' / '+bytes(r.down)+'</td><td>'+rng(r.first,r.last)+'</td>'
      +'<td><button type="button" class="lnk" data-fl="'+esc([c||"",sv||"",r.port||"",(r.first||0)-60000,(r.last||0)+60000].join("|"))+'">flows</button></td></tr>'}).join("")+'</tbody></table></div>':'<p class="mut">No flows in this window.</p>')}
// a page that refreshes every minute shows the same answer again for two minutes, without asking Sycope each time
S.talk={};
function loadTalk(d){if(d.dataset.done)return;d.dataset.done="1";var key=d.dataset.flh,p=key.split("|"),ip=p[0],box=d.querySelector(".flb"),c=S.talk[key];if(c&&Date.now()-c.at<120000){box.innerHTML=c.html;return}
  var q=function(o){return getJ("flows?"+new URLSearchParams(o).toString()).catch(function(e){return {error:e.message}})};
  Promise.all([q({c:ip,from:p[1],to:p[2],mode:"client",limit:20}),q({s:ip,from:p[1],to:p[2],mode:"server",limit:20})]).then(function(x){var html=peerTable(x[0],"As client: what it reached, by bytes sent",ip,true)+peerTable(x[1],"As server: who reached it, by bytes it sent back",ip,false);
    if(!x[0].error&&!x[1].error)S.talk[key]={at:Date.now(),html:html};box.innerHTML=html})}
// ---- help, as in Sycope: the ? opens the part for the view on screen, with its annotated screenshots ----
var HELP={doc:null,cur:"",manual:false};
function helpPinned(){try{return localStorage.getItem("sc-help-pin")==="1"}catch(x){return false}}
function helpCtx(){var k=S.open||(INC?incKey():"");if(k){var t=k.slice(0,1),D=S.det[k];
    if(t==="h")return D&&D.target_inc&&!D.actor?"target":"host";return t==="s"?"group":t==="c"?"campaign":t==="i"?"record":"host"}
  return {queue:"queue",targets:"targets",external:"external",tuning:"tuning",hygiene:"hygiene",history:"history",audit:"audit",config:"configuration"}[S.tab]||"queue"}
function helpOpen(id,manual){var p=$("#helpp");if(!p)return;p.hidden=false;document.body.classList.add("help-on");HELP.manual=!!manual;var o=$("#hlpo");if(o)o.classList.add("on");
  (HELP.doc?Promise.resolve(HELP.doc):getJ("helpdoc").then(function(d){HELP.doc=d;return d})).then(function(d){var sid=d.parts[id]?id:"queue",P=d.parts[sid];HELP.cur=sid;
    $("#hlpb").innerHTML='<h2 class="hlpt">'+esc(P.title)+'</h2>'+P.html+'<div class="hall"><h3>All topics</h3>'+d.order.map(function(k){return '<a href="help#'+esc(k)+'" data-help="'+esc(k)+'"'+(k===sid?' class="on"':"")+'>'+esc(d.parts[k].title)+'</a>'}).join("")+'</div>';$("#hlpb").scrollTop=0})
    .catch(function(e){$("#hlpb").innerHTML='<p class="mut">'+esc(e.message)+'</p>'})}
function helpClose(){var p=$("#helpp");if(p)p.hidden=true;document.body.classList.remove("help-on");HELP.manual=false;var o=$("#hlpo");if(o)o.classList.remove("on")}
function helpFollow(){var p=$("#helpp");if(!p||p.hidden||HELP.manual)return;var id=helpCtx();if(id!==HELP.cur)helpOpen(id)}
function helpPinShow(){var b=$("#hlppin");if(b){b.classList.toggle("on",helpPinned());b.title=helpPinned()?"Pinned: help opens on every page (click to unpin)":"Keep help open on every page"}}
function zoom(src){var l=$("#lbx");if(!l)return;l.innerHTML='<img src="'+esc(src)+'" alt="">';l.hidden=false}
// an explanation on demand: hover or focus the (i); r = the bubble opens to the left (near the right edge)
var APLEG='<span class="apl"><i style="background:#ff7a00"></i>confirmed: the family\'s step in What happened reached the confirmation threshold of the model (2 bits unless an admin changed it; the host header says confirmed at high confidence)</span><span class="apl"><i style="border:2px dashed #ff7a00;height:6px"></i>suspected: weaker evidence</span>'
  +'<span class="apl">→ the order of the attacker\'s steps</span><span class="apl" style="color:#ffb020">→ a step against a host the previous one touched</span><span class="apl">Ticks are separate findings; hover one for its ATT&CK technique and details.</span>';
// ---- sections as cards, as Sycope's widgets: the header folds them, remembered in this browser ----
var FOLD={};try{FOLD=JSON.parse(localStorage.getItem("sc-fold")||"{}")||{}}catch(x){FOLD={}}
function secId(sx,h){if(sx.dataset.sec)return sx.dataset.sec;var c=h.cloneNode(true);$$(".ii,.nxc,button,.mut",c).forEach(function(n){n.remove()});
  return c.textContent.toLowerCase().replace(/[^a-z ]+/g," ").trim().split(/\s+/).slice(0,4).join("-")||"section"}
function secSet(sx,shut,save){sx.classList.toggle("shut",shut);var b=sx.querySelector(":scope>h3>.secx");if(b){b.setAttribute("aria-expanded",shut?"false":"true");b.title=shut?"Show":"Fold"}
  if(save){FOLD[sx.dataset.fid]=shut?1:0;try{localStorage.setItem("sc-fold",JSON.stringify(FOLD))}catch(y){}}
  if(!shut&&sx.dataset.flh)loadTalk(sx)}
function secPrep(sx){if(sx.dataset.sx)return;sx.dataset.sx="1";var h=sx.querySelector(":scope>h3");if(!h)return;sx.dataset.fid=secId(sx,h);
  var b=document.createElement("div");b.className="secb";while(h.nextSibling)b.appendChild(h.nextSibling);sx.appendChild(b);
  h.insertAdjacentHTML("afterbegin",'<button type="button" class="secx" aria-expanded="true" title="Fold">▾</button>');
  secSet(sx,sx.dataset.fid in FOLD?FOLD[sx.dataset.fid]===1:sx.dataset.fold==="1",false)}
var V4=/^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d{1,5}))?$/;
function v4n(ip){var p=ip.split(".");return ((+p[0])*16777216)+((+p[1])<<16)+((+p[2])<<8)+(+p[3])}
var NETS=(C.internal||[]).concat(["10.0.0.0/8","172.16.0.0/12","192.168.0.0/16","100.64.0.0/10","169.254.0.0/16","127.0.0.0/8"]).map(function(c){var p=String(c).split("/"),b=p.length>1?+p[1]:32;
  if(!V4.test(p[0])||!(b>=0&&b<=32))return null;var sz=Math.pow(2,32-b);return [Math.floor(v4n(p[0])/sz)*sz,sz]}).filter(Boolean);
function internalIp(ip){if(ip.indexOf(":")>=0)return /^(fc|fd|fe80)/i.test(ip);if(!V4.test(ip))return true;var n=v4n(ip);return NETS.some(function(x){return n>=x[0]&&n<x[0]+x[1]})}
function itemOf(k){var d=S.data||{},hit=null;(d.items||[]).forEach(function(it){if(itKey(it)===k)hit=it;(it.children||[]).forEach(function(c){if(itKey(c)===k)hit=c})});return hit}
// the time the Sycope links ask for: the incident's, else the last 24 hours
function winOf(el){var r=el.closest&&el.closest("tr[data-k]"),it=r?itemOf(r.dataset.k):null;if(it&&it.first&&it.last)return [it.first-300000,it.last+60000];
  var root=el.closest&&el.closest("#drwb,#view"),D=root&&root.dataset.k&&S.det[root.dataset.k],a=D&&(D.actor||D.target_inc||D.target||D.external);
  if(a&&a.first&&a.last)return [a.first-300000,a.last+60000];var now=S.data&&S.data.now?S.data.now*1000:Date.now();return [now-86400000,now]}
function ipAt(t){var el=t.closest("[data-ip]");if(el)return {ip:el.dataset.ip,port:el.dataset.port||""};
  var a=t.closest('a[data-peek^="h:"],a[data-open^="h:"]');if(a)return {ip:(a.dataset.peek||a.dataset.open).slice(2),port:""};
  var n=t.closest("b,span,td,a,div");if(n&&n.childElementCount<=1){var m=V4.exec((n.textContent||"").trim());if(m)return {ip:m[1],port:m[2]||""}}return null}
function sycopeItems(ip,port,w){if(!C.rawdata)return [];var q='clientIp = "'+ip+'" or serverIp = "'+ip+'"',L=[{sep:1},{head:"In Sycope"},{label:"Flows of "+ip,href:rawUrl(q,w[0],w[1]),tip:"Raw data, the time of this incident"}];
  if(port)L.push({label:"Flows to "+ip+":"+port,href:rawUrl(nqlOf(null,ip,port),w[0],w[1])});L.push({label:"Alerts of "+ip,href:alertsUrl(q,w[0],w[1])});return L}
function pivotItems(ip){if(internalIp(ip)||!(C.pivots||[]).length)return [];var L=[{sep:1},{head:"Look it up (the address leaves your network)"}];
  C.pivots.forEach(function(p){L.push({label:"Check in "+p[0],href:p[1].split("{ip}").join(encodeURIComponent(ip))})});return L}
function ipItems(ip,port,w,el){var lab=port?ip+":"+port:ip,deep=!!(el&&el.closest&&el.closest("#drawer"));
  return [{head:'<span class="mono">'+esc(lab)+'</span>'+(internalIp(ip)?"":" · outside your networks")},{label:"Quick look",run:function(){openDetail("h:"+ip,false,deep)}},{label:"Open in a new tab",href:keyUrl("h:"+ip)},
    {label:"Find it everywhere",tip:"The search in the top bar",run:function(){var q=$("#gsq");if(!q)return;q.value=ip;q.dispatchEvent(new Event("input",{bubbles:true}));q.focus()}}]
    .concat(sycopeItems(ip,port,w),pivotItems(ip),[{sep:1},{label:"Copy "+lab,run:function(){copy(lab)}}])}
function rowItems(k,row){var t=k.slice(0,1),v=k.slice(2),it=itemOf(k),where=rootOf(row),held=row.classList.contains("held"),L=[];
  var hk=held&&row.dataset.hk?row.dataset.hk:k,ip=hk.slice(0,2)==="h:"?hk.slice(2):"";
  L.push({head:esc(t==="h"?"Host "+v:t==="s"?(it?it.title:"Group incident"):t==="c"?"Campaign "+v:"History record #"+v)+(held&&ip&&t!=="h"?' · <span class="mono">'+esc(ip)+'</span>':"")});
  L.push({label:"Quick look",run:function(){openDetail(k,false,where==="drwb")}},{label:"Open in a new tab",href:keyUrl(k)});
  if(ip&&C.edit&&(t==="h"||held)){var vv=(it&&it.verdict)||row.dataset.v||"",tr=it&&it.triage,go=function(a){return function(){actOn(hk,a,vv,where)}};L.push({sep:1});
    if(held)L.push({label:"Close…",run:go("close")},{label:"Release: back to New",run:go("open")});
    else{if(!(ownerOf(tr)===ME.name&&ME.name))L.push({label:"Take it",run:go("investigating")});
      L.push({label:"Assign…",run:go("assign")},{label:"Escalate…",run:go("escalated")},{label:"Seen",run:go("ack")},{label:"Close…",run:go("close")});if(tr&&tr.handled)L.push({label:"Reopen",run:go("open")})}
    L.push({label:"Add a note…",run:go("note")})}
  else if((t==="s"||t==="c")&&C.edit)L.push({sep:1},{label:"Add a note…",run:function(){noteDialog(k,it?itLabel(it):k)}});
  if(t==="i"&&C.edit){var rv=function(a){return function(){reviewRecord(v,a,row.dataset.v,where)}};
    if(row.classList.contains("unrev"))L.splice(2,0,{sep:1},{label:"Take it",run:rv("investigating")},{label:"Escalate…",run:rv("escalated")},{label:"Seen",run:rv("ack")},{label:"Close…",run:rv("close")});
    else if(row.classList.contains("heldrec"))L.splice(2,0,{sep:1},{label:"Close…",run:rv("close")},{label:"Release: back to Ended, not reviewed",run:rv("open")})}
  if(ip)L=L.concat(sycopeItems(ip,"",winOf(row)),pivotItems(ip));
  L.push({sep:1},{label:"Copy the link",run:function(){copy(new URL(keyUrl(k),location.href).href)}});if(ip)L.push({label:"Copy "+ip,run:function(){copy(ip)}});
  return L}
function lineItems(row){var d=row.dataset,t0=+d.t0,t1=+d.t1,L=[{head:esc(d.rule)}];
  if(C.rawdata){var w=[];if(NAMERE.test(d.rule))w.push('alertName = "'+d.rule+'"');if(d.c&&IPRE.test(d.c))w.push('clientIp = "'+d.c+'"');if(d.s&&IPRE.test(d.s))w.push('serverIp = "'+d.s+'"');
    if(w.length)L.push({label:"These alerts in Sycope",href:alertsUrl(w.join(" and "),t0-60000,t1+120000)});var fq=nqlOf(d.c,d.s,d.port);if(fq)L.push({label:"Flows of this pair in Sycope",href:rawUrl(fq,t0-300000,t1+60000)})}
  if(C.edit&&!SMw(rootOf(row)))L.push({sep:1},{label:"Silence alerts like this…",run:function(){silenceLine(d)}});
  L.push({sep:1},{label:"Copy the alert name",run:function(){copy(d.rule)}});return L}
function cmItemsFor(t){if(!t.closest||t.closest(".cm,.dlg-w,#helpp,.gs,input,textarea,select,#lbx,.hlpp"))return null;
  var ip=ipAt(t),row=t.closest("tr[data-k]"),lane=t.closest("tr[data-open]"),line=t.closest("tr[data-ag],tr[data-sl]");
  if(row&&ip&&!ip.port&&(row.dataset.k==="h:"+ip.ip||row.dataset.hk==="h:"+ip.ip))return rowItems(row.dataset.k,row);
  if(ip){var L=ipItems(ip.ip,ip.port,winOf(t),t);if(line)L=L.concat([{sep:1}],lineItems(line));
    else if(row){var rk=row.dataset.k;L.push({sep:1},{head:"The row"},{label:"Quick look of the row",run:function(){openDetail(rk,false,rootOf(row)==="drwb")}})}return L}
  if(line)return lineItems(line);if(row)return rowItems(row.dataset.k,row);
  if(lane&&lane.dataset.open.slice(0,2)==="h:")return ipItems(lane.dataset.open.slice(2),"",winOf(lane),lane);
  return null}
// ---- group incidents: a story (hosts with the same pattern) and a campaign (many hosts of one network) ----
function updateBulk(ctx){var root=$("#"+ctx),b=R[ctx];if(!root||!b||!b.bulk)return;var e=root.querySelector(".bulk");if(e)e.innerHTML=bulkBtns(ctx);
  var a=root.querySelector(".selall");if(a){var n=b.sel.size;a.checked=n>0&&n===b.bulk.ips.length;a.indeterminate=n>0&&n<b.bulk.ips.length}}
function hfState(){return R[CTX].hf||(R[CTX].hf={q:"",net:"",st:""})}
function net24(ip){var p=String(ip).split(".");return p.length===4?p.slice(0,3).join(".")+".0/24":ip}
function hostFilter(list){if(SM())return list;var f=hfState(),words=f.q?f.q.toLowerCase().split(/\s+/).filter(Boolean):[];return list.filter(function(m){
  if(f.net&&net24(m.ip)!==f.net)return false;var t=m.triage;
  if(f.st==="open"&&t&&t.handled)return false;if(f.st==="handled"&&!(t&&t.handled))return false;if(f.st==="taken"&&!ownerOf(t))return false;
  if(f.st==="mine"&&!(ME.name&&ownerOf(t)===ME.name))return false;if(f.st==="hot"&&m.verdict!=="act"&&m.verdict!=="investigate")return false;
  if(words.length){var h=[m.ip,m.name,m.path,m.headline,m.net].join(" ").toLowerCase();if(!words.every(function(w){return h.indexOf(w)>=0}))return false}return true})}
function hostFilterBar(list,nets){var f=hfState(),n=hostFilter(list).length;
  return '<div class="hfb"><input type="search" data-hfq="1" placeholder="Filter: IP, name, what happened…" value="'+esc(f.q)+'" autocomplete="off">'
    +'<select data-hfn="1"><option value="">every /24</option>'+(nets||[]).map(function(x){return '<option value="'+esc(x[0])+'"'+(f.net===x[0]?" selected":"")+'>'+esc(x[0])+' ('+num(x[1])+')</option>'}).join("")+'</select>'
    +'<select data-hfs="1">'+[["","every status"],["open","open"],["taken","in progress or escalated"],["mine","mine"],["handled","handled"],["hot","Act now or Investigate"]].map(function(o){return '<option value="'+o[0]+'"'+(f.st===o[0]?" selected":"")+'>'+o[1]+'</option>'}).join("")+'</select>'
    +(n<list.length?'<span class="mut">'+num(n)+' of '+num(list.length)+' shown; the actions above apply to these · <button type="button" class="lnk" data-hfclear="1">clear</button></span>':"")+'</div>'}
function hostsTable(list,limit){var shown=limit?list.slice(0,limit):list;
  if(SM()){limit=R[CTX].hall?0:20;shown=limit?list.slice(0,limit):list}     // Simple: 20 rows, then "show all"
  if(SM())return '<div class="qwrap"><table class="qt ht"><thead><tr><th>Host</th><th>Verdict</th><th>What happened</th><th></th></tr></thead><tbody>'
    +shown.map(function(m){return '<tr class="qr'+(m.triage&&m.triage.handled?" handled":"")+(S.open==="h:"+m.ip?" sel":"")+'" style="--vc:'+VC[m.verdict]+'" data-k="'+esc("h:"+m.ip)+'" title="Quick look">'
      +'<td>'+ilink("h:"+m.ip,m.ip)+(m.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(m.name?'<div class="mut">'+esc(m.name)+'</div>':"")+'</td><td>'+vp(m.verdict)+'</td><td class="c-p">'+esc(m.path||m.headline||"")+'</td>'
      +'<td class="c-a"><a class="b2 pri" href="'+esc(keyUrl("h:"+m.ip))+'" target="_blank" rel="noopener" title="The host on its own page, in a new tab">Open ›</a></td></tr>'}).join("")+'</tbody></table></div>'
    +(list.length>shown.length?'<button type="button" class="b2 more2" data-hall="1">show all '+num(list.length)+'</button>':"");
  return '<div class="qwrap"><table class="qt ht"><thead><tr>'+(C.edit?'<th class="c-x"><input type="checkbox" class="selall" title="Select all '+esc(list.length)+' hosts"></th>':"")+'<th>Host</th><th>Verdict</th><th>Kill chain</th><th>Confidence</th><th>What happened</th><th>Last activity</th><th>Status</th><th></th></tr></thead><tbody>'
    +shown.map(function(m){var u=keyUrl("h:"+m.ip);return '<tr class="qr'+(m.triage&&m.triage.handled?" handled":"")+(S.open==="h:"+m.ip?" sel":"")+'" style="--vc:'+VC[m.verdict]+'" data-k="'+esc("h:"+m.ip)+'" title="Quick look">'+(C.edit?'<td class="c-x"><input type="checkbox" data-sel="'+esc(m.ip)+'"'+(R[CTX].sel.has(m.ip)?" checked":"")+' aria-label="Select '+esc(m.ip)+'"></td>':"")
      +'<td>'+ilink("h:"+m.ip,m.ip)+(m.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(m.name?'<div class="mut">'+esc(m.name)+'</div>':"")+'</td><td>'+vp(m.verdict)+'</td><td class="c-k">'+kc4(m.stages,m.stage)+'</td><td>'+cw(m)+'</td>'
      +'<td class="c-p">'+esc(m.path||m.headline||"")+' '+tagsHtml(m)+'</td><td class="c-l">'+lastHtml(m)+'</td><td class="c-st">'+statusHtml(m)+'</td><td class="c-a">'+KB+'<a class="b2 pri" href="'+esc(u)+'" target="_blank" rel="noopener" title="The host on its own page, in a new tab">Open ›</a></td></tr>'}).join("")+'</tbody></table></div>'
    +(list.length>shown.length?'<button type="button" class="b2 more2" data-hall="1">Show all '+num(list.length)+' hosts</button>':"")}
function groupHist(T){if(!T||!T.length)return "";
  return '<div class="sec" data-sec="ghist"><h3>History of this incident'+ii("The actions taken on it as a whole. The system's own decisions about each host are in that host's history.")+'</h3><ol class="hist">'+T.map(function(x){return '<li style="--hc:#8cc4ff"><span class="tm">'+tm(x.at*1000,"dhm")+'</span><b>'+esc(x.who)+'</b>'+vok(x.verified)+' '+esc(x.text)+(x.hosts?' <span class="mut">('+hp(x.hosts,"host")+')</span>':"")+(x.note?': “'+esc(x.note)+'”':"")+'</li>'}).join("")+'</ol></div>'}
function groupFacts(D){return '<div class="facts">'+kc(D.stages)+'<span>confidence up to <b style="color:#fff" title="'+esc(pc(D.conf))+'">'+esc(D.conf_word||pc(D.conf))+'</b></span>'
  +(D.new?'<span class="tg new">'+(D.new===D.count?"all new":num(D.new)+" new")+'</span>':"")+(D.active?'<span class="tg lv">'+num(D.active)+' active</span>':"")+(D.pcap_hosts?'<span class="tg pc">PCAP on '+hp(D.pcap_hosts,"host")+'</span>':"")
  +'<span>'+rng(D.first,D.last)+'</span><span>'+(D.open?num(D.open)+' open':'all handled')+(D.handled?' · '+num(D.handled)+' handled':"")+(D.changed?' · <b style="color:#ffb3c0">'+num(D.changed)+' changed since handled</b>':"")+'</span></div>'}
function connectHtml(D){return '<div class="sec"><h3>What connects these hosts</h3>'+(D.path&&D.path.length?'<ol class="steps">'+D.path.map(function(p){return '<li style="--sc:#ff7a00">'+esc(p.label)+' <span class="fam">'+num(p.hosts)+' of '+hp(D.count,"host")+'</span></li>'}).join("")+'</ol>':'<p class="mut">The same confirmed families, in no common order.</p>')
    +(D.spread&&D.spread.length?'<p><b>Spreads</b>: '+D.spread.map(function(n){return esc(n[0])+" ("+n[1]+" hosts scanning)"}).join(", ")+'</p>':"")+'</div>'}
function groupHtml(D){if(SM())return groupSimple(D);var h="",ips=D.members.map(function(m){return m.ip}),lead=D.members[0];
  h+='<div class="hsum" style="--vc:'+VC[D.verdict]+'"><div class="dh">'+vp(D.verdict)+priTag(D.priority)+'<span class="ip" style="font-family:inherit">'+esc(D.title)+'</span><span class="tg">Incident · '+hp(D.count,"host")+'</span>'
    +'<span class="sp"></span><button type="button" class="b2" data-ticket="1" title="A plain-text summary for a ticket, chat or e-mail">Copy as ticket</button></div>';
  h+='<div class="dsum">'+hp(D.count,"host")+' show the same pattern: '+esc(D.families.map(fam).join(", "))+(D.chain_words&&D.chain_words.length?'. '+D.chain_words.map(function(c){return '<b>'+esc(c.title)+'</b>'}).join(", ")+ii(D.chain_words.map(function(c){return '<b>'+esc(c.title)+'</b>: '+esc(c.what)}).join("<br>")):"")+'.</div>';
  if(lead)h+='<div class="rsn2"><b>'+esc(VL[D.verdict])+'</b>: for example '+esc(lead.ip)+': '+esc(lead.reason)+'</div>';
  h+=groupFacts(D)+(D.campaign?'<div class="partof">Part of '+ilink("c:"+D.campaign.net,"campaign "+D.campaign.net,"")+'.</div>':"");
  var shownM=hostFilter(D.members),fl=shownM.length<D.members.length;if(fl)ips=shownM.map(function(m){return m.ip});
  var vmap={};D.members.forEach(function(m){vmap[m.ip]=m.verdict});h+='<div class="hact">'+bulkBar("s:"+D.key,D.title+" ("+(fl?num(shownM.length)+" of "+num(D.count)+" hosts, filtered":D.count+" hosts")+")",ips,vmap,D.members.length)+'</div></div>'+nextHtml(D);
  h+=connectHtml(D);
  var link=function(ip){return ilink("h:"+ip,ip)};
  h+='<div class="sec"><h3>Scope</h3><div class="cols"><div><div class="mut">Networks</div><p>'+(D.all_nets||[]).map(function(n){return '<span class="pill2">'+esc(n[0])+' ×'+n[1]+'</span>'}).join("")+'</p>'
    +(D.crown_hosts&&D.crown_hosts.length?'<div class="mut">Crown jewels</div><p>'+D.crown_hosts.map(link).join(", ")+'</p>':"")+'</div><div>'
    +(D.common_targets&&D.common_targets.length?'<div class="mut">Most hit counterparts</div><p>'+D.common_targets.map(function(t){return link(t[0])+' <span class="mut">×'+num(t[1])+'</span>'}).join(", ")+'</p>':"")
    +(D.outside&&D.outside.length?'<div class="mut">Outside your networks</div><p>'+D.outside.map(function(o){return link(o.ip)+' <span class="mut">'+hp(o.hosts,"host")+(o.asn?" · "+esc(o.asn):"")+'</span>'+(o.ti.length?' <span class="pill2" style="background:#5c1a2b">'+esc(o.ti.join(", "))+'</span>':"")+(pivotLinks(o.ip)?" "+pivotLinks(o.ip):"")}).join("<br>")+'</p>':"")+'</div></div></div>';
  h+='<div class="sec"><h3>Hosts ('+num(D.count)+')</h3>'+hostFilterBar(D.members,D.all_nets)+hostsTable(shownM,R[CTX].hall?0:200)+'</div>';
  return h+groupHist(D.history)}
function campaignHtml(D){if(SM())return campaignSimple(D);var h="",ips=D.hosts.map(function(m){return m.ip});
  h+='<div class="hsum" style="--vc:'+VC[D.verdict]+'"><div class="dh">'+vp(D.verdict)+priTag(D.priority)+'<span class="ip" style="font-family:inherit">'+esc(D.title)+'</span><span class="tg">Campaign · '+hp(D.count,"host")+' in '+hp(D.children_n,"incident")+'</span>'
    +'<span class="sp"></span><button type="button" class="b2" data-ticket="1" title="A plain-text summary for a ticket, chat or e-mail">Copy as ticket</button></div>';
  h+='<div class="dsum">'+hp(D.count,"host")+' of '+esc(D.net)+' at Investigate or above: '+esc(D.families.map(fam).join(", "))+(D.chain_words&&D.chain_words.length?'. Chain rules: '+D.chain_words.map(function(c){return '<b>'+esc(c.title)+'</b>'}).join(", "):"")+'.</div>';
  h+='<div class="rsn2"><b>'+esc(VL[D.verdict])+'</b>: '+esc(D.reason||"")+'</div>';
  h+=groupFacts(D);
  var shownH=hostFilter(D.hosts),fl=shownH.length<D.hosts.length;if(fl)ips=shownH.map(function(m){return m.ip});
  var vmap={};D.hosts.forEach(function(m){vmap[m.ip]=m.verdict});h+='<div class="hact">'+bulkBar("c:"+D.net,"Campaign "+D.net+(fl?" ("+num(shownH.length)+" of "+num(D.hosts.length)+" hosts, filtered)":""),ips,vmap,D.hosts.length)+'</div></div>'+nextHtml(D);
  h+='<div class="sec"><h3>Incidents in this campaign ('+num(D.children.length)+')</h3><div class="qwrap"><table class="qt">'+(SM()?SHEAD:QHEAD)+'<tbody>'+D.children.map(function(c){return rowHtml({it:c,child:false})}).join("")+'</tbody></table></div></div>';
  h+='<div class="sec"><h3>Networks</h3><p>'+(D.all_nets||[]).map(function(n){return '<span class="pill2">'+esc(n[0])+' ×'+n[1]+'</span>'}).join("")+'</p></div>';
  h+='<div class="sec"><h3>Hosts ('+num(D.hosts.length)+')</h3>'+hostFilterBar(D.hosts,D.all_nets)+hostsTable(shownH,R[CTX].hall?0:100)+'</div>';
  return h+groupHist(D.history)}
// ---- the incident history: every incident the queue showed, kept as it was ----
var OUTW={ack:"Seen",tp:"True positive",benign:"Benign",fp:"False positive",resolved:"Resolved",investigating:"In progress",escalated:"Escalated",partial:"Partly handled",expired:"Ended, no action",excepted:"Excepted",unrev:"Ended, not reviewed",merged:"Merged into a group",open:"Active, new",none:"-"};
var OUTC={ack:"st-ack",tp:"st-tp",benign:"st-benign",resolved:"st-resolved",fp:"st-fp",investigating:"st-investigating",escalated:"st-escalated",partial:"st-ch",expired:"st-exp",excepted:"st-exp",unrev:"st-unrev",merged:"st0",open:"st-open"};
function dur(s){if(s==null)return "-";s=Math.round(s);if(s<90)return s+" s";var m=Math.round(s/60);if(m<90)return m+" min";var h=Math.floor(m/60);if(h<48)return h+" h"+(m%60?" "+m%60+" min":"");return Math.round(h/24)+" days"}
function kindBadge(r){var k=r.kind==="group"?"pattern":(r.subject_kind||"x"),l=r.kind==="group"?"Group":(r.subject_label||r.subject_kind||"?");
  return '<span class="ekind ekind-'+esc(k)+'" title="Subject: '+esc(r.subject)+'">'+esc(l)+'</span>'}
function scopeN(r){var n=r.members_n||0,pk=r.peak_n;return hp(n,"host")+(pk&&pk!==n?" over its life":"")}
function scopeSub(r){return r.peak_n&&r.peak_n!==(r.members_n||0)?'<div class="mut" title="The title and the reason are kept as they were at the peak; the record counts every host it ever held">'+hp(r.peak_n,"host")+' at its peak</div>':""}
function subjectHtml(r){if(r.kind==="entity")return kindBadge(r)+' <span class="mono">'+esc(r.subject_value)+'</span>'+(r.host?'<div class="mut">'+esc(r.host)+'</div>':"");
  if(r.kind==="campaign")return kindBadge(r)+' <span class="mono">'+esc(r.subject_value)+'</span><div class="mut">'+scopeN(r)+'</div>'+scopeSub(r);
  return kindBadge(r)+' <b>'+scopeN(r)+'</b>'+scopeSub(r)+(r.parent?'<div class="mut mono">in '+esc(r.parent.split(":").slice(1).join(":"))+'</div>':"")}
function outcomeOf(r){return isUnrev(r)?"unrev":r.outcome||(r.status==="open"?"open":"none")}
function outcomeHtml(r){var o=outcomeOf(r);
  return '<span class="'+(OUTC[o]||"st0")+'">'+esc(OUTW[o]||o)+(o==="partial"&&r.handled_n?" ("+num(r.handled_n)+"/"+num(r.members_n)+")":"")+'</span>'
    +(r.outcome_by&&o!=="expired"&&o!=="merged"?'<div class="mut">'+esc(r.outcome_by)+'</div>':"")+(r.status==="open"&&o!=="open"?'<div class="mut">still open</div>':"")}
function outcomeLine(r){var o=outcomeOf(r),t=esc(OUTW[o]||o);if(o==="partial")t+=" ("+num(r.handled_n||0)+" of "+num(r.members_n||0)+" hosts)";
  if(r.outcome_by&&o!=="expired"&&o!=="merged")t+=" by <b>"+esc(r.outcome_by)+"</b>";if(r.outcome_at&&o!=="expired")t+=", "+tm(r.outcome_at*1000,"dhm");
  if(r.tth!=null)t+=" ("+dur(r.tth)+" after it opened)";return t}
var HHEAD='<thead><tr><th>Opened</th><th>Peak verdict</th><th>Incident</th><th>Subject</th><th>Peak stage</th><th>Outcome</th><th>Time to handle</th><th></th></tr></thead>';
function laneHistory(L){var st=L.stats||{},sel=function(id,cur,opts){return '<select id="'+id+'">'+opts.map(function(o){return '<option value="'+esc(o[0])+'"'+(String(cur)===String(o[0])?" selected":"")+'>'+esc(o[1])+'</option>'}).join("")+'</select>'};
  var bar='<div class="afl">'+sel("hfd",S.hf.hours?"h"+S.hf.hours:"d"+S.hf.days,[["h8","last 8 hours (a shift)"],["h12","last 12 hours"],["h24","last 24 hours"],["d7","last 7 days"],["d30","last 30 days"],["d90","last 90 days"],["d0","all time"]])
    +sel("hfk",S.hf.kind,[["","every kind"],["entity","single hosts"],["group","groups of hosts"],["campaign","campaigns"]])
    +sel("hfv",S.hf.verdict,[["","every peak verdict"],["act","Act now"],["investigate","Investigate"],["review","Review"]])
    +sel("hfo",S.hf.outcome,[["","every outcome"],["open","active, new"],["investigating","in progress"],["escalated","escalated"],["tp","true positive"],["benign","benign"],["fp","false positive"],["ack","seen"],["partial","partly handled"],["expired","ended without action"],["excepted","closed by an exception"],["merged","merged into a group"],["resolved","resolved (older records)"]])
    +'<input type="search" id="hfq" placeholder="IP, host name, subnet, rule, family…" value="'+esc(S.hf.q)+'"><span class="sp" style="flex:1"></span><button type="button" class="b2" data-handover="1" title="What happened in the shift (the period here when it is in hours, else since the team was last here: the last action before a pause of 6 hours or more, so on Monday it covers the weekend): new, handled, still open and who has it, what ended unreviewed, notes; as text for the next shift">Copy as handover</button><a class="b2" href="'+esc(histUrl("csv"))+'" download>Export CSV</a></div>';
  var V=st.verdicts||{},vrow=function(v){var x=V[v];if(!x)return "";var cl=[x.tp?num(x.tp)+" true positive":"",x.benign?num(x.benign)+" benign":"",x.fp?num(x.fp)+" false positive":""].filter(Boolean);
    return '<span><b style="color:'+VC[v]+'">'+esc(VL[v])+'</b> '+num(x.incidents)+(x.open?' · '+num(x.open)+' active':"")+(x.median_tth!=null?' · handled in <b>'+esc(dur(x.median_tth))+'</b> (median)':"")
      +(cl.length?' · closed: '+esc(cl.join(", ")):"")+(v!=="review"&&x.expired?' · <span class="st-exp">'+num(x.expired)+' ended without action</span>':"")+'</span>'};
  var nums='<div class="hstat"><span><b>'+num(st.incidents||0)+'</b> '+(st.incidents===1?"incident":"incidents")+(st.nested?' <span title="Groups and hosts inside a campaign are listed as their own records; they count as part of the campaign, as in the queue">(+'+num(st.nested)+' inside campaigns)</span>':"")+(S.hf.hours?" in the last "+S.hf.hours+" hours":"")+(st.per_day!=null?" · "+st.per_day+" a day"+(st.covered_days<(S.hf.days||3650)?" (the oldest record is "+(st.covered_days<2?"a day":Math.round(st.covered_days)+" days")+" old)":""):"")+'</span>'+vrow("act")+vrow("investigate")+vrow("review")+'</div>';
  var rows=L.rows.map(histRow).join(""),more=L.total>S.hf.offset+L.rows.length;
  var pg=S.hf.offset>0||more?'<div class="qbar" style="margin-top:8px"><span class="mut">'+num(L.rows.length?S.hf.offset+1:0)+'–'+num(S.hf.offset+L.rows.length)+' of '+num(L.total)+'</span><span class="sp"></span>'
    +(S.hf.offset>0?'<button type="button" class="b2" data-hfp="-1">Newer</button>':"")+(more?'<button type="button" class="b2" data-hfp="1">Older</button>':"")+'</div>':"";
  $("#view").innerHTML='<p class="lead1">Every incident the queue showed, kept as it was at its peak.'+ii("The verdict and its reason, the evidence, what the team did and when. Each record is about an entity: today an IP, a group of hosts or a network; host names from asset discovery, users and devices once those sources are connected.")+'</p>'
    +bar+nums+(rows?tcard('<div class="qwrap"><table class="qt">'+HHEAD+'<tbody>'+rows+'</tbody></table></div>'):'<div class="empty2">No incidents match. The history fills as incidents appear in the queue.</div>')+pg;
  saveSeq("history","the history",L.rows.map(function(r){return {u:keyUrl("i:"+r.id),l:"Incident #"+r.id}}));
  var re=function(){S.hf.offset=0;loadLane("history")};
  $("#hfd").onchange=function(e){var v=e.target.value;if(v[0]==="h")S.hf.hours=+v.slice(1);else{S.hf.hours=0;S.hf.days=+v.slice(1)}re()};$("#hfk").onchange=function(e){S.hf.kind=e.target.value;re()};
  $("#hfv").onchange=function(e){S.hf.verdict=e.target.value;re()};$("#hfo").onchange=function(e){S.hf.outcome=e.target.value;re()};
  var qq=$("#hfq"),tmr=null;qq.oninput=function(){clearTimeout(tmr);tmr=setTimeout(function(){S.hf.q=qq.value;S.hfFocus=true;re()},350)};
  if(S.hfFocus){S.hfFocus=false;qq.focus();try{qq.setSelectionRange(qq.value.length,qq.value.length)}catch(x){}}
  $$("[data-hfp]").forEach(function(b){b.onclick=function(){S.hf.offset=Math.max(0,S.hf.offset+100*(+b.dataset.hfp));loadLane("history")}})}
var EVW={opened:"opened as","escalated":"escalated to","de-escalated":"de-escalated to",handled:"handled:",reopened:"reopened:",closed:"closed:"};
function eventsHtml(E){if(!E||!E.length)return "";
  return '<div class="sec"><h3>What happened to it</h3><ol class="hist">'+E.slice().reverse().map(function(x){var c=x.kind==="closed"?"#808297":x.kind==="handled"?"#8cc4ff":x.kind==="reopened"?"#ffb3c0":(VC[x.verdict]||"#808297"),wv=x.verdict&&VL[x.verdict]&&(x.kind==="opened"||x.kind==="escalated"||x.kind==="de-escalated");
    return '<li style="--hc:'+c+'"><span class="tm">'+tm(x.at*1000,"dhm")+'</span><b>'+esc(EVW[x.kind]||x.kind)+'</b> '+(wv?vp(x.verdict)+" ":"")+'<span class="mut">'+esc(x.text||"")+'</span></li>'}).join("")+'</ol></div>'}
function snapTargetHtml(s){var h='<div class="sec"><h3>The attack at the peak</h3><p>'+esc(hp((s.attackers||[]).length,"outside address","outside addresses"))+(s.ti&&s.ti.length?' · threat list: <b>'+esc(s.ti.join(", "))+'</b>':"")+' · it answered <b>'+bytes(s.answered)+'</b> · '+num(s.alerts)+' alerts</p>';
  if(s.findings&&s.findings.length)h+='<div class="qwrap"><table class="qt lt"><thead><tr><th>Alert</th><th>From</th><th>Port</th><th>Alerts</th><th>It answered</th><th>First – last</th></tr></thead><tbody>'+s.findings.map(function(f){return '<tr class="nk"><td>'+rn(f.rule)+'</td><td class="mono">'+esc(f.cp||"")+'</td><td>'+esc(f.port||"")+'</td><td>'+num(f.n)+'</td><td>'+bytes(f.down)+'</td><td>'+rng(f.first,f.last)+'</td></tr>'}).join("")+'</tbody></table></div>';
  return h+'</div>'}
function snapHostHtml(s){var h="";
  if(!SM()&&s.families&&s.families.length)h+='<div class="sec"><h3>Evidence at the peak</h3><div class="math">'+s.families.map(function(f){return '<b>'+num(f.bits,1)+'</b> '+esc(f.label)+' <span class="mut">('+esc(f.rule)+')</span>'}).join("\n")
    +(s.chains&&s.chains.length?"\n"+s.chains.map(function(c){return '<b>'+num(c.bits,1)+'</b> '+esc(c.id)+' '+esc(c.title)+(c.continuity?' <span class="mut">'+esc(c.continuity)+'</span>':"")}).join("\n"):"")
    +(s.E!=null?'\n= <b>'+num(s.E,1)+' bits</b>, confidence <b class="v">'+pc(s.conf)+'</b>':"")+'</div></div>';
  if(s.narrative&&s.narrative.length)h+='<div class="sec"><h3>What happened then</h3>'+stepsHtml(s.narrative)+(s.background?bgHtml(s.background):"")+'</div>';
  if(!SM()&&s.findings&&s.findings.length)h+='<div class="sec"><h3>Findings then ('+num(s.findings_n||s.findings.length)+')</h3><div class="card" style="padding:0"><div class="grid"><table style="min-width:0"><tr><th>Bits</th><th>Finding</th><th>Family</th><th>Counterpart</th><th>Alerts</th><th>Time</th></tr>'
    +s.findings.map(function(f){return '<tr'+(f.counted?"":' style="opacity:.6"')+'><td class="mono">'+num(f.bits,2)+'</td><td>'+rn(f.rule)+(f.attack?' <span class="mut" title="'+esc(f.tpl_tag?"template tag: "+f.tpl_tag:"")+'">'+esc(f.attack_id||f.attack)+'</span>':f.mitre?' <span class="mut">template tag '+esc(f.mitre)+'</span>':"")+'</td><td>'+esc(f.flabel)+(f.stage!=null?' <span class="mut">'+esc(C.stages[f.stage])+'</span>':"")+'</td><td class="mono">'+esc(f.cp||"")+'</td><td>'+num(f.n)+'</td><td>'+rng(f.first,f.last)+'</td></tr>'}).join("")+'</table></div></div></div>';
  return h}
function snapGroupHtml(s,D){var now={};(D.members||[]).forEach(function(m){now[m.value]=m});var h="";
  if(s.path&&s.path.length)h+='<div class="sec"><h3>What connected the hosts</h3><ol class="steps">'+s.path.map(function(p){return '<li style="--sc:#ff7a00">'+esc(p.label)+' <span class="fam">'+num(p.hosts)+' hosts</span></li>'}).join("")+'</ol></div>';
  if(s.nets&&s.nets.length)h+='<div class="sec"><h3>Networks</h3><p>'+s.nets.map(function(n){return '<span class="pill2">'+esc(n[0])+' ×'+n[1]+'</span>'}).join("")+'</p></div>';
  var list=s.members||[];if(list.length)h+='<div class="sec"><h3>Hosts then ('+num(D.members_total||list.length)+')</h3><div class="qwrap"><table class="qt ht"><thead><tr><th>Host</th><th>Verdict then</th><th>Kill chain then</th><th>Confidence</th><th>What happened</th><th>Now</th></tr></thead><tbody>'
    +list.map(function(m){var n=now[m.ip];return '<tr class="qr" style="--vc:'+(VC[m.verdict]||"#808297")+'" data-k="'+esc("h:"+m.ip)+'" title="Quick look of the host now"><td>'+ilink("h:"+m.ip,m.ip)+(m.name?'<div class="mut">'+esc(m.name)+'</div>':"")+'</td><td>'+vp(m.verdict)+'</td><td class="c-k">'+kc4(m.stages,m.stage)+'</td><td>'+cw(m)+'</td><td class="c-p">'+esc(m.path||"")+'</td>'
      +'<td class="c-st">'+(n&&n.now?vp(n.now)+(n.triage?'<div class="mut">'+esc(STW[n.triage.status]||n.triage.status)+'</div>':""):'<span class="mut">not on the board</span>')+'</td></tr>'}).join("")+'</tbody></table></div></div>';
  return h}
function snapCampaignHtml(s){var h="";
  if(s.children&&s.children.length)h+='<div class="sec"><h3>Its incidents then ('+num(s.children.length)+')</h3><div class="qwrap"><table class="qt"><thead><tr><th>Verdict then</th><th>Incident</th><th>Kill chain then</th><th>Scope</th><th>Confidence</th></tr></thead><tbody>'
    +s.children.map(function(c){var k=c.type==="host"?"h:"+c.ip:"";return '<tr class="qr" style="--vc:'+(VC[c.verdict]||"#808297")+'"'+(k?' data-k="'+esc(k)+'"':"")+'><td>'+vp(c.verdict)+'</td><td>'+esc(c.title||c.ip||"")+'</td><td class="c-k">'+kc4(c.stages,c.stage)+'</td><td>'+(c.type==="host"?'<span class="mono">'+esc(c.ip)+'</span>':hp(c.count||0,"host"))+'</td><td>'+cw(c)+'</td></tr>'}).join("")+'</tbody></table></div></div>';
  if(s.nets&&s.nets.length)h+='<div class="sec"><h3>Networks</h3><p>'+s.nets.map(function(n){return '<span class="pill2">'+esc(n[0])+' ×'+n[1]+'</span>'}).join("")+'</p></div>';
  return h}
function historyHtml(D){var s=D.snapshot||{},h="",what=D.kind==="entity"?"Historical incident · "+(D.subject_label||""):D.kind==="group"?"Historical incident · group of "+scopeN(D):"Historical campaign · "+scopeN(D);
  h+='<div class="hsum" style="--vc:'+(VC[D.verdict]||"#808297")+'"><div class="dh">'+(D.verdict?vp(D.verdict):"")+'<span class="ip" style="font-family:inherit">'+esc(D.label||D.subject)+'</span><span class="tg">'+esc(what)+'</span>'
    +(D.status==="open"?'<span class="tg lv">still open</span>':'<span class="tg">closed</span>')+'<span class="sp"></span>'+(D.live&&D.ui_key?ilink(D.ui_key,"Current state ›","b2"):"")+'</div>';
  h+='<div class="dsum">'+esc(D.headline||"")+'</div><div class="rsn2"><b>'+esc(VL[D.verdict]||"")+'</b> at its peak: '+esc(D.reason||"")+'</div>';
  h+='<div class="facts">'+(s.stages?kc(s.stages):"")+(D.conf!=null?'<span>confidence at the peak <b style="color:#fff" title="'+esc(pc(D.conf))+'">'+esc(D.conf_word||pc(D.conf))+'</b></span>':"")
    +'<span>opened '+tm(D.opened_at*1000,"dhm")+(D.closed_at?", closed "+tm(D.closed_at*1000,"dhm"):", still open")+'</span>'
    +(D.first_ms?'<span>alerts '+tm(D.first_ms,"dhm")+(D.last_ms?" – "+tm(D.last_ms,"dhm"):"")+'</span>':"")+'</div>';
  h+='<div class="partof"><b>Outcome</b>: '+outcomeLine(D)+(D.outcome_reason?' ('+esc(D.outcome_reason)+')':"")+(D.outcome_note?': “'+esc(D.outcome_note)+'”':"")+'</div>';
  var ids=D.identifiers||{},idl=Object.keys(ids).filter(function(k){return ids[k]&&ids[k].length}).map(function(k){return esc(k)+": "+esc(ids[k].slice(0,6).join(", "))+(ids[k].length>6?" …":"")});
  if(D.kind==="entity")h+='<div class="partof mut">Subject <span class="mono">'+esc(D.subject)+'</span>'+(D.resolution&&D.resolution.method?", resolved "+esc(D.resolution.method)+(D.resolution.confidence?" (confidence "+esc(D.resolution.confidence)+")":""):"")+(idl.length?" · "+idl.join(" · "):"")+'</div>';
  var ha="";if(D.kind==="entity"&&D.subject_kind==="ip"&&D.status==="open")ha+=triPanel("h",D.subject_value,D.triage,D.verdict_last||D.verdict);
  var rk="i:"+D.id;
  if(isUnrev(D)&&C.edit)ha+='<div class="tri"><span class="st-unrev" style="margin-right:8px">Ended, not reviewed: nobody looked at it while it was on the board.</span>'+actBtn("investigating","Take it",rk,D.verdict,"pri","In progress and yours: it waits under Taken, now quiet")+actBtn("escalated","Escalate…",rk,D.verdict,"","Hand it to L2 with a note")+actBtn("ack","Seen",rk,D.verdict,"","Nothing to do now: it leaves the queue")+actBtn("close","Close…",rk,D.verdict,"","Close it as a true positive, benign or a false positive")+'</div>';
  else if(isTaken(D)&&C.edit)ha+='<div class="tri"><span class="st-'+esc(D.outcome)+'" style="margin-right:8px">Taken after it ended: '+esc(STW[D.outcome]||D.outcome)+' · '+esc(D.outcome_by||"?")+'</span>'+actBtn("close","Close…",rk,D.verdict,"pri","Close it as a true positive, benign or a false positive")+actBtn("open","Release",rk,D.verdict,"","Nobody holds it any more: back to Ended, not reviewed")+'</div>';
  if(D.kind==="entity"&&D.subject_kind==="ip"&&D.first_ms){var a=[hostAlerts(D.subject_value,D.first_ms,D.last_ms||D.first_ms,"Alerts of that time in Sycope ↗"),flows(D.subject_value,null,null,D.first_ms,D.last_ms||D.first_ms,"Flows as client ↗"),flows(null,D.subject_value,null,D.first_ms,D.last_ms||D.first_ms,"as server ↗")].filter(Boolean);
    if(a.length)ha+='<div class="tri pvt">'+a.join(" · ")+' <span class="mut">(while Sycope still keeps them)</span></div>'}
  h+=(ha?'<div class="hact">'+ha+'</div>':"")+'</div>';
  h+=nextHtml(D,D.kind==="entity"&&D.subject_kind==="ip"?D.subject_value:"");
  if(s.what==="host")h+=snapHostHtml(s);else if(s.what==="target")h+=snapTargetHtml(s);else if(s.what==="group")h+=snapGroupHtml(s,D);else if(s.what==="campaign")h+=snapCampaignHtml(s);
  if(D.snapshot_at)h+='<p class="mut" style="font-size:12px">Snapshot taken '+tm(D.snapshot_at*1000,"dhm")+', at the incident\'s peak.</p>';
  return h+eventsHtml(D.events)}
function earlierHtml(E,ip){var L=(E||[]).filter(function(r){return !(r.status==="open"&&r.kind==="entity"&&r.subject_value===ip)});if(!L.length)return "";
  return '<div class="sec" data-sec="earlier" data-fold="1"><h3>Earlier incidents of this host ('+num(L.length)+')</h3><div class="qwrap"><table class="qt">'+HHEAD+'<tbody>'+L.map(histRow).join("")+'</tbody></table></div></div>'}
function afterMe(){if(S.data&&!INC&&S.tab==="queue")renderQueue()}
//@@SHARED@@
function statusHtml(it){if(it.type==="host"||!it.type){var t=it.triage;if(!t)return '<span class="st0">New</span>';
    var lab=STW[t.status]||t.status,own=ownerOf(t),by=own?(t.status==="escalated"?"→ ":"")+own:t.who,tip=tm(t.at*1000,"dhm")+(t.reason?" · "+t.reason:"")+(t.note?": "+t.note:"");
    if(t.changed)return '<span class="st-ch" title="'+esc(lab+" by "+(t.who||"?")+" "+tm(t.at*1000,"dhm")+"; since then: "+((t.new_parts||[]).map(fam).join(", ")||"a higher verdict"))+'">Changed since '+esc(lab.replace("Closed: ","closed as ").toLowerCase())+'</span>'+(t.who?'<div class="mut">'+esc(t.who)+'</div>':"");
    return '<span class="st-'+esc(t.status)+(own&&own===ME.name?" mine":"")+'" title="'+esc(tip)+'">'+esc(lab)+'</span>'+(by?'<div class="mut">'+esc(by)+'</div>':"")}
  var parts=[];if(it.in_progress)parts.push(num(it.in_progress)+" in progress");if(it.escalated_n)parts.push(num(it.escalated_n)+" escalated");
  return (it.open?'<span class="st0">'+num(it.open)+' open</span>':'<span class="st-ack">All handled</span>')+(parts.length?'<div class="mut">'+esc(parts.join(" · "))+'</div>':"")
    +(it.handled&&it.open?'<div class="mut">'+num(it.handled)+' handled</div>':"")+(it.changed?'<div class="st-ch">'+num(it.changed)+' changed since handled</div>':"")}
var KB='<button type="button" class="kb" data-rowmenu="1" aria-label="More actions" title="More actions (or right-click the row)">⋯</button>';
function actBtn(a,label,k,v,cls,tip){return '<button type="button" class="b2 '+(cls||"")+'" data-act="'+a+'" data-k="'+esc(k)+'" data-v="'+esc(v||"")+'" title="'+esc(tip||"")+'">'+label+'</button>'}
function triPanel(kind,key,t,v){if(!C.edit)return '<div class="tri"><span class="st">Read-only (SC_TRIAGE_EDIT is off).</span></div>';
  var k=kind+":"+key,own=ownerOf(t),st=t?('<span class="st">'+esc(STW[t.status]||t.status)+(own?(t.status==="escalated"?" to ":" · ")+esc(own):"")+' · by '+esc(t.who||"?")+' '+tm(t.at*1000,"dhm")+(t.reason?' ('+esc(t.reason)+')':"")+(t.note?': “'+esc(t.note)+'”':"")+(t.changed?' · <b style="color:#ffb3c0">changed since</b>':"")+'</span>'):"";
  if(SM())return '<div class="tri">'+(own===ME.name&&t&&t.status==="investigating"?"":actBtn("investigating","Take it",k,v,"pri","In progress and assigned to you; it stays in the queue"))
    +actBtn("escalated","Escalate…",k,v,"","Hand it to L2 with a note; it stays in the queue")+actBtn("close","Close…",k,v,"","Close it as a true positive, benign or a false positive")+'</div>'+(st?'<div class="tri">'+st+'</div>':"");
  return '<div class="tri">'+(own===ME.name&&t&&t.status==="investigating"?"":actBtn("investigating","Take it",k,v,"pri","In progress and assigned to you; it stays in the queue"))
    +actBtn("assign","Assign…",k,v,"","Give it to someone")+actBtn("escalated","Escalate…",k,v,"","Hand it to L2 with a note; it stays in the queue")
    +actBtn("ack","Seen",k,v,"","Nothing to do now: out of the queue until it shows something new")+actBtn("close","Close…",k,v,"","Close it as a true positive, benign or a false positive")
    +actBtn("note","Add note",k,v,"","A note in its history; the state does not change")+(t?actBtn("open","Reopen",k,v,"","Back to New"):"")+'</div>'+(st?'<div class="tri">'+st+'</div>':"")}
function bulkBar(scope,label,ips,verdicts,total){R[CTX].bulk={scope:scope,label:label,ips:ips,verdicts:verdicts||{},total:total||ips.length};
  if(!C.edit)return '<div class="tri"><span class="st">Read-only (SC_TRIAGE_EDIT is off).</span></div>';
  return '<div class="bulk">'+bulkBtns(CTX)+'</div>'}
function bulkBtns(ctx){var B=R[ctx].bulk,n=R[ctx].sel.size,all=B.ips.length,fl=B.total>all,what=n?num(n)+" selected":(all===1?"1 host":(fl?"the "+num(all)+" hosts shown":"all "+num(all)+" hosts"));
  var b=function(a,l,tip){return '<button type="button" class="b2 bk" data-bulk="'+a+'" title="'+esc(tip||"")+'">'+esc(l)+'</button>'};
  if(SM())return b("investigating","Take all","In progress and assigned to you")+b("escalated","Escalate…","Hand them to L2 with a note")+b("close","Close…","Close as a true positive, benign or a false positive");
  return '<span class="bscope">'+(n?'<b>'+num(n)+'</b> of '+hp(all,"host")+' selected · <button type="button" class="lnk" data-selnone="1">clear</button>':'For <b>'+esc(what)+'</b>'+(fl?' (the filter below is on)':' of this incident')+', or tick some below')+'</span>'
    +b("investigating","Take "+what,"In progress and assigned to you")+b("assign","Assign…","Give them to someone")+b("escalated","Escalate…","Hand them to L2 with a note")
    +b("ack","Seen","Nothing to do now")+b("close","Close…","Close as a true positive, benign or a false positive")+b("open","Reopen","Back to New")
    +'<button type="button" class="b2" data-act="note" data-k="'+esc(B.scope)+'" data-label="'+esc(B.label)+'" title="A note in the incident\'s history">Add note</button>'}
// one entry point for every change of state: a host, the hosts of an incident, or the ticked ones
function changeState(o){return ensureWho().then(function(w){if(!w)return;
  var n=o.ips.length,many=n>1,acts=o.verdicts.filter(function(v){return v==="act"}).length,why=o.verdicts.some(function(v){return v==="act"||v==="investigate"});
  var scope=many?'<div class="scope-box">'+esc(o.label||"")+': <b>'+hp(n,"host")+'</b>'+(acts?' · <b style="color:#ff8b98">'+num(acts)+' at Act now</b>':"")+'</div>':(o.label?'<div class="scope-box">'+esc(o.label)+'</div>':"");
  var title=function(verb){return verb+(many?" "+hp(n,"host"):"")};
  var ask=null,needNames=o.status==="assign"||o.status==="escalated";
  return (needNames?loadNames():Promise.resolve([])).then(function(){
    if(o.status==="close")ask=dlg({title:title("Close"),body:scope,ok:"Close",fields:[{name:"cls",label:"How do you close it?",type:"select",options:CLOSEW,value:"fp"},
      {name:"reason",label:"Reason",type:"select",deps:{field:"cls",map:C.reasons}},{name:"note",label:"What did you check?",type:"textarea",required:why,placeholder:why?"Required for Act now and Investigate: it goes into the audit log and the history":"optional"}]});
    else if(o.status==="escalated")ask=dlg({title:title("Escalate"),body:scope+'<p class="mut">It stays in the queue as Escalated, with the person or team named.</p>',ok:"Escalate",fields:[{name:"owner",label:"To (person or team)",value:"L2",max:40,list:KNOWN},{name:"note",label:"What should they look at?",type:"textarea",required:true}]});
    else if(o.status==="assign")ask=dlg({title:title("Assign"),body:scope,ok:"Assign",fields:[{name:"owner",label:"To",required:true,max:40,list:KNOWN},{name:"note",label:"Note",type:"textarea"}]});
    else if(o.status==="ack"&&(why||many))ask=dlg({title:title("Mark seen"),body:scope+'<p class="mut">Seen: nothing to do now. It leaves the queue and comes back when it shows something new.</p>',ok:"Mark seen",fields:[{name:"note",label:"Why is there nothing to do now?",type:"textarea",required:why}]});
    else if(many)ask=dlg({title:title(o.status==="investigating"?"Take":o.status==="open"?"Reopen":"Change"),body:scope,ok:o.status==="investigating"?"Take":o.status==="open"?"Reopen":"OK",fields:[{name:"note",label:"Note",type:"textarea"}]});
    return ask||{}}).then(function(v){if(!v)return;
    var status=o.status==="close"?v.cls:o.status==="assign"?"investigating":o.status,body={status:status,who:w,note:v.note||"",reason:v.reason||"",owner:v.owner||(status==="investigating"&&o.status!=="assign"?w:"")};
    if(n===1&&!o.scope){body.op="triage";body.ip=o.ips[0]}else{body.op="hosts";body.ips=o.ips;body.scope=o.scope||"sel";body.label=o.label||""}
    return post(body).then(function(j){var msg=o.status==="assign"?"Assigned to "+v.owner:o.status==="escalated"?"Escalated to "+(v.owner||"L2"):DONEW[status];
      toastUndo(msg+(j.hosts>1?" ("+hp(j.hosts,"host")+")":""),j.previous,o);if(o.after)o.after(status);
      if(o.where==="drwb"&&!INC&&!many&&["ack","tp","benign","fp"].indexOf(status)>=0&&S.open===o.key&&!S.handled)closeDetail();
      delete S.det[o.key];setTimeout(refreshAll,250)}).catch(function(e){toast(e.message,true)})})})}
function doAct(x){var k=x.dataset.k||"";if(x.dataset.act==="note"&&x.dataset.label)return noteDialog(k,x.dataset.label);actOn(k,x.dataset.act,x.dataset.v,x.closest("#drwb,#view")?rootOf(x):"")}
function actOn(k,a,v,where){var t=k.slice(0,1),val=k.slice(2);
  if(a==="note")return noteDialog(k,t==="h"?"Host "+val:val);
  if(t==="i"&&(a==="ack"||a==="close"||a==="investigating"||a==="escalated"||a==="open"))return reviewRecord(val,a,v,where);
  if(t!=="h")return;var d=S.det[k],verdict=v||(d&&d.actor?d.actor.verdict:"");
  changeState({status:a,ips:[val],verdicts:[verdict],label:"Host "+val,where:where||"",key:k})}
function doBulk(a,btn){var where=rootOf(btn),b=R[where],B=b.bulk;if(!B)return;var picked=!SMw(where)&&b.sel.size>0,ips=picked?B.ips.filter(function(ip){return b.sel.has(ip)}):B.ips.slice();if(!ips.length)return;
  changeState({status:a,ips:ips,verdicts:ips.map(function(ip){return B.verdicts[ip]||""}),scope:B.scope,label:B.label+(picked?" ("+ips.length+" selected)":""),where:where,key:"",after:function(){b.sel.clear()}})}
function noteDialog(k,label){ensureWho().then(function(w){if(!w)return;dlg({title:"Add a note",body:'<div class="scope-box">'+esc(label)+'</div><p class="mut">The note goes into the incident\'s history and the audit log; the state does not change.</p>',
  fields:[{name:"text",label:"Note",type:"textarea",required:true,max:1000}],ok:"Add note"}).then(function(v){if(!v)return;
  post({op:"comment",target:k,text:v.text,who:w,label:label}).then(function(){toast("Note added");setTimeout(refreshAll,250)}).catch(function(e){toast(e.message,true)})})})}
// ---- exceptions: what they will hide, before they are saved ----
function exceptionDialog(o){var q=new URLSearchParams({kind:o.kind,rule:o.rule||"",server:o.server||"",port:o.port||"",actor:o.actor||""});
  return getJ("exception-preview?"+q.toString()).catch(function(){return null}).then(function(pv){var where=o.kind==="service"?(o.server+(o.port?":"+o.port:"")):o.actor;
    var body='<div class="scope-box">'+(o.kind==="service"?'<b>Known service</b> <span class="mono">'+esc(where)+'</span> for “'+esc(o.rule)+'”: alerts of this rule to it stop counting <b>for every host</b>.':'<b>Allowed on this host</b> <span class="mono">'+esc(where)+'</span>: its alerts of “'+esc(o.rule)+'” stop counting.')+'</div>'
      +(pv?'<p>On the board now it takes the weight off <b>'+num(pv.findings)+'</b> finding'+(pv.findings===1?"":"s")+' of <b>'+hp(pv.hosts,"host")+'</b> ('+num(pv.alerts)+' alerts)'+(pv.act_or_investigate?', of which <b style="color:#ff8b98">'+hp(pv.act_or_investigate,"host")+' at Act now or Investigate</b>':"")+'. Other rules still count, and Sycope keeps every alert.</p>':"");
    var ver=isVerified(),adm=isAdmin()&&ver,big=pv&&pv.big,two=pv&&pv.second,propose=two||!ver||(C.approval&&!adm);
    if(two&&!ver)return dlg({title:"Sycope has not confirmed who you are",body:body+'<p>It touches '+esc(pv.protected.join(", "))+': two people Sycope has confirmed are behind it. Reload this page inside Sycope so it can confirm you, then propose it again.</p>',ok:"Close",fields:[]}).then(function(){return null});
    if(big&&pv.limits)body+='<p style="color:#ffcf8a">It covers '+hp(pv.alerts,"alert")+' and '+hp(pv.hosts,"host")+' in the last 24 hours: more than '+num(pv.limits.alerts)+' alerts or '+num(pv.limits.hosts)+' hosts. '+(adm?'As an admin you may add it.':'Only an admin can add it, so this one is not for you.')+'</p>';
    if(two)body+='<p class="mut">It touches '+esc(pv.protected.join(", "))+': a second person (an admin other than the one who proposes it) approves it before it counts.</p>';
    else if(!ver)body+='<p class="mut">Sycope has not confirmed who you are, so this only proposes it: a confirmed user approves it before it counts.</p>';
    else if(propose)body+='<p class="mut">An admin approves it before it counts (exceptions need approval here).</p>';
    if(big&&!adm)return dlg({title:"This exception needs an admin",body:body,ok:"Close",fields:[]}).then(function(){return null});
    return dlg({title:o.kind==="service"?"Accept a known service":"Allow a behaviour on this host",body:body,ok:propose?"Propose the exception":"Save the exception",fields:[{name:"reason",label:"Why (required, kept in the audit log)",type:"textarea",required:true,value:o.defReason||""},
      {name:"days",label:"For how long (it ends by itself)",type:"select",options:[[1,"1 day"],[7,"7 days"],[30,"30 days"],[90,"90 days"]],value:30}]})})}
function proposedToast(j){return j.second_person?"Proposed: it counts once a second admin approves it":j.unverified?"Proposed: it counts once a user Sycope has confirmed approves it":"Proposed: it counts once an admin approves it"}
function addEx(x){var k=x.dataset.ex;ensureWho().then(function(w){if(!w)return;exceptionDialog({kind:k,rule:x.dataset.rule,server:x.dataset.server,port:x.dataset.port,actor:x.dataset.actor}).then(function(v){if(!v)return;x.disabled=true;
  var body={op:"exception-add",kind:k,rule:x.dataset.rule,reason:v.reason,days:+v.days,who:w,admin:isAdmin()};if(k==="service"){body.server=x.dataset.server;body.port=x.dataset.port}else body.actor=x.dataset.actor;
  post(body).then(function(j){if(j.pending){toast(proposedToast(j)+" (Noise & tuning)");x.disabled=false;return}toast("Exception added; the board rescores in a moment");setTimeout(function(){delete S.det[S.open];refreshAll()},1500)}).catch(function(e){toast(e.message,true);x.disabled=false})})})}
// ---- silence rules (1.4): the exception with more precise fields, a time window and a counter ----
var DAYN=["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
function offLabel(){var m=confOff(),a=Math.abs(m);return "UTC"+(m<0?"-":"+")+Math.floor(a/60)+(a%60?":"+(a%60<10?"0":"")+a%60:"")}
function silWin(x){if(x.win_from==null)return "";var h=function(m){return p2(Math.floor(m/60))+":"+p2(m%60)},d=x.win_days?String(x.win_days).split(",").map(function(i){return DAYN[+i]}).join(" "):"every day";return d+" "+h(x.win_from)+"-"+h(x.win_to)+" ("+offLabel()+")"}
function silLine(x){return "silenced by rule #"+x.id+" · "+x.who+" · "+x.reason+(x.expires?" · expires "+tm(x.expires*1000,"dhm"):"")}
function silChips(x){var src=x.src||(x.kind==="host-rule"||x.kind==="host"?x.actor:""),dst=x.dst||(x.kind==="service"?x.server:""),c=function(k,v){return v?'<span class="sch"><i>'+k+'</i>'+esc(v)+'</span>':""};
  return c("alert",x.rule&&x.rule!=="*"?x.rule:"any")+c("src",src)+c("dst",dst)+c("port",x.port)+c("",x.proto)+c("when",silWin(x))}
function silSpark(arr){var mx=Math.max.apply(null,arr)||1,n=arr.length,W=n*10,h=22,out='<line x1="0" y1="21.5" x2="'+W+'" y2="21.5"/>';
  arr.forEach(function(v,i){if(!v)return;var bh=Math.max(2,v/mx*(h-3));out+='<rect x="'+(i*10+1.5)+'" y="'+(h-1-bh).toFixed(1)+'" width="7" height="'+bh.toFixed(1)+'"/>'});
  return '<svg class="ssp" viewBox="0 0 '+W+' '+h+'" preserveAspectRatio="none" role="img" aria-label="Alerts silenced per day, the last 14 days">'+out+'</svg>'}
function silAlerts(cur,D){var by={},seen=[],act=[],ina=[],cmp=function(a,b){return a.n<b.n?-1:a.n>b.n?1:0},known=function(f){return f&&f!=="UNK"?f:""};
  var defs={};((D&&D.defs)||[]).forEach(function(d){defs[d.name]=d});
  var mk=function(n,f,c){var d=own(defs,n)?defs[n]:null;return {n:n,f:known(f)||(d?known(d.family):""),t:d?d.tactic||"":"",c:c||0}};
  ((S.lanes.tuning||{}).rules||[]).forEach(function(r){if(r.rule&&!by[r.rule]){by[r.rule]=mk(r.rule,r.family,+r.alerts||0);seen.push(by[r.rule])}});
  ((D&&D.defs)||[]).forEach(function(d){if(by[d.name])return;var i=by[d.name]=mk(d.name,d.family,0);(d.active?act:ina).push(i)});
  var mine=[];if(cur&&!by[cur]){by[cur]=mk(cur,"",0);mine.push(by[cur])}
  seen.sort(function(a,b){return b.c-a.c||cmp(a,b)});
  var lc=function(a,b){var x=a.n.toLowerCase(),y=b.n.toLowerCase();return x<y?-1:x>y?1:cmp(a,b)};act.sort(lc);ina.sort(lc);
  return {groups:[["Chosen for this rule",mine,""],["Seen in the last 24 h",seen,""],["Active in Sycope",act,""],["Inactive in Sycope",ina," off"]]}}
function silPick(cur){return '<div class="sil-pick"><input type="hidden" data-v="rule" value="'+esc(cur||"")+'">'
  +'<button type="button" class="sil-pk-b" aria-haspopup="listbox" aria-expanded="false" aria-label="Alert"><span class="'+(cur?"":"mut")+'">'+esc(cur||"Choose an alert…")+'</span><i aria-hidden="true"></i></button>'
  +'<div class="sil-pk-p" hidden><input type="text" class="sil-pk-q" placeholder="Search alerts…" autocomplete="off" aria-label="Search alerts"><div class="sil-pk-l" role="listbox" aria-label="Alerts"></div><div class="sil-pk-n" role="status" hidden></div></div></div>'}
function silPickSetup(w){var box=w.querySelector(".sil-pick");if(!box)return;
  var hid=box.querySelector('input[type=hidden]'),btn=box.querySelector(".sil-pk-b"),pan=box.querySelector(".sil-pk-p"),q=box.querySelector(".sil-pk-q"),list=box.querySelector(".sil-pk-l"),note=box.querySelector(".sil-pk-n"),row=box.closest(".sil-r"),tick=row.querySelector('[data-on="rule"]'),items=[];
  var D=null,fail="",A=silAlerts(hid.value,D),label=function(i){var d=own(C.ruleNames,i.n)?C.ruleNames[i.n]:"";return (i.n+" "+d+" "+i.t).toLowerCase()};
  var drawNote=function(){var e=fail||(D&&D.error)||"",hm=D&&D.read_at?tm(D.read_at*1000,"hm"):"";
    note.textContent=!D&&!fail?"Reading Sycope's alert list…":e?(D&&D.defs.length?"Sycope's alert list could not be refreshed: "+e+" (showing the list read at "+hm+")":"Sycope's alert list could not be read: "+e):"";note.hidden=!note.textContent};
  var draw=function(){var t=q.value.trim().toLowerCase(),h="";items=[];
    A.groups.forEach(function(g){var m=g[1].filter(function(i){return !t||label(i).indexOf(t)>=0});if(!m.length)return;
      h+='<div class="sil-pk-g">'+g[0]+'</div>';m.forEach(function(i){items.push(i);var k=i.f?fam(i.f):i.t;h+='<div class="sil-pk-i'+(i.n===hid.value?" sel":"")+g[2]+'" role="option" aria-selected="'+(i.n===hid.value)+'" data-i="'+(items.length-1)+'"><span class="n">'+esc(i.n)+'</span><span class="m">'+esc(k)+(i.c?(k?" · ":"")+num(i.c)+" today":"")+'</span></div>'})});
    list.innerHTML=h||'<div class="sil-pk-e">No alert matches.</div>';drawNote()};
  var close=function(){pan.hidden=true;btn.setAttribute("aria-expanded","false")};
  var open=function(){q.value="";draw();pan.hidden=false;btn.setAttribute("aria-expanded","true");q.focus();var s=list.querySelector(".sel");if(s)list.scrollTop=Math.max(0,s.offsetTop-list.offsetTop-80)};
  btn.addEventListener("click",function(){if(pan.hidden)open();else close()});
  var redraw=function(){A=silAlerts(hid.value,D);if(!pan.hidden)draw()};
  // Sycope's own alert definitions (the service reads them with the lookups) and, on a host page, the Noise & tuning lane
  // for the "seen in the last 24 h" counts: both fetched when the dialog opens
  getJ("alertdefs").then(function(d){D=d}).catch(function(e){fail=(e&&e.message)||"the service did not answer"}).then(redraw);
  if(!S.lanes.tuning)getJ("lane?name=tuning").then(function(d){if(!S.lanes.tuning)S.lanes.tuning=d;redraw()}).catch(function(){});
  q.addEventListener("input",function(e){e.stopPropagation();draw()});
  q.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();e.stopPropagation()}});
  list.addEventListener("click",function(e){var el=e.target.closest("[data-i]"),i=el&&items[+el.dataset.i];if(!i)return;
    hid.value=i.n;var sp=btn.querySelector("span");sp.textContent=i.n;sp.className="";close();btn.focus();
    tick.checked=true;tick.dispatchEvent(new Event("change",{bubbles:true}));hid.dispatchEvent(new Event("change",{bubbles:true}))});
  w.addEventListener("click",function(e){if(!pan.hidden&&!e.target.closest(".sil-pick"))close()})}
function silBtn(){return C.edit&&!SM()?'<button type="button" class="lnk" data-silline="1" title="Silence alerts like this: pick which fields must match, how long, and see what it would hide first">Silence…</button>':""}
function silRow(key,label,input,on,hint){return '<div class="sil-r" data-f="'+key+'"><label><input type="checkbox" data-on="'+key+'"'+(on?" checked":"")+'><span>'+label+'</span></label><div>'+input+'</div>'+(hint?'<span class="sil-h">'+hint+'</span>':"")+'</div>'}
function silForm(o){var d=o.win_days?String(o.win_days).split(",").map(Number):[],t=function(m){return m==null?"":p2(Math.floor(m/60))+":"+p2(m%60)},tw=o.win_from!=null;
  return '<div class="scope-box">Alerts that match <b>every ticked field</b> stop counting; an unticked field means any. Sycope keeps every alert.</div><div class="sil">'
    +silRow("rule","Alert",silPick(o.rule),!!o.rule)
    +silRow("src","Source",'<input type="text" data-v="src" maxlength="64" autocomplete="off" placeholder="10.1.2.3 or 10.1.2.0/24" value="'+esc(o.src||"")+'">',!!o.src)
    +silRow("dst","Destination",'<input type="text" data-v="dst" maxlength="64" autocomplete="off" placeholder="10.1.2.3 or 10.1.2.0/24" value="'+esc(o.dst||"")+'">',!!o.dst)
    +silRow("port","Port",'<input type="text" data-v="port" maxlength="12" autocomplete="off" placeholder="443 or 8000-8100" value="'+esc(o.port||"")+'">',!!o.port)
    +silRow("proto","Protocol",'<select data-v="proto">'+["TCP","UDP","ICMP"].map(function(x){return '<option'+(o.proto===x?" selected":"")+'>'+x+'</option>'}).join("")+'</select>',!!o.proto)
    +silRow("win","Time window",'<div class="sil-w">'+DAYN.map(function(n,i){return '<label><input type="checkbox" data-day="'+i+'"'+(!o.win_days||d.indexOf(i)>=0?" checked":"")+'>'+n+'</label>'}).join("")
      +'<input type="time" data-v="from" value="'+t(o.win_from)+'" aria-label="From"> – <input type="time" data-v="to" value="'+t(o.win_to)+'" aria-label="To"></div>',tw,"Only together with a source or a destination · read in "+offLabel()+"; the end is not included; 22:00-06:00 crosses midnight")
    +'</div><div class="sil-pv" id="sil-pv" aria-live="polite"><span class="note">Checking what it would hide…</span></div>'}
function silFields(w){var f={},on=function(k){var c=w.querySelector('[data-on="'+k+'"]');return c&&c.checked},val=function(k){var e=w.querySelector('[data-v="'+k+'"]');return e?e.value.trim():""};
  ["rule","src","dst","port","proto"].forEach(function(k){f[k]=on(k)?val(k):""});
  if(on("win")){var ds=$$("[data-day]",w).filter(function(c){return c.checked}).map(function(c){return c.dataset.day});f.win_days=ds.length===7?"":ds.join(",");f.win_from=val("from");f.win_to=val("to")}
  else{f.win_days="";f.win_from="";f.win_to=""}return f}
function silPreview(w,o){var box=w.querySelector("#sil-pv"),ok=w.querySelector('[data-dlg="1"]'),n=0,tick=0;
  var run=function(){var f=silFields(w),mine=++tick;if(!Object.keys(f).some(function(k){return f[k]})){box.innerHTML='<span class="note">Tick the fields that must match.</span>';if(ok)ok.disabled=true;return}box.innerHTML='<span class="note">Checking what it would hide…</span>';
    getJ("exception-preview?"+new URLSearchParams(Object.assign({kind:"silence"},f)).toString()).catch(function(e){return {refused:e.message}}).then(function(pv){if(mine!==tick)return;
      var ver=isVerified(),adm=isAdmin()&&ver,h="",stop=false;
      if(pv.refused){h='<div class="bad">'+esc(pv.refused)+'</div>';stop=true}
      else{h='On the board now it takes the weight off <b>'+hp(pv.findings,"finding")+'</b> of <b>'+hp(pv.hosts,"host")+'</b> ('+num(pv.alerts)+' alerts in the last 24 hours)'+(pv.act_or_investigate?', of which <b style="color:#ff8b98">'+hp(pv.act_or_investigate,"host")+' at Act now or Investigate</b>':"")+'.'
        +(pv.names&&pv.names.length?'<div class="note">'+pv.names.map(function(x){return esc(x.name)+" ×"+num(x.alerts)}).join(" · ")+'</div>':"")
        +(pv.sample&&pv.sample.length?'<div class="note mono">'+pv.sample.map(esc).join(", ")+(pv.hosts>pv.sample.length?" …":"")+'</div>':"");
        if(pv.big&&pv.limits){h+='<div class="warn">More than '+num(pv.limits.alerts)+' alerts or '+num(pv.limits.hosts)+' hosts. '+(adm?"As an admin you may add it.":"Only an admin can add it, so this one is not for you.")+'</div>';if(!adm)stop=true}
        if(pv.second){h+='<div class="note">A second person (an admin other than the one who proposes it) approves it before it counts: '+esc(pv.protected.join("; "))+'.</div>';if(!ver){h+='<div class="bad">Sycope has not confirmed who you are: reload this page inside Sycope, then propose it again.</div>';stop=true}}
        else if(!ver)h+='<div class="note">Sycope has not confirmed who you are, so this only proposes it: a confirmed user approves it before it counts.</div>';
        else if(C.approval&&!adm)h+='<div class="note">An admin approves it before it counts (exceptions need approval here).</div>'}
      box.innerHTML=h;if(ok){ok.disabled=stop;ok.textContent=(o.id?"Save the changes":(!pv.refused&&(pv.second||!isVerified()||(C.approval&&!(isAdmin()&&isVerified())))?"Propose the rule":"Save the rule"))}})};
  var later=function(){clearTimeout(n);n=setTimeout(run,250)};
  $$("[data-on]",w).forEach(function(c){var row=c.closest(".sil-r"),sync=function(){row.classList.toggle("off",!c.checked);$$("input[data-v],select[data-v],input[data-day]",row).forEach(function(e){e.disabled=!c.checked})};sync();c.addEventListener("change",function(){sync();later()})});
  w.querySelector(".sil").addEventListener("input",later);w.querySelector(".sil").addEventListener("change",later);run()}
function silenceDialog(o){return dlg({title:o.id?"Edit silence rule #"+o.id:"Silence alerts like this",wide:false,body:silForm(o),ok:o.id?"Save the changes":"Save the rule",setup:function(w){silPreview(w,o);silPickSetup(w)},
  collect:function(w){var f=silFields(w);if(w.querySelector('[data-on="win"]').checked&&(!f.win_from||!f.win_to))return "Set both the start and the end of the time window.";return f},
  fields:[{name:"reason",label:"Why (required, kept in the audit log)",type:"textarea",required:true,value:o.reason||o.defReason||""},
    {name:"days",label:"For how long (it ends by itself, at most "+(C.excMaxDays||90)+" days)",type:"select",options:[[1,"1 day"],[7,"7 days"],[14,"14 days"],[30,"30 days"],[60,"60 days"],[90,"90 days"]],value:o.days||30}]})}
function silenceRule(o){ensureWho().then(function(w){if(!w)return;silenceDialog(o).then(function(v){if(!v)return;
  var body={op:o.id?"exception-edit":"exception-add",kind:"silence",rule:v.rule,src:v.src,dst:v.dst,port:v.port,proto:v.proto,win_days:v.win_days,win_from:v.win_from,win_to:v.win_to,reason:v.reason,days:+v.days,who:w,admin:isAdmin()};if(o.id)body.id=o.id;
  post(body).then(function(j){if(j.pending){toast(proposedToast(j)+" (Noise & tuning)");loadLane("tuning");return}toast("Silence rule "+(o.id?"saved":"added")+"; the board rescores in a moment");setTimeout(function(){if(S.open)delete S.det[S.open];refreshAll();if(S.tab==="tuning")loadLane("tuning")},1500)}).catch(function(e){toast(e.message,true)})})})}
function silenceLine(d){silenceRule({rule:d.rule,src:d.c,dst:d.s,port:d.port,proto:d.proto,defReason:""})}
function silenceExtend(x){ensureWho().then(function(w){if(!w)return;dlg({title:"Extend silence rule #"+x.id,body:'<p>It counts again from the next rebuild, for the days asked from now.</p>',ok:"Extend",fields:[{name:"days",label:"For how long",type:"select",options:[[7,"7 days"],[14,"14 days"],[30,"30 days"],[60,"60 days"],[90,"90 days"]],value:30}]}).then(function(v){if(!v)return;
  post({op:"exception-extend",id:+x.id,days:+v.days,who:w,admin:isAdmin()}).then(function(){toast("Extended; the board rescores in a moment");setTimeout(function(){loadLane("tuning");load()},1500)}).catch(function(e){toast(e.message,true)})})})}
function silenceHits(id){getJ("silence-hits?id="+encodeURIComponent(id)).then(function(d){var r=d.rule,rows=(d.hours||[]).map(function(h){return '<tr><td class="c-l">'+tm(h.hour*1000,"dhm")+'</td><td>'+num(h.alerts)+'</td><td>'+num(h.hosts)+'</td><td class="mut">'+(h.first?tm(h.first,"hm")+" – "+tm(h.last,"hm"):"")+'</td><td>'
    +(h.samples||[]).slice(0,6).map(function(a){return alertLink({id:a,t:h.hour*1000+1800000})||'<span class="mono mut">'+esc(String(a).slice(0,10))+'</span>'}).join(" ")+'</td></tr>'}).join("");
  dlg({title:"Rule #"+r.id+": what it silenced",wide:true,ok:"Close",fields:[],body:'<p>'+silChips(r)+'</p><p class="mut">Per hour, not per alert. Sample alerts are the first alert of up to 20 buckets of the hour; they open in Sycope.</p>'
    +'<div class="qwrap" style="max-height:46vh;overflow:auto"><table class="qt lt"><thead><tr><th>Hour</th><th>Alerts</th><th>Hosts</th><th>First – last</th><th>Sample alerts</th></tr></thead><tbody>'+(rows||'<tr class="nk"><td colspan="5" class="empty">Nothing yet.</td></tr>')+'</tbody></table></div>'})}).catch(function(e){toast(e.message,true)})}
// ---- spikes: a rule that hides far more than usual is reported once per rule and day (the bell) ----
function silenceSpikes(d){var sp=d.silence_spikes||[];if(!sp.length||!notifyOn())return;var seen={};try{seen=JSON.parse(localStorage.getItem("sc-silspike")||"{}")}catch(x){}
  sp.forEach(function(x){var k=x.id+":"+x.day;if(seen[k])return;seen[k]=1;try{new Notification("Sycope Security Triage",{body:x.text,tag:"sc-sil-"+x.id})}catch(y){}});
  try{localStorage.setItem("sc-silspike",JSON.stringify(seen))}catch(x){}}
// ---- actions ----
function addService(key,n,btn){var p=key.split("|");ensureWho().then(function(w){if(!w)return;exceptionDialog({kind:"service",rule:p[0],server:p[1],port:p[2],defReason:btn.dataset.why||("Known service: "+n+" internal hosts use it every day")}).then(function(v){if(!v)return;btn.disabled=true;
  post({op:"exception-add",kind:"service",rule:p[0],server:p[1],port:p[2],reason:v.reason,days:+v.days,who:w,admin:isAdmin()}).then(function(j){if(j.pending){toast(proposedToast(j));btn.disabled=false;loadLane("tuning");return}toast("Accepted; the board rescores in a moment");setTimeout(function(){loadLane("tuning");load()},1500)}).catch(function(e){toast(e.message,true);btn.disabled=false})})})}
function decideEx(id,decision,btn){ensureWho().then(function(w){if(!w)return;dlg({title:(decision==="approve"?"Approve":"Reject")+" exception #"+id,body:decision==="approve"?'<p>It counts from now, for the days asked.</p>':'<p>It never counts; the analyst sees why.</p>',fields:[{name:"note",label:decision==="approve"?"Note":"Why not",type:"textarea",required:decision!=="approve"}],ok:decision==="approve"?"Approve":"Reject",danger:decision!=="approve"}).then(function(v){if(!v)return;btn.disabled=true;
  post({op:"exception-decide",id:+id,decision:decision,who:w,note:v.note||"",admin:isAdmin()}).then(function(){toast(decision==="approve"?"Approved; the board rescores in a moment":"Rejected");setTimeout(function(){loadLane("tuning");load()},1200)}).catch(function(e){toast(e.message,true);btn.disabled=false})})})}
function removeEx(id,btn){ensureWho().then(function(w){if(!w)return;dlg({title:"Remove exception #"+id+"?",body:'<p>Its alerts count again from the next rebuild.</p>',fields:[{name:"note",label:"Why",type:"textarea"}],ok:"Remove",danger:true}).then(function(v){if(!v)return;btn.disabled=true;
  post({op:"exception-remove",id:+id,who:w,note:v.note||""}).then(function(){toast("Removed");setTimeout(function(){loadLane("tuning");load()},1500)}).catch(function(e){toast(e.message,true);btn.disabled=false})})})}
function redrawRoot(id){var root=$("#"+id);if(!root)return;var k=root.dataset.k,D=k&&S.det[k];if(!D)return;
  var n=root.querySelector(".note2"),v=n?n.value:"",f=n&&document.activeElement===n,top=id==="view"?window.scrollY:root.scrollTop;
  CTX=id;root.innerHTML=detailHtml(k,D);CTX="view";if(id==="view")window.scrollTo(0,top);else root.scrollTop=top;
  var m=root.querySelector(".note2");if(m){m.value=v;if(f)m.focus()}updateBulk(id)}
function reqPcap(id,where){S.pcapreq[id]="asking Sycope…";redrawRoot(where);
  fetch("pcap-request",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-SC-Action":"1"},body:JSON.stringify({id:id})})
  .then(function(r){return r.json().then(function(j){return [r.ok,j]})}).then(function(x){S.pcapreq[id]=x[0]?"sent to the recorder":"refused: "+(x[1].error||"?");redrawRoot(where);if(x[0])setTimeout(function(){delete S.pcapreq[id];if(where==="drwb")openDetail(S.open,true);else loadIncident(true)},4000)})
  .catch(function(e){S.pcapreq[id]="failed: "+e.message;redrawRoot(where)})}
// Get PCAP for every alert of the incident a recording can still come from: no job yet, inside the recorder's
// buffer, the newest PCAPALL at most; one request after another (never a burst at the destination), stop at a refusal
var PCAPALL=50;
function pcapAllList(D){var P=D.pcap||{};return (D.alerts||[]).filter(function(a){return !P[a.id]&&!S.pcapreq[a.id]&&!pastBuffer(a,D)}).slice(0,PCAPALL)}
function pcapAllBtn(D){if(!D.recorder||!D.recorder.on||!D.recorder.request)return "";var n=pcapAllList(D).length;if(!n)return "";
  return '<div class="pcl"><button type="button" class="b2" data-pcapall="1" title="One request per alert, one after another; alerts older than the recorder\'s buffer and those already recorded are left out">Get PCAP for all '+num(n)+' alert'+(n===1?"":"s")+(n===PCAPALL?" (newest)":"")+'</button></div>'}
function reqPcapAll(where){var root=$("#"+where),k=root&&root.dataset.k,D=k&&S.det[k];if(!D)return;var L=pcapAllList(D);if(!L.length)return;
  dlg({title:"Get PCAP for "+hp(L.length,"alert")+"?",body:'<p>Sycope sends them to the recorder one after another; it stops at the first refusal. Alerts older than the recorder\'s buffer and those already recorded are left out.</p>',ok:"Get PCAP"}).then(function(ok){if(!ok)return;
    L.forEach(function(a){S.pcapreq[a.id]="waiting…"});redrawRoot(where);var sent=0,i=0;
    var next=function(){if(i>=L.length){toast(hp(sent,"alert")+" sent to the recorder");setTimeout(function(){L.forEach(function(a){delete S.pcapreq[a.id]});if(where==="drwb")openDetail(S.open,true);else loadIncident(true)},4000);return}
      var id=L[i++].id;S.pcapreq[id]="asking Sycope…";redrawRoot(where);
      fetch("pcap-request",{method:"POST",credentials:"same-origin",headers:{"Content-Type":"application/json","X-SC-Action":"1"},body:JSON.stringify({id:id})})
      .then(function(r){return r.json().then(function(j){return [r.ok,j]})}).then(function(x){if(x[0]){sent++;S.pcapreq[id]="sent to the recorder";redrawRoot(where);setTimeout(next,400);return}
        throw new Error(x[1].error||"?")})
      .catch(function(e){S.pcapreq[id]="refused: "+e.message;L.slice(i).forEach(function(a){delete S.pcapreq[a.id]});redrawRoot(where);toast("Stopped after "+hp(sent,"alert")+": "+e.message,true)})};
    next()})}
// ---- notifications: a new Act now item plays a sound and shows a notification (per browser) ----
var SEEN_ACT=null;function notifyOn(){try{return localStorage.getItem("sc-notify")==="1"&&window.Notification&&Notification.permission==="granted"}catch(x){return false}}
function notify(d){silenceSpikes(d);var act=(d.items||[]).filter(function(i){return i.verdict==="act"&&(i.type==="host"?!(i.triage&&i.triage.handled):i.open>0)}).map(function(i){return i.key});
  if(SEEN_ACT&&notifyOn()){var fresh=act.filter(function(k){return SEEN_ACT.indexOf(k)<0});if(fresh.length){try{new Notification("Sycope Security Triage: "+fresh.length+" new Act now",{body:fresh.slice(0,4).join(", "),tag:"sc-tri"})}catch(x){}}}
  SEEN_ACT=act;var b=$("#bell");if(b){b.classList.toggle("on",notifyOn());b.title=notifyOn()?"Notifications on (click to turn off)":"Notify me about new Act now items"}}
function load(){if(S.busy)return;S.busy=true;getJ("board"+(S.handled?"?handled=1":"")+(S.vd.has("watch")?(S.handled?"&":"?")+"watch=1":""))
  .then(function(d){if(d.utc_offset_min!=null)window.SC_OFF=d.utc_offset_min;var hold=!S.force&&S.data&&S.data.ready&&d.ready&&busyNow();S.force=false;
    if(hold){S.pendingData=d;S.pendingN=diffN(S.data,d);pendShow();staleBar(d);if(S.open)openDetail(S.open,true);return}
    S.data=d;S.pendingData=null;pendShow();$("#err").innerHTML="";render();if(S.tab!=="queue")loadLane(S.tab,true);if(S.open)openDetail(S.open,true)})
  .catch(function(e){$("#err").innerHTML=readErr(e,"the board","Triage")})
  .then(function(){S.busy=false;clearTimeout(timer);timer=setTimeout(load,S.data&&S.data.ready?C.poll*1000:5000)})}
// ---- a list that holds still while the analyst works on it ----
function busyNow(){return S.paused||!!S.open||Date.now()-(S.lastHover||0)<10000||!!document.querySelector(".dlg-w")||(INC&&R.view.sel.size>0)}
function sig(d){var m={};(d.items||[]).forEach(function(it){var f=function(x){var t=x.triage;m[(x.type||"h")+":"+x.key]=x.verdict+"|"+(x.open!=null?x.open:"")+"|"+(t?t.status+(t.changed?"*":""):"")};f(it);(it.children||[]).forEach(f)});return m}
function diffN(a,b){var A=sig(a),B=sig(b),n=0,k;for(k in B)if(A[k]!==B[k])n++;for(k in A)if(!(k in B))n++;return n}
function pendShow(){var el=$("#pend");if(!el)return;var waiting=INC?!!S.pendInc:!!S.pendingData;
  if(!waiting&&!S.paused){el.hidden=true;return}el.hidden=false;
  el.innerHTML=(S.paused?'<b>Updates paused</b> · ':"")+(waiting?(INC?"newer data":(S.pendingN?hp(S.pendingN,"change"):"newer data"))+' · <button type="button" class="lnk" data-pend="1">show now</button>':"up to date")
    +(S.paused?' · <button type="button" class="lnk" data-pause="1">resume</button>':' <span class="mut">(held while you work)</span>')}
function applyPending(){if(INC){S.pendInc=false;pendShow();redrawRoot("view");return}if(!S.pendingData)return;S.data=S.pendingData;S.pendingData=null;pendShow();render();if(S.tab!=="queue")loadLane(S.tab,true)}
function staleBar(f){var el=$("#stale");if(!el||!f)return;var at=f.built_at||0,age=at?Date.now()/1000-at:0,limit=Math.max(300,3*(f.poll_s||C.poll||60));
  if(at&&(age>limit||f.poll_ok===false)){el.hidden=false;el.title=Math.round(age/60)+" min ago";el.innerHTML='⚠ Data from <b>'+tm(at*1000)+'</b>'+(f.poll_ok===false?'. Sycope cannot be read now: '+esc(f.poll_msg||"no answer"):"")+'. What you see may be out of date.'}
  else el.hidden=true}
// the profile still learning: how many of the days it wants it has, said to everyone (verdicts lean on shipped norms until then)
function profBanner(p){var el=$("#pbn");if(!el)return;if(!p||p.days>=p.want){el.hidden=true;return}el.hidden=false;
  el.innerHTML='Profile: <b>'+num(p.days)+'/'+num(p.want)+' days</b>. The triage is still learning what is normal on this network and leans on shipped norms until the profile fills'+(p.frozen?" (it is frozen)":"")+'.'}
function render(){var d=S.data;if(!d)return;
  $("#asof").innerHTML=d.ready?("as of "+tm(d.built_at*1000,"hm")+(d.poll_ok?"":' <span class="dot fail" title="'+esc(d.poll_msg)+'"></span>')):"reading Sycope…";
  tzPaint();
  staleBar({built_at:d.built_at,poll_ok:d.poll_ok,poll_msg:d.poll_msg,poll_s:d.poll_s});profBanner(d.profile);
  if(!d.ready){$("#view").innerHTML='<div class="loading">'+esc(d.poll_msg||"Reading alerts from Sycope…")+'</div>';return}
  tabs(d);notify(d);
  var q=$("#q"),typing=q&&document.activeElement===q,pos=typing?q.selectionStart:0;
  if(S.tab==="queue")renderQueue();else if(S.tab==="config")cfgShow();else renderLane();
  if(typing){var n=$("#q");if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}}}}
function rowsOf(d){var out=[];sortItems(d.items||[]).forEach(function(it){
    if(it.type==="campaign"){var k=sortItems((it.children||[]).filter(passes)),self=passes(it);if(!self&&!k.length)return;
      var open=S.exp.has(it.key)||(!SM()&&!S.col.has(it.key)&&((it.by_verdict||{}).act>0))||(!!S.q&&k.length>0&&!qmatch(it));out.push({it:it,child:false,open:open,nk:k.length});
      if(open)k.forEach(function(c){out.push({it:c,child:true})});return}
    if(passes(it))out.push({it:it,child:false})});return out}
function wpass(it){if(!S.wf)return true;var t=it.type==="host"?it.triage:null;
  if(S.wf==="mine")return !!ME.name&&(it.type==="host"?ownerOf(t)===ME.name:(it.owners||[]).indexOf(ME.name)>=0);
  if(S.wf==="esc")return it.type==="host"?!!(t&&!t.changed&&t.status==="escalated"):(it.escalated_n||0)>0;
  if(S.wf==="free")return it.type==="host"?!ownerOf(t):(it.in_progress||0)+(it.escalated_n||0)<(it.open||it.count||1);
  return true}
// where a name, a role tag and a location come from (ctx, from the server): no source, no tooltip
function ctxName(o){var c=o.ctx||{};return o.name?'<div class="mut"'+(c.name_src?' title="'+esc("Name from "+c.name_src)+'"':"")+'>'+esc(o.name)+'</div>':""}
function ctxTags(o){var T=(o.ctx||{}).tag_tips||{};return (o.tags||[]).map(function(x){return '<span class="tg svc"'+(T[x]?' title="'+esc(T[x])+'"':"")+'>'+esc(x)+'</span>'}).join("")}
function scopeHtml(it){if(it.type==="host")return '<span class="mono">'+esc(it.ip)+'</span>'+(it.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")
    +ctxName(it)+ctxTags(it)+(it.net?'<div class="mut" title="'+esc((it.ctx||{}).net_tip||"")+'">'+esc(it.net)+'</div>':(!it.name&&it.loc?'<div class="mut" title="'+esc((it.ctx||{}).loc_tip||"")+'">'+esc(it.loc)+'</div>':""));
  var N=it.nets||[],nets=N.length?'<span title="'+esc(N.map(function(n){return n[0]+" ×"+n[1]}).join("\n"))+'">'+esc(N[0][0])+" ×"+N[0][1]+(N.length>1?' <span class="mut">+'+(N.length-1)+' more</span>':"")+'</span>':"";
  if(it.type==="campaign"){var bv=it.by_verdict||{},parts=["act","investigate","review"].filter(function(v){return bv[v]}).map(function(v){return '<span style="color:'+VC[v]+'">'+num(bv[v])+" "+esc(VL[v])+'</span>'});
    return '<b>'+hp(it.count,"host")+'</b> <span class="mut">in '+hp(it.children_n,"incident")+'</span><div class="mut">'+parts.join(" · ")+'</div><div class="mut mono">'+esc(it.net)+'</div>'}
  return '<b>'+hp(it.count,"host")+'</b>'+(it.crown?' <span class="jw" title="'+esc(hp(it.crown,"crown jewel"))+'">'+ic("jewel",12)+'</span>':"")+'<div class="mut">'+nets+'</div>'}
function lastHtml(it){var act=it.type==="host"||!it.type?!!it.active:it.active>0,quiet=it.last&&S.data?(S.data.now*1000-it.last)/3600000:0;
  return '<span title="Last alert: '+esc(fullTime(it.last))+'">'+(act?'<i class="ldot"></i>':"")+at(it.last)+'</span>'+(it.type&&it.type!=="host"&&it.active?'<div class="mut">'+num(it.active)+' active</div>':"")
    +(!act&&quiet>=6?'<div class="mut" title="No alerts for '+Math.round(quiet)+' hours: still worth the look, less urgent">quiet for '+Math.round(quiet)+' h</div>':"")
    +(isNewSince(it)?'<div class="nsince" title="First evidence after your last visit">new since your visit</div>':"")}
var SECW={act:["Act now","do these first"],investigate:["Investigate","today"],review:["Review","when Act now and Investigate are done"],watch:["Watch","background: weak signals only"]};
function secRow(v,c){var w=SECW[v]||[v,""];return '<tr class="qsec"><td colspan="9"><span class="qsec-l" style="--vc:'+VC[v]+'">'+esc(w[0])+'</span> <span class="mut">'+(c?hp(c.items,"incident")+" ("+hp(c.hosts,"host")+")":"")+(w[1]?" · "+esc(w[1]):"")+'</span></td></tr>'}
function wfCount(d,f){var o=S.wf;S.wf=f;var n=0;(d.items||[]).forEach(function(it){if(it.verdict!=="watch"&&wpass(it))n++});(d.held||[]).forEach(function(x){if(heldWho(x,f))n++});(d.held_records||[]).forEach(function(r){if(heldWho(recHeld(r),f))n++});S.wf=o;return n}
function renderQueue(){var d=S.data,cnt=d.counts||{},rows=rowsOf(d);
  var chips=C.verdicts.filter(function(x){return x.key!=="watch"}).map(function(x){var c=cnt[x.key]||{items:0,hosts:0};return '<button type="button" class="vch'+(S.vd.has(x.key)?" on":"")+'" style="--vc:'+x.color+'" data-vd="'+x.key+'" title="'+esc(hp(c.items,"incident")+", "+hp(c.hosts,"host"))+'"><i></i>'+esc(x.label)+' <b>'+num(c.items)+'</b><span class="hn">('+num(c.hosts)+')</span></button>'}).join("");
  var wfs=[["mine","Mine"],["free","Unassigned"],["esc","Escalated"]].map(function(w){var n=wfCount(d,w[0]);return '<button type="button" class="wf'+(S.wf===w[0]?" on":"")+'" data-wf="'+w[0]+'" title="'+esc(hp(n,"incident")+": includes taken records, excludes unreviewed ones")+'">'+esc(w[1])+' <b>'+num(n)+'</b></button>'}).join("");
  var bar='<div class="qbar">'+chips+'<span class="wfs" title="Who has it: counts incidents">'+wfs+'</span><span class="sp"></span>'
    +'<label><input type="checkbox" id="chg"'+(S.changes?" checked":"")+'> changed only</label><label><input type="checkbox" id="hnd"'+(S.handled?" checked":"")+'> show handled ('+num(d.handled||0)+')</label>'
    +'<label title="Hosts with weak or background signals only"><input type="checkbox" id="wat"'+(S.vd.has("watch")?" checked":"")+'> Watch hosts ('+num((cnt.watch||{}).hosts||0)+')</label></div>';
  var tb='<div class="qtb">'+(C.edit?'<button type="button" class="abtn" id="qact" disabled title="Tick incidents in the list, then one action for all their hosts"><span class="al">Action</span><span class="chev">▾</span></button><span class="qsn" id="qsn"></span>':"")
    +'<div class="hl2" id="headline"></div><span class="sp"></span><label title="One line per incident, as in Sycope\'s tables"><input type="checkbox" id="dens"'+(DENSE?" checked":"")+'> compact</label>'
    +'<button type="button" class="b2" data-pause="1" title="Hold the list as it is while you work">'+(S.paused?"Resume updates":"Pause updates")+'</button>'
    +'<form class="srch" onsubmit="return false"><svg class="lupa" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="6.5" cy="6.5" r="5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="m10.5 10.5 4 4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg><input type="search" id="q" placeholder="Find: IP, alert, family…" value="'+esc(S.q)+'" autocomplete="off"></form></div>';
  var shown=rows.slice(0,S.limit),body,tops=rows.filter(function(r){return !r.child}),top=tops.length,held=(d.held||[]).filter(heldPass),recs=(d.held_records||[]).filter(function(r){return heldPass(recHeld(r))}),unrev=(d.unreviewed||[]).filter(unrevPass);
  var topHosts=tops.reduce(function(n,r){return n+(r.it.type==="host"?1:(r.it.count||0))},0);
  if(!shown.length&&!held.length&&!recs.length&&!unrev.length)body='<div class="empty2">'+((d.items||[]).length?"Nothing matches. Clear the search or turn on another verdict.":"Nothing to act on in the last 24 hours. The board reads Sycope every "+C.poll+" s.")+'</div>';
  else{var lastV=null,html=[];
    // Act now, Investigate, Review (Watch), then what ended unreviewed, then what was taken and went quiet
    var uput=function(){var uo=unrevIsOpen();html.push(unrevSec(unrev.length,uo));if(uo)unrev.forEach(function(r){html.push(unrevRow(r))});unrev=[]};
    shown.forEach(function(r){if(!r.child&&r.it.verdict!==lastV){lastV=r.it.verdict;if(lastV==="watch"&&unrev.length)uput();html.push(secRow(lastV,cnt[lastV]))}html.push(rowHtml(r))});
    if(unrev.length)uput();
    if(held.length||recs.length){html.push(heldSec(held.length+recs.length));held.forEach(function(x){html.push(heldRow(x))});recs.forEach(function(r){html.push(recHeldRow(r))})}
    body='<div class="qwrap"><table class="qt qq'+(DENSE?" compact":"")+'">'+qhead()+'<tbody>'+(SM()?html.join("").replace(/colspan="9"/g,'colspan="5"'):html.join(""))+'</tbody></table></div>'
    +(rows.length>S.limit?'<button type="button" class="b2 more2" id="more">Show '+Math.min(60,rows.length-S.limit)+' more ('+num(rows.length-S.limit)+' left)</button>':"")
    +'<div class="tfoot">'+hp(top,"incident")+' ('+hp(topHosts,"host")+')'+(d.more?" · +"+num(d.more)+" not loaded":"")+(d.silenced_alerts?' · <span title="Alerts of the last 24 hours that a silence rule took the weight off. Sycope keeps them.">'+num(d.silenced_alerts)+' alert'+(d.silenced_alerts===1?"":"s")+' silenced</span>':"")+'</div>'
}
  $("#view").innerHTML=bar+(S.sort&&!SM()?'<div class="srtn">Sorted by '+esc({stage:"kill chain",conf:"confidence",last:"last activity",hosts:"scope"}[S.sort.k])+' inside each verdict · <button type="button" class="lnk" data-sort="">back to the recommended order</button></div>':"")+'<div class="tcard">'+tb+body+'</div>';headline(d);qselBar();
  var dn=$("#dens");if(dn)dn.onchange=function(e){DENSE=e.target.checked;try{localStorage.setItem("sc-dense",DENSE?"1":"0")}catch(y){}var tq=$(".qq");if(tq)tq.classList.toggle("compact",DENSE)};
  var q=$("#q");q.oninput=function(){S.q=q.value;S.limit=60;sync();var pos=q.selectionStart;renderQueue();var n=$("#q");n.focus();try{n.setSelectionRange(pos,pos)}catch(x){}};
  $("#chg").onchange=function(e){S.changes=e.target.checked;renderQueue()};
  $("#hnd").onchange=function(e){S.handled=e.target.checked;sync();load()};
  $("#wat").onchange=function(e){if(e.target.checked)S.vd.add("watch");else S.vd.delete("watch");sync();load()};
  var m=$("#more");if(m)m.onclick=function(){S.limit+=60;renderQueue()};
  // the order the analyst sees is the order "Next" follows on the incident pages
  var seq=rows.map(function(r){return {u:incUrl(r.it),l:itLabel(r.it)}});
  saveSeq("queue","the queue",seq);
  restoreScroll()}
// ---- the lanes, in the same table as the queue ----
var HEATW={hot:"Exposure: high",warm:"Exposure: medium",service:"Busy service",noted:"Exposure: low"},HEATC={hot:"#e0122d",warm:"#ff7a00",service:"#4aa3ff",noted:"#808297"};
var HEATT={hot:"Attackers on a threat list, attacks across the internet edge, a crown jewel under real attack, or three attack families",warm:"Ten or more attackers, or attackers from outside",service:"Most of its alerts are a busy service doing its job",noted:"A few internal attackers"};
function tiPills(ti){return ti&&ti.length?ti.map(function(x){return '<span class="pill2" style="background:#5c1a2b">'+esc(x)+'</span>'}).join(""):'<span class="mut">-</span>'}
function topRules(r){return r.slice(0,2).map(function(x){return esc(x[0])+' <span class="mut">×'+num(x[1])+'</span>'}).join("<br>")}
function tcard(h){return '<div class="tcard">'+h+'</div>'}
function laneTable(head,rows,empty,cols){return '<div class="qwrap"><table class="qt lt"><thead><tr>'+head.map(function(h){return '<th>'+h+'</th>'}).join("")+'</tr></thead><tbody>'+(rows||'<tr class="nk"><td colspan="'+(cols||head.length)+'" class="empty">'+empty+'</td></tr>')+'</tbody></table></div>'}
function laneTargets(L){var rows=L.rows.map(function(t){return '<tr class="qr" style="--vc:'+(HEATC[t.heat]||"#808297")+'" data-open="h:'+esc(t.ip)+'" title="Quick look"><td><span class="hb '+esc(t.heat)+'" title="'+esc("Exposure, not a verdict. "+(HEATT[t.heat]||""))+'">'+esc(HEATW[t.heat]||t.heat)+'</span></td>'
    +'<td><span class="mono">'+esc(t.ip)+'</span>'+(t.crown?' <span class="jw" title="crown jewel">'+ic("jewel",12)+'</span>':"")+(t.incident?' <span class="tg" title="Attacked from outside and it answered (or the source is listed): an incident in the queue">in the queue · '+esc(VL[t.incident])+'</span>':"")+(t.name?'<div class="mut">'+esc(t.name)+'</div>':"")+'</td>'
    +'<td>'+num(t.attackers)+' <span class="mut">('+num(t.internal)+' internal, '+num(t.external)+' external)</span></td><td>'+tiPills(t.ti)+'</td><td>'+famPills(t.families)+'</td><td>'+topRules(t.rules)+'</td>'
    +'<td>'+(t.service?pc(t.service/Math.max(1,t.alerts))+' on busy services':"")+'</td><td>'+bytes(t.responded)+'</td><td class="c-l" title="'+esc(fullTime(t.last))+'">'+at(t.last)+'</td></tr>'}).join("");
  $("#view").innerHTML='<p class="lead1">Internal hosts under attack, from the internet or from other internal hosts.'+ii("A target is not a compromised host: it moves to the queue when it starts acting itself, or as a Target when it was attacked from outside and answered. <b>Exposure: high</b> (not a verdict): attackers on a threat list, attacks across the internet edge, a crown jewel under real attack, or three attack families. <b>Busy service</b>: mostly a busy service doing its job.")+'</p>'
    +tcard(laneTable(["Level","Target","Attackers","Threat intel","Families","Top rules","Service share","It answered","Last"],rows,"No targets in the window."))
    +(L.total>L.rows.length?'<p class="mut" style="font-size:12px">'+num(L.rows.length)+' of '+num(L.total)+' shown.</p>':"")}
var RATEC={hostile:"#e0122d",suspicious:"#ff7a00",context:"#808297"};
function laneExternal(L){var hostile=L.rows.filter(function(x){return x.rating==="hostile"}).map(function(x){return x.ip});
  var rows=L.rows.map(function(x){return '<tr class="qr" style="--vc:'+(RATEC[x.rating]||"#808297")+'" data-open="h:'+esc(x.ip)+'" title="Quick look"><td><span class="hb '+esc(x.rating)+'">'+esc(x.rating)+'</span></td><td><span class="mono">'+esc(x.ip)+'</span>'+(x.new?' <span class="tg new">new</span>':"")+(x.wave?' <span class="tg ch" title="Three or more internal hosts contacted this listed IP">wave</span>':"")+(pivotLinks(x.ip)?'<div>'+pivotLinks(x.ip)+'</div>':"")+'</td>'
    +'<td>'+esc(x.asn_label||"")+'</td><td>'+tiPills(x.ti)+'</td><td>'+(x.in_hosts?'<b>'+num(x.in_hosts)+'</b> targeted':"")+(x.in_hosts&&x.out_hosts?" · ":"")+(x.out_hosts?'<b>'+num(x.out_hosts)+'</b> contacted it':"")+'</td><td>'+topRules(x.rules)+'</td>'
    +'<td>'+(x.up?"↑ "+bytes(x.up):"")+(x.up&&x.down?" ":"")+(x.down?"↓ "+bytes(x.down):"")+'</td><td class="c-l" title="'+esc(fullTime(x.last))+'">'+at(x.last)+'</td></tr>'}).join("");
  $("#view").innerHTML='<div class="qbar"><span class="lead1">IPs outside your networks that touched your hosts.'+ii("<b>Hostile</b>: on a threat list (not a shared cloud address) or attacking inward. <b>Wave</b>: several of your hosts contacted the same listed address.")+'</span><span class="sp"></span>'
    +(hostile.length?'<button type="button" class="b2" id="cpy">Copy '+num(hostile.length)+' hostile IPs</button>':"")+'</div>'
    +tcard(laneTable(["Rating","IP","Network","Threat intel","Your hosts","Top rules","Bytes","Last"],rows,"No external IPs touched your hosts."))
    +(L.context?'<p class="mut" style="font-size:12px">'+num(L.context)+' more external IPs appear only with other external IPs (if those are your public ranges, add them to SC_INTERNAL_NETS).</p>':"");
  var b=$("#cpy");if(b)b.onclick=function(){copy(hostile.join("\n"))}}
function laneHygiene(L){var rows=L.rows.map(function(h){return '<tr class="qr nk" style="--vc:#7c86b8"><td>'+rn(h.rule)+'</td><td>'+esc(h.label)+'</td><td>'+num(h.hosts)+'</td><td>'+num(h.alerts)+'</td><td>'+h.top.slice(0,5).map(function(t){return '<a href="#" class="mono" data-open="h:'+esc(t[0])+'">'+esc(t[0])+'</a> <span class="mut">×'+num(t[1])+'</span>'}).join(", ")+'</td><td class="mono">'+h.peers.map(function(p){return esc(p[0])}).join(", ")+'</td></tr>'}).join("");
  $("#view").innerHTML='<p class="lead1">Policy and hygiene findings on '+hp(L.hosts,"host")+'.'+ii("Cleartext protocols, unauthorized services, asset changes. They never raise a threat verdict: they are the list to clean up, and the trend to report.")+'</p>'
    +tcard(laneTable(["Rule","Family","Hosts","Alerts","Top hosts","Peers"],rows,"Nothing."))}
function laneTuning(L){var tot=Math.max(1,L.alerts),soon=Date.now()/1000+7*86400;
  var sv=L.services.map(function(s){var key=s.rule+"|"+s.server+"|"+s.port;return '<tr class="qr nk" style="--vc:#4aa3ff"><td>'+rn(s.rule)+'</td><td class="mono">'+esc(s.server)+(s.port?":"+esc(s.port):"")+'</td><td>'+num(s.actors)+' <span class="mut">('+pc(s.share_hosts)+' of hosts)</span></td>'
    +'<td>'+num(s.alerts)+' <span class="mut">('+pc(s.alerts/tot)+' of all)</span></td><td title="Days this pattern showed up, out of the comparable days the triage compares today with (the same weekdays, no holidays)">'+(s.depth?num(Math.min(s.days,s.depth))+" of "+num(s.depth)+" days":"today")+'</td><td>'
    +(s.excepted?'<span class="tg st">accepted</span>':(L.edit?'<button type="button" class="b2 pri" data-svc="'+esc(key)+'" data-n="'+esc(s.actors)+'">Accept as known service…</button>':'<span class="mut">read-only</span>'))+'</td></tr>'}).join("");
  var rr=L.rules.slice(0,40).map(function(r){var flags=[];if(r.download_pct>0.5)flags.push(pc(r.download_pct)+" are downloads, not uploads");if(r.cloud_pct>0.5)flags.push(pc(r.cloud_pct)+" to shared cloud IPs");if(!r.known)flags.push("not in the catalog");
    if(r.share>0.1)flags.push("on "+pc(r.share)+" of hosts");if(r.chronic_pct>0.6)flags.push(pc(r.chronic_pct)+" chronic");
    return '<tr class="qr nk" style="--vc:'+((C.families[r.family]||[0,0,"#808297"])[2])+'"><td>'+rn(r.rule)+'</td><td>'+esc(fam(r.family))+'</td><td>'+esc(r.cls)+'</td><td>'+num(r.alerts)+' <span class="mut">'+pc(r.alerts/tot)+'</span></td><td>'+num(r.actors)+'</td>'
      +'<td>'+(r.base?'<span class="sc"><b>'+pc(r.value)+'</b></span>':'<span class="mut">'+(r.cls==="D"?"hygiene: no threat weight":r.actors?"no weight left":'both sides are outside your networks, or the internal side is a resolver or proxy: reviewed in <a href="./?tab=external">External</a>')+'</span>')+'</td><td class="mut">'+esc(flags.join(" · "))+'</td></tr>'}).join("");
  var sr=(L.silence||[]).filter(function(x){return x.state==="active"||x.state==="expired"||x.state==="lookup"}).map(function(x){var exp=x.state==="expired",soon2=!exp&&x.expires&&x.expires<soon,st=x.stats||{},big=function(v,tip){return '<button type="button" class="lnk" data-silhits="'+esc(x.id)+'" title="'+esc(tip)+'">'+num(v)+'</button>'};
    return '<tr class="qr nk" style="--vc:'+(exp||soon2?"#c9a05b":"#2f3060")+'"><td>'+(x.source?'<span class="mut">lookup</span>':'#'+esc(x.id))+'</td><td>'+silChips(x)+(x.kind!=="silence"&&!x.source?' <span class="tg" title="Made as a '+esc(x.kind)+' exception before silence rules: same rule, same id">'+esc(x.kind)+'</span>':"")+(x.suggest_remove?' <span class="tg" title="Nothing matched it for '+esc(L.silence_remove_days||30)+' days: remove it?">remove?</span>':"")+'</td>'
      +(x.source?'<td colspan="6" class="mut">read-only, from the Sycope silenced-hosts lookup</td>':'<td class="sct">'+big(st.today||0,"Open the hit log")+'</td><td class="sct">'+num(st.week||0)+'</td><td class="sct">'+big(st.total||0,"Open the hit log")+'</td><td class="c-l sct">'+(st.last?tm(st.last,"dhm"):'<span class="mut">never</span>')+'</td><td class="sct">'+num(st.hosts||0)+'</td><td>'+silSpark(st.days||[])+'</td>')
      +'<td class="rs" title="'+esc(x.reason)+'">'+esc(x.reason||"")+'</td><td>'+esc(x.who)+(x.source?"":" "+tm(x.created*1000,"dhm"))+'</td>'
      +'<td class="sc-x'+(exp||soon2?" st-exp":"")+'"'+(exp||soon2?' title="'+(exp?"Expired: it no longer matches":"Expires within 7 days: its alerts will count again")+'"':"")+'>'+(x.source?"":(exp?"expired ":"")+tm(x.expires*1000,"dhm")+(soon2?" · soon":""))+'</td><td class="sc-a">'
      +(L.edit&&!x.source?'<span class="btns">'+(x.kind==="silence"&&!exp?'<button type="button" class="b2" data-siledit="'+esc(x.id)+'">Edit…</button>':"")+(x.kind==="silence"?'<button type="button" class="b2" data-silext="'+esc(x.id)+'">Extend…</button>':"")+'<button type="button" class="b2 warn" data-unex="'+esc(x.id)+'">Remove…</button></span>':"")+'</td></tr>'}).join("");
  var spk=(L.silence_spikes||[]).map(function(x){return '<div class="sil-warn">'+esc(x.text)+'. It keeps silencing; open its hit log below.</div>'}).join("");
  var au=(L.audit||[]).map(function(a){return '<tr class="qr nk" style="--vc:#2f3060"><td>'+tm(a.at*1000,"dhm")+'</td><td>'+esc(a.who)+'</td><td>'+aw(a.action)+'</td><td class="mono">'+tgt(a.target)+'</td><td>'+esc(a.note)+'</td></tr>'}).join("");
  $("#view").innerHTML='<div class="sec" style="margin-top:0"><h3>Busy services: '+pc(L.explained/tot)+' of today\'s alerts'+ii("One internal server:port that a large share of your hosts reaches with the same rule, day after day: a service doing its job, not an attack. Accepting one keeps its alerts in Sycope but takes their weight off the triage, with your name, a reason and an expiry; the dialog shows what it would hide first.")+'</h3>'
    +laneTable(["Rule","Service","Hosts today","Alerts today","Seen",""],sv,"No busy-service pattern in the window.")+'</div>'
    +suggestHtml(L)
    +'<div class="sec"><h3>Rules by volume, and what their alerts are worth'+ii("Value: the evidence the triage kept from a rule's alerts after rarity and habit, against its full weight. A rule with high volume and low value is the one to tune in Sycope.")+'</h3>'
    +laneTable(["Rule","Family","Class","Alerts","Hosts","Value","Why"],rr,"No rules.")+'</div>'
    +pendingHtml(L)+'<div class="sec"><h3>Silence rules'+ii("Alerts that match every field of a rule stop counting: the weight comes off the findings, with your name, a reason and an expiry (at most "+(C.excMaxDays||90)+" days). Sycope keeps every alert and every count here includes them. A rule that suddenly silences far more than usual is reported (Health, the bell). The older known-service and allowed-behaviour exceptions are rules too, under the same number.")+(L.edit?' <button type="button" class="b2 pri" data-silnew="1" style="margin-left:8px;text-transform:none;letter-spacing:0">New rule…</button>':"")+'</h3>'+spk
    +'<div class="qwrap"><table class="qt lt slt"><thead><tr><th>#</th><th>Rule</th><th>Today</th><th>7 days</th><th>Total</th><th>Last hit</th><th>Hosts</th><th>14 days</th><th>Reason</th><th>By</th><th>Expires</th><th></th></tr></thead><tbody>'+(sr||'<tr class="nk"><td colspan="12" class="empty">None yet. Open an alert on a host page and choose Silence, or start a rule here.</td></tr>')+'</tbody></table></div></div>'
    +(L.unknown&&L.unknown.length?'<div class="sec"><h3>Alert names not in the rule catalog</h3><p class="mut">Scored as weak evidence from their MITRE tactic: '+esc(L.unknown.join(", "))+'</p></div>':"")
    +'<div class="sec"><h3>Activity</h3>'+laneTable(["When","Who","Action","Target","Note"],au,"No analyst actions yet.")+'</div>'}
// where the team keeps closing the same thing: the exception it suggests (the analyst decides, with the preview)
function pendingHtml(L){var P=L.pending||[];if(!P.length)return "";var ver=isVerified(),adm=isAdmin()&&ver,mx=C.excMaxDays||90;
  var rows=P.map(function(x){var can=L.edit&&ver&&(adm||(!L.approval&&!x.second&&!x.big)),who=x.second?"waiting for a second admin":(x.big||L.approval)?"waiting for an admin":"waiting for a confirmed user",
    tag=x.second?' <span class="tg" title="'+esc(x.kind==="host"?"A whole-host exception covers every alert family":"Credential, exfiltration, C2 or threat-intel evidence")+': an admin other than the proposer approves it, whatever SC_EXCEPTION_APPROVAL says">second person</span>':"";
    return '<tr class="qr nk" style="--vc:#e0a8ff"><td>#'+esc(x.id)+'</td><td>'+esc(x.kind)+'</td><td>'+(x.kind==="silence"?silChips(x):esc(x.rule||"*"))+tag+'</td><td class="mono">'+(x.kind==="silence"?"":esc(x.server||x.actor||"")+(x.port?":"+esc(x.port):""))+'</td><td>'+esc(x.reason)+'</td><td>'+esc(x.who)+(x.verified?"":' <span class="mut" title="Sycope had not confirmed this name">unconfirmed</span>')+' '+tm(x.created*1000,"dhm")+'</td><td>'+num(Math.min(x.days||30,mx))+' days</td><td>'
    +(can?'<span class="btns"><button type="button" class="b2 pri" data-exdec="approve" data-id="'+esc(x.id)+'">Approve…</button><button type="button" class="b2 warn" data-exdec="reject" data-id="'+esc(x.id)+'">Reject…</button></span>':'<span class="mut">'+who+'</span>')+'</td></tr>'}).join("");
  return '<div class="sec"><h3>Waiting for approval ('+num(P.length)+')'+ii("Exceptions that were proposed; they count once a user Sycope has confirmed approves them (an admin when approval is required here, or when they touch credential, exfiltration, C2 or threat-intel evidence, or are big). Never the one who proposed it.")+'</h3>'+laneTable(["#","Kind","Rule","Where","Reason","By","For",""],rows,"")+'</div>'}
function suggestHtml(L){var G=L.suggest||{},sv=G.services||[],rl=G.rules||[];if(!sv.length&&!rl.length)return "";
  var why=function(x){return num(x.closed)+' of '+hp(x.hosts,"host")+' closed ('+[x.fp?num(x.fp)+" false positive":"",x.benign?num(x.benign)+" benign":""].filter(Boolean).join(", ")+')'+(x.reasons&&x.reasons.length?' <span class="mut">· '+esc(x.reasons.map(function(r){return r[0]+(r[1]>1?" ×"+r[1]:"")}).join("; "))+'</span>':"")};
  var rows=sv.map(function(x){var key=x.rule+"|"+x.server+"|"+x.port;return '<tr class="qr nk" style="--vc:#3ecf72"><td>'+rn(x.rule)+'</td><td class="mono">'+esc(x.server)+(x.port?":"+esc(x.port):"")+'</td><td>'+why(x)+'</td><td>'+pc(x.rate)+'</td><td>'
    +(L.edit?'<button type="button" class="b2 pri" data-svc="'+esc(key)+'" data-n="'+esc(x.hosts)+'" data-why="'+esc("Suggested by the closures: "+x.closed+" of "+x.hosts+" hosts closed as false positive or benign")+'">Accept as known service…</button>':'<span class="mut">read-only</span>')+'</td></tr>'}).join("");
  var rr=rl.map(function(x){return '<tr class="qr nk" style="--vc:#c9a05b"><td>'+rn(x.rule)+'</td><td>'+why(x)+'</td><td>'+pc(x.rate)+'</td><td class="mut">tune the rule in Sycope (its threshold or scope): it fires on traffic your team does not treat as an attack</td></tr>'}).join("");
  return '<div class="sec"><h3>Suggested by your team\'s closures'+ii("Where hosts keep being closed as false positive or benign for the same thing (3 or more hosts, 80% or more of the hosts that have it). Nothing changes until someone accepts it; the dialog shows what it would hide first.")+'</h3>'
    +(rows?laneTable(["Rule","Service","Closed","Share",""],rows,""):"")+(rr?laneTable(["Rule","Closed","Share",""],rr,""):"")+'</div>'}
// ---- the host's alerts: one line per rule and pair, each alert one click away ----
function alertsHtml(D){var G=D.alert_groups||[];if(!D.alerts.length&&!G.length)return "";if(S.alertsFlat||!G.length)return alertsFlat(D);
  var rec=D.recorder&&D.recorder.on,P=D.pcap||{},me=function(ip){return ip===D.ip?'<b>'+esc(ip)+'</b>':ip?esc(ip):nul()};
  var rows=G.map(function(g,i){var gk=D.ip+"|"+i,open=!!S.gopen[gk],pcn=g.ids.filter(function(id){return P[id]&&P[id].state==="done"}).length;
    var main='<tr class="qr ag'+(pcn?" hasp":"")+'" style="--vc:#2f3060" data-ag="'+esc(gk)+'" data-rule="'+esc(g.name)+'" data-c="'+esc(g.client||"")+'" data-s="'+esc(g.server||"")+'" data-port="'+esc(g.port==null?"":g.port)+'" data-proto="'+esc(g.proto||"")+'" data-t0="'+esc(g.first)+'" data-t1="'+esc(g.last)+'" title="'+(open?"Hide":"Show")+' the alerts of this line"><td class="c-x">'+(open?"▾":"▸")+'</td><td>'+rn(g.name)+'</td><td class="mono">'+num(g.n)+'</td>'
      +'<td class="c-l" title="'+esc(fullTime(g.first)+" – "+fullTime(g.last))+'">'+tm(g.first,"dhm")+(g.n>1?' – '+tm(g.last,g.last-g.first<86400000?"hm":"dhm"):"")+'</td><td>'+sevHtml(g.severity,g.thr)+'</td>'
      +'<td class="mono">'+me(g.client)+'</td><td class="mono">'+me(g.server)+'</td><td>'+(g.port==null?nul():esc(g.port))+'</td>'
      +'<td style="white-space:nowrap">'+[alertsOf(g.name,g.client,g.server,g.first,g.last),flows(g.client,g.server,g.port,g.first,g.last),silBtn()].filter(Boolean).join(" · ")+'</td>'+(rec?'<td>'+(pcn?'<span class="badge b-done">'+num(pcn)+' PCAP</span>':"")+'</td>':"")+'</tr>';
    if(!open)return main;
    var items=D.alerts.filter(function(a){return a.name===g.name&&a.client===g.client&&a.server===g.server&&String(a.port==null?"":a.port)===String(g.port==null?"":g.port)});
    return main+items.map(function(a){return '<tr class="agi'+(P[a.id]&&P[a.id].state==="done"?" hasp":"")+'"><td></td><td colspan="3" class="mut" title="'+esc(fullTime(a.t))+'">'+tm(a.t)+'</td><td colspan="4"></td><td style="white-space:nowrap">'+[alertLink(a),flows(a.client,a.server,a.port,a.t,a.t)].filter(Boolean).join(" · ")+'</td>'+(rec?'<td>'+pcapCell(a,D)+'</td>':"")+'</tr>'}).join("")
      +(g.n>items.length?'<tr class="agi"><td></td><td colspan="'+(rec?9:8)+'" class="mut">'+num(g.n-items.length)+' older alert'+(g.n-items.length===1?"":"s")+' of this line: in Sycope (alerts link above)</td></tr>':"")});
  return '<div class="sec" data-sec="alerts" data-fold="1"><h3>Alerts naming this host: '+num(D.alerts_total)+' in '+num(G.length)+' line'+(G.length===1?"":"s")+' <button type="button" class="lnk" data-aflat="1" style="text-transform:none;letter-spacing:0">show each alert</button></h3>'
    +'<div class="grid" style="max-height:440px;overflow:auto"><table class="qt lt"><thead><tr><th></th><th>Alert</th><th>Count</th><th>First – last</th><th>Severity</th><th>Client</th><th>Server</th><th>Port</th><th>Sycope</th>'+(rec?"<th>PCAP</th>":"")+'</tr></thead><tbody>'+rows.join("")+'</tbody></table></div></div>'}
function histRow(r){var k="i:"+r.id;return '<tr class="qr'+(S.open===k?" sel":"")+'" style="--vc:'+(VC[r.verdict]||"#808297")+'" data-k="'+esc(k)+'" title="Quick look of the record">'
  +'<td class="c-l" title="'+esc(fullTime(r.opened_at*1000))+'">'+tm(r.opened_at*1000,"dhm")+'<div class="mut">'+(r.closed_at?"ended "+tm(r.closed_at*1000,"dhm"):"active")+'</div></td>'
  +'<td class="c-v">'+(r.verdict?vp(r.verdict):"")+'</td><td class="c-i"><span class="qt-t">'+esc(r.headline||r.label||"")+'</span><div class="qt-s">'+esc((r.families||[]).map(fam).join(", "))+'</div></td>'
  +'<td class="c-s">'+subjectHtml(r)+'</td><td class="c-k"><span class="kcn">'+esc(r.stage!=null?C.stages[r.stage]:"no stage")+'</span></td>'
  +'<td class="c-st">'+outcomeHtml(r)+'</td><td class="c-c">'+esc(dur(r.tth))+'</td>'
  +'<td class="c-a">'+KB+'<a class="b2 pri" href="'+esc(keyUrl(k))+'" target="_blank" rel="noopener" title="The record on its own page, in a new tab">Open ›</a></td></tr>'}
// ---- events ----
var TIP=document.getElementById("tip");
document.addEventListener("mousemove",function(e){if(e.target.closest&&e.target.closest("#view .qt"))S.lastHover=Date.now();var g=e.target.closest&&e.target.closest(".ap [data-tip]");if(!TIP)return;
  if(!g){if(TIP.dataset.ap){TIP.style.display="none";delete TIP.dataset.ap}return}
  TIP.textContent=g.getAttribute("data-tip");TIP.dataset.ap="1";TIP.style.display="block";var w=TIP.offsetWidth,hh=TIP.offsetHeight;
  var x=Math.min(e.clientX+14,innerWidth-w-8),y=e.clientY+16;if(y+hh>innerHeight-8)y=e.clientY-hh-12;TIP.style.left=x+"px";TIP.style.top=y+"px"});
var downIn=false;document.addEventListener("mousedown",function(e){downIn=!!e.target.closest("#drawer")});
function interactive(t){return !!t.closest("a,button,input,label,select,textarea,summary")}
document.addEventListener("click",function(e){var x,mod=e.metaKey||e.ctrlKey||e.shiftKey,deep=!!e.target.closest("#drawer");
  if(e.target.closest(".dlg-w"))return;
  if((x=e.target.closest(".cm-i"))&&CM){var cit=CM._items[+x.dataset.cm];if(cit&&cit.run){e.preventDefault();cmClose();cit.run()}else setTimeout(cmClose,0);return}
  if(CM&&!e.target.closest(".cm")){cmClose();return}
  if((x=e.target.closest("[data-rowmenu]"))){var mr=x.closest("tr[data-k]");if(mr)cmAt(x,rowItems(mr.dataset.k,mr));return}
  if((x=e.target.closest("[data-pivot]"))){var pl=pivotItems(x.dataset.pivot).filter(function(i){return !i.sep});if(!pl.length)pl=C.pivots.map(function(p){return {label:"Check in "+p[0],href:p[1].split("{ip}").join(encodeURIComponent(x.dataset.pivot))}});cmAt(x,pl);return}
  if((x=e.target.closest("#qact"))){if(!x.disabled)qselMenu(x);return}
  if((x=e.target.closest(".sec>h3"))&&!e.target.closest(".ii,a,input,select,textarea")&&(!e.target.closest("button")||e.target.closest(".secx"))){var sx=x.parentNode;secSet(sx,!sx.classList.contains("shut"),true);return}
  if(!e.target.closest(".gs"))gsHide();
  if((x=e.target.closest("#lbx"))){x.hidden=true;x.innerHTML="";return}
  if((x=e.target.closest("#hlpo"))){var hp0=$("#helpp");if(hp0&&!hp0.hidden&&HELP.cur===helpCtx())helpClose();else helpOpen(helpCtx());return}
  if((x=e.target.closest("#hlpx"))){helpClose();return}
  if((x=e.target.closest("#hlppin"))){try{localStorage.setItem("sc-help-pin",helpPinned()?"0":"1")}catch(y){}helpPinShow();return}
  if((x=e.target.closest("#helpp [data-help]"))){e.preventDefault();helpOpen(x.dataset.help,true);return}
  if((x=e.target.closest("#helpp img[data-zoom]"))){zoom(x.getAttribute("src"));return}
  if(e.target.closest("#helpp"))return;
  if((x=e.target.closest("[data-dv]"))){window.SCV.setInc(x.dataset.dv);return}
  if((x=e.target.closest("[data-alld]"))){window.SCV.setInc("full");return}
  if(S.open&&!downIn&&!deep&&!e.target.closest("[data-peek],[data-open],tr[data-k],.toast,[data-unrev]"))closeDetail();
  if((x=e.target.closest("[data-dback]"))){var back=S.dstack.pop();if(back)openDetail(back);return}
  if((x=e.target.closest("[data-unrev]"))){UNREV=!unrevIsOpen();try{localStorage.setItem("sc-unrev",UNREV?"1":"0")}catch(y){}renderQueue();return}
  if((x=e.target.closest("[data-gowhy]"))){e.preventDefault();var wr=$("#"+rootOf(x)),ws=wr&&wr.querySelector('[data-sec="why"]');if(ws){secPrep(ws);secSet(ws,false,false);ws.scrollIntoView({block:"start",behavior:"smooth"})}return}
  if((x=e.target.closest("[data-tab]"))){e.preventDefault();S.tab=x.dataset.tab;sync();render();if(S.tab!=="queue")loadLane(S.tab);HELP.manual=false;helpFollow();return}
  if((x=e.target.closest("[data-exp]"))){e.preventDefault();var ek=x.dataset.exp;if(x.getAttribute("aria-expanded")==="true"){S.exp.delete(ek);S.col.add(ek)}else{S.exp.add(ek);S.col.delete(ek)}
    try{sessionStorage.setItem("sc-exp",JSON.stringify(Array.from(S.exp)));sessionStorage.setItem("sc-col",JSON.stringify(Array.from(S.col)))}catch(y){}renderQueue();return}
  if((x=e.target.closest("[data-pause]"))){S.paused=!S.paused;try{sessionStorage.setItem("sc-paused",S.paused?"1":"0")}catch(y){}if(!S.paused)applyPending();pendShow();if(S.data&&!INC&&S.tab==="queue")renderQueue();return}
  if((x=e.target.closest("[data-pend]"))){applyPending();return}
  if((x=e.target.closest("[data-wf]"))){S.wf=S.wf===x.dataset.wf?"":x.dataset.wf;S.limit=60;sync();renderQueue();return}
  if((x=e.target.closest("[data-ag]"))&&!interactive(e.target)){var gk=x.dataset.ag;S.gopen[gk]=!S.gopen[gk];redrawRoot(rootOf(x));return}
  if((x=e.target.closest("[data-aflat]"))){S.alertsFlat=x.dataset.aflat==="1";var ar=$("#"+rootOf(x));redrawRoot(rootOf(x));var as=ar&&ar.querySelector('[data-sec="alerts"]');if(as){secPrep(as);secSet(as,false,true)}return}
  if((x=e.target.closest("[data-peek]"))){if(mod)return;e.preventDefault();openDetail(x.dataset.peek,false,deep);return}
  if((x=e.target.closest("[data-act]"))){doAct(x);return}
  if((x=e.target.closest("#me"))){if(ME.src!=="sycope")askName();return}
  if((x=e.target.closest("[data-bulk]"))){doBulk(x.dataset.bulk,x);return}
  if((x=e.target.closest("[data-selnone]"))){var w0=rootOf(x);R[w0].sel.clear();$$("[data-sel]",$("#"+w0)).forEach(function(c){c.checked=false});updateBulk(w0);return}
  if((x=e.target.closest("[data-hall]"))){var w1=rootOf(x);R[w1].hall=true;redrawRoot(w1);return}
  if((x=e.target.closest("[data-svc]"))){addService(x.dataset.svc,x.dataset.n,x);return}
  if((x=e.target.closest("[data-unex]"))){removeEx(x.dataset.unex,x);return}
  if((x=e.target.closest("[data-silline]"))){e.preventDefault();e.stopPropagation();silenceLine(x.closest("tr").dataset);return}
  if((x=e.target.closest("[data-silnew]"))){silenceRule({});return}
  if((x=e.target.closest("[data-siledit]"))){var rr=((S.lanes.tuning||{}).silence||[]).filter(function(y){return String(y.id)===x.dataset.siledit})[0];if(rr)silenceRule({id:rr.id,rule:rr.rule,src:rr.src,dst:rr.dst,port:rr.port,proto:rr.proto,win_days:rr.win_days,win_from:rr.win_from,win_to:rr.win_to,reason:rr.reason,days:rr.days&&[1,7,14,30,60,90].indexOf(rr.days)>=0?rr.days:30});return}
  if((x=e.target.closest("[data-silext]"))){silenceExtend({id:x.dataset.silext});return}
  if((x=e.target.closest("[data-silhits]"))){silenceHits(x.dataset.silhits);return}
  if((x=e.target.closest("[data-exdec]"))){decideEx(x.dataset.id,x.dataset.exdec,x);return}
  if((x=e.target.closest("[data-fl]"))){showFlows(x);return}
  if((x=e.target.closest("[data-sort]"))){var sk=x.dataset.sort;if(!sk)S.sort=null;else if(!S.sort||S.sort.k!==sk)S.sort={k:sk,d:1};else if(S.sort.d>0)S.sort.d=-1;else S.sort=null;
    try{sessionStorage.setItem("sc-sort",JSON.stringify(S.sort))}catch(y){}renderQueue();return}
  if((x=e.target.closest("[data-qbulk]"))){qselAct(x.dataset.qbulk);return}
  if((x=e.target.closest("[data-qnone]"))){S.qsel.clear();$$("[data-qsel]").forEach(function(c){c.checked=false});qselBar();return}
  if((x=e.target.closest("[data-hfclear]"))){var wh=rootOf(x);R[wh].hf={q:"",net:"",st:""};R[wh].sel.clear();redrawRoot(wh);return}
  if((x=e.target.closest("[data-pcapall]"))){reqPcapAll(rootOf(x));return}
  if((x=e.target.closest("[data-pcap]"))){reqPcap(x.dataset.pcap,rootOf(x));return}
  if((x=e.target.closest("[data-copy]"))){copy(x.dataset.copy);return}
  if((x=e.target.closest("[data-stepsall]"))){S.stepsAll=true;redrawRoot(rootOf(x));return}
  if((x=e.target.closest("[data-pconly]"))){S.pcapOnly=!S.pcapOnly;redrawRoot(rootOf(x));return}
  if((x=e.target.closest("[data-ticket]"))){var w2=$("#"+rootOf(x)),k2=w2&&w2.dataset.k,TD=k2&&S.det[k2];if(TD)copy(ticketText(TD));return}
  if((x=e.target.closest("[data-ex]"))){addEx(x);return}
  if((x=e.target.closest("[data-handover]"))){getJ("handover"+(S.hf.hours?"?hours="+S.hf.hours:"")).then(function(H){copy(handoverText(H))}).catch(function(e2){toast(e2.message,true)});return}
  if((x=e.target.closest("[data-vd]"))){var k=x.dataset.vd;if(S.vd.has(k))S.vd.delete(k);else S.vd.add(k);S.limit=60;sync();if(k==="watch")load();else renderQueue();return}
  if((x=e.target.closest("[data-open]"))){if(e.target.closest("a[target]"))return;e.preventDefault();if(mod){window.open(keyUrl(x.dataset.open),"_blank","noopener");return}openDetail(x.dataset.open,false,deep);return}
  if((x=e.target.closest("tr[data-k]"))&&!interactive(e.target)){if(mod){window.open(keyUrl(x.dataset.k),"_blank","noopener");return}openDetail(x.dataset.k,false,deep);return}
});
document.addEventListener("auxclick",function(e){if(e.button!==1)return;var x=e.target.closest("tr[data-k]");if(x&&!interactive(e.target)){e.preventDefault();window.open(keyUrl(x.dataset.k),"_blank","noopener")}});
document.addEventListener("change",function(e){var x=e.target,w=rootOf(x);if(x.dataset&&x.dataset.step){stepCheck(x);return}
  if(x.dataset&&x.dataset.qsel){if(x.checked)S.qsel.set(x.dataset.qsel,1);else S.qsel.delete(x.dataset.qsel);qselBar();return}
  if(x.dataset&&(x.dataset.hfn||x.dataset.hfs)){var f=R[w].hf||(R[w].hf={q:"",net:"",st:""});if(x.dataset.hfn)f.net=x.value;else f.st=x.value;R[w].sel.clear();redrawRoot(w);return}
  if(x.dataset&&x.dataset.sel){if(x.checked)R[w].sel.add(x.dataset.sel);else R[w].sel.delete(x.dataset.sel);updateBulk(w);return}
  if(x.classList&&x.classList.contains("selall")&&R[w].bulk){if(x.checked)R[w].bulk.ips.forEach(function(ip){R[w].sel.add(ip)});else R[w].sel.clear();$$("[data-sel]",$("#"+w)).forEach(function(c){c.checked=R[w].sel.has(c.dataset.sel)});updateBulk(w)}});
// the quick look is as wide as the analyst drags it (remembered in this browser)
(function(){var g=$("#drwg"),dr=$("#drawer");if(!g||!dr)return;try{var w0=+localStorage.getItem("sc-drw-w");if(w0>=420)dr.style.width=Math.min(w0,innerWidth-60)+"px"}catch(x){}
  g.addEventListener("mousedown",function(e){e.preventDefault();dr.classList.add("rs");document.body.style.userSelect="none";
    var mv=function(ev){dr.style.width=Math.max(420,Math.min(innerWidth-60,innerWidth-ev.clientX))+"px"},
        up=function(){document.removeEventListener("mousemove",mv);document.removeEventListener("mouseup",up);dr.classList.remove("rs");document.body.style.userSelect="";try{localStorage.setItem("sc-drw-w",String(parseInt(dr.style.width,10)))}catch(x){}};
    document.addEventListener("mousemove",mv);document.addEventListener("mouseup",up)})})();
document.addEventListener("contextmenu",function(e){if(e.shiftKey){cmClose();return}var items=cmItemsFor(e.target);if(!items){cmClose();return}if(cmShow(items,e.clientX,e.clientY))e.preventDefault()});
document.addEventListener("keydown",function(e){if(!CM)return;var its=$$(".cm-i",CM),i=its.indexOf(document.activeElement);
  if(e.key==="Escape"){e.preventDefault();e.stopPropagation();cmClose()}else if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();if(!its.length)return;i=e.key==="ArrowDown"?(i+1)%its.length:(i-1+its.length)%its.length;its[i].focus()}
  else if(e.key==="Tab")cmClose()},true);
window.addEventListener("resize",cmClose);document.addEventListener("scroll",function(e){if(CM&&!(e.target&&e.target.closest&&e.target.closest(".cm")))cmClose()},true);
// every section a render puts on the page becomes a card that folds (the queue's, the lanes', the incidents', the quick look's)
["view","drwb"].forEach(function(id){var r=$("#"+id);if(!r)return;var all=function(){$$(".sec",r).forEach(secPrep)};all();if(window.MutationObserver)new MutationObserver(all).observe(r,{childList:true,subtree:true})});
// the filter over a group's hosts redraws as the analyst types, keeping the caret
var HFT=null;document.addEventListener("input",function(e){var x=e.target;if(!x.dataset||!x.dataset.hfq)return;var w=rootOf(x);clearTimeout(HFT);
  HFT=setTimeout(function(){var f=R[w].hf||(R[w].hf={q:"",net:"",st:""});f.q=x.value;var pos=x.selectionStart;R[w].sel.clear();redrawRoot(w);
    var n=$("#"+w+" [data-hfq]");if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(y){}}},250)});
(function(){var q=$("#gsq");if(!q)return;
  q.addEventListener("input",function(){clearTimeout(GS.t);var v=q.value.trim();if(v.length<2){gsHide();return}
    GS.t=setTimeout(function(){var my=++GS.seq;getJ("search?q="+encodeURIComponent(v)).then(function(d){if(my===GS.seq)gsRender(d)}).catch(function(){})},220)});
  q.addEventListener("keydown",function(e){if(e.key==="Escape"){e.stopPropagation();gsHide();q.blur()}else if(e.key==="Enter"&&GS.first){e.preventDefault();gsHide();openDetail(GS.first,false,false)}});
  q.addEventListener("focus",function(){var r=$("#gsr");if(r&&q.value.trim().length>=2&&r.innerHTML)r.hidden=false})})();
var dx=$("#drwx");if(dx)dx.onclick=closeDetail;
document.addEventListener("keydown",function(e){if(e.key!=="Escape")return;var l=$("#lbx");if(l&&!l.hidden){l.hidden=true;l.innerHTML="";return}if(S.open)closeDetail()});
window.addEventListener("pagehide",saveScroll);
if(!INC){try{history.scrollRestoration="manual"}catch(x){}}
$("#reload").onclick=refreshAll;  // asked for: it does not wait for the mouse to leave the list
var bell=$("#bell");if(bell)bell.onclick=function(){if(notifyOn()){try{localStorage.setItem("sc-notify","0")}catch(x){}notify(S.data||{});return}
  if(!window.Notification){alert("This browser has no notifications.");return}Notification.requestPermission().then(function(p){try{localStorage.setItem("sc-notify",p==="granted"?"1":"0")}catch(x){}notify(S.data||{})})};
//@@CONFIG@@
// the Simple | Full toggle (pages.py): redraw what is on screen, keep the tab, the scroll position and the open quick look
function viewChanged(sc){INCS=!!window.SCV.inc;LISTS=INC?INCS:!!window.SCV.simple;var y=window.scrollY,q=!INC&&sc==="list",d=INC||sc==="incident";
  if(q||INC){simpleState();R.view.sel.clear();S.qsel.clear()}if(d)R.drwb.sel.clear();
  if(INC){if(S.det[incKey()])redrawRoot("view")}else if(q&&S.data){render();S.force=true;load()}
  if(d&&S.open){drwTitle(S.open);if(S.det[S.open])redrawRoot("drwb")}window.scrollTo(0,y)}
if(window.SCV)window.SCV.on(viewChanged);
helpPinShow();if(!INC&&helpPinned())helpOpen(helpCtx());
loadMe().then(adminCheck);if(INC)loadIncident();else load();
})();
"""
_JS = _JS_BASE.replace("//@@CONFIG@@", confui.JS).replace("//@@SHARED@@", _WORK_JS_SHARED)


def _value(st: dict) -> str:
    return f"{st['value'] * 100:.0f}%" if st.get("base") else "-"


def evidence_doc(board) -> str:
    """The Scoring page's section on the triage model, with the rule catalog and today's numbers per rule."""
    from html import escape as _e

    from sycope_clusters import evidence as ev
    from sycope_clusters.params import FACTORY

    p = board.params if board is not None else FACTORY          # the numbers the board was scored with
    stats = board.rule_stats if board else {}
    rows = []
    for r in sorted(CATALOG.values(), key=lambda r: (list(FAMILIES).index(r.family), r.name)):
        st = stats.get(r.name)
        rows.append(f"<tr><td>{_e(r.name)}</td><td>{_e(FAMILIES[r.family][0])}</td><td>{r.cls}</td>"
                    f"<td>{_e(STAGES[r.stage]) if r.stage is not None else '-'}</td><td>{_e(r.subject)}</td>"
                    f"<td>{st['alerts']:,}</td><td>{st['actors']:,}</td>"
                    f"<td>{_value(st)}</td></tr>"
                    if st else
                    f"<tr><td>{_e(r.name)}</td><td>{_e(FAMILIES[r.family][0])}</td><td>{r.cls}</td>"
                    f"<td>{_e(STAGES[r.stage]) if r.stage is not None else '-'}</td><td>{_e(r.subject)}</td>"
                    f"<td class='mut'>0</td><td class='mut'>0</td><td class='mut'>-</td></tr>")
    chains = "".join(f"<tr><td>{k}</td><td>{_e(v[0])}</td><td>+{p[f'chain.{k}.bonus']:g}</td><td>{_e(v[2])}</td></tr>"
                     for k, v in ev.CHAINS.items())
    classes = "".join(f"<tr><td><b>{c}</b></td><td>{b:g}</td><td>{_e(t)}</td></tr>" for c, b, t in (
        ("A", p["class_bits.A"], "indicator match: threat intel IP or domain, known-bad TLS client"),
        ("B", p["class_bits.B"], "attack behaviour: scan, brute force, lateral movement, beacon, upload"),
        ("C", p["class_bits.C"], "weak or ambiguous: anomalies, odd ports, LLMNR; only the strongest weak signal counts"),
        ("D", p["class_bits.D"], "hygiene, asset or policy: never threat, listed under Hygiene")))
    pc = lambda x: f"{x * 100:.0f}%"
    impacts = ", ".join(f"{n} {p['impact.' + k]:g}" for n, k in zip(STAGES, "0123"))
    obj = STAGES[-1]
    odds = ", ".join(f"{b:g} bits = {pc(1 / (1 + 2 ** -(b - p['prior_bits'])))}"
                     for b in (p["prior_bits"] - 2, p["prior_bits"], p["prior_bits"] + 2, p["prior_bits"] + 4))
    act_chains = ", ".join(sorted(p["act_chains"]))
    return f"""
<div class="card doc"><h2 class="ct">Triage: the evidence model</h2>
<p>The Triage page does not rank clusters by the MITRE tag of their alerts. A template's tactic says what an alert
<i>could</i> mean; on the lab, "Suspicious Port - Allowlist" (tag C2) fires on 28% of all hosts and "IoT/OT Device
Discovered" is tagged C2 too, so two thirds of the clusters "reached the last stage". Instead every alert becomes part of a
<b>finding</b> (one rule between one host and one counterpart) and every finding carries <b>bits of evidence</b>: log2 of
how much more likely it is under attack than in normal traffic. Bits add up like a scorecard, and each one has a reason
the analyst can read.</p>
<div class="formula">bits(finding) = min( class + severity + threshold level,  rarity,  habit )  - deductions
  rarity = log2(1 / share of hosts that have this rule with this counterpart on a normal day)   (history, not today)
  habit  = log2((D + 2) / (d + 1))   when the host already had this rule on d of the last D days

evidence(host) = Σ over families of the strongest finding  + kill-chain progression  + chain rules
confidence     = 1 / (1 + 2^-(evidence - {p['prior_bits']:g}))      {odds}
risk           = confidence × impact of the highest stage with confirmed evidence ({impacts}; a command channel weighs {obj} at least; crown jewel × {p['crown_mult']:g})</div>
<p>A stage has <b>evidence</b> when one of its findings carries at least {p['confirm_bits']:g} bits (likelihood ratio {2 ** p['confirm_bits']:g});
weaker evidence makes it only <i>suspected</i> (hollow on the kill-chain bar). The word <b>confirmed</b> in a reason means two
things at once: that evidence, and a confidence of {pc(p['wording.conf_high'])} or more; at a lower confidence the same evidence is called
"&lt;Stage&gt;-stage evidence". The stages are the Unified Kill Chain in four steps: Recon, Foothold (a beacon, a covert channel
or a listed command-and-control address proves one), Lateral, and Objectives (data out, floods). A command channel keeps the
verdict and the risk weight of Objectives (a missed one costs as much), whatever stage it is drawn at. Rules that see the same thing do not add
up (the strongest finding of a family counts), weak signals do not stack, an "upload" alert whose bytes went the other
way is read as a download anomaly, an upload under the host's normal daily upload (and never under
{p['exfil_floor_bytes'] / 1e6:g} MB) cannot confirm exfiltration, and a threat-intel hit or beacon to an outside shared cloud or
CDN address loses a bit. Threat intel never habituates below half its
weight, and the same intel or C2 contact with one non-cloud counterpart on {p['persist_days']} of the last 7 days is read as persistence
(CR-10), not as habit: a beacon that runs for weeks gets more weight, not less.</p>
<div class="cols2"><div><h3>Classes</h3><div class="grid"><table style="min-width:0"><tr><th>Class</th><th>Bits</th><th>Meaning</th></tr>{classes}</table></div></div>
<div><h3>Chain rules (on confirmed families)</h3><div class="grid"><table style="min-width:0"><tr><th>Rule</th><th>Name</th><th>Bonus</th><th>When</th></tr>{chains}</table></div>
<p class="mut" style="font-size:12px">CR-08 +{p['chain.CR-08.same_hosts_bonus']:g} and CR-09 +{p['chain.CR-09.same_hosts_bonus']:g} more when the second step hits a host the first step touched
(the scan alert lists its targets).</p></div></div>
<h3>Verdicts (a decision table, the page shows which line matched)</h3>
<div class="grid"><table style="min-width:0"><tr><th>Verdict</th><th>When</th></tr>
<tr><td>Act now</td><td>{act_chains} with confidence ≥ {pc(p['verdict.act_chain_conf'])}; CR-08/CR-09 against the same hosts with ≥ {pc(p['verdict.linked_conf'])};
a command channel or Objectives with evidence and confidence ≥ {pc(p['verdict.impact_conf'])}; the same evidence on a crown jewel (any confidence); a crown jewel at Lateral or later
with ≥ {pc(p['verdict.crown_stage_conf'])}</td></tr>
<tr><td>Investigate</td><td>a command channel or Objectives with evidence (any confidence: missing an exfiltration or a command channel costs far more than a look); risk ≥ {p['verdict.investigate_risk']:g}; CR-03 (full kill chain across the week), CR-06 (attacked, then calling home), CR-08, CR-09 or CR-10 (persistent channel);
a threat-intel contact the host never had before</td></tr>
<tr><td>Review</td><td>risk ≥ {p['verdict.review_risk']:g}, any confirmed stage, or any threat-intel contact</td></tr>
<tr><td>Watch</td><td>everything else: weak or background signals</td></tr></table></div>
<p>Inside a verdict the queue is ordered by the stage first (a command channel or Objectives above any Lateral),
then by risk (SC_STAGE_ORDER=stage, the default; =risk orders by risk only). On the 14 expert-ranked reference cases
the stage order agrees with the expert ranking at Spearman 0.84, the risk order at 0.29.</p>
<p>Hosts with the same verdict and the same chain rules (or the same confirmed families) form a <b>story</b>; more hosts
of one network segment at Investigate or above than chance explains for its size (at least five) form a <b>campaign</b>. In the queue each is one <b>incident</b> with its own page:
a single host, a group of hosts, or a campaign that holds the stories and hosts mostly sitting in it (a host counts once,
under the verdict of the incident it is in). A handled host stays out of the queue until it shows a family, chain rule or
verdict it did not show when it was handled.</p>
<h3>Rule catalog (the product owns this table; SC_RULES_FILE overrides it)</h3>
<div class="grid" style="max-height:520px;overflow:auto"><table><tr><th>Alert name</th><th>Family</th><th>Class</th>
<th>Stage it can confirm</th><th>Subject</th><th>Alerts today</th><th>Hosts</th><th>Value kept</th></tr>{"".join(rows)}</table></div>
</div>
"""


_DIGEST_CSS = """
.dg h2{font-size:16px;margin:22px 0 8px;font-weight:600}.dg p{line-height:1.5;max-width:120ch}
.dg .big{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:8px;margin:10px 0}
.dg .big div{background:var(--panel);border-radius:5px;padding:12px 14px}.dg .big b{display:block;font-size:26px;font-weight:400}
.dg .big span{font-size:12px;color:var(--mut)}.dg ol{margin:0;padding-left:20px}.dg li{margin:0 0 6px;line-height:1.45}
.dg .v{display:inline-block;min-width:92px;font:600 11px "Kumbh Sans",sans-serif;text-transform:uppercase;letter-spacing:.4px}
@media print{body{background:#fff!important;color:#111}.top,.menu{display:none}.dg .big div,.card{background:#f2f3f7!important;color:#111}
  .mut,.dg .big span{color:#555!important}a{color:#111}th{background:#ddd!important;color:#111!important}td{background:#fff!important;color:#111!important}}
"""


def _dur(s: float | None) -> str:
    """A time span the way the queue says it: 45 s, 12 min, 3 h 10 min, 4 days."""
    if s is None:
        return "-"
    s = round(s)
    if s < 90:
        return f"{s} s"
    m = round(s / 60)
    if m < 90:
        return f"{m} min"
    h = m // 60
    return f"{h} h" + (f" {m % 60} min" if m % 60 else "") if h < 48 else f"{round(h / 24)} days"


def _trend_section(board, store, _e) -> str:
    """S-8: week over week per verdict, the median time to the first action and to close, SLA breaches, and Act now
    incidents per day, from the incident records of the last two weeks (sla.py)."""
    from sycope_clusters import sla as sla_mod

    p = board.params
    tr = sla_mod.trends(store.sla_rows(board.now - 14 * 86400), p, board.now, int(p["calendar.utc_offset_min"]))
    names = {"act": "Act now", "investigate": "Investigate", "review": "Review"}

    def na(v, what):
        return _dur(v) if v is not None else f'<span title="{_e(what)}">n/a</span>'

    rows = []
    for v in ("act", "investigate", "review"):
        w, pr = tr["week"][v], tr["prev"][v]
        ch = f"{w - pr:+d}" + (f" ({(w - pr) / pr * 100:+.0f}%)" if pr else " (none before)" if w else "")
        sla_on = v in sla_mod.VERDICTS
        rows.append(
            f'<tr><td><span class="v" style="color:{VERDICT[v][1]}">{_e(names[v])}</span></td><td>{w}</td><td>{pr}</td>'
            f"<td>{_e(ch)}</td>"
            + (f"<td>{na(tr['mtta'][v], 'No incident of this verdict was acted on in the last 7 days')}</td>"
               f"<td>{na(tr['mttr'][v], 'No incident of this verdict was closed or escalated in the last 7 days')}</td>"
               f"<td>{tr['breaches_24h'][v]}</td><td>{tr['breaches_7d'][v]}</td>" if sla_on else
               '<td colspan="4" class="mut">no SLA</td>') + "</tr>")
    days = "".join(f'<td title="{_e(d)}"><b>{n}</b><br><span class="mut">{_e(d[5:])}</span></td>'
                   for d, n in tr["act_per_day"])
    return f"""<h2>Trends and SLA (7 days)</h2>
<p class="mut" style="font-size:12px">Top-level incidents, by the verdict they peaked at. The clock starts when an incident first
shows that verdict. SLA limits: Act now, first action within {p['sla.act.ack_min']:g} min and closed or escalated within
{p['sla.act.handle_h']:g} h; Investigate, {p['sla.investigate.ack_h']:g} h and {p['sla.investigate.handle_h']:g} h (parameters sla.*, in the
Configuration). MTTA is over the incidents first acted on in the last 7 days, MTTR over those closed or escalated in them.</p>
<div class="grid"><table><tr><th>Verdict</th><th>Incidents, last 7 days</th><th>The 7 days before</th><th>Change</th>
<th title="MTTA: median time from the incident showing its verdict to the first analyst action, over the incidents first acted on in the last 7 days">Median time to first action (MTTA)</th>
<th title="MTTR: median time from the incident showing its verdict to a close with an outcome or an escalation, over the incidents closed or escalated in the last 7 days">Median time to close (MTTR)</th>
<th title="Deadlines that passed without the action, or were met late: last 24 hours">SLA breaches, 24 h</th>
<th title="Deadlines that passed without the action, or were met late: last 7 days">SLA breaches, 7 d</th></tr>{"".join(rows)}</table></div>
<h3 style="font-size:14px;margin:14px 0 6px">Act now incidents per day</h3>
<div class="grid"><table><tr>{days}</tr></table></div>"""


def digest_page(settings: Settings, board, store, offset_min: int = 0) -> str:
    """One page for the security manager: what the triage found in the last 24 h, in words, printable."""
    from html import escape as _e

    from sycope_clusters import triage as tri
    from sycope_clusters.evidence import CHAINS, conf_text
    from sycope_clusters.pages import _page
    from sycope_clusters.rules import display_name as rn

    pl = fmt.plural
    if board is None:
        return _page("Daily digest", '<div class="card">The board is not built yet.</div>', "digest", settings,
                     sub="Daily digest", offset_min=offset_min)
    t = store.triage() if store else {}
    q = tri.queue(board, t, order=settings.stage_order)
    f = tri.funnel(board, q)
    off = int(board.params["calendar.utc_offset_min"])
    when = f"{fmt.tm(board.now, board.now, off, 'dt')} {fmt.zone(off)}"          # a date always: the page is printed and read later
    lab = {k: v[0] for k, v in VERDICT.items()}

    def item_line(it: dict) -> str:
        if it["type"] == "campaign":
            return (f'<li><span class="v" style="color:{VERDICT[it["verdict"]][1]}">{_e(lab[it["verdict"]])}</span>'
                    f'<b>{_e(it["title"])}</b>: {pl(it["count"], "host")} in {pl(it["children_n"], "incident")}, {it["new"]:,} new '
                    f'today; families: {_e(", ".join(FAMILIES[k][0] for k in it["families"][:4]))}'
                    f'{"; chain rules: " + _e(", ".join(CHAINS[k][0] for k in it["chains"][:3])) if it["chains"] else ""}'
                    f'</li>')
        if it["type"] == "story":
            return (f'<li><span class="v" style="color:{VERDICT[it["verdict"]][1]}">{_e(lab[it["verdict"]])}</span>'
                    f'<b>{_e(it["title"])}</b>: {pl(it["count"], "host")} ({_e(", ".join(n for n, _ in it["nets"][:3]))}), '
                    f'up to {conf_text(it["conf"])} confidence. e.g. {_e((it["sample"] or [""])[0])}</li>')
        return (f'<li><span class="v" style="color:{VERDICT[it["verdict"]][1]}">{_e(lab[it["verdict"]])}</span>'
                f'<b class="mono">{_e(it["ip"])}</b>{" (" + _e(it["name"]) + ")" if it.get("name") else ""}: '
                f'{_e(it["headline"])}. <span class="mut">{_e(it["reason"])}</span></li>')

    act = [i for i in q["items"] if i["verdict"] == "act"]
    inv = [i for i in q["items"] if i["verdict"] == "investigate"][:10]
    hot = [x for x in board.targets if x["heat"] == "hot"][:6]
    hostile = [x for x in board.externals if x["rating"] == "hostile"][:6]
    svc = board.tuning["services"][:6]
    hyg = board.hygiene[:6]
    acts = tri.activity(store, 400) if store else []
    since = board.now - 86400
    today_acts = [a for a in acts if a["at"] >= since]
    by = {}
    for a in today_acts:
        by[a["action"]] = by.get(a["action"], 0) + 1
    words = {**triage.ACTION_WORDS, **cluster_work.ACTION_WORDS}
    activity = ", ".join(f'<span title="{_e(k)}">{_e(words.get(k, k))}</span>: {v:,}' for k, v in
                         sorted(by.items(), key=lambda kv: (words.get(kv[0], kv[0]), kv[0]))) or "No actions."
    big = "".join(f"<div><b>{v}</b><span>{_e(k)}</span></div>" for k, v in (
        ("alerts in 24 h", f"{f['alerts']:,}"), ("findings", f"{f['findings']:,}"),
        ("busy-service share", f"{f['service_alerts'] / max(1, f['alerts']) * 100:.0f}%"),
        ("incidents", f"{f['incidents']:,} ({pl(f['incident_hosts'], 'host')})"),
        ("to act on now", f"{f['act_items']:,} ({pl(f['act'], 'host')})"),
        ("to investigate", f"{f['investigate_items']:,} ({pl(f['investigate'], 'host')})")))
    body = f"""
<div class="dg">
<h1 class="ptitle">Security digest <span class="mut" style="font-size:14px;font-weight:400">{_e(when)}, last 24 hours</span></h1>
<p>Sycope raised {f['alerts']:,} alerts. The triage merged them into {f['findings']:,} findings (one rule between one host
and one counterpart), recognised {pl(f['services'], 'busy internal service')} that explain
{f['service_alerts'] / max(1, f['alerts']) * 100:.0f}% of the volume, and grouped the rest into {pl(f['incidents'], 'incident')}
({pl(f['incident_hosts'], 'host')}). <b>{pl(f['act_items'], 'incident')} {"needs" if f['act_items'] == 1 else "need"} action now ({pl(f['act'], 'host')}), {f['investigate_items']:,}
{"needs" if f['investigate_items'] == 1 else "need"} investigation ({pl(f['investigate'], 'host')}).</b>
{pl(q['handled'], 'host')} {"was" if q['handled'] == 1 else "were"} handled by analysts and {"stays" if q['handled'] == 1 else "stay"} off the queue until {"it changes" if q['handled'] == 1 else "they change"}.</p>
<div class="big">{big}</div>
<h2>Act now</h2>{"<ol>" + "".join(item_line(i) for i in act) + "</ol>" if act else '<p class="mut">Nothing.</p>'}
<h2>Investigate (top {len(inv)})</h2>{"<ol>" + "".join(item_line(i) for i in inv) + "</ol>" if inv else '<p class="mut">Nothing.</p>'}
<h2>Under attack</h2>{"<ol>" + "".join(f'<li><b class="mono">{_e(x["ip"])}</b>: {pl(x["attackers"], "attacker")}, {x["external"]:,} external; {_e(", ".join(FAMILIES[k][0] for k in x["families"][:3]))}{" · threat intel: " + _e(", ".join(x["ti"])) if x["ti"] else ""}</li>' for x in hot) + "</ol>" if hot else '<p class="mut">No hot targets.</p>'}
<h2>Hostile external IPs</h2>{"<ol>" + "".join(f'<li><b class="mono">{_e(x["ip"])}</b> {_e(x["asn_label"] or "")}: touched {pl(x["in_hosts"] + x["out_hosts"], "host")}{" · " + _e(", ".join(x["ti"])) if x["ti"] else ""}</li>' for x in hostile) + "</ol>" if hostile else '<p class="mut">None.</p>'}
<h2>Noise the triage set aside</h2>{"<ol>" + "".join(f'<li>{_e(rn(x["rule"]))} to <span class="mono">{_e(x["server"])}{":" + _e(x["port"]) if x["port"] else ""}</span>: {pl(x["actors"], "host")}, {pl(x["alerts"], "alert")} ({x["share_alerts"] * 100:.0f}% of all){" · accepted" if x["excepted"] else ""}</li>' for x in svc) + "</ol>" if svc else '<p class="mut">None.</p>'}
<h2>Hygiene</h2>{"<ol>" + "".join(f'<li>{_e(rn(x["rule"]))}: {pl(x["hosts"], "host")}, {pl(x["alerts"], "alert")}</li>' for x in hyg) + "</ol>" if hyg else '<p class="mut">Nothing.</p>'}
<h2>Analyst activity (24 h)</h2><p>{activity}</p>
{_trend_section(board, store, _e) if store else ""}
<p class="mut" style="font-size:12px">Deterministic: every verdict above has its reason and its evidence term by term on the Triage page.</p>
</div>"""
    return _page("Security digest", f"<style>{_DIGEST_CSS}</style>" + body, "digest", settings, sub="Daily digest",
                 offset_min=off)
