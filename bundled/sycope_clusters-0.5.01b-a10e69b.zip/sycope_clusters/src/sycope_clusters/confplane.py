"""The configuration plane: the administrator's settings as numbered versions in the state database.

A body is plain JSON:

    {"schema_version": 1, "params": {parameter id: value}, "catalog": {rule: {"family", "class", "stage",
     "subject", "kind", "ti"}}, "playbook": [overlay ops], "internal": {ip: true | false}, "note": text}

Edit -> draft -> (preview on live data: Live.preview_config) -> publish -> active. A version is only ever written
when `validate` finds nothing wrong, and again checked when it is published; going back is a rollback, which copies
an old body into a new published version. A file `config-import.json` in the state directory is the way in when
nobody can reach the pages (break-glass): it goes through the same checks and is audited as "file".
"""

from __future__ import annotations

import ipaddress
import json
import logging
import time
from pathlib import Path

from sycope_clusters import params, playbook, rules

log = logging.getLogger(__name__)
SCHEMA_VERSION = 1
FILE_NAME = "config-import.json"
KEYS = ("params", "catalog", "playbook", "internal", "note")
CATALOG_FIELDS = ("family", "class", "stage", "subject", "kind", "ti", "technique", "tactic", "c2", "variants")
OVERLAY_OPS = playbook.OPS
DRAFT_KEEP_S = 24 * 3600      # an unpublished draft (a preview) is kept this long


class ConfigError(Exception):
    """A configuration that is not allowed; `errors` has one plain sentence per problem."""

    def __init__(self, errors: list[str]) -> None:
        super().__init__("; ".join(errors))
        self.errors = list(errors)


def empty_body() -> dict:
    return {"schema_version": SCHEMA_VERSION, "params": {}, "catalog": {}, "playbook": [], "internal": {}, "note": ""}


def _v0_to_v1(body: dict) -> dict:
    return {**body, "schema_version": 1}


_MIGRATIONS = {0: _v0_to_v1}      # schema_version -> function that returns the body one version newer


def migrate(body: dict) -> dict:
    """The body at the current schema version (a body without a version counts as version 0). A copy; a body from
    a newer release than this one is an error."""
    if not isinstance(body, dict):
        raise ConfigError(["the configuration must be a JSON object"])
    version = body.get("schema_version", 0)
    if isinstance(version, bool) or not isinstance(version, int) or version < 0 or version > SCHEMA_VERSION:
        raise ConfigError([f"schema_version {version!r} is not known to this release (up to {SCHEMA_VERSION})"])
    try:
        out = json.loads(json.dumps(body))
    except RecursionError:
        raise ConfigError(["the configuration is nested too deeply"]) from None
    while version < SCHEMA_VERSION:
        out = _MIGRATIONS[version](out)
        version = out["schema_version"]
    return out


def _catalog_errors(catalog: object) -> list[str]:
    if not isinstance(catalog, dict):
        return ["catalog must be an object of rule entries"]
    errs = []
    for key in sorted(catalog):
        o = catalog[key]
        if not isinstance(o, dict):
            errs.append(f"catalog {key}: must be an object")
            continue
        for f in sorted(set(o) - set(CATALOG_FIELDS)):
            errs.append(f"catalog {key}: unknown field {f}")
        errs += [f"catalog {key}: {m}" for m in rules.entry_errors(o)]
    return errs


def _playbook_errors(ops: object) -> list[str]:
    """The overlay operations: their shape, the ids, the link templates (playbook.validate_overlay)."""
    return playbook.validate_overlay(ops)


def _internal_errors(internal: object) -> list[str]:
    if not isinstance(internal, dict):
        return ["internal must be an object of IP addresses"]
    errs = []
    for ip in sorted(internal):
        try:
            ipaddress.ip_address(ip)
        except ValueError:
            errs.append(f"internal {ip}: not an IP address")
            continue
        if not isinstance(internal[ip], bool):
            errs.append(f"internal {ip}: must be true or false")
    return errs


def validate(body: dict) -> list[str]:
    """Every problem of a body at the current schema version, one sentence each; [] when it is allowed. Unknown
    keys and values outside the bounds are errors (never clamped). Rules this release has not seen are kept: they
    may belong to a newer template sheet."""
    if not isinstance(body, dict):
        return ["the configuration must be a JSON object"]
    errs = []
    if body.get("schema_version") != SCHEMA_VERSION:
        errs.append(f"schema_version must be {SCHEMA_VERSION} (got {body.get('schema_version')!r})")
    for k in sorted(set(body) - {"schema_version", *KEYS}):
        errs.append(f"unknown key {k}")
    if "params" in body:
        if not isinstance(body["params"], dict):
            errs.append("params must be an object of parameter values")
        else:
            errs += [e for pid in sorted(body["params"]) if (e := params.validate(pid, body["params"][pid]))]
    if "catalog" in body:
        errs += _catalog_errors(body["catalog"])
    if "playbook" in body:
        errs += _playbook_errors(body["playbook"])
    if "internal" in body:
        errs += _internal_errors(body["internal"])
    if "note" in body and not isinstance(body["note"], str):
        errs.append("note must be text")
    return errs


def normalize(body: dict) -> dict:
    """The body with every key present (what an export carries)."""
    return {**empty_body(), **body}


def changed_params(old: dict, new: dict) -> list[str]:
    a, b = old.get("params") or {}, new.get("params") or {}
    return sorted(pid for pid in {*a, *b} if a.get(pid) != b.get(pid) or (pid in a) != (pid in b))


class ConfPlane:
    def __init__(self, store) -> None:
        self.store = store

    def active(self) -> tuple[int | None, dict]:
        """(version id, body) of the published version; (None, an empty body) before the first one."""
        vid = self.store.active_config_id()
        row = self.store.config(vid) if vid is not None else None
        return (row["id"], row["body"]) if row else (None, empty_body())

    def last_good(self) -> tuple[int | None, dict]:
        """The newest published or retired version that still validates (for a start where the active one does
        not any more), else (None, an empty body)."""
        for row in self.store.configs(10**6, with_body=True):
            if row["status"] in ("published", "retired") and not validate(row["body"]):
                return row["id"], row["body"]
        return None, empty_body()

    def get(self, vid: int) -> dict:
        row = self.store.config(vid)
        if row is None:
            raise ConfigError([f"there is no configuration version {vid}"])
        return row

    def versions(self, limit: int = 50) -> list[dict]:
        active = self.store.active_config_id()
        return [{**r, "active": r["id"] == active} for r in self.store.configs(limit)]

    def export(self, vid: int) -> dict:
        """The body of a version, complete and at the current schema version, ready to import elsewhere."""
        return normalize(migrate(self.get(vid)["body"]))

    # ---- writes -------------------------------------------------------------------------------------------

    def _save(self, body: dict, who: str, note: str, action: str) -> int:
        body = migrate(body)
        errs = validate(body)
        if errs:
            raise ConfigError(errs)
        self.store.prune_drafts(time.time() - DRAFT_KEEP_S)      # previews nobody published do not pile up
        base = self.active()
        vid = self.store.add_config(who, note or body.get("note", ""), base[0], "draft", body, SCHEMA_VERSION)
        self.store.log(who, action, f"v{vid}", note, {"version": vid, "params": changed_params(base[1], body)})
        return vid

    def draft(self, body: dict, who: str, note: str = "") -> int:
        """Validate and keep a body as a draft. Raises ConfigError (and writes nothing) when it is not allowed."""
        return self._save(body, who, note, "config:draft")

    def import_(self, data: dict, who: str) -> int:
        """A body exported elsewhere (or by an older release): migrated, validated, saved as a draft."""
        return self._save(data, who, "", "config:import")

    def _activate(self, vid: int, who: str, action: str, body: dict) -> None:
        before = self.active()[1]
        if not self.store.activate_config(vid):
            raise ConfigError([f"version {vid} is not a draft any more (published by someone else?)"])
        self.store.stamp = (vid, self.store.stamp[1])
        self.store.prune_drafts(time.time() - DRAFT_KEEP_S)
        # the line carries the version explicitly: a rebuild landing between the two statements restamps the global
        self.store.log(who, action, f"v{vid}", self.get(vid)["note"] or "",
                       {"version": vid, "params": changed_params(before, body)}, stamp=(vid, self.store.stamp[1]))

    def publish(self, vid: int, who: str) -> int:
        """Make a draft the active version (checked again: the bounds may have moved since it was saved)."""
        row = self.get(vid)
        if row["status"] != "draft":
            raise ConfigError([f"version {vid} is {row['status']}, not a draft: use rollback to bring it back"])
        errs = validate(migrate(row["body"]))
        if errs:
            raise ConfigError(errs)
        self._activate(vid, who, "config:publish", row["body"])
        return vid

    def rollback(self, vid: int, who: str) -> int:
        """Publish an earlier version again: its body is copied into a new version, which becomes the active one."""
        row = self.get(vid)
        body = migrate(row["body"])
        errs = validate(body)
        if errs:
            raise ConfigError(errs)
        new = self.store.add_config(who, f"rollback to version {vid}", vid, "draft", body, SCHEMA_VERSION)
        self._activate(new, who, "config:rollback", body)
        return new

    def break_glass(self, state_dir: Path, now: float) -> str | None:
        """Apply `config-import.json` from the state directory: validated like an import, published as a new
        version by "file", then renamed to `config-import.json.applied-<unix time>` so it is not applied twice.
        None when there was no file or it was applied; otherwise the text of what is wrong with it. An invalid
        file stays where it is and the active version stays."""
        path = Path(state_dir) / FILE_NAME
        if not path.is_file():
            return None
        try:
            body = migrate(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError) as exc:
            return f"{FILE_NAME}: cannot be read as JSON ({exc})"
        except ConfigError as exc:
            return f"{FILE_NAME}: {exc}"
        errs = validate(body)
        if errs:
            return f"{FILE_NAME}: {'; '.join(errs)}"
        stamp = int(now.timestamp() if hasattr(now, "timestamp") else now or time.time())
        applying = path.with_name(f"{FILE_NAME}.applying-{stamp}")
        try:   # out of the way first: a file that cannot be moved would be applied again at every start
            path.rename(applying)
        except OSError as exc:
            log.warning("%s was not applied: it cannot be renamed (%s)", FILE_NAME, exc)
            return f"{FILE_NAME} was not applied: it cannot be renamed in the state directory ({exc})"
        try:
            active_id, active_body = self.active()
            if active_id is None or normalize(active_body) != normalize(body):
                vid = self.store.add_config("file", body.get("note", ""), active_id, "draft", body, SCHEMA_VERSION)
                self._activate(vid, "file", "config:file", body)
        except Exception as exc:
            log.exception("%s could not be applied", FILE_NAME)
            try:
                applying.rename(path)
            except OSError:
                pass
            return f"{FILE_NAME} was not applied: {type(exc).__name__}: {exc}"
        try:
            applying.rename(path.with_name(f"{FILE_NAME}.applied-{stamp}"))
        except OSError as exc:
            log.warning("%s was applied; the marker could not be renamed: %s", FILE_NAME, exc)
        return None
