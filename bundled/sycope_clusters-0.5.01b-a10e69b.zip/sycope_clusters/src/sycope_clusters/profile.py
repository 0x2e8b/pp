"""The environment profile: what a normal day looks like at this customer, learned once a day from the stored
history and shrunk toward the shipped priors (spec 5.3-5.5). The verdict thresholds never move; what adapts is the
input to them.

    rarity      share of acting hosts with a signature (rule, counterpart, port) over the comparable past days:
                customer p = (k + alpha * p0) / (n + alpha), a role's (k_r + alpha * p) / (n_r + alpha)
    volumes     99th percentile of a host's daily upload to outside (netflow, day_flows_cli), shrunk toward its
                role's (the median host of the role), shrunk toward the prior; per internal service the 99th
                percentile of the daily bytes it sent back per client (day_flows_srv)
    roles       the lookup's function/service, else the services a host offers (profile_roles.py)
    segments    lookup subnets, else /24 (/64) merged upward (profile_roles.py)
    base rate   daily share of hosts at Investigate or above, from the incident history
    rhythm      the team's longest daily pause, from the audit

Safety rails (5.5): never today; hosts of open, owned, true-positive and unreviewed incidents stay out of the norms;
a value moves at most drift_day x per day (shares: 1 bit) and drift_week x per week; a host's volume norm stays
under host_norm_ceiling x its role's, except a host an admin confirmed as a backup server or monitoring poller (the
answer to its suggestion, R32): its norm is its own 99th percentile, reset on the day of confirmation. `learn` reads
the store and its arguments only: no clock, no Sycope.
"""

from __future__ import annotations

import ipaddress
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from itertools import pairwise
from statistics import median

from sycope_clusters import calendar as cal
from sycope_clusters import entities, fmt, lookups
from sycope_clusters import evidence as ev
from sycope_clusters.addresses import AddressBook
from sycope_clusters.params import Params, Value
from sycope_clusters.priors import Priors, rule_prior
from sycope_clusters.profile_roles import (
    LOWERING,
    MONITOR_PORTS,
    WORKSTATION,
    role_day_counts,
    roles_of,
    segments,
    suggest,
)
from sycope_clusters.rules import Catalog, catalog_key, stored_rule
from sycope_clusters.store import Store, _day_start

ALL = "*"
WANT_DAYS = 14          # comparable past days a profile looks at
FULL_FLOW_HOURS = 20    # a day with fewer hours of netflow says nothing about daily volumes
TEAM_DAYS = 14
KEEP_MARGIN_BITS = 2    # see keep_share()
TEAM_ALWAYS_HOURS = 20  # the team acted in this many hours of the day: it never stops
SERVICE_WHO = ("sycope-lookup", "file", "system", "service", "")   # audit lines the service wrote itself (+ sycope-*)
OWNED = ("investigating", "escalated")
CLEARED = ("fp", "benign")
NEVER_BACK = ("tp", "resolved")
SERVICE_PREFIX = "sycope-"
ROLE_MIN_HOSTS = 3      # a role is its own peer group only with this many hosts (ruling R28)
INVESTIGATE_UP = ("act", "investigate")
FORMAT = 1
VOLUME_ROLES = ("backup", "monitoring")   # confirmed roles whose volume is the host's own norm (ruling R32)


@dataclass
class Share:
    p: float
    n: int
    conf: float


@dataclass
class Profile:
    day: str
    calendar: cal.Calendar
    roles: dict[str, list[str]]          # role -> hosts (workstations are not listed)
    role_of: dict[str, str]              # host -> its main role (absent: workstation)
    suggestions: list[dict]
    share: dict[tuple, Share]            # (role, sig) and ("*", sig) of the signatures seen
    up_norm: dict[str, float]
    role_up_norm: dict[str, float]
    answer_norm: dict[tuple, float]      # (server ip, port) -> bytes per client per day
    segment_of: dict[str, str]
    segment_hosts: dict[str, int]
    base_rate: Share
    shift_gap_h: float | None
    book_digest: str
    frozen: bool
    values: dict[str, Value]
    rhythm: str = "factory"              # "factory" (not enough audit), "shifts", "24/7"
    population: dict[str, int] = field(default_factory=dict)   # role ("*" all) -> acting host-days behind shares
    alphas: dict[str, float] = field(default_factory=dict)     # share, volume, rate
    floor: float = 0.0                   # profile.prior_floor_share at learning
    norm_n: dict[str, int] = field(default_factory=dict)       # "host:<ip>" days, "role:<role>" hosts
    answer_n: dict[tuple, int] = field(default_factory=dict)
    answer_prior: dict[str, float] = field(default_factory=dict)
    role_norm_from: dict[str, str] = field(default_factory=dict)   # role -> "role" | "customer" | "prior"
    held: list[str] = field(default_factory=list)              # hosts the incident history keeps out of the norms
    days: list[str] = field(default_factory=list)              # the comparable days learned from, newest first
    book: dict = field(default_factory=dict)                   # AddressBook.snapshot() at learning (replay)
    confirmed: dict[str, str] = field(default_factory=dict)    # host -> lowering role an admin confirmed
    role_days: dict[str, dict[str, list[int]]] = field(default_factory=dict)   # host -> role -> [days, of days]


def role(prof: Profile, ip: str) -> str:
    return prof.role_of.get(ip, WORKSTATION)


def _conf(n: float, alpha: float) -> float:
    return n / (n + alpha) if n + alpha > 0 else 0.0


def evidence_key(s: dict) -> str:
    """What a suggestion rests on, without counts: kind, subject and basis (the role, directory/database/file/fan-in
    for a crown candidate, "server+client" for a public IP that looks internal). A rejection is kept with it and
    holds until it differs (ruling R38)."""
    return f"{s['kind']}:{s['subject']}:{s.get('basis') or s.get('role') or ''}"


def parse_key(key: str) -> tuple[str, str, str]:
    """(kind, role, subject) of a suggestion key: "crown:<ip or cidr>", "role:<lowering role>:<ip>",
    "internal-ip:<ip>". ValueError for anything else (subjects must be in canonical form)."""
    kind, _, rest = (key or "").partition(":")
    role_ = ""
    if kind == "role":
        role_, _, rest = rest.partition(":")
        if role_ not in LOWERING:
            raise ValueError(f"{key!r}: the role must be one of {', '.join(LOWERING)}")
    elif kind not in ("crown", "internal-ip"):
        raise ValueError(f"{key!r}: not a suggestion key")
    try:
        if kind == "crown" and "/" in rest:
            ok = str(ipaddress.ip_network(rest)) == rest
        else:
            ok = str(ipaddress.ip_address(rest)) == rest
    except ValueError:
        ok = False
    if not ok:
        raise ValueError(f"{key!r}: the subject is not an address in canonical form")
    return kind, role_, rest


def unanswered(suggestions: list[dict], answers: dict[str, dict]) -> list[dict]:
    """The suggestions still open: an accepted one is done, a rejected one stays quiet until its evidence key
    differs from the one it was rejected on. The one place that decides it (learn and crown.candidates)."""
    out = []
    for s in suggestions:
        a = answers.get(s["key"])
        if a is None or (a["answer"] == "reject" and a["evidence"] != evidence_key(s)):
            out.append(s)
    return out


def waiting(suggestions: list[dict], answers: dict[str, dict]) -> list[dict]:
    """The suggestions the Configuration list shows and the health block counts: the open ones, without the crown
    candidates (those are answered in the Crown jewels card, which counts them itself)."""
    return [s for s in unanswered(suggestions, answers) if s.get("kind") != "crown"]


def confirmed_roles(answers: dict[str, dict]) -> dict[str, str]:
    """host -> lowering role (scanner, backup, monitoring) of the suggestions an admin accepted; malformed rows
    are ignored."""
    out = {}
    for key, a in sorted(answers.items()):
        try:
            kind, role_, ip = parse_key(key)
        except ValueError:
            continue
        if kind == "role" and a["answer"] == "accept":
            out[ip] = role_
    return out


def freeze(store: Store, frozen: bool) -> str | None:
    """Freeze the profile in use (the newest snapshot) or unfreeze it, and keep `meta` profile_frozen in step. The
    day it concerned, None when there was no snapshot to freeze."""
    day = store.freeze_profile(frozen)
    if day is not None or not frozen:
        store.meta("profile_frozen", "1" if frozen and day is not None else "0")
    return day


def rarity(prof: Profile, sig: tuple, role_: str, rule_key: str, kind: str, pr: Priors) -> Share:
    """Share of hosts of a role ("*" = all) with the signature on a comparable day: the role's share shrunk toward
    the customer's, the customer's toward the prior. A role has its own level only where at least 3 of its hosts
    showed the signature; otherwise the customer's share answers. A signature nobody showed is prior-only with `n` =
    the population, so its rarity is bounded by the prior, not by the network's size."""
    hit = prof.share.get((role_, sig))
    if hit is not None:
        return hit
    a = prof.alphas.get("share", pr.alpha_share)
    n_all = prof.population.get(ALL, 0)
    whole = prof.share.get((ALL, sig))
    if whole is None:
        p0 = max(prof.floor, rule_prior(pr, rule_key, kind))
        whole = Share(a * p0 / (n_all + a), n_all, _conf(n_all, a))
    return whole      # no role level: fewer than 3 hosts of the role have it (R28), or the role is everyone


def _norm_text(what: str, n: int, unit: str, alpha: float) -> str:
    c = _conf(n, alpha)
    low = "; low norm confidence" if c < 0.5 else ""
    return f"learned for {what}, {n} {unit}, norm confidence {c:.2f}{low}"


def exfil_norm(prof: Profile, ip: str) -> tuple[float, str]:
    """The normal daily upload to outside of a host (99th percentile), and where it comes from."""
    a = prof.alphas.get("volume", 5.0)
    if ip in prof.up_norm:
        if prof.confirmed.get(ip) in VOLUME_ROLES and ip in prof.held:
            return prof.up_norm[ip], (f"held at the last profile's value, with no ceiling: the host is in an incident "
                                      f"and an admin confirmed it as {fmt.with_article(prof.confirmed[ip])}")
        if prof.confirmed.get(ip) in VOLUME_ROLES:
            return prof.up_norm[ip], (f"its own daily upload (99th percentile): an admin confirmed it as "
                                      f"{fmt.with_article(prof.confirmed[ip])}")
        if ip in prof.held:
            return prof.up_norm[ip], "held at the last profile's value: the host is in an incident"
        return prof.up_norm[ip], _norm_text("this host", prof.norm_n.get("host:" + ip, 0), "days", a)
    r = role(prof, ip)
    if r not in prof.role_up_norm:
        r = WORKSTATION
    v = prof.role_up_norm.get(r)
    if v is None:
        return 0.0, "no norm"
    src = prof.role_norm_from.get(r, "role" if prof.norm_n.get("role:" + r) else "prior")
    if src == "customer":
        return v, _norm_text(f"all hosts ({r}s are too few)", prof.norm_n.get("role:" + ALL, 0), "hosts", a)
    if src == "role":
        return v, _norm_text(f"{r}s", prof.norm_n.get("role:" + r, 0), "hosts", a)
    return v, f"shipped prior for {r}s"


def answer_norm(prof: Profile, server_ip: str, port: str) -> tuple[float, str]:
    """The normal daily bytes an internal service sends back per client (99th percentile), and where it comes from."""
    key = (server_ip, str(port))
    if key in prof.answer_norm:
        return prof.answer_norm[key], _norm_text("this service", prof.answer_n.get(key, 0), "days",
                                                 prof.alphas.get("volume", 5.0))
    v = prof.answer_prior.get(str(port), prof.answer_prior.get(ALL, 1e6))
    return v, "shipped prior"


# ---- learning ---------------------------------------------------------------------------------------------------

def _q99(vals: list[float]) -> float:
    """99th percentile of sorted values (linear between ranks)."""
    if not vals:
        return 0.0
    x = 0.99 * (len(vals) - 1)
    i = int(x)
    return vals[i] if i + 1 >= len(vals) else vals[i] + (x - i) * (vals[i + 1] - vals[i])


def _days_between(a: str, b: str) -> int:
    return (datetime.strptime(b, "%Y-%m-%d") - datetime.strptime(a, "%Y-%m-%d")).days


def _hosts(o: dict) -> set[str]:
    out = set()
    for k in (o["subject"], *o["members"]):
        kind, value = entities.parse(k)
        if kind == "ip":
            out.add(value)
    return out


def excluded_hosts(incs: list[dict], t_today: float, unreviewed_days: float) -> set[str]:
    """Hosts held out of the norms (spec 5.5, D50, ruling R26). Only a human "this was fine" brings a host back
    early:
        never back      closed as tp or resolved, or peaked at Act now with any outcome but fp/benign
        back at once    fp or benign (peak not Act now)
        held            open or owned (investigating, escalated)
        unreviewed      everything else (ack, partial, expired, no outcome, fp/benign after an Act now peak):
                        back `unreviewed_days` after it closed"""
    out: set[str] = set()
    for o in incs:
        outcome = o["outcome"] or ""
        act = o["verdict_peak"] == "act"
        if outcome in CLEARED and not act:
            continue
        never = outcome in NEVER_BACK or (act and outcome not in CLEARED)
        live = o["closed_at"] is None or o["status"] == "open" or outcome in OWNED
        if never or live or t_today < o["closed_at"] + unreviewed_days * 86400:
            out |= _hosts(o)
    return out


class _Memo(dict):
    def __init__(self, f) -> None:
        super().__init__()
        self.f = f

    def __missing__(self, k):
        v = self[k] = self.f(k)
        return v


class _Nets:
    """The book's internal() behind a plain dict: actor_of asks it twice for every stored row."""

    def __init__(self, book: AddressBook) -> None:
        self.internal = _Memo(book.internal).__getitem__


def _activity(store: Store, days: list[str], catalog: Catalog, nets: _Nets):
    """Pass 1, one day at a time: the acting hosts of each day (the calendar's input and the rarity population),
    the hosts Sycope found to be IoT/OT, and per actor the days it scanned (and scanned monitoring ports)."""
    canon: dict[str, str] = {}
    actors: dict[str, set] = {}
    iot: dict[str, set] = defaultdict(set)
    scan_days: dict[str, set] = defaultdict(set)
    mon_days: dict[str, set] = defaultdict(set)
    for d in days:
        acts = set()
        for row in store.day_rows([d]):
            _, name, client, server, port = row[:5]
            rule = stored_rule(catalog, name, ev.row_rule_id(row))
            rule, _dir = ev.resolve(rule, client or None, server or None, row[9] if len(row) > 9 else None, nets)
            if rule.hygiene:
                if "IoT/OT" in rule.name:
                    for _lane, subj, _cp in ev.attribute(rule, client or None, server or None, nets):
                        iot[subj].add(d)
                continue
            actor, _cp = ev.actor_of(rule, client or None, server or None, nets)
            if actor is None:
                continue
            actor = canon.setdefault(actor, actor)
            acts.add(actor)
            if rule.kind == "scan":
                scan_days[actor].add(d)
                if port in MONITOR_PORTS:
                    mon_days[actor].add(d)
        actors[d] = acts
    return actors, iot, scan_days, mon_days


def _counts(store: Store, days: list[str], catalog: Catalog, nets: _Nets, excluded: set[str],
            role_of: dict[str, str], skip_roles: set[str]) -> tuple[Counter, Counter, dict]:
    """Pass 2 over the comparable days: host-days per signature, for the customer and per role (a role holding the
    whole population is skipped: its share is the customer's), and up to ROLE_MIN_HOSTS distinct hosts per role
    signature."""
    k: Counter = Counter()
    k_role: Counter = Counter()
    who: dict[tuple, tuple] = {}
    for d in days:
        seen = set()
        for row in store.day_rows([d]):
            _, name, client, server, port = row[:5]
            rule = stored_rule(catalog, name, ev.row_rule_id(row))
            rule, _dir = ev.resolve(rule, client or None, server or None, row[9] if len(row) > 9 else None, nets)
            if rule.hygiene:
                continue
            actor, cp = ev.actor_of(rule, client or None, server or None, nets)
            if actor is None or actor in excluded:
                continue
            name = rule.name       # the catalog's name: one rule across a rename in Sycope
            seen.add((actor, (name, cp or "", port or "") if cp else (name,)))
        for actor, sig in seen:
            k[sig] += 1
            r = role_of.get(actor, WORKSTATION)
            if r not in skip_roles:
                key = (r, sig)
                k_role[key] += 1
                w = who.get(key, ())
                if len(w) < ROLE_MIN_HOSTS and actor not in w:
                    who[key] = (*w, actor)
    return k, k_role, {key: len(w) for key, w in who.items()}


def population(actors: dict[str, set], excluded: set[str], role_of: dict[str, str]) -> dict[str, int]:
    """Acting host-days behind the shares, for all hosts ("*") and per role."""
    pop: Counter = Counter()
    for acts in actors.values():
        for h in acts:
            if h not in excluded:
                pop[ALL] += 1
                pop[role_of.get(h, WORKSTATION)] += 1
    pop[ALL] += 0
    return dict(sorted(pop.items()))


def keep_share(p: Params) -> float:
    """Shares under this are not stored: their rarity limit is above anything one finding can carry (the largest
    class bits plus the largest severity and threshold bonus, plus a margin), so the prior-only fallback of rarity()
    gives the same caps. Keeps the snapshot small where most counterparts are seen once."""
    top = (max(p[f"class_bits.{c}"] for c in "ABCD") + max(p[f"sev_adj.{s}"] for s in range(1, 6))
           + max(p[f"thr_adj.{t}"] for t in range(1, 4)))
    return 2.0 ** -(top + KEEP_MARGIN_BITS)


class _Drift:
    """Bounds a new value by the previous profile (drift_day x per day, shares 1 bit per day) and by the newest
    snapshot at least a week old (drift_week x per week)."""

    def __init__(self, today: str, prev: Profile | None, week: Profile | None, p: Params) -> None:
        self.prev, self.week = prev, week
        dd, dw = p["profile.drift_day"], p["profile.drift_week"]
        g = max(1, _days_between(prev.day, today)) if prev else 1
        weeks = math.ceil(g / 7)
        self.f_prev = min(dd ** g, dw ** weeks)
        self.f_prev_share = min(2.0 ** g, dw ** weeks)
        self.f_week = dw ** math.ceil(max(7, _days_between(week.day, today)) / 7) if week else 0.0

    @staticmethod
    def _clamp(v: float, old: float | None, f: float) -> float:
        if old is None or old <= 0 or f <= 0:
            return v
        return min(max(v, old / f), old * f)

    def value(self, v: float, get, share: bool = False) -> float:
        """`get(profile)` is the old value in a profile."""
        if self.prev is not None:
            v = self._clamp(v, get(self.prev), self.f_prev_share if share else self.f_prev)
        if self.week is not None:
            v = self._clamp(v, get(self.week), self.f_week)
        return min(v, 1.0) if share else v

    def confirmed_host(self, v: float, ip: str) -> float:
        """A confirmed host's norm: its own q99 on the day of confirmation, then bounded like any value, but only
        by profiles that already knew it as confirmed (the older ones hold its capped norm)."""
        for old, f in ((self.prev, self.f_prev), (self.week, self.f_week)):
            if old is not None and old.confirmed.get(ip) in VOLUME_ROLES:
                v = self._clamp(v, exfil_norm(old, ip)[0], f)
        return v


def _shares(k: Counter, k_role: Counter, role_hosts: dict, pop: dict[str, int], catalog: Catalog, pr: Priors,
            alpha: float, floor: float, keep: float, drift: _Drift) -> dict[tuple, Share]:
    n_all = pop.get(ALL, 0)
    prior: dict[str, tuple[float, str, str]] = {}
    for name in {sig[0] for sig in k}:
        rule = catalog.get(name)
        key, kind = catalog_key(rule), rule.kind
        prior[name] = (max(floor, rule_prior(pr, key, kind)), key, kind)
    out: dict[tuple, Share] = {}
    whole: dict[tuple, float] = {}
    for sig, c in k.items():
        p0, key, kind = prior[sig[0]]
        v = whole[sig] = (c + alpha * p0) / (n_all + alpha)
        if v < keep:
            continue
        v = drift.value(v, lambda prof, s=sig, k_=key, kd=kind: rarity(prof, s, ALL, k_, kd, pr).p, share=True)
        out[(ALL, sig)] = Share(v, n_all, _conf(n_all, alpha))
    for (r, sig), k_r in k_role.items():
        if role_hosts.get((r, sig), 0) < ROLE_MIN_HOSTS:
            continue
        p0, key, kind = prior[sig[0]]
        n_r = pop.get(r, 0)
        parent = out[(ALL, sig)].p if (ALL, sig) in out else whole[sig]
        v = (k_r + alpha * parent) / (n_r + alpha)
        if v < keep and parent < keep:      # both levels too rare to cap anything
            continue
        v = drift.value(v, lambda prof, s=sig, r_=r, k_=key, kd=kind: rarity(prof, s, r_, k_, kd, pr).p, share=True)
        out[(r, sig)] = Share(v, n_r, _conf(n_r, alpha))
    return out


def _role_prior(pr: Priors, r: str) -> float:
    if r in pr.up_q99:
        return pr.up_q99[r]
    if r != WORKSTATION and "server" in pr.up_q99:
        return pr.up_q99["server"]
    return pr.up_q99.get(WORKSTATION) or max(pr.up_q99.values(), default=5e7)


def _volumes(cli: list[tuple], full: set[str], excluded: set[str], role_of: dict[str, str], pr: Priors,
             p: Params, drift: _Drift, prev: Profile | None, confirmed: dict[str, str] | None = None):
    """Host and role upload norms (see the module text). A role with fewer than ROLE_MIN_HOSTS hosts with data
    takes the customer's norm ("*", every host's q99, shrunk toward the workstation prior). A held host gets its
    role's norm bounded by what the previous profile said for it: its own flows teach nothing. A host confirmed as
    a backup server or monitoring poller has no ceiling and no shrinking: its norm is its own q99 (ruling R32)."""
    a = pr.alpha_volume
    confirmed = confirmed or {}
    per_host: dict[str, list[float]] = defaultdict(list)
    held_seen: set[str] = set()
    for d, ip, _peers, up, _down, *_ in cli:
        if d not in full:
            continue
        if ip in excluded:
            held_seen.add(ip)
        else:
            per_host[ip].append(float(up or 0))
    q_host = {ip: _q99(sorted(v)) for ip, v in sorted(per_host.items())}
    by_role: dict[str, list[float]] = defaultdict(list)
    for ip, q in q_host.items():
        by_role[role_of.get(ip, WORKSTATION)].append(q)
    role_norm, norm_n, origin = {}, {}, {}

    def shrunk(qs: list[float], prior: float) -> float:
        return (len(qs) * (median(qs) if qs else 0.0) + a * prior) / (len(qs) + a)

    everyone = sorted(q_host.values())
    ws_prior = _role_prior(pr, WORKSTATION)
    role_norm[ALL] = drift.value(shrunk(everyone, ws_prior), lambda prof: prof.role_up_norm.get(ALL, ws_prior))
    norm_n["role:" + ALL] = len(everyone)
    for r in sorted({WORKSTATION, *by_role, *role_of.values()}):
        qs = sorted(by_role.get(r, ()))
        if len(qs) >= ROLE_MIN_HOSTS:
            v, origin[r] = shrunk(qs, _role_prior(pr, r)), "role"
        elif everyone:
            v, origin[r] = role_norm[ALL], "customer"
        else:
            v, origin[r] = _role_prior(pr, r), "prior"
        role_norm[r] = drift.value(v, lambda prof, r_=r: prof.role_up_norm.get(r_, _role_prior(pr, r_)))
        norm_n["role:" + r] = len(qs)
    ceiling = p["profile.host_norm_ceiling"]
    up_norm = {}
    for ip, q in q_host.items():
        rn = role_norm[role_of.get(ip, WORKSTATION)]
        n = len(per_host[ip])
        if confirmed.get(ip) in VOLUME_ROLES:
            up_norm[ip] = drift.confirmed_host(q, ip)
            norm_n["host:" + ip] = n
            continue
        v = min((n * q + a * rn) / (n + a), ceiling * rn)
        up_norm[ip] = min(drift.value(v, lambda prof, ip_=ip: exfil_norm(prof, ip_)[0]), ceiling * rn)
        norm_n["host:" + ip] = n
    for ip in sorted(held_seen | (set(prev.up_norm) & excluded if prev else set())):
        rn = role_norm[role_of.get(ip, WORKSTATION)]
        if confirmed.get(ip) in VOLUME_ROLES:     # R32: no ceiling, held at what the last profile said
            up_norm[ip] = exfil_norm(prev, ip)[0] if prev is not None else rn
            norm_n["host:" + ip] = 0
            continue
        up_norm[ip] = min(drift.value(rn, lambda prof, ip_=ip: exfil_norm(prof, ip_)[0]), ceiling * rn)
        norm_n["host:" + ip] = 0
    return up_norm, role_norm, norm_n, per_host, origin


def _answers(srv: list[tuple], full: set[str], excluded: set[str], pr: Priors, drift: _Drift,
             prev: Profile | None):
    """Per internal service the 99th percentile of the bytes sent back per client and day; a held host keeps the
    previous profile's numbers."""
    a = pr.alpha_volume
    per: dict[tuple, list[float]] = defaultdict(list)
    for d, ip, port, clients, _up, down, ext in srv:
        if d in full and not ext and clients and ip not in excluded:
            per[(ip, str(port))].append((down or 0) / clients)
    out, n_of = {}, {}
    for key, vals in sorted(per.items()):
        n = len(vals)
        prior = pr.answer_q99.get(key[1], pr.answer_q99.get(ALL, 1e6))
        v = (n * _q99(sorted(vals)) + a * prior) / (n + a)
        out[key] = drift.value(v, lambda prof, k_=key: answer_norm(prof, *k_)[0])
        n_of[key] = n
    if prev is not None:
        for key, v in prev.answer_norm.items():
            if key[0] in excluded:
                out[key], n_of[key] = v, prev.answer_n.get(key, 0)
    return dict(sorted(out.items())), dict(sorted(n_of.items()))


def scored_since(store: Store, incs: list[dict]) -> float | None:
    """When the triage started scoring this network: its first board (meta triage_since, Live.rebuild) or, in a store
    from before 1.0, its oldest incident. None: nothing was ever scored."""
    times = [o["opened_at"] for o in incs if o["opened_at"] is not None]
    try:
        times.append(float(store.meta("triage_since") or ""))
    except ValueError:
        pass
    times = [t for t in times if math.isfinite(t)]
    return min(times) if times else None


def _base_rate(incs: list[dict], days: list[str], active: dict[str, set], pr: Priors, drift: _Drift,
               since: float | None) -> Share:
    """Investigate+ hosts / all active hosts over the comparable days, days with a campaign left out (call 2). A day
    that ended before the triage scored anything (backfilled at install) has no incidents because nobody looked, not
    because nothing was there: it is left out, else a fresh install learns a share of ~0 and every handful of
    Investigate hosts in a big segment looks like a campaign."""
    camp, inv = [], []
    for o in incs:
        span = (o["opened_at"], o["closed_at"] if o["closed_at"] is not None else o["last_seen"])
        if o["kind"] == "campaign":
            camp.append(span)
        elif o["verdict_peak"] in INVESTIGATE_UP:
            inv.append((*span, _hosts(o)))
    k = n = 0
    for d in sorted(days):
        ds = _day_start(d)
        de = ds + 86400
        if since is None or de <= since or any(a < de and b >= ds for a, b in camp):
            continue
        hs = set()
        for a, b, h in inv:
            if a < de and b >= ds:
                hs |= h
        k += len(hs)
        n += len(active.get(d, set()) | hs)
    alpha = pr.alpha_rate
    v = drift.value((k + alpha * pr.investigate_rate) / (n + alpha), lambda prof: prof.base_rate.p, share=True)
    return Share(v, n, _conf(n, alpha))


def team_rhythm(store: Store, today: str, offset_min: int) -> tuple[float | None, str, int]:
    """(shift gap in hours or None, "shifts" | "24/7" | "factory", days with activity) from 14 days of audit."""
    end = _day_start(today)
    start = end - TEAM_DAYS * 86400
    first = store.audit_first(SERVICE_WHO, SERVICE_PREFIX)
    if first is None or first > start:
        return None, "factory", 0
    off = offset_min * 60
    acts = sorted(at for at, who in store.team_activity(start)
                  if at < end and (who or "") not in SERVICE_WHO and not (who or "").startswith(SERVICE_PREFIX))
    if len(acts) < 2:
        return None, "factory", 0
    hours = {int(((at + off) % 86400) // 3600) for at in acts}
    days = {int((at + off) // 86400) for at in acts}
    if len(hours) >= TEAM_ALWAYS_HOURS:
        return None, "24/7", len(days)
    longest: dict[int, float] = {}
    for a, b in pairwise(acts):
        d = int((b + off) // 86400)
        longest[d] = max(longest.get(d, 0.0), b - a)
    gap = median(sorted(longest.values())) / 3600
    return min(16.0, max(4.0, gap)), "shifts", len(days)


def _week_snapshot(store: Store, today: str) -> Profile | None:
    old = [d for d, _ in store.profile_days() if _days_between(d, today) >= 7]
    if not old:
        return None
    body = store.profile(old[-1])
    return from_json(body) if body else None


def learn(store: Store, today: str, pr: Priors, p: Params, book: AddressBook, catalog: Catalog,
          prev: Profile | None = None) -> Profile:
    """The profile for `today`, from the stored days before it (see the module text). The caller stores it."""
    t_today = _day_start(today)
    found = sorted(d for d in store.days() if d < today)
    stored = sorted({*found, *(d for d in store.flow_days() if d < today)})
    nets = _Nets(book)
    all_actors, iot_days, scan_all, mon_all = _activity(store, found, catalog, nets)
    calendar = cal.learn({d: len(a) for d, a in all_actors.items()}, p)
    days = cal.comparable(calendar, today, stored, WANT_DAYS)
    in_days = set(days)
    actors = {d: all_actors.get(d, set()) for d in days}
    del all_actors
    iot = {ip for ip, ds in iot_days.items() if ds & in_days}
    scan_days = {ip: ds & in_days for ip, ds in scan_all.items() if ds & in_days}
    mon_days = {ip: ds & in_days for ip, ds in mon_all.items() if ds & in_days}
    incs = store.incident_facts()
    excluded = excluded_hosts(incs, t_today, p["unreviewed_days"])
    srv, cli_all = store.day_flows(days)
    cli = [r for r in cli_all if not r[5]]              # our hosts; ext = 1 rows are public clients
    ext_cli = [r for r in cli_all if r[5]]
    full = {d for d in days if store.flow_coverage(d) >= FULL_FLOW_HOURS}
    active: dict[str, set] = {d: set(actors.get(d, ())) for d in days}
    for d, ip, *_ in cli:
        active[d].add(ip)
    for d, ip, _port, _c, _u, _dn, ext in srv:
        if not ext:
            active[d].add(ip)
    hosts = set().union(*active.values()) if active else set()

    digest = lookups.digest(book.entries)
    monday = cal.local_weekday(today, calendar.offset_min) == 0
    if prev is None or monday or prev.book_digest != digest:
        seg_of, seg_n = segments(hosts, book, p["segment_min_hosts"])
    else:
        seg_of, seg_n = dict(prev.segment_of), dict(prev.segment_hosts)
        new = {h for h in hosts if h not in seg_of}
        if new:
            more_of, more_n = segments(new, book, p["segment_min_hosts"], known=seg_n)
            seg_of.update(more_of)
            seg_n.update({k: v for k, v in more_n.items() if k not in seg_n})
    seg_of, seg_n = dict(sorted(seg_of.items())), dict(sorted(seg_n.items()))

    role_sets, role_of, lowering = roles_of(hosts, book, srv, cli, days, active, seg_of, iot, pr, excluded,
                                            prev.role_of if prev else None)
    week = _week_snapshot(store, today)
    drift = _Drift(today, prev, week, p)
    alpha, floor = p["profile.alpha_share"], p["profile.prior_floor_share"]
    pop = population(actors, excluded, role_of)
    skip = {r for r, n in pop.items() if r != ALL and n == pop[ALL]}
    k, k_role, role_hosts = _counts(store, days, catalog, nets, excluded, role_of, skip)
    share = _shares(k, k_role, role_hosts, pop, catalog, pr, alpha, floor, keep_share(p), drift)
    del k, k_role, role_hosts
    answers = store.answers()
    confirmed = confirmed_roles(answers)
    up_norm, role_norm, norm_n, per_host, origin = _volumes(cli, full, excluded, role_of, pr, p, drift, prev,
                                                            confirmed)
    ans, ans_n = _answers(srv, full, excluded, pr, drift, prev)
    base = _base_rate(incs, days, active, pr, drift, scored_since(store, incs))
    sugg = unanswered(suggest(days, srv, ext_cli, book, excluded, role_of, lowering, scan_days, mon_days, per_host,
                              role_norm, p["profile.host_norm_ceiling"], p["own_public_min_clients"], seg_of),
                      answers)
    gap, rhythm, team_days = team_rhythm(store, today, calendar.offset_min)
    values = {}
    if gap is not None:
        values["shift_gap_h"] = Value(gap, "learned", team_days, 1.0,
                                      f"the team's longest daily pause, median of {TEAM_DAYS} days of audit")
    return Profile(
        day=today, calendar=calendar, roles={r: sorted(v) for r, v in sorted(role_sets.items())}, role_of=role_of,
        suggestions=sugg, share=share, up_norm=up_norm, role_up_norm=role_norm, answer_norm=ans,
        segment_of=seg_of, segment_hosts=seg_n, base_rate=base, shift_gap_h=gap, book_digest=digest, frozen=False,
        values=values, rhythm=rhythm, population=pop,
        alphas={"share": float(alpha), "volume": pr.alpha_volume, "rate": pr.alpha_rate}, floor=float(floor),
        norm_n=dict(sorted(norm_n.items())), answer_n=ans_n, answer_prior=dict(sorted(pr.answer_q99.items())),
        days=list(days), book=book.snapshot(), role_norm_from=origin,
        held=sorted(h for h in excluded if h in hosts or h in up_norm), confirmed=confirmed,
        role_days=role_day_counts(role_sets, srv, days, active, seg_of, pr))


def save(store: Store, prof: Profile) -> bool:
    """Store a learned profile under its day (a frozen snapshot of that day is kept instead: False)."""
    return store.put_profile(prof.day, to_json(prof))


# ---- JSON ---------------------------------------------------------------------------------------------------------

def to_json(prof: Profile) -> dict:
    """Plain JSON data, deterministic (sorted lists, string keys)."""
    c = prof.calendar
    return {
        "format": FORMAT, "day": prof.day,
        "calendar": {"weekday_class": {str(w): c.weekday_class[w] for w in sorted(c.weekday_class)},
                     "day_class": dict(sorted(c.day_class.items())), "dormant": sorted(c.dormant),
                     "learned": c.learned, "offset_min": c.offset_min},
        "roles": {r: sorted(v) for r, v in sorted(prof.roles.items())}, "role_of": dict(sorted(prof.role_of.items())),
        "suggestions": [dict(sorted(s.items())) for s in prof.suggestions],
        "share": [[r, list(sig), s.p, s.n, s.conf] for (r, sig), s in sorted(prof.share.items())],
        "up_norm": dict(sorted(prof.up_norm.items())), "role_up_norm": dict(sorted(prof.role_up_norm.items())),
        "answer_norm": [[ip, port, v] for (ip, port), v in sorted(prof.answer_norm.items())],
        "answer_n": [[ip, port, n] for (ip, port), n in sorted(prof.answer_n.items())],
        "answer_prior": dict(sorted(prof.answer_prior.items())),
        "segment_of": dict(sorted(prof.segment_of.items())), "segment_hosts": dict(sorted(prof.segment_hosts.items())),
        "base_rate": {"p": prof.base_rate.p, "n": prof.base_rate.n, "conf": prof.base_rate.conf},
        "shift_gap_h": prof.shift_gap_h, "rhythm": prof.rhythm, "book_digest": prof.book_digest,
        "frozen": prof.frozen,
        "values": {k: {"value": v.value, "source": v.source, "n": v.n, "conf": v.conf, "note": v.note}
                   for k, v in sorted(prof.values.items())},
        "population": dict(sorted(prof.population.items())), "alphas": dict(sorted(prof.alphas.items())),
        "floor": prof.floor, "norm_n": dict(sorted(prof.norm_n.items())), "days": list(prof.days),
        "role_norm_from": dict(sorted(prof.role_norm_from.items())), "held": sorted(prof.held),
        "book": prof.book, "confirmed": dict(sorted(prof.confirmed.items())),
        **({"role_days": {ip: dict(sorted(v.items())) for ip, v in sorted(prof.role_days.items())}}
           if prof.role_days else {}),
    }


def from_json(d: dict) -> Profile:
    c = d["calendar"]
    calendar = cal.Calendar({int(w): v for w, v in c["weekday_class"].items()}, dict(c["day_class"]),
                            frozenset(c["dormant"]), bool(c["learned"]), int(c["offset_min"]))
    br = d["base_rate"]
    return Profile(
        day=d["day"], calendar=calendar, roles={r: list(v) for r, v in d["roles"].items()},
        role_of=dict(d["role_of"]), suggestions=[dict(s) for s in d["suggestions"]],
        share={(r, tuple(sig)): Share(p, n, conf) for r, sig, p, n, conf in d["share"]},
        up_norm=dict(d["up_norm"]), role_up_norm=dict(d["role_up_norm"]),
        answer_norm={(ip, port): v for ip, port, v in d["answer_norm"]},
        segment_of=dict(d["segment_of"]), segment_hosts=dict(d["segment_hosts"]),
        base_rate=Share(br["p"], br["n"], br["conf"]), shift_gap_h=d["shift_gap_h"], book_digest=d["book_digest"],
        frozen=bool(d.get("frozen")),
        values={k: Value(v["value"], v["source"], v["n"], v["conf"], v["note"]) for k, v in d["values"].items()},
        rhythm=d.get("rhythm", "factory"), population=dict(d.get("population", {})),
        alphas=dict(d.get("alphas", {})), floor=d.get("floor", 0.0), norm_n=dict(d.get("norm_n", {})),
        answer_n={(ip, port): n for ip, port, n in d.get("answer_n", [])},
        answer_prior=dict(d.get("answer_prior", {})), days=list(d.get("days", [])), book=d.get("book", {}),
        role_norm_from=dict(d.get("role_norm_from", {})), held=list(d.get("held", [])),
        confirmed=dict(d.get("confirmed", {})),
        role_days={ip: {r: list(x) for r, x in v.items()} for ip, v in d.get("role_days", {}).items()})
