"""Chain rules of the Clusters board (CR-01, CR-03, CR-05, CR-07, CR-08, CR-09): a score multiplier, not bits.

A step is one finding of a strong rule (a stage, class A to C, a family that sets a phase) with the time of its
first alert. The families that make each rule, and the order CR-08 and CR-09 need, are the ones of
evidence.score_entity, which Triage scores with; only the effect differs (a multiplier on the host's newest cluster
here, evidence bits there). CR-02, CR-04, CR-06 and CR-10 are Triage only (the ids are the same in both views). Each rule looks only at the steps
inside its own window before `now`.
"""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable, Iterable
from typing import NamedTuple

HOUR_MS = 3_600_000

# id -> (title, window in hours, multiplier)
CHAINS: dict[str, tuple[str, int, float]] = {
    "CR-01": ("Data theft in progress", 24, 2.0),
    "CR-03": ("Full kill chain (7 days)", 168, 2.5),
    "CR-05": ("Confirmed C2", 24, 1.8),
    "CR-07": ("Worm propagation", 12, 1.8),
    "CR-08": ("Credential theft, then lateral movement", 48, 1.6),
    "CR-09": ("Recon, then exploitation", 72, 1.4),
}
WORM_HOSTS = 3          # hosts of one segment scanning at once


class Step(NamedTuple):
    actor: str
    family: str
    stage: int
    first_ms: int
    cp: str | None       # the counterpart of the first alert, when it had one


def _inside(steps: list[Step], now_ms: int, rule: str) -> list[Step]:
    lo = now_ms - CHAINS[rule][1] * HOUR_MS
    return [s for s in steps if lo <= s.first_ms <= now_ms]


def _ti3(steps: Iterable[Step]) -> list[Step]:
    """Threat-intel steps with the command-channel code 3 (clusters.step_code): a contact with a listed IP that stands
    for command and control. Its rule's stage is Foothold since 1.2; the code stays 3 so Phishing (stage 1) is no C2."""
    return [s for s in steps if s.family == "CL-01" and s.stage == 3]


def match(steps: list[Step], now_ms: int) -> dict[str, list[Step]]:
    """CR-01, CR-03, CR-05, CR-08, CR-09 for one host (in id order): chain id -> the steps that make it (a chain id that does not match is absent)."""
    out: dict[str, list[Step]] = {}

    def fam(ss: list[Step], *families: str) -> list[Step]:
        return [s for s in ss if s.family in families]

    s = _inside(steps, now_ms, "CR-05")
    c2 = fam(s, "CL-02", "CL-03")
    if _ti3(s) and c2:
        out["CR-05"] = _ti3(s) + c2
    s = _inside(steps, now_ms, "CR-01")
    c2 = fam(s, "CL-02", "CL-03") or _ti3(s)
    if fam(s, "CL-06") and c2:
        out["CR-01"] = fam(s, "CL-06") + c2
    s = _inside(steps, now_ms, "CR-08")
    cred, lat = fam(s, "CL-05"), fam(s, "CL-10")
    if cred and lat and min(x.first_ms for x in cred) <= min(x.first_ms for x in lat):
        out["CR-08"] = cred + lat
    s = _inside(steps, now_ms, "CR-09")
    scans = fam(s, "CL-04")
    if scans:
        t0 = min(x.first_ms for x in scans)
        later = [x for x in fam(s, "CL-05", "CL-10") if x.first_ms >= t0]
        if later:
            out["CR-09"] = scans + later
    s = _inside(steps, now_ms, "CR-03")
    groups = [fam(s, "CL-04"), fam(s, "CL-05", "CL-10"), fam(s, "CL-02", "CL-03"), fam(s, "CL-06")]
    if not groups[2]:
        groups[2] = _ti3(s)        # a command-channel threat-intel contact counts as the C2 group when that is empty
    if sum(1 for g in groups if g) >= 3:
        out["CR-03"] = [x for g in groups for x in g]
    return dict(sorted(out.items()))


def worm_steps(steps: Iterable[Step], now_ms: int) -> bool:
    """Whether a host's steps hold a scan inside the CR-07 window."""
    lo = now_ms - CHAINS["CR-07"][1] * HOUR_MS
    return any(s.family == "CL-04" and lo <= s.first_ms <= now_ms for s in steps)


def text(chain: str, episodes: int) -> str:
    return f"{CHAINS[chain][0]} ({chain}) across {episodes} cluster{'' if episodes == 1 else 's'}"


def worm_text(hosts: int, segment: str) -> str:
    return f"{CHAINS['CR-07'][0]} (CR-07): {hosts} hosts scanning in {segment}"


def episodes_of(actor: str, steps: Iterable[Step], episode: Callable[[str, int], object] | None) -> int:
    """How many clusters hold these steps. `episode(actor, first_ms)` names the cluster of a step; without it the
    steps an hour or less apart count as one episode (the engine's chaining, on step times)."""
    if episode is not None:
        return len({episode(actor, s.first_ms) for s in steps})
    n, last = 0, None
    for t in sorted({s.first_ms for s in steps}):
        if last is None or t - last > HOUR_MS:
            n += 1
        last = t
    return n


def evaluate(steps: Iterable[Step], now_ms: int, segment: Callable[[str], str],
             episode: Callable[[str, int], object] | None = None) -> dict[str, list[tuple[str, float, str]]]:
    """actor -> [(chain id, multiplier, text)] for the steps of any number of hosts. CR-07 is the one rule across
    hosts: three or more hosts of one `segment(actor)` with a scan inside 12 h all get it."""
    by: dict[str, list[Step]] = defaultdict(list)
    for s in steps:
        by[s.actor].append(s)
    out: dict[str, list[tuple[str, float, str]]] = {}
    seg: dict[str, set[str]] = defaultdict(set)
    for actor, ss in by.items():
        for cid, hit in match(ss, now_ms).items():
            out.setdefault(actor, []).append((cid, CHAINS[cid][2], text(cid, episodes_of(actor, hit, episode))))
        if worm_steps(ss, now_ms):
            seg[segment(actor)].add(actor)
    for name, hosts in seg.items():
        if len(hosts) >= WORM_HOSTS:
            for actor in hosts:
                out.setdefault(actor, []).append(("CR-07", CHAINS["CR-07"][2], worm_text(len(hosts), name)))
    for rows in out.values():
        rows.sort(key=lambda r: r[0])            # id order, the order the rules are listed in
    return out
