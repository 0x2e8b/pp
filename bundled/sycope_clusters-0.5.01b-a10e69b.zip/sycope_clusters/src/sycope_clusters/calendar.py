"""The calendar of a site, learned from how many hosts acted each day: which weekdays are days off (a Fri-Sat
weekend works), which days were dormant (holidays, outages) and which past days are fair to compare today with.

Days are "YYYY-MM-DD" UTC strings (evidence.day_key); `day_actors` maps a day to its number of acting hosts. This
module is named like the stdlib one; import it as `from sycope_clusters import calendar as cal`.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from statistics import median

from .params import FACTORY, Params

WORK, OFF = "work", "off"
MIN_CLASS_DAYS = 3       # fewer days than this in a class: no typical day to measure against
MIN_COMPARABLE = 3       # fewer days of today's class than this: compare with days of any class
_FACTORY_CLASSES = {w: (WORK if w < 5 else OFF) for w in range(7)}


@dataclass(frozen=True)
class Calendar:
    weekday_class: dict[int, str]          # local weekday (0 = Monday) -> "work" | "off"
    day_class: dict[str, str]              # every day seen -> its class
    dormant: frozenset[str]                # days far quieter than their class
    learned: bool                          # False: the factory Mon-Fri week, not enough history yet
    offset_min: int = 0                    # the UTC offset the weekdays were taken with


def local_weekday(day: str, offset_min: int) -> int:
    """Local weekday (0 = Monday) of a stored UTC day: the weekday of 12:00 UTC on it moved by the offset."""
    noon = datetime.strptime(day, "%Y-%m-%d") + timedelta(hours=12, minutes=offset_min)
    return noon.weekday()


def class_of(cal: Calendar, day: str) -> str:
    """The class of a day, also for a day that was not in the history (today)."""
    return cal.day_class.get(day) or cal.weekday_class[local_weekday(day, cal.offset_min)]


def learn(day_actors: dict[str, int], p: Params = FACTORY) -> Calendar:
    """Classes come from the median acting hosts of each local weekday, so a holiday that hit one weekday a few
    times does not turn it "off". With only `calendar.min_weeks` weeks of data a long holiday can still dominate."""
    offset = int(p["calendar.utc_offset_min"])
    weekday = {d: local_weekday(d, offset) for d in day_actors}
    classes = dict(_FACTORY_CLASSES)
    learned = len(day_actors) >= 7 * int(p["calendar.min_weeks"])
    if learned:
        per_weekday = {w: median(n for d, n in day_actors.items() if weekday[d] == w)
                       for w in sorted(set(weekday.values()))}
        typical = median(per_weekday.values())
        for w, m in per_weekday.items():
            classes[w] = OFF if m < p["calendar.off_ratio"] * typical else WORK
    day_class = {d: classes[weekday[d]] for d in sorted(day_actors)}
    dormant = set()
    for cls in (WORK, OFF):
        members = [d for d in day_class if day_class[d] == cls]
        if len(members) >= MIN_CLASS_DAYS:
            limit = p["calendar.dormant_ratio"] * median(day_actors[d] for d in members)
            dormant.update(d for d in members if day_actors[d] < limit)
    return Calendar(classes, day_class, frozenset(dormant), learned, offset)


def comparable(cal: Calendar, today: str, days: list[str], want: int = 7) -> list[str]:
    """Up to `want` past days to compare today with, newest first: non-dormant days of today's class; when fewer
    than 3 of them, the newest non-dormant days of any class."""
    live = sorted((d for d in set(days) if d < today and d not in cal.dormant), reverse=True)
    mine = [d for d in live if class_of(cal, d) == class_of(cal, today)]
    return (mine if len(mine) >= MIN_COMPARABLE else live)[:want]
