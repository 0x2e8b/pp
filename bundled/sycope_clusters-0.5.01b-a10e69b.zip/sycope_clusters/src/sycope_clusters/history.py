"""The incident history: every incident the queue showed, kept as it was at the time.

The board is rebuilt every minute and forgets. This keeps one record per incident (a host, a group of hosts with the
same pattern, a campaign in one network) from the moment it enters the queue until it leaves it: the peak verdict and
its reason, a snapshot of the evidence at that peak, what the analysts did (outcome, who, when) and the events in
between. Records are keyed by entity (entities.py), so the same table will hold incidents about a hostname, a user or
a device once those resolvers exist.

    opened       the incident appears on the board (Review or above)
    escalated    its verdict goes up; the snapshot is taken again at the new peak
    handled      an analyst acknowledges it, marks it false positive, resolves it or takes it
    reopened     it shows something new after being handled (or an analyst reopens it)
    closed       it has been off the board for GRACE_S: no alerts in the 24 h window, its verdict fell to Watch, or
                 (a host) it joined a group incident ("merged")

Why it closed is kept (end_reason): quiet (its evidence left the 24 h window: no alerts, or only weak ones are
left), exception (an analyst's exception took its evidence away), regrouped (most of its hosts are in other
incidents now) or merged. An incident that peaked at Act now or Investigate, went quiet and that nobody touched is
"ended, not reviewed": the queue keeps showing it until someone marks it seen or closes it, so a weekend's incidents
are there on Monday morning even when their alerts have left the window.

A group incident is matched by its hosts, not by its key: the key changes with the verdict, the hosts mostly do not.
"""

from __future__ import annotations

import logging
import re
import statistics
import threading
import time
from collections import Counter

from sycope_clusters import entities, fmt, playbook, triage
from sycope_clusters import evidence as ev
from sycope_clusters.params import FACTORY, Params, factory
from sycope_clusters.rules import FAMILIES, STAGES

log = logging.getLogger(__name__)

# the factory values of the grace_min, shift_gap_h and shift_h parameters, in seconds
GRACE_S = factory("grace_min") * 60       # off the board this long: closed (a flickering verdict does not split it)
SHIFT_GAP_S = factory("shift_gap_h") * 3600   # no team activity this long: the team was away; the next shift starts
SHIFT_S = factory("shift_h") * 3600       # a team that never stops (24/7): a handover covers one shift
MATCH = 0.5             # a group incident stays the same while half the hosts of the smaller side are shared
EVENTS_MAX = 80
HANDLED = ("ack", "tp", "benign", "fp", "resolved")
CLOSED = ("tp", "benign", "fp", "resolved")
OWNED = ("investigating", "escalated")      # an analyst has it: it stays until someone closes it
TAKEN = (*HANDLED, *OWNED)
WORDS = {"ack": "marked it seen", "tp": "closed it as a true positive", "benign": "closed it as benign",
         "fp": "closed it as a false positive", "resolved": "resolved it", "investigating": "took it",
         "escalated": "escalated it", "partial": "handled part of its hosts"}


# ---- what the board shows now, as records ------------------------------------------------------------------------

def current(b: ev.Board, tri: dict, overlay: list[dict] | tuple = ()) -> list[dict]:
    """The incidents on the board now (Review and above), in the shape of history records."""
    built, camps = triage.incidents(b, tri)
    out = []
    for x in built:
        if x["verdict"] == "watch":
            continue
        out.append(_target_rec(b, x, overlay) if x.get("target") else _host_rec(b, x, overlay) if x["type"] == "host"
                   else _story_rec(b, x, tri, overlay))
    for item, kids in camps.values():
        out.append(_campaign_rec(b, item, kids, tri, overlay))
    return out


def _parent(x: dict) -> str | None:
    return entities.key("subnet", x["parent"]) if x.get("parent") else None


def _host_rec(b: ev.Board, x: dict, overlay: list[dict] | tuple = ()) -> dict:
    ip = x["ip"]
    e = b.entities[ip]
    ids, res = entities.of_ip(ip, b.names, b.locs, getattr(b, "netnames", None))
    o = x.get("triage")
    outcome = by = at = note = reason = None
    if o and not o.get("changed"):
        outcome, by, at, note, reason = o.get("status"), o.get("who"), o.get("at"), o.get("note"), o.get("reason")
        if outcome in OWNED and o.get("owner"):
            by = o["owner"]
    return {"kind": "entity", "subject": entities.key("ip", ip), "label": ip, "ui_key": "h:" + ip, "parent": _parent(x),
            "first_ms": e.first, "last_ms": e.last, "verdict": e.verdict, "conf": round(e.conf, 4), "risk": e.risk,
            "stage": e.confirmed, "headline": e.headline, "reason": e.reason,
            "families": [k for k, _ in sorted(e.families.items(), key=lambda kv: -kv[1].bits)],
            "chains": [c for c, _, _ in e.chains], "members": [], "members_n": 1, "identifiers": ids,
            "resolution": res, "outcome": outcome, "outcome_by": by, "outcome_at": at, "outcome_note": note,
            "outcome_reason": reason, "handled_n": int(outcome in HANDLED), "changed": bool(o and o.get("changed")),
            "snap": lambda: snap_host(b, e, overlay)}


def _target_rec(b: ev.Board, x: dict, overlay: list[dict] | tuple = ()) -> dict:
    """A host attacked from outside, as a record about that host (kind entity, like a host that acts)."""
    ti = b.target_inc[x["ip"]]
    ids, res = entities.of_ip(ti.ip, b.names, b.locs, getattr(b, "netnames", None))
    ids["attacker"] = list(ti.attackers[:20])
    o = x.get("triage")
    outcome = by = at = note = reason = None
    if o and not o.get("changed"):
        outcome, by, at, note, reason = o.get("status"), o.get("who"), o.get("at"), o.get("note"), o.get("reason")
        if outcome in OWNED and o.get("owner"):
            by = o["owner"]
    return {"kind": "entity", "subject": entities.key("ip", ti.ip), "label": ti.ip, "ui_key": "h:" + ti.ip,
            "parent": None, "first_ms": ti.first, "last_ms": ti.last, "verdict": ti.verdict, "conf": None,
            "risk": ti.risk, "stage": None, "headline": ti.headline, "reason": ti.reason, "families": list(ti.families),
            "chains": [], "members": [], "members_n": 1, "identifiers": ids, "resolution": res, "outcome": outcome,
            "outcome_by": by, "outcome_at": at, "outcome_note": note, "outcome_reason": reason,
            "handled_n": int(outcome in HANDLED), "changed": bool(o and o.get("changed")),
            "snap": lambda: snap_target(b, ti, overlay)}


def _changed(b: ev.Board, ips: list[str], tri: dict) -> bool:
    """Whether a host of the group shows something new since an analyst handled it (the group is back in the queue)."""
    return any(o and o["changed"] for o in (ev.overlay(b.entities[ip], tri.get(ip)) for ip in ips if ip in b.entities))


def _group_outcome(b: ev.Board, ips: list[str], tri: dict) -> tuple:
    """A group's outcome from its hosts: one status when every host has it, "partial" when some do."""
    got = []
    for ip in ips:
        e = b.entities.get(ip)
        o = ev.overlay(e, tri.get(ip)) if e else None
        if o and not o["changed"]:
            got.append(o)
    if not got:
        return None, None, None, 0
    last = max(got, key=lambda o: o.get("at") or 0)
    handled = sum(1 for o in got if o["status"] in HANDLED)
    if len(got) < len(ips):
        return "partial", last.get("who"), last.get("at"), handled
    status = Counter(o["status"] for o in got).most_common(1)[0][0]
    return status, last.get("who"), last.get("at"), handled


def _story_rec(b: ev.Board, x: dict, tri: dict, overlay: list[dict] | tuple = ()) -> dict:
    s = b.stories[x["key"]]
    ips = list(s["members"])
    outcome, by, at, handled = _group_outcome(b, ips, tri)
    lead = b.entities[ips[0]] if ips else None
    names = [b.names[ip] for ip in ips if b.names.get(ip)]
    return {"kind": "group", "subject": entities.key("pattern", s["key"]), "label": s["title"], "ui_key": "s:" + s["key"],
            "parent": _parent(x), "first_ms": s["first"], "last_ms": s["last"], "verdict": s["verdict"],
            "conf": round(s["conf"], 4), "risk": s["risk"], "stage": s["confirmed"],
            "headline": f"{s['title']}: {fmt.plural(len(ips), 'host')}", "peak_n": len(ips), "reason": (f"for example {lead.ip}: {lead.reason}" if lead else ""),
            "families": list(x["families"]), "chains": list(x["chains"]), "members": [entities.key("ip", ip) for ip in ips],
            "members_n": len(ips), "identifiers": {"host": names[:100]} if names else {},
            "resolution": {"method": "pattern", "confidence": None}, "outcome": outcome, "outcome_by": by,
            "outcome_at": at, "outcome_note": None, "outcome_reason": None, "handled_n": handled,
            "changed": _changed(b, ips, tri), "snap": lambda: snap_story(b, s["key"], tri, overlay)}


def _campaign_rec(b: ev.Board, item: dict, kids: list[dict], tri: dict, overlay: list[dict] | tuple = ()) -> dict:
    ips: list[str] = []
    for k in kids:
        ips.extend(b.stories[k["key"]]["members"] if k["type"] == "story" else [k["ip"]])
    outcome, by, at, handled = _group_outcome(b, ips, tri)
    why = item.get("reason") or "more hosts of one network segment at Investigate or above than chance explains"
    why += f"; {item['why']}" if item.get("why") else ""
    return {"kind": "campaign", "subject": entities.key("subnet", item["net"]), "label": item["title"],
            "ui_key": "c:" + item["net"], "parent": None, "first_ms": item["first"], "last_ms": item["last"],
            "verdict": item["verdict"], "conf": round(item["conf"], 4), "risk": item["risk"], "stage": item["stage"],
            "headline": f"{item['title']}: {fmt.plural(len(ips), 'host')} in {fmt.plural(len(kids), 'incident')}", "peak_n": len(ips),
            "reason": why,
            "families": list(item["families"]), "chains": list(item["chains"]),
            "members": [entities.key("ip", ip) for ip in ips], "members_n": len(ips),
            "identifiers": {"subnet": [item["net"]]}, "resolution": {"method": "network", "confidence": None},
            "outcome": outcome, "outcome_by": by, "outcome_at": at, "outcome_note": None, "outcome_reason": None,
            "handled_n": handled, "changed": _changed(b, ips, tri),
            "snap": lambda: snap_campaign(b, item, kids, overlay)}


# ---- snapshots: the evidence as it was at the incident's peak ----------------------------------------------------

def _steps(make) -> list[dict] | None:
    """The next steps at the peak, kept with the snapshot so the record can be worked after it ends."""
    try:
        return make()
    except Exception:   # a snapshot without steps is still a snapshot
        log.exception("next steps for the snapshot failed")
        return None


def snap_host(b: ev.Board, e: ev.Entity, overlay: list[dict] | tuple = ()) -> dict:
    steps, back = ev.narrative(e, b.names, b.params)
    fs = sorted(e.findings, key=lambda f: (-f.counted, -f.bits, -f.n))[:25]
    return {"what": "host", "ip": e.ip, "name": b.names.get(e.ip), "verdict": e.verdict, "reason": e.reason,
            "headline": e.headline, "conf": round(e.conf, 4), "risk": e.risk, "E": e.E, "stage": e.confirmed,
            "stages": triage.stage_marks(e.findings, b.params), "crown": e.crown, "novelty": e.novelty,
            "alerts": e.alerts,
            "findings_n": len(e.findings), "first": e.first, "last": e.last,
            "families": [{"family": k, "label": FAMILIES[k][0], "bits": round(f.bits, 2), "rule": f.rule.name}
                         for k, f in sorted(e.families.items(), key=lambda kv: -kv[1].bits)],
            "chains": [{"id": c, "title": ev.CHAINS[c][0], "bits": bb, "continuity": t} for c, bb, t in e.chains],
            "narrative": steps[:12], "background": back[:4],
            "steps": _steps(lambda: playbook.for_host(b, e, 0, overlay)),
            "findings": [{"rule": f.rule.name, "family": f.family, "flabel": FAMILIES.get(f.family, ("?",))[0],
                          "stage": f.stage, "cp": ev.cp_label(f, b.names), "n": f.n, "first": f.first, "last": f.last,
                          "bits": round(f.bits, 2), "counted": f.counted, "attack": f.rule.attack,
                          "attack_id": f.rule.technique, "tpl_tag": f.tpl_tag} for f in fs]}


def snap_target(b: ev.Board, ti: ev.TargetIncident, overlay: list[dict] | tuple = ()) -> dict:
    fs = sorted(b.target_f.get(ti.ip, ()), key=lambda f: (-f.down, -f.n))[:25]
    return {"what": "target", "ip": ti.ip, "name": b.names.get(ti.ip), "verdict": ti.verdict, "reason": ti.reason,
            "headline": ti.headline, "crown": ti.crown, "attackers": ti.attackers, "ti": ti.ti,
            "answered": ti.answered, "alerts": ti.alerts, "first": ti.first, "last": ti.last,
            "steps": _steps(lambda: playbook.for_target(b, ti, overlay)),
            "families": [{"family": k, "label": FAMILIES.get(k, (k,))[0]} for k in ti.families],
            "findings": [{"rule": f.rule.name, "family": f.family, "cp": f.cp, "port": f.port, "n": f.n,
                          "first": f.first, "last": f.last, "down": f.down, "up": f.up} for f in fs]}


def snap_story(b: ev.Board, key: str, tri: dict, overlay: list[dict] | tuple = ()) -> dict:
    d = triage.story_detail(b, key, tri) or {}
    return {"what": "group", "title": d.get("title"), "verdict": d.get("verdict"), "conf": d.get("conf"),
            "count": d.get("count"), "stages": d.get("stages"), "families": d.get("families"),
            "chains": d.get("chain_words"), "path": d.get("path"), "spread": d.get("spread"),
            "nets": d.get("all_nets"), "common_targets": d.get("common_targets"), "outside": d.get("outside"),
            "first": d.get("first"), "last": d.get("last"),
            "steps": _steps(lambda: playbook.for_story(b, b.stories[key], overlay)),
            "members": [{"ip": m["ip"], "name": m.get("name"), "verdict": m["verdict"], "conf": m["conf"],
                         "stage": m["stage"], "stages": m["stages"], "path": m.get("path")}
                        for m in (d.get("members") or [])[:100]]}


def snap_campaign(b: ev.Board, item: dict, kids: list[dict], overlay: list[dict] | tuple = ()) -> dict:
    return {"what": "campaign", "title": item["title"], "net": item["net"], "verdict": item["verdict"],
            "conf": item["conf"], "count": item["count"], "stages": item["stages"], "families": item["families"],
            "chains": [{"id": c, "title": ev.CHAINS[c][0]} for c in item["chains"]], "nets": item["nets"],
            "first": item["first"], "last": item["last"],
            "steps": _steps(lambda: playbook.for_campaign(b, item, kids, overlay)),
            "children": [{"type": k["type"], "key": k["key"], "title": k.get("title") or k.get("headline"),
                          "ip": k.get("ip"), "verdict": k["verdict"], "count": k.get("count", 1), "conf": k["conf"],
                          "stage": k.get("stage"), "stages": k.get("stages")} for k in kids[:60]]}


# ---- keeping the records up to date ------------------------------------------------------------------------------

def _search(r: dict) -> str:
    fams = r.get("families") or []
    parts = [r.get("subject"), r.get("label"), r.get("headline"), r.get("reason"), " ".join(fams),
             " ".join(FAMILIES.get(f, (f,))[0] for f in fams), " ".join(r.get("chains") or [])]
    for values in (r.get("identifiers") or {}).values():
        parts.append(" ".join(values))
    return " ".join(p for p in parts if p).lower()[:4000]


def _outcome_text(r: dict) -> str:
    who = r.get("outcome_by") or "an analyst"
    text = f"{who} {WORDS.get(r.get('outcome'), r.get('outcome'))}"
    if r.get("outcome_reason"):
        text += f" ({r['outcome_reason']})"
    return text + (f": {r['outcome_note']}" if r.get("outcome_note") else "")


def _create(r: dict, now: float) -> tuple[dict, list[str]]:
    events = [{"at": now, "kind": "opened", "verdict": r["verdict"], "text": r["reason"]}]
    if r["outcome"]:
        events.append({"at": r["outcome_at"] or now, "kind": "handled", "text": _outcome_text(r),
                       "outcome": r["outcome"]})
    fields = {k: r[k] for k in ("kind", "subject", "label", "ui_key", "parent", "first_ms", "last_ms", "headline",
                                "reason", "families", "chains", "members_n", "identifiers", "resolution", "outcome",
                                "outcome_by", "outcome_at", "outcome_note", "handled_n")}
    fields["outcome_reason"] = r.get("outcome_reason")
    fields["peak_n"] = r.get("peak_n")
    fields["peak_at"] = now
    fields.update(opened_at=now, last_seen=now, closed_at=None, verdict_peak=r["verdict"], verdict_last=r["verdict"],
                  conf_peak=r["conf"], risk_peak=r["risk"], stage_peak=r["stage"], status="open", snapshot=r["snap"](),
                  snapshot_at=now, events=events, search=_search(r))
    return fields, r["members"]


def _update(o: dict, r: dict, now: float) -> tuple[int, dict, list[str]]:
    f = {"last_seen": now, "first_ms": min(x for x in (o["first_ms"], r["first_ms"]) if x is not None),
         "last_ms": max(o["last_ms"] or 0, r["last_ms"] or 0), "verdict_last": r["verdict"]}
    for k in ("subject", "ui_key", "label", "parent", "handled_n"):    # only what changed: the store tells a refresh from a decision
        if o.get(k) != r[k]:
            f[k] = r[k]
    events = list(o["events"] or [])
    rank, peak_rank = ev.VRANK[r["verdict"]], ev.VRANK.get(o["verdict_peak"], -1)
    last_rank = ev.VRANK.get(o["verdict_last"], -1)
    if rank != last_rank:
        events.append({"at": now, "kind": "escalated" if rank > last_rank else "de-escalated", "verdict": r["verdict"],
                       "text": r["reason"]})
    snap = o.get("snapshot") or {}
    if rank > peak_rank or (rank == peak_rank and (r["conf"] or 0) > (o["conf_peak"] or 0) + 0.1) or not snap:
        f.update(verdict_peak=r["verdict"] if rank >= peak_rank else o["verdict_peak"],
                 conf_peak=max(r["conf"] or 0, o["conf_peak"] or 0), risk_peak=max(r["risk"] or 0, o["risk_peak"] or 0),
                 headline=r["headline"], peak_n=r.get("peak_n"), reason=r["reason"], families=r["families"], chains=r["chains"],
                 snapshot=r["snap"](), snapshot_at=now)
    if rank > peak_rank:
        f["peak_at"] = now          # the SLA clock of the new peak verdict (sla.start_of)
    if r["stage"] is not None and (o["stage_peak"] is None or r["stage"] > o["stage_peak"]):
        f["stage_peak"] = r["stage"]
    if (r["outcome"], r["outcome_at"]) != (o["outcome"], o["outcome_at"]):
        if r["outcome"]:
            events.append({"at": r["outcome_at"] or now, "kind": "handled", "text": _outcome_text(r),
                           "outcome": r["outcome"]})
        elif o["outcome"]:
            f["reopened_at"] = now          # the SLA clock of the reopened period starts here (sla.clock_of)
            events.append({"at": now, "kind": "reopened", "verdict": r["verdict"],
                           "text": r.get("reopen_text") or
                           "back in the queue: it shows something it did not show when it was handled"})
        f.update(outcome=r["outcome"], outcome_by=r["outcome_by"], outcome_at=r["outcome_at"],
                 outcome_note=r["outcome_note"], outcome_reason=r.get("outcome_reason"))
    new_members = [m for m in r["members"] if m not in o["members"]]
    if new_members:
        f["members_n"] = len(o["members"]) + len(new_members)
    ids = entities.merge(o["identifiers"], r["identifiers"])
    if ids != o["identifiers"]:
        f["identifiers"] = ids
    if events != (o["events"] or []):
        f["events"] = events[-EVENTS_MAX:]
    f["search"] = _search({**o, **r, "identifiers": ids})
    return o["id"], f, new_members


def _excepted(e: ev.Entity | None) -> bool:
    return bool(e is not None and any(f.excepted for f in e.findings))


def _covered(e: ev.Entity | None) -> bool:
    """Every piece of evidence of the host is excepted: an exception took all of it (nothing counts any more)."""
    return bool(e is not None and e.findings and any(f.excepted for f in e.findings)
                and not any(f.bits > 0 for f in e.findings))


def _covering(o: dict, b: ev.Board) -> tuple[float, int] | None:
    """(when the exception began to cover all of the record's evidence, the id of that exception) when the record's
    current evidence is fully covered by exceptions: its host (for a group or campaign, every one of its hosts) shows
    nothing but excepted findings, some of them strong (Entity.excepted_at is set). None otherwise."""
    if o["kind"] == "entity":
        es = [b.entities.get(entities.parse(o["subject"])[1])]
    else:
        es = [b.entities.get(v) for k, v in map(entities.parse, o["members"]) if k == "ip"]
    if not es or not all(_covered(e) and e.excepted_at for e in es):
        return None
    ids = [f.excepted["id"] for e in es for f in e.findings if f.excepted and f.excepted.get("id") is not None]
    return max(e.excepted_at for e in es), max(ids, default=0)


def _all_excepted(o: dict, b: ev.Board) -> bool:
    return _covering(o, b) is not None


def _end_reason(o: dict, b: ev.Board) -> str:
    """Why an incident left the board: quiet (its evidence left the window), exception (an analyst's exception
    took it away) or regrouped (most of its hosts are in other incidents now)."""
    if o["kind"] == "entity":
        return "exception" if _excepted(b.entities.get(entities.parse(o["subject"])[1])) else "quiet"
    ips = [v for k, v in map(entities.parse, o["members"]) if k == "ip"]
    if not ips:
        return "quiet"
    on = [b.entities.get(ip) for ip in ips]
    if 2 * sum(1 for e in on if e is not None and e.verdict != "watch") >= len(ips):
        return "regrouped"
    return "exception" if 2 * sum(1 for e in on if _excepted(e)) >= len(ips) else "quiet"


def _close(o: dict, b: ev.Board, in_groups: set) -> tuple[int, dict, list[str]] | None:
    outcome = o["outcome"]
    if o["kind"] == "entity" and outcome in OWNED and o["subject"] not in in_groups:
        return None  # an analyst has it: quiet is not over, it ends when someone closes it
    end = _end_reason(o, b)
    if o["kind"] == "entity":
        ip = entities.parse(o["subject"])[1]
        if o["subject"] in in_groups and outcome in (None, "investigating"):
            outcome, why, end = "merged", "joined a group incident", "merged"
        elif ip in b.entities:
            why = ("its verdict fell to Watch: an exception took its evidence away" if end == "exception" else
                   "its verdict fell to Watch: its strong evidence left the 24 h window")
        else:
            why = "no alerts in the last 24 hours"
    elif o["kind"] == "group":
        why = {"regrouped": "the group is gone: most of its hosts are in other incidents now",
               "exception": "the group is gone: an exception took its hosts' evidence away"}.get(
            end, "the group is gone: its hosts went quiet or left the 24 h window")
    else:
        why = "no longer more hosts of this network segment at Investigate or above than chance explains"
    if not outcome and end == "quiet" and o["verdict_peak"] in ("act", "investigate") and not o.get("parent"):
        why += "; nobody has looked at it: it stays in the queue under Ended, not reviewed"
    events = list(o["events"] or [])
    fields: dict = {"status": "closed", "closed_at": o["last_seen"], "outcome": outcome or "expired", "end_reason": end}
    cover = _covering(o, b) if not outcome and end == "exception" else None
    if cover:
        # an exception took all of it: that is a decision with a reason and an expiry, handled for the SLA. Its time is
        # the moment the exception began to cover everything: memory reads it as an analyst's action, so the release
        # lasts after the excepted findings have left the window
        fields.update(outcome="excepted", outcome_at=cover[0], _exception=cover[1])
        events.append({"at": o["last_seen"], "kind": "handled", "outcome": "excepted",
                       "text": f"excepted: exception {cover[1]} covers all of its evidence"})
    events.append({"at": o["last_seen"], "kind": "closed", "text": why})
    return o["id"], {**fields, "events": events[-EVENTS_MAX:]}, []


def _match(r: dict, groups: list[dict], taken: set) -> dict | None:
    mem = set(r["members"])
    best, score = None, 0.0
    for o in groups:
        if o["id"] in taken or not o["members"] or not mem:
            continue
        shared = len(mem & o["members"])
        if shared:
            sc = shared / min(len(mem), len(o["members"]))
            if sc > score:
                best, score = o, sc
    return best if score >= MATCH else None


_LOCK = threading.Lock()   # the poller and an analyst's request may both bring the history up to date


def record(b: ev.Board, tri: dict, store, now: float | None = None, overlay: list[dict] | tuple = ()) -> dict:
    """Bring the history up to date with the board (after every rebuild and every analyst action). Returns how many
    records changed. `overlay` is the admin's playbook overlay (the steps kept with a snapshot are the effective
    ones)."""
    with _LOCK:
        return _record(b, tri, store, now or time.time(), overlay)


def _record(b: ev.Board, tri: dict, store, now: float, overlay: list[dict] | tuple = ()) -> dict:
    cur = current(b, tri, overlay)
    opened = store.open_incidents()
    by_subject = {o["subject"]: o for o in opened if o["kind"] != "group"}
    groups = [o for o in opened if o["kind"] == "group"]
    taken: set = set()
    creates, updates = [], []
    new_ones: list[dict] = []     # the records created (what an outbound webhook says: incident.new)
    changes: list[dict] = []      # the open records that rose or came back (incident.raised)
    stamp = {"config_version": b.config_version, "profile_day": b.profile_day}   # what the record was scored under
    top = ev.VRANK["investigate"]
    for r in cur:
        o = _match(r, groups, taken) if r["kind"] == "group" else by_subject.get(r["subject"])
        if o is None or o["id"] in taken:
            fields, members = _create(r, now)
            creates.append(({**fields, **stamp}, members))
            if not r["parent"] and ev.VRANK[r["verdict"]] >= top:
                new_ones.append({"index": len(creates) - 1, "verdict": r["verdict"]})
        else:
            taken.add(o["id"])
            iid, fields, members = _update(o, r, now)
            updates.append((iid, {**fields, **stamp}, members))
            rank = ev.VRANK[r["verdict"]]
            if not r["parent"] and rank >= top:
                # a rise above the peak this incident has shown, or back in the queue after it was handled; a verdict
                # the hysteresis lowered and that rises again never repeats what was already said
                peak = ev.VRANK.get(o["verdict_peak"], -1)
                if rank > peak:
                    # first time it reaches Investigate: new to whoever listens (a Review incident was never sent)
                    changes.append({"id": iid, "transition": "entered" if peak < top else "escalated",
                                    "verdict": r["verdict"], "prev": o["verdict_peak"]})
                elif o["outcome"] and not r["outcome"] and r.get("changed"):
                    changes.append({"id": iid, "transition": "reopened", "verdict": r["verdict"],
                                    "prev": o["verdict_last"]})
    in_groups = {m for r in cur if r["kind"] == "group" for m in r["members"]}
    closed = 0
    excepted: list[dict] = []    # the records closed as excepted (what an outbound webhook says: incident.status)
    for o in opened:
        if o["id"] in taken:
            continue
        if now - o["last_seen"] < b.params["grace_min"] * 60 and not _all_excepted(o, b):
            continue      # (a record whose evidence an exception took away has nothing left to wait for: it leaves the SLA queue now)
        c = _close(o, b, in_groups)
        if c:
            x = c[1].pop("_exception", None)
            if x is not None:
                excepted.append({"id": c[0], "exception": x, "at": c[1]["outcome_at"]})
            updates.append(c)
            closed += 1
    ids: list[int] = []
    if creates or updates:
        ids = store.apply_incidents(creates, updates)
    events = [{"id": ids[n["index"]], "transition": "entered", "verdict": n["verdict"], "prev": None}
              for n in new_ones if n["index"] < len(ids)] + changes
    return {"opened": len(creates), "updated": len(updates) - closed, "closed": closed, "events": events,
            "excepted": excepted}


def note(store, target: str, who: str, text: str, now: float | None = None, product: str = "triage") -> bool:
    """An analyst's note on an incident (h:<ip>, s:<story>, c:<network>; Clusters: cl:<id>, ct:<ip>): one more event of
    its open record."""
    with _LOCK:
        o = store.open_incident_by_key(target, product)
        if not o:
            return False
        events = list(o["events"] or []) + [{"at": now or time.time(), "kind": "note", "text": f"{who}: {text}"}]
        store.apply_incidents([], [(o["id"], {"events": events[-EVENTS_MAX:]}, [])])
        return True


def workable(o: dict) -> bool:
    """A record whose next steps can be checked: open, or one that ended quiet (it can still be worked)."""
    return o["status"] == "open" or (o["status"] == "closed" and o.get("end_reason") == "quiet")


def event(store, iid: int, kind: str, text: str, now: float | None = None, product: str = "triage") -> bool:
    """One more event of a workable record by its id (a next step checked or unchecked). Only a record of `product`:
    the other product's id is not found."""
    with _LOCK:
        o = store.incident(iid, product)
        if not o or not workable(o):
            return False
        events = list(o["events"] or []) + [{"at": now or time.time(), "kind": kind, "text": text}]
        store.apply_incidents([], [(iid, {"events": events[-EVENTS_MAX:]}, [])])
        return True


def review(store, iid: int, status: str, who: str, note: str = "", reason: str | None = None,
           now: float | None = None, owner: str | None = None, product: str = "triage") -> dict:
    """An analyst works an incident that ended with nobody having looked at it: seen (ack), closed (tp, benign, fp,
    resolved), taken (investigating) or escalated. A taken record stays a record (closed, quiet) with an outcome that
    says who has it. status "open" puts it back as not reviewed (undo, release). Returns the previous outcome. A record
    of the other product is refused like a missing one."""
    now = now or time.time()
    with _LOCK:
        o = store.incident(iid, product)
        if (not o or o["status"] != "closed" or o.get("end_reason") != "quiet"
                or o["outcome"] not in ("expired", *HANDLED, *OWNED)):
            raise ValueError("this incident is not one that ended without a review: refresh the page")
        prev = {k: o[k] for k in ("outcome", "outcome_by", "outcome_at", "outcome_note", "outcome_reason")}
        events = list(o["events"] or [])
        if status == "open":
            f = {"outcome": "expired", "outcome_by": None, "outcome_at": None, "outcome_note": None,
                 "outcome_reason": None}
            events.append({"at": now, "kind": "reopened", "text": f"{who} put it back as not reviewed"})
        elif status in OWNED:
            owner = owner or (who if status == "investigating" else "L2")
            f = {"outcome": status, "outcome_by": owner, "outcome_at": now, "outcome_note": note or None,
                 "outcome_reason": None}
            text = (f"{who} took it" if status == "investigating" and owner == who else
                    f"{who} escalated it to {owner}" if status == "escalated" else f"{who} assigned it to {owner}")
            events.append({"at": now, "kind": "handled", "text": text + " (after it ended)"
                           + (f": {note}" if note else ""), "outcome": status})
        else:
            f = {"outcome": status, "outcome_by": who, "outcome_at": now, "outcome_note": note or None,
                 "outcome_reason": reason}
            events.append({"at": now, "kind": "handled", "text": _outcome_text(f) + " (after it ended)",
                           "outcome": status})
        f["events"] = events[-EVENTS_MAX:]
        f["handled_n"] = o["members_n"] if status in HANDLED else 0
        store.apply_incidents([], [(iid, f, [])])
    return {"previous": prev, "previous_owner": prev["outcome_by"] if prev["outcome"] in OWNED else None,
            "kind": o["kind"], "subject": o["subject"], "label": o["label"], "ui_key": o["ui_key"]}


def _ended_row(o: dict, b: ev.Board | None) -> dict:
    """A record that ended, as a queue row: the peak verdict and reason, and whether the host is back on the board."""
    r = _row(o, b.params if b is not None else FACTORY)
    r["reason"] = o["reason"]
    kind, value = entities.parse(o["subject"])
    e = b.entities.get(value) if (b is not None and kind == "ip") else None
    r["back"] = bool(kind == "ip" and b is not None and ((e is not None and e.verdict != "watch")
                                                         or value in getattr(b, "target_inc", {})))
    r["back_verdict"] = e.verdict if r["back"] and e is not None else None
    r["name"] = b.names.get(value) if (b is not None and kind == "ip") else None
    r["crown"] = bool(e is not None and e.crown)
    return r


def unreviewed(store, b: ev.Board | None, days: int | None = None, now: float | None = None,
               product: str = "triage") -> list[dict]:
    """Incidents that reached Act now or Investigate, went quiet and ended with nobody having looked at them (the
    last `days`): for the queue, worst first. "back" when the same host is on the board again now."""
    now = now or time.time()
    days = (b.params if b else Params.factory())["unreviewed_days"] if days is None else days
    out = [_ended_row(o, b) for o in store.unreviewed(now - days * 86400, product)]
    out.sort(key=lambda r: (-ev.VRANK.get(r["verdict"], 0), -(r["last_ms"] or 0)))
    return out


def taken(store, b: ev.Board | None, product: str = "triage") -> list[dict]:
    """Ended incidents an analyst took or escalated after they ended (no age limit: work taken does not disappear),
    in the shape of unreviewed(), newest first."""
    return [_ended_row(o, b) for o in store.taken_records(product)]


def shift_start(store, now: float | None = None, look_days: int = 14, p: Params = FACTORY,
                product: str = "triage") -> dict:
    """Since when the team has been away: the last thing anyone did before the latest pause of shift_gap_h or more
    (a night, a weekend). A team active around the clock gets one shift (shift_h); no activity at all in
    `look_days`, the last 24 hours."""
    now = now or time.time()
    gap, shift = p["shift_gap_h"] * 3600, p["shift_h"] * 3600
    acts = store.team_activity(now - look_days * 86400, product)
    if not acts:
        return {"since": now - 86400, "how": "none", "at": None, "who": None}
    prev = now
    for at, who in acts:
        if prev - at >= gap:
            return {"since": at, "how": "away", "at": at, "who": who}
        if now - at > 86400:
            return {"since": now - shift, "how": "around the clock", "at": None, "who": None}
        prev = at
    return {"since": now - look_days * 86400, "how": "first", "at": None, "who": None}


# ---- views -------------------------------------------------------------------------------------------------------

_PEAK_HOSTS = re.compile(r": (\d+) hosts\b")


def peak_hosts(headline: str | None) -> int | None:
    """The size of a group or campaign at its peak: the headline is frozen then ("title: 343 hosts in 14
    incidents"), while members_n keeps growing to every host the record ever held."""
    m = _PEAK_HOSTS.search(headline or "")
    return int(m.group(1)) if m else None


def _peak_n(o: dict) -> int | None:
    """The stored peak size; records written before 1.2 have none, so it is read from their headline."""
    if o["kind"] == "entity":
        return None
    return o.get("peak_n") if o.get("peak_n") is not None else peak_hosts(o["headline"])


def stage_name(stage: int | None, families: list | None) -> str:
    """The name of a stored peak stage, for the CSV. Records stored before 1.2 put command-and-control evidence at
    stage 3 (Impact); the records carry no version, but since 1.2 a stage 3 needs an exfiltration or flood family, so a
    stage 3 whose families hold a C2 family and neither of those was a command-channel incident, a Foothold on the
    1.2 scale."""
    if stage is None:
        return ""
    fams = set(families or [])
    if stage == 3 and fams & {"CL-01", "CL-02", "CL-03"} and not fams & {"CL-06", "CL-08"}:
        return "Foothold (stored as stage 3 before 1.2)"
    return STAGES[stage] if 0 <= stage < len(STAGES) else str(stage)


def _row(o: dict, p: Params = FACTORY) -> dict:
    kind, value = entities.parse(o["subject"])
    tth = (o["outcome_at"] - o["opened_at"] if o.get("outcome_at") and o.get("outcome") in TAKEN
           and o["outcome_at"] >= o["opened_at"] else None)
    host = ((o.get("identifiers") or {}).get("host") or [None])[0] if o["kind"] == "entity" else None
    return {"id": o["id"], "kind": o["kind"], "subject": o["subject"], "subject_kind": kind, "subject_value": value,
            "subject_label": entities.KINDS.get(kind, kind), "label": o["label"], "host": host, "ui_key": o["ui_key"],
            "parent": o["parent"], "opened_at": o["opened_at"], "closed_at": o["closed_at"], "last_seen": o["last_seen"],
            "first_ms": o["first_ms"], "last_ms": o["last_ms"], "verdict": o["verdict_peak"],
            "verdict_last": o["verdict_last"], "conf": o["conf_peak"],
            "conf_word": ev.conf_word(o["conf_peak"], p) if o["conf_peak"] is not None else None, "stage": o["stage_peak"],
            "stage_name": stage_name(o["stage_peak"], o["families"]), "headline": o["headline"], "families": o["families"], "members_n": o["members_n"],
            "peak_n": _peak_n(o), "status": o["status"],
            "outcome": o["outcome"], "outcome_by": o["outcome_by"], "outcome_at": o["outcome_at"],
            "outcome_reason": o.get("outcome_reason"), "end_reason": o.get("end_reason"), "handled_n": o["handled_n"],
            "tth": tth}


def _verdict_stats(rows: list[dict]) -> dict:
    out = {}
    for v in ("act", "investigate", "review"):
        rs = [r for r in rows if r["verdict_peak"] == v]
        if not rs:
            continue
        closed = [r for r in rs if r["outcome"] in CLOSED]
        tths = [r["outcome_at"] - r["opened_at"] for r in rs
                if r["outcome"] in TAKEN and r.get("outcome_at") and r["outcome_at"] >= r["opened_at"]]
        out[v] = {"incidents": len(rs), "closed": len(closed),
                  "tp": sum(1 for r in closed if r["outcome"] in ("tp", "resolved")),
                  "benign": sum(1 for r in closed if r["outcome"] == "benign"),
                  "fp": sum(1 for r in closed if r["outcome"] == "fp"),
                  "median_tth": statistics.median(tths) if tths else None,
                  "expired": sum(1 for r in rs if r["outcome"] == "expired"),
                  "open": sum(1 for r in rs if r["status"] == "open")}
    return out


def stats(rows: list[dict], days: int) -> dict:
    """Counted like the queue counts: an incident inside a campaign is part of the campaign (its outcome rolls up
    into the campaign's), so the numbers are about the top-level incidents and say how many sit inside."""
    nested = sum(1 for r in rows if r.get("parent"))
    rows = [r for r in rows if not r.get("parent")]
    handled = [r for r in rows if r["outcome"] in HANDLED]
    tths = [r["outcome_at"] - r["opened_at"] for r in rows
            if r["outcome"] in TAKEN and r.get("outcome_at") and r["outcome_at"] >= r["opened_at"]]
    by_outcome = Counter((r["outcome"] or ("open" if r["status"] == "open" else "none")) for r in rows)
    first = min((r["opened_at"] for r in rows), default=None)
    covered = max(1.0, min(days or 3650, (time.time() - first) / 86400)) if first else 1.0
    return {"incidents": len(rows), "nested": nested, "per_day": round(len(rows) / covered, 1) if rows else None,
            "covered_days": round(covered, 1),
            "open": sum(1 for r in rows if r["status"] == "open"), "handled": len(handled),
            "fp_rate": (sum(1 for r in handled if r["outcome"] == "fp") / len(handled)) if handled else None,
            "median_tth": statistics.median(tths) if tths else None, "expired": by_outcome.get("expired", 0),
            "by_outcome": dict(by_outcome), "by_verdict": dict(Counter(r["verdict_peak"] for r in rows)),
            "verdicts": _verdict_stats(rows),
            "by_kind": dict(Counter(r["kind"] for r in rows))}


def listing(store, days: int = 30, kind: str = "", verdict: str = "", outcome: str = "", q: str = "",
            limit: int = 100, offset: int = 0, hours: int = 0, product: str = "triage",
            p: Params = FACTORY) -> dict:
    """The records of the last `days` (or `hours`, for a shift), filtered, with the numbers of the period."""
    since = time.time() - hours * 3600 if hours else (time.time() - days * 86400 if days else 0)
    rows, total = store.history_query(since, kind, verdict, outcome, q, limit, offset, product)
    st = stats(store.history_rows(since, product), days if not hours else 1)
    if hours:
        st["per_day"], st["covered_days"] = None, None
    return {"rows": [_row(r, p) for r in rows], "total": total, "days": days, "hours": hours, "offset": offset,
            "stats": st}


def handover(store, since: float | None = None, tri: dict | None = None, unreviewed_days: int | None = None,
             p: Params = FACTORY, product: str = "triage") -> dict:
    """What happened since `since` (a shift; None = since the team was last here, see shift_start), for the next
    shift: new incidents, what the team did, what is still open and who has it, what ended with nobody having
    looked at it, and the notes. Top-level incidents, as in the queue. `product`: one product's records and lines only
    (Clusters' records carry their state in their outcome, which its work layer keeps current)."""
    tri = tri or {}
    unreviewed_days = p["unreviewed_days"] if unreviewed_days is None else unreviewed_days
    start = (shift_start(store, p=p, product=product) if since is None
             else {"since": since, "how": "asked", "at": None, "who": None})
    since = start["since"]
    rows = [_row(o) for o in store.history_changed(since, product)]
    top = [r for r in rows if not r["parent"]]
    opened = [r for r in top if r["opened_at"] >= since]
    acted = [r for r in rows if r["outcome"] in TAKEN and (r["outcome_at"] or 0) >= since]
    still = [r for r in top if r["status"] == "open"]
    for r in still:   # who has it now: a host from the triage state, a group from its outcome
        kind, value = entities.parse(r["subject"])
        t = tri.get(value) if kind == "ip" and product == "triage" else None
        r["now_status"] = t["status"] if t else r["outcome"]
        r["now_owner"] = (t.get("owner") or t.get("who")) if t else r["outcome_by"]
    for o in store.taken_records(product):   # taken after it ended: a record that stays closed but is being worked
        r = _row(o)
        r["now_status"], r["now_owner"] = r["outcome"], r["outcome_by"]
        still.append(r)
    ended = [_row(o) for o in store.unreviewed(min(since, time.time() - unreviewed_days * 86400), product)]
    notes, _ = store.audit_query(action="comment", since=since, limit=60, product=product)
    noted, _ = store.audit_query(since=since, limit=300, product=product)
    notes += [a for a in noted if a["note"] and a["action"].startswith(("triage:", "hosts:"))
              and a["action"] != "triage:undo"]
    notes.sort(key=lambda a: -a["at"])
    return {"since": since, "start": start, "now": time.time(), "opened": opened, "acted": acted, "still": still,
            "ended": ended,
            "notes": notes[:60], "by_verdict": dict(Counter(r["verdict"] for r in opened))}


def _live(b: ev.Board | None, o: dict) -> bool:
    if b is None or o["status"] != "open" or not o.get("ui_key"):
        return False
    t, v = o["ui_key"][:1], o["ui_key"][2:]
    if t == "h":
        e = b.entities.get(v)
        return bool(e and e.verdict != "watch") or v in getattr(b, "target_inc", {})
    if t == "s":
        return v in b.stories
    return any(c["net"] == v for c in b.campaigns)


def item(store, b: ev.Board | None, iid: int, tri: dict | None = None, product: str = "triage",
         p: Params = FACTORY) -> dict | None:
    """One record for its page: the row, the snapshot, the events, the members with what they are now. A record of
    another product is not found."""
    o = store.incident(iid, product)
    if not o:
        return None
    tri = tri or {}
    members = []
    for m in o["members"][:500]:
        kind, value = entities.parse(m)
        e = b.entities.get(value) if (b and kind == "ip") else None
        t = tri.get(value) if kind == "ip" else None
        members.append({"entity": m, "kind": kind, "value": value, "name": b.names.get(value) if b else None,
                        "now": e.verdict if e else None, "triage": ev.overlay(e, t) if e and t else None})
    kind, value = entities.parse(o["subject"])
    snap = o["snapshot"]
    if isinstance(snap, dict):   # the confidence of members and child incidents as words, like the queue
        for k in ("members", "children"):
            for m in snap.get(k) or ():
                if isinstance(m, dict) and m.get("conf") is not None:
                    m["conf_word"] = ev.conf_word(m["conf"], p)
        if snap.get("conf") is not None:
            snap["conf_word"] = ev.conf_word(snap["conf"], p)
    return {**_row(o, p), "triage": tri.get(value) if kind == "ip" else None, "reason": o["reason"], "chains": o["chains"],
            "identifiers": o["identifiers"],
            "resolution": o["resolution"], "snapshot": o["snapshot"], "snapshot_at": o["snapshot_at"],
            "events": o["events"], "outcome_note": o["outcome_note"], "members": members,
            "members_total": len(o["members"]), "live": _live(b, o)}


def record_steps(store, d: dict, catalog=None, overlay: list[dict] | tuple = ()) -> dict:
    """The next steps of a record for its page, with what the team checked; `rec` says whether they can be checked.
    The steps stored with the snapshot are the effective ones of its peak; a record from before they were stored is
    rebuilt with `overlay`."""
    snap = d.get("snapshot") or {}
    steps = []
    if snap.get("what") in ("host", "target", "group", "campaign"):
        steps = playbook.for_snapshot(snap, catalog, overlay)
    return {"list": steps, "rec": d["id"] if (d["status"] == "open" or d.get("end_reason") == "quiet") else None,
            "done": store.steps(d["id"])}


def earlier(store, ip: str, limit: int = 20, current: tuple | list = ()) -> list[dict]:
    """The incidents a host was the subject of or a member of, newest first, without the ones it is in now (the
    page's own incident and its group and campaign, `current` ui keys): those are the breadcrumb, not the past."""
    rows = store.incidents_of(entities.key("ip", ip), limit + len(current))
    return [_row(o) for o in rows if not (o["status"] == "open" and o["ui_key"] in current)][:limit]
