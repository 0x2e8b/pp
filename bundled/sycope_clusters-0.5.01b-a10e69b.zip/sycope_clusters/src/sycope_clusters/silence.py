"""Silence rules (1.4): the analyst's exceptions with more precise fields, a time window and a counter.

ONE mechanism: a silence rule is a row of the `exceptions` table (store.py) of kind "silence". The 1.0-1.3 kinds
(`service`: rule + server + port, `host-rule`: host + rule, `host`: a whole host) are the same table; their rows keep
their id, author, reason, expiry and approval, and are matched as before (finding level, the subject's side counts).
What a silence rule adds (all fields AND, empty = any):

    rule      one alert name, exact (no regex)
    src, dst  an IP or a CIDR (v4 or v6) of the alert's client and server
    port      the server port: one or a range a-b
    proto     TCP, UDP or ICMP (Sycope's protocolName)
    window    weekdays and HH:MM-HH:MM (may cross midnight) in the configured calendar time zone

A rule is matched against the hourly buckets of the window (ingest.py), before scoring, exactly where exceptions
act today: the findings of a matched bucket are marked excepted, weight 0. Nothing leaves Sycope or the counts.
The bucket's own alerts decide the time: a bucket matches a time window when its first and its last alert are in it
(under-silencing, never over-silencing, at the edge of a window).

Speed: the rules are indexed (by alert name, by exact destination, by exact source); a bucket costs a few dict
lookups when no rule names its alert, and rules without a name or an exact address are a short list. The result is
cached per address for the CIDR tests.
"""

from __future__ import annotations

import ipaddress
import re
from collections.abc import Callable, Iterable

MAX_DAYS = 90
DEFAULT_DAYS = 30
PROTOS = ("TCP", "UDP", "ICMP")
DAY_NAMES = ("mon", "tue", "wed", "thu", "fri", "sat", "sun")
SAMPLES = 20                 # alert ids kept per rule and hour in the hit log
HOSTS_KEPT = 200             # distinct hosts kept per rule and hour (the count goes on past it)
WIDE_V4, WIDE_V6 = 24, 64    # a source or destination wider than this needs a second person
MIN_ENDED_HOURS = 6          # a rule younger than this is not judged by the spike guard

TUNE_HINT = ("tune the rule in Sycope instead (its threshold or its exclusions): Noise & tuning lists the rules "
             "to tune, the busiest first")

_HHMM = re.compile(r"^(\d{1,2}):(\d{2})$")


class RuleError(ValueError):
    """A silence rule the guard rails (or its own fields) refuse; the message is shown to the analyst."""


# ---- the fields ------------------------------------------------------------------------------------------------------

def norm_net(text, what: str = "address") -> str:
    """An IP or a CIDR as text, canonical (a host bits-set network is rounded down: 10.0.0.7/24 is 10.0.0.0/24)."""
    t = str(text or "").strip()
    try:
        if "/" in t:
            n = ipaddress.ip_network(t, strict=False)
            return str(n)
        return str(ipaddress.ip_address(t))
    except ValueError:
        raise RuleError(f"the {what} must be an IP address or a network such as 10.1.2.0/24") from None


def net_prefix(text: str) -> tuple[int, int]:
    """(prefix length, maximum) of a canonical address or network text."""
    n = ipaddress.ip_network(text, strict=False)
    return n.prefixlen, n.max_prefixlen


def is_wide(text: str | None) -> bool:
    """Wider than /24 (v4) or /64 (v6): such a rule needs a second person."""
    if not text:
        return False
    plen, mx = net_prefix(text)
    return plen < (WIDE_V4 if mx == 32 else WIDE_V6)


def norm_port(text) -> str | None:
    t = str(text if text is not None else "").strip().replace(" ", "")
    if not t:
        return None
    m = re.fullmatch(r"(\d{1,5})(?:-(\d{1,5}))?", t)
    if not m:
        raise RuleError("the port must be one number or a range such as 8000-8100")
    lo = int(m.group(1))
    hi = int(m.group(2)) if m.group(2) else lo
    if not (0 < lo <= 65535 and 0 < hi <= 65535) or hi < lo:
        raise RuleError("the port must be 1-65535 (a range runs from the lower to the higher number)")
    return str(lo) if lo == hi else f"{lo}-{hi}"


def port_range(text: str | None) -> tuple[int, int] | None:
    if not text:
        return None
    lo, _, hi = text.partition("-")
    return int(lo), int(hi or lo)


def norm_proto(text) -> str | None:
    t = str(text or "").strip().upper()
    if not t:
        return None
    if t not in PROTOS:
        raise RuleError("the protocol must be TCP, UDP or ICMP")
    return t


_NUM_PROTO = {"6": "TCP", "17": "UDP", "1": "ICMP", "58": "ICMP"}


_PROTO_MEMO: dict = {}


def proto_of(v) -> str:
    """The protocol of an alert as the matcher reads it: TCP, UDP, ICMP, another name in upper case, or "" (none).
    Memoised: a window repeats a handful of values two million times."""
    got = _PROTO_MEMO.get(v)
    if got is not None:
        return got
    if v is None:
        out = ""
    else:
        t = str(v).strip().upper()
        out = "ICMP" if t.startswith("ICMP") else _NUM_PROTO.get(t, t)
    if len(_PROTO_MEMO) < 1000:
        _PROTO_MEMO[v] = out
    return out


def _minutes(text, what: str) -> int:
    t = str(text or "").strip()
    if t == "24:00":
        return 1440
    m = _HHMM.match(t)
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
        raise RuleError(f"the {what} of the time window must be HH:MM")
    return int(m.group(1)) * 60 + int(m.group(2))


def norm_window(days, frm, to) -> tuple[str | None, int | None, int | None]:
    """(weekdays as "0,1,2" with Monday = 0, from minute, to minute); all None for no window. A window needs a time
    range; no weekday means every day. The end is exclusive; the range may cross midnight (22:00-06:00)."""
    have_days = bool(days)
    if not frm and not to and not have_days:
        return None, None, None
    if not frm or not to:
        raise RuleError("a time window needs both its start and its end (HH:MM-HH:MM)")
    a, b = _minutes(frm, "start"), _minutes(to, "end")
    if a == b:
        raise RuleError("the time window is empty: its start and its end are the same")
    if isinstance(days, str):
        days = [d for d in re.split(r"[,\s]+", days) if d]
    out = set()
    for d in days or ():
        s = str(d).strip().lower()
        if s.isdigit() and 0 <= int(s) <= 6:
            out.add(int(s))
        elif s[:3] in DAY_NAMES:
            out.add(DAY_NAMES.index(s[:3]))
        else:
            raise RuleError("weekdays are mon, tue, wed, thu, fri, sat, sun")
    return ",".join(str(d) for d in sorted(out)) if out else None, a, b


def hhmm(minutes: int | None) -> str:
    return "" if minutes is None else f"{minutes // 60:02d}:{minutes % 60:02d}"


def clean(body: dict) -> dict:
    """The silence fields of a request, normalised: rule, src, dst, port, proto, win_days, win_from, win_to (None for
    any). Raises RuleError on a malformed field."""
    name = str(body.get("rule") or "").strip()
    days, a, b = norm_window(body.get("win_days"), body.get("win_from"), body.get("win_to"))
    return {"rule": None if name in ("", "*") else name,
            "src": norm_net(body["src"], "source") if str(body.get("src") or "").strip() else None,
            "dst": norm_net(body["dst"], "destination") if str(body.get("dst") or "").strip() else None,
            "port": norm_port(body.get("port")), "proto": norm_proto(body.get("proto")),
            "win_days": days, "win_from": a, "win_to": b}


def check_shape(f: dict) -> None:
    """The guard rails that concern the shape of the rule (the expiry and the second person are the caller's)."""
    name, has_ep = f["rule"], bool(f["src"] or f["dst"])
    if name:
        if not (has_ep or f["port"]):
            raise RuleError("a rule on the alert name alone (even with a protocol or a time) would hide that alert "
                            "for every host: " + TUNE_HINT + ". Add a source, a destination or a port to make it "
                            "specific")
    elif not (has_ep and f["port"]):
        raise RuleError("without an alert name a rule needs a source or a destination, and a port (a known "
                        "service); a protocol or a time alone is not enough")
    if f["win_from"] is not None and not has_ep:
        raise RuleError("a time window works only together with a source or a destination")


def wide_reasons(f: dict) -> list[str]:
    out = []
    for key, label in (("src", "source"), ("dst", "destination")):
        if is_wide(f.get(key)):
            out.append(f"the {label} {f[key]} is wider than /{WIDE_V4} (IPv6 /{WIDE_V6})")
    return out


def describe(x: dict) -> str:
    """One line for the audit and the dialogs: 'Horizontal Scan, src 10.1.2.3, dst 10.0.0.0/24, port 445, TCP, ...'"""
    parts = [x.get("rule") or "any alert"]
    kind = x.get("kind")
    src = x.get("src") or (x.get("actor") if kind in ("host-rule", "host") else None)
    dst = x.get("dst") or (x.get("server") if kind == "service" else None)
    for label, v in (("src", src), ("dst", dst), ("port", x.get("port")), ("", x.get("proto"))):
        if v:
            parts.append(f"{label} {v}".strip())
    if x.get("win_from") is not None:
        days = x.get("win_days")
        names = ",".join(DAY_NAMES[int(d)].capitalize() for d in days.split(",")) if days else "every day"
        parts.append(f"{names} {hhmm(x['win_from'])}-{hhmm(x['win_to'])}")
    return ", ".join(parts)


# ---- matching --------------------------------------------------------------------------------------------------------

_CANON: dict[str, str] = {}


def _canon(ip: str) -> str:
    """The canonical text of an address as a rule keeps it (only IPv6 has more than one spelling)."""
    if ":" not in ip:
        return ip
    v = _CANON.get(ip)
    if v is None:
        try:
            v = str(ipaddress.ip_address(ip))
        except ValueError:
            v = ip
        if len(_CANON) < 200_000:
            _CANON[ip] = v
    return v


class _Addr:
    """An IP or CIDR of a rule: an exact text compare for a host address, a memoised containment test for a network."""
    __slots__ = ("exact", "memo", "net")

    def __init__(self, text: str) -> None:
        if "/" in text:
            n = ipaddress.ip_network(text, strict=False)
            if n.prefixlen == n.max_prefixlen:
                self.exact, self.net = str(n.network_address), None
            else:
                self.exact, self.net = None, n
        else:
            self.exact, self.net = str(ipaddress.ip_address(text)), None
        self.memo: dict[str, bool] = {}

    def has(self, ip: str | None) -> bool:
        if not ip:
            return False
        if self.exact is not None:
            return (ip if ":" not in ip else _canon(ip)) == self.exact
        v = self.memo.get(ip)
        if v is None:
            try:
                a = ipaddress.ip_address(ip)
                v = a.version == self.net.version and a in self.net
            except ValueError:
                v = False
            if len(self.memo) < 200_000:
                self.memo[ip] = v
        return v


class _R:
    """One rule, compiled."""
    __slots__ = ("days", "dst", "exact_server", "frm", "host", "id", "name", "port", "proto", "silence", "src", "to")

    def __init__(self, x: dict, silence: bool) -> None:
        self.id = x["id"]
        self.silence = silence
        kind = x["kind"]
        name = x.get("rule")
        self.name = None if name in (None, "", "*") else name
        self.src = self.dst = self.host = self.exact_server = None
        self.proto = x.get("proto") or None
        self.port = port_range(x.get("port"))
        self.days, self.frm, self.to = None, x.get("win_from"), x.get("win_to")
        if kind == "silence":
            self.src = _Addr(x["src"]) if x.get("src") else None
            self.dst = _Addr(x["dst"]) if x.get("dst") else None
        elif kind == "service":      # the 1.0 shape: one server (string compare, as the finding matcher does)
            self.exact_server = x.get("server")
        else:                       # host-rule, host: the host on either side (a count only; scoring uses the subject)
            self.host = _Addr(x["actor"]) if x.get("actor") else None
        if self.frm is not None:
            ds = x.get("win_days")
            self.days = sum(1 << int(d) for d in ds.split(",")) if ds else 127

    def ok(self, client, server, port, proto, first, last, offset) -> bool:
        if self.src is not None and not self.src.has(client):
            return False
        if self.dst is not None and not self.dst.has(server):
            return False
        if self.exact_server is not None and server != self.exact_server:
            return False
        if self.host is not None and not (self.host.has(client) or self.host.has(server)):
            return False
        if self.port is not None:
            try:
                p = int(port)
            except (TypeError, ValueError):
                return False
            if not self.port[0] <= p <= self.port[1]:
                return False
        if self.proto is not None and self.proto != proto:
            return False
        if self.frm is not None:
            return _in_window(first, self.days, self.frm, self.to, offset) and \
                _in_window(last, self.days, self.frm, self.to, offset)
        return True


def _in_window(ts_ms, mask: int, frm: int, to: int, offset: int) -> bool:
    if ts_ms is None:
        return False
    m = int(ts_ms // 60000) + offset
    mod, day = m % 1440, (m // 1440 + 3) % 7        # 1970-01-01 was a Thursday
    if frm < to:
        return frm <= mod < to and bool(mask >> day & 1)
    if mod >= frm:
        return bool(mask >> day & 1)
    return mod < to and bool(mask >> ((day - 1) % 7) & 1)


class _Index:
    """Rules by alert name, by exact destination and exact source (nameless ones), and the rest."""

    def __init__(self) -> None:
        self.by_name: dict[str, list[_R]] = {}
        self.by_dst: dict[str, list[_R]] = {}
        self.by_src: dict[str, list[_R]] = {}
        self.rest: list[_R] = []
        self.n = 0

    def add(self, r: _R) -> None:
        self.n += 1
        if r.name is not None:
            self.by_name.setdefault(r.name, []).append(r)
        elif r.dst is not None and r.dst.exact is not None:
            self.by_dst.setdefault(r.dst.exact, []).append(r)
        elif r.exact_server is not None:
            self.by_dst.setdefault(r.exact_server, []).append(r)
        elif r.src is not None and r.src.exact is not None:
            self.by_src.setdefault(r.src.exact, []).append(r)
        else:
            self.rest.append(r)

    def find(self, name, client, server, port, proto, first, last, offset) -> tuple:
        out = None
        cands = self.by_name.get(name, ())
        if self.by_dst and server:
            cands = (*cands, *self.by_dst.get(_canon(server), ()))
        if self.by_src and client:
            cands = (*cands, *self.by_src.get(_canon(client), ()))
        if self.rest:
            cands = (*cands, *self.rest)
        for r in cands:
            if r.ok(client, server, port, proto, first, last, offset):
                (out := out or []).append(r.id)
        return tuple(out) if out else ()


class Silencer:
    """The active rules, ready to match buckets and alerts, and the hit counters of one pass over the window.

    `rules`: rows of store.exceptions() (stored ones only: an id that is an int; the read-only host rows of the
    silenced lookup are matched by the finding matcher alone). `silence_ids(...)` is what splits findings (kind
    "silence"); `all_ids(...)` adds the older kinds for the counters of the hit log."""

    def __init__(self, rules: Iterable[dict], offset_min: int = 0,
                 internal: Callable[[str], bool] | None = None) -> None:
        self.offset = int(offset_min)
        self.internal = internal
        self._s, self._l = _Index(), _Index()
        self.kinds: dict[int, str] = {}
        sig = [self.offset]
        for x in rules:
            rid = x.get("id")
            if not isinstance(rid, int):
                continue
            try:
                r = _R(x, x["kind"] == "silence")
            except (ValueError, KeyError):
                continue
            (self._s if r.silence else self._l).add(r)
            self.kinds[rid] = x["kind"]
            sig.append((rid, x["kind"], x.get("rule"), x.get("src"), x.get("dst"), x.get("server"), x.get("port"),
                        x.get("actor"), x.get("proto"), x.get("win_days"), x.get("win_from"), x.get("win_to")))
        self.signature = hash(tuple(sig))       # the same rules, the same answers: the window caches by it
        self.hits: dict[tuple, list] = {}
        self.silenced = 0            # alerts of the window that some rule (any kind) matched, once each (Window.rows)

    @property
    def active(self) -> bool:
        return bool(self._s.n or self._l.n)

    @property
    def has_silence(self) -> bool:
        return bool(self._s.n)

    def silence_ids(self, name, client, server, port, proto, first, last) -> tuple:
        if not self._s.n:
            return ()
        return self._s.find(name, client, server, port, proto, first, last, self.offset)

    def legacy_ids(self, name, client, server, port, proto, first, last) -> tuple:
        if not self._l.n:
            return ()
        return self._l.find(name, client, server, port, proto, first, last, self.offset)

    # a bucket or an alert, as the row tuples of ingest.py / sycope.py (positions are given by the caller)

    def count(self, ids: tuple, hour: int, n: int, first, last, client, server, sample, into: dict | None = None) -> None:
        """Add a matched bucket to the hit counters of this pass (the pass starts from nothing: counting the same
        window twice gives the same numbers, which is what makes the hit log idempotent)."""
        hits = self.hits if into is None else into
        for rid in ids:
            h = hits.get((rid, hour))
            if h is None:
                h = hits[(rid, hour)] = [0, set(), first, last, [], 0]
            h[0] += n
            h[2], h[3] = min(h[2], first), max(h[3], last)
            if len(h[4]) < SAMPLES and sample:
                h[4].append(sample)
            # the host a bucket is about: the client when it is ours (it acts), else the server
            ip = client if client and (self.internal is None or self.internal(client)) else \
                server if server and self.internal is not None and self.internal(server) else None
            if ip:
                if len(h[1]) < HOSTS_KEPT:
                    h[1].add(ip)
                else:
                    h[5] += ip not in h[1]


# ---- the finding-level matcher (the exceptions as they always were, plus the silence rules by id) -------------------

def _inside(ip: str, net: str) -> bool:
    try:
        n = ipaddress.ip_network(net, strict=False)
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.version == n.version and a in n


def _legacy(f, x: dict) -> bool:
    k = x["kind"]
    if k == "service":
        return x["rule"] in (f.rule.name, "*") and x["server"] == (f.cp or "") and (x["port"] or "") in ("", f.port)
    if k == "host-rule":
        return x["actor"] == f.subject and x["rule"] in (f.rule.name, "*")
    if k == "host":
        return x["actor"] == f.subject or "/" in (x["actor"] or "") and _inside(f.subject, x["actor"])
    return False


def find_linear(f, exceptions: list[dict]) -> dict | None:
    """The first exception that covers the finding, in list order (a plain list: the preview's one candidate, tests)."""
    sil = getattr(f, "sil", ())
    for x in exceptions:
        if x["kind"] == "silence":
            if sil and x.get("id") in sil:
                return x
        elif _legacy(f, x):
            return x
    return None


class ExceptionSet(list):
    """The exceptions of one build as a list that is also an index: `find(f)` is a few dict lookups per finding
    instead of a pass over every exception (300,000 findings x 100 rules is 30 million comparisons)."""

    def __init__(self, items: Iterable[dict] = ()) -> None:
        super().__init__(items)
        self._pos: dict[int, int] = {}
        self._by_server: dict[str, list[dict]] = {}
        self._by_actor: dict[str, list[dict]] = {}
        self._nets: list[dict] = []
        self._silence: dict = {}
        for i, x in enumerate(self):
            self._pos[id(x)] = i
            k = x["kind"]
            if k == "service":
                self._by_server.setdefault(x["server"], []).append(x)
            elif k == "host-rule":
                self._by_actor.setdefault(x["actor"], []).append(x)
            elif k == "host":
                if "/" in (x["actor"] or ""):
                    self._nets.append(x)
                else:
                    self._by_actor.setdefault(x["actor"], []).append(x)
            elif k == "silence" and x.get("id") is not None:
                self._silence[x["id"]] = x
        self._silencer: Silencer | None = None
        self.offset = 0

    @classmethod
    def of(cls, items: Iterable[dict] | None, offset_min: int = 0) -> ExceptionSet:
        if isinstance(items, cls):
            return items
        out = cls(items or ())
        out.offset = int(offset_min)
        return out

    @property
    def silencer(self) -> Silencer:
        if self._silencer is None:
            self._silencer = Silencer([x for x in self if x["kind"] == "silence"], self.offset)
        return self._silencer

    def find(self, f) -> dict | None:
        if not self:
            return None
        best = None
        cands: list[dict] = []
        sil = getattr(f, "sil", ())
        for rid in sil:
            x = self._silence.get(rid)
            if x is not None:
                cands.append(x)
        if f.cp and self._by_server:
            cands += [x for x in self._by_server.get(f.cp, ()) if _legacy(f, x)]
        if f.subject:
            for x in self._by_actor.get(f.subject, ()):
                if _legacy(f, x):
                    cands.append(x)
        for x in self._nets:
            if _legacy(f, x):
                cands.append(x)
        for x in cands:
            if best is None or self._pos[id(x)] < self._pos[id(best)]:
                best = x
        return best


# ---- the candidate's preview, the rules' listing, the spike guard ---------------------------------------------------

def scan_rows(rows: Iterable[tuple], fields: dict, fields_of: dict[str, int], offset: int = 0) -> list[tuple]:
    """The alerts or buckets among `rows` (the FIELDS order, plus _n, _first, _last for a bucket) that a candidate rule
    would take, as Window.scan reports them: (alert name, client, server, port, alerts, first alert id, hour). For a test
    or a caller that has rows and no Window; `fields_of` is the position of each field (evidence.IX)."""
    s = Silencer([{**fields, "id": -1, "kind": "silence"}], offset)
    i = fields_of
    out = []
    for r in rows:
        bucket = len(r) >= len(i) + 3
        cnt, first, last = (r[len(i)], r[len(i) + 1], r[len(i) + 2]) if bucket else (1, r[i["timestamp"]] or 0, None)
        last = first if last is None else last
        port = r[i["serverPort"]]
        if port in (None, "") and r[i["serverPorts"]]:
            p0 = str(r[i["serverPorts"]]).split(",")[0].strip()
            port = p0 if p0.isdigit() else ""
        if s.silence_ids(r[i["alertName"]], r[i["clientIp"]] or None, r[i["serverIp"]] or None,
                         str(port) if port not in (None, "") else None, proto_of(r[i["protocolName"]]), first, last):
            out.append((r[i["alertName"]], r[i["clientIp"]], r[i["serverIp"]], port, cnt, r[i["id"]],
                        int(first) // 3_600_000))
    return out


def state_of(x: dict, now: float) -> str:
    """pending, rejected, removed, expired, lookup or active, for the listing."""
    if x.get("source"):
        return "lookup"
    if x.get("pending"):
        return "pending"
    if not x.get("active"):
        return "removed" if x.get("removed_at") else "rejected"
    return "expired" if x.get("expires") and x["expires"] < now else "active"


def rules_view(store, now: float, offset_min: int = 0, remove_after_days: int = 30) -> list[dict]:
    """Every stored rule of every kind, newest first, with its state and its counters (store.silence_stats) for the
    Noise & tuning table. `suggest_remove`: in force, older than the quiet period, and no hit in it."""
    stats = store.silence_stats(now, offset_min)
    out = []
    for x in store.exceptions(active_only=False):
        st = stats.get(x["id"]) or {"today": 0, "week": 0, "total": 0, "last": None, "hosts": 0, "first_hour": None,
                                    "days": [0] * 14}
        state = state_of(x, now)
        quiet = remove_after_days * 86400
        last = (st["last"] or 0) / 1000
        old = (x.get("created") or now) < now - quiet
        out.append({**x, "state": state, "label": describe(x), "stats": st,
                    "suggest_remove": state == "active" and old and (not last or last < now - quiet)})
    return out


def spike(hourly: list[tuple[int, int]], now_hour: int, x: float, minimum: int) -> tuple[int, float] | None:
    """(alerts in the last hour, the usual hourly count) when the last hour is a spike, else None. The last hour is the
    larger of the hour in progress and the one before it; usual is the mean per hour over the 7 days before them (the
    hours the rule has existed: a hit log under MIN_ENDED_HOURS hours old is not judged); a spike is at least `minimum`
    alerts and more than `x` times the usual."""
    by_hour = dict(hourly)
    last = max(by_hour.get(now_hour, 0), by_hour.get(now_hour - 1, 0))
    if last < minimum or not by_hour:
        return None
    lo, hi = now_hour - 1 - 168, now_hour - 2
    first = min(by_hour)
    span = hi - max(lo, first) + 1
    if span < MIN_ENDED_HOURS:
        return None
    usual = sum(n for h, n in by_hour.items() if lo <= h <= hi) / span
    return (last, usual) if last > x * usual else None
