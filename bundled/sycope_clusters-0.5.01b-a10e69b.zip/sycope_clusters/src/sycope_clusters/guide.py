"""The whole help on one page (/help): every part of helpdoc in order, with its screenshots, for reading end to end
or printing. The side panel the ? opens shows one part at a time."""

from __future__ import annotations

from sycope_clusters import helpdoc
from sycope_clusters.config import Settings
from sycope_clusters.pages import VERSION, _e, _page, _pname
from sycope_clusters.params import Params

STAGE_WORDS = helpdoc.STAGE_WORDS


def help_page(settings: Settings, p: Params | None = None, product: str = "triage", offset_min: int = 0) -> str:
    """Every part on one page, stating the numbers of `p` (the board's parameters; the shipped ones when none)."""
    img = f"helpimg?v={VERSION}&n="
    secs = helpdoc.SECTIONS if p is None else helpdoc.sections(p)
    by = {s["id"]: s for s in secs}
    toc = "".join(f'<a href="#{_e(s["id"])}">{_e(s["title"])}</a>' for s in secs)
    parts = "".join(f'<section id="{_e(s["id"])}"><h2>{_e(s["title"])}</h2>{helpdoc.render(s["id"], img, p, by)}</section>'
                    for s in secs)
    body = f"""<style>.guide{{max-width:1080px}}.guide h2{{margin:34px 0 8px;font-size:24px;font-weight:400;color:#fff;text-transform:none;letter-spacing:0}}
.guide h3{{margin:16px 0 6px;font-size:14px;font-weight:600;color:#fff}}.guide p,.guide li,.guide dd{{color:#cfd4e6;line-height:1.55}}
.guide .toc a{{display:inline-block;margin:0 14px 8px 0}}.guide .hin{{font-size:15px}}
.guide .hf img{{max-width:100%;border:1px solid var(--panel2);border-radius:4px}}
.guide .hf figcaption{{color:var(--mut);font-size:12px;margin-top:4px}}.guide .hlg{{list-style:none;padding:0}}
.guide .hlg li{{display:flex;gap:9px;margin:0 0 8px}}.guide .hlg b{{color:#fff;margin-right:4px}}
.guide .hn{{display:inline-flex;flex:none;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;
background:#ffc83d;color:#0c0e2e;font-size:12px;font-weight:700}}.guide .hdl dt{{margin-top:9px;color:#fff;font-weight:600}}
.guide .hdl dd{{margin:2px 0 0}}.guide .htb{{width:100%;border-collapse:collapse;font-size:13px}}
.guide .htb th,.guide .htb td{{padding:6px;border-bottom:1px solid var(--panel2);text-align:left;vertical-align:top;color:#cfd4e6}}
.guide .htb th{{color:var(--mut)}}.guide .vdot{{display:inline-block;width:10px;height:10px;margin-right:8px;border-radius:50%}}
.guide .vdot[data-v=act]{{background:#e0122d}}.guide .vdot[data-v=investigate]{{background:#ff7a00}}
.guide .vdot[data-v=review]{{background:#e5c100}}.guide .vdot[data-v=watch]{{background:#4aa3ff}}
.guide section{{border-top:1px solid var(--panel2);margin-top:20px}}</style>
<div class="guide"><p class="hin">How to read and work the triage. The ? in the top bar opens the part for the view you are
on; this page has them all.</p><p class="toc">{toc}</p>{parts}</div>"""
    return _page(f"Help · Sycope Security {_pname(product, settings.clusters_compare)}", body, "help", settings,
                 sub="Help", product=product, offset_min=offset_min)
