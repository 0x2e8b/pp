"""The alerts of the window as hourly finding buckets, plus a small ring of raw alerts per host.

At 2 million alerts a day the raw alerts cannot stay in memory, and the triage does not need them: it scores
findings. An alert goes into the bucket (hour, rule, client, server, port) of the hour of its timestamp, which keeps
what the scoring reads: how many alerts, the first and last time (exact, in ms, so chain order never depends on the
hour), the strongest severity and threshold level, the bytes each way (None until an alert carries them), the largest session and unique-server counts,
the targets (union, 64 at most), the counterpart's ASN and country, locations, functions and MITRE fields (the first
that is not empty). `evidence.collect` reads a bucket row like an alert that happened `_n` times.

What stays raw: the newest `raw_per_host` alerts of every host (client or server side), for the host page and PCAP
links, and - only while the window holds at most `classic_max` alerts - every alert, for the classic board.

Window edge: a bucket is dropped once its hour ENDED before `now - retention_s`, so the scored window can hold up to
one hour more than the retention. The raw rings and the classic list are cut exactly at `now - retention_s`.

Dedup: an alert id already counted is not counted again when the overlap of the next poll reads it. The ids are kept
per hour as 64-bit hashes (about half the memory of the strings; a collision is one in 10^7 for a whole window) and go
with their hour; the poll forgets them for the hours behind its overlap (`forget_ids`), which no poll reads again.
Alert ids are never interned: Python 3.12 interned strings are immortal.

Memory: `mem_bytes()` is an estimate from counts and the per-item sizes below (measured on CPython 3.12, rounded
up); it only has to grow with the buckets, the ids and the rings. Under pressure `degrade(level)` thins, never
touching class A and B: 1 = rings of 20 alerts per host at most, 2 = class D buckets are merged to counts per
(rule, client), 3 = class C buckets lose their target lists. A level also applies to alerts that arrive later.
"""

from __future__ import annotations

import json
import logging
import threading
from collections.abc import Callable

from sycope_clusters import evidence as ev
from sycope_clusters import silence
from sycope_clusters.sycope import FIELDS, RESULT_CAP

log = logging.getLogger("sycope_clusters.ingest")

BUCKET_FIELDS = FIELDS + ("_n", "_first", "_last")
BI = {f: i for i, f in enumerate(BUCKET_FIELDS)}

HOUR_MS = 3_600_000
MAX_TARGETS = 64
DEGRADED_RING = 20
CHUNK = 4096               # alerts added under one hold of the lock: pages and the poll never wait for a whole day

# estimated bytes (CPython 3.12): a bucket list of 31 slots with its ints, the strings it owns and its two entries in
# the host index; a target string in a tuple; an id hash in a set; a raw alert tuple with its unique strings (id,
# target list); a slot of a ring (a tuple is in two rings: half of it); a ring's own list and dict entry; a
# reference in the classic list
BUCKET_B, TARGET_B, ID_B, RAW_B, RING_SLOT_B, LIST_REF_B, RING_B = 790, 72, 72, 480, 248, 8, 120

_I = {f: BI[f] for f in BUCKET_FIELDS}
_ID, _TS, _NAME, _RID, _C, _S, _PORT = (_I[k] for k in ("id", "timestamp", "alertName", "alertRuleId", "clientIp",
                                                         "serverIp", "serverPort"))
_PROTO = _I["protocolName"]
_SEV, _THR, _UP, _DOWN, _SESS, _UNIQ, _SIPS = (_I[k] for k in ("alertSeverity", "alertFlagThresholdLevel",
                                                               "sumClientBytes", "sumServerBytes", "_countSessions",
                                                               "_uniqueServerIps", "serverIps"))
_SASN, _SCC, _CASN, _CCC = (_I[k] for k in ("serverAsName", "serverCountry", "clientAsName", "clientCountry"))
_N, _FIRST, _LAST = _I["_n"], _I["_first"], _I["_last"]
_TAC = _I["alertMitreTactic"]
# first non-empty wins; the key fields, the severities, the sums and the paired ASN/country are handled apart
_FILL = tuple(_I[k] for k in ("alertRuleType", "alertDefId", "alertMitreTactic", "alertMitreTechnique", "alertMitreId",
                              "clientLocation", "serverLocation", "clientFunction", "serverFunction", "serverPorts"))
_EMPTY = (None, "")
_EMPTY_SET = frozenset(_EMPTY)
_NB = len(BUCKET_FIELDS)
_SEV_W, _THR_W = ev.SEV_W, ev.THR_LEVEL


def targets_of(v) -> list[str]:
    """The addresses of a target list: a comma separated string from Sycope, or a tuple of a bucket."""
    if not v:
        return []
    if isinstance(v, (tuple, list)):
        return list(v)
    return [t for t in (x.strip() for x in str(v).split(",")) if t]


class _Hour:
    """The buckets, alert ids and raw alerts of one hour."""
    __slots__ = ("b", "by_ip", "ids", "n", "raw", "sil", "tgt")

    def __init__(self) -> None:
        self.b: dict[tuple, list] = {}
        self.by_ip: dict[str, list[tuple]] = {}   # ip -> keys of the buckets that name it (client or server)
        self.ids: set[int] = set()
        self.raw: list[tuple] = []
        self.n = 0                 # alerts counted in the hour
        self.tgt = 0               # target strings held in its buckets (memory estimate)
        self.sil: tuple | None = None   # (rule signature, alerts, {bucket key: rule ids}, hit counters): rows() reuses it


class Window:
    def __init__(self, retention_s: int, raw_per_host: int, classic_max: int, *, dedup: bool = True,
                 classify: Callable[[str | None, str | None, str | None], str] | None = None) -> None:
        self.retention_s, self.raw_per_host, self.classic_max = retention_s, raw_per_host, classic_max
        self.dedup = dedup
        self.classify = classify          # (alertName, tactic, ruleId) -> rule class; None: the degrading is off
        self.alerts = 0
        self.level = 0
        self._hours: dict[int, _Hour] = {}
        self._rings: dict[str, list] = {}
        self._missing: set[int] = set()   # hours that lack some raw alert for the classic board
        self._raw_held = False
        self._cut_ms = 0.0
        self._lock = threading.RLock()

    # ---- adding ---------------------------------------------------------------------------------------------

    def add(self, rows: list[tuple]) -> int:
        """Take alerts (FIELDS order); returns how many were new to the window."""
        new = 0
        for i in range(0, len(rows), CHUNK):
            with self._lock:
                new += self._add(rows[i:i + CHUNK])
        return new

    def _add(self, rows: list[tuple]) -> int:
        new = 0
        cap = self._ring_cap()
        for r in rows:
            ts = r[_TS] or 0
            hour = int(ts) // HOUR_MS
            h = self._hours.get(hour)
            if h is None:
                h = self._hours[hour] = _Hour()
            if self.dedup:
                key = hash(r[_ID]) if r[_ID] else hash(r)
                if key in h.ids:
                    continue
                h.ids.add(key)
            new += 1
            h.n += 1
            self.alerts += 1
            self._fold(h, r, ts)
            self._keep_raw(hour, h, r, cap)
        return new

    def _fold(self, h: _Hour, r: tuple, ts: float) -> None:
        name, rid = r[_NAME] or "", r[_RID] or None
        client, server, port = r[_C] or "", r[_S] or "", ev._port(r)
        proto = silence.proto_of(r[_PROTO])
        keep_targets = True
        if self.level >= 2 and self.classify is not None:
            cls = self.classify(r[_NAME], r[_TAC], rid)
            if cls == "D":
                server, port, proto, keep_targets = "", "", "", False
            elif cls == "C" and self.level >= 3:
                keep_targets = False
        h.tgt += self._absorb(h, (rid or name, name, client, server, port, proto), r, 1, ts, ts, keep_targets)

    def _absorb(self, h: _Hour, key: tuple, r, n: int, first: float, last: float, keep_targets: bool) -> int:
        """Fold alert `r` (n alerts, first..last) into its bucket; returns the targets added."""
        b = h.b.get(key)
        if b is None:
            b = [None] * _NB
            b[_ID], b[_NAME], b[_RID] = r[_ID], key[1], r[_RID] or None
            b[_C], b[_S], b[_PORT], b[_PROTO] = key[2] or None, key[3] or None, key[4] or None, key[5] or None
            b[_SESS] = b[_UNIQ] = 0         # the byte sums stay None until an alert carries them (Health: fill rate)
            b[_SIPS] = ()
            b[_N], b[_FIRST], b[_LAST] = 0, first, last
            h.b[key] = b
            for ip in {b[_C], b[_S]} - _EMPTY_SET:
                h.by_ip.setdefault(ip, []).append(key)
        b[_N] += n
        b[_FIRST] = min(b[_FIRST], first)
        b[_LAST] = max(b[_LAST], last)
        b[_TS] = b[_LAST]
        sev = r[_SEV]
        if b[_SEV] is None or _SEV_W.get(sev, 0) > _SEV_W.get(b[_SEV], 0):
            b[_SEV] = sev
        thr = r[_THR]
        if b[_THR] is None or _THR_W.get(thr, 0) > _THR_W.get(b[_THR], 0):
            b[_THR] = thr
        if r[_UP] not in _EMPTY:
            b[_UP] = (b[_UP] or 0) + ev._int(r[_UP])
        if r[_DOWN] not in _EMPTY:
            b[_DOWN] = (b[_DOWN] or 0) + ev._int(r[_DOWN])
        v = ev._int(r[_SESS])
        b[_SESS] = max(b[_SESS], v)
        v = ev._int(r[_UNIQ])
        b[_UNIQ] = max(b[_UNIQ], v)
        if b[_SASN] in _EMPTY and r[_SASN] not in _EMPTY:
            b[_SASN], b[_SCC] = r[_SASN], r[_SCC]
        if b[_CASN] in _EMPTY and r[_CASN] not in _EMPTY:
            b[_CASN], b[_CCC] = r[_CASN], r[_CCC]
        for i in _FILL:
            if b[i] in _EMPTY and r[i] not in _EMPTY:
                b[i] = r[i]
        added = 0
        sips = r[_SIPS]
        if keep_targets and sips and len(b[_SIPS]) < MAX_TARGETS:
            have = b[_SIPS]
            extra = []
            for t in targets_of(sips):
                if t not in have and t not in extra:
                    extra.append(t)
                    if len(have) + len(extra) >= MAX_TARGETS:
                        break
            if extra:
                b[_SIPS] = have + tuple(extra)
                added = len(extra)
        return added

    def _keep_raw(self, hour: int, h: _Hour, r: tuple, cap: int) -> None:
        if cap:
            for ip in {r[_C], r[_S]} - _EMPTY_SET:
                ring = self._rings.get(ip)
                if ring is None:
                    ring = self._rings[ip] = []
                ring.append(r)
                if len(ring) >= 2 * cap:
                    self._compact(ring, cap)
        if self.alerts > self.classic_max:
            if self._raw_held:
                self._drop_raw()
            self._missing.add(hour)
        elif hour not in self._missing:
            h.raw.append(r)
            self._raw_held = True

    def _drop_raw(self) -> None:
        """Over the classic limit: free every raw list; the hours present are missing alerts until they leave."""
        for hr, x in self._hours.items():
            x.raw = []
            self._missing.add(hr)
        self._raw_held = False

    @staticmethod
    def _compact(ring: list, cap: int) -> None:
        ring.sort(key=_newest)
        del ring[cap:]

    def _ring_cap(self) -> int:
        return min(self.raw_per_host, DEGRADED_RING) if self.level >= 1 else self.raw_per_host

    # ---- reading --------------------------------------------------------------------------------------------

    def buckets(self) -> list[tuple]:
        """Every bucket in BUCKET_FIELDS order, sorted by key (hour first); the targets as one comma separated string."""
        return self._rows(None)

    def iter_hours(self):
        """The rows of buckets(), one list per hour, same order: each hour is copied under the lock on its own, so a
        reader that drops a list after using it never holds the whole window's rows at once."""
        with self._lock:
            hours = sorted(self._hours)
        for hour in hours:
            with self._lock:
                h = self._hours.get(hour)
                rows = [(*b[:_SIPS], ", ".join(b[_SIPS]) or None, *b[_SIPS + 1:])
                        for b in (h.b[k] for k in sorted(h.b))] if h is not None else []
            if rows:
                yield rows

    def rows(self, silence: silence.Silencer | None = None) -> list[tuple]:
        """What the board scores: every key of the window once, its hours folded like the alerts of one hour (sums,
        first and last, the strongest severity and threshold, the first ASN and filled field, the targets in the order
        seen, 64 at most), in the order the keys first appear in buckets(). `evidence.collect` folds hours of one key
        into one finding anyway, so the board is the same; the list is a quarter of the hourly one at 2M alerts.
        Holds the window lock throughout (about 1.8 s at 2M alerts): a page the poll adds meanwhile waits.

        With a `silence` matcher that has rules (1.4) every hourly bucket is matched first, in its own hour (a time
        window needs the hour), the hit counters of the matcher are filled from the whole window, hours with a
        different set of matching rules are not folded together, and each row gets one more element: the tuple of
        silence rule ids that match it (empty for most)."""
        sil = silence if silence is not None and silence.active else None
        with self._lock:
            m: dict[tuple, list] = {}
            owned: set[tuple] = set()       # keys whose list is a copy (a key of one hour stays the bucket itself)
            for hour in sorted(self._hours):
                h = self._hours[hour]
                bs = h.b
                matched: dict | None = None
                if sil is not None:
                    c = h.sil
                    if c is not None and c[0] == sil.signature and c[1] == h.n:    # the hour did not change: reuse it
                        matched = c[2]
                        sil.hits.update(c[3])
                        sil.silenced += c[4]
                    else:
                        matched, hh, took = {}, {}, 0
                        for key, b in bs.items():
                            args = (key[1], b[_C], b[_S], b[_PORT], key[5], b[_FIRST], b[_LAST])
                            ids, lids = sil.silence_ids(*args), sil.legacy_ids(*args)
                            if ids or lids:
                                matched[key] = ids
                                took += b[_N]
                                sil.count((*ids, *lids), hour, b[_N], b[_FIRST], b[_LAST], b[_C], b[_S], b[_ID], hh)
                        h.sil = (sil.signature, h.n, matched, hh, took)
                        sil.hits.update(hh)
                        sil.silenced += took
                for key in sorted(bs):
                    b = bs[key]
                    mk = key if matched is None else (key, matched.get(key, ()))
                    a = m.get(mk)
                    if a is None:
                        m[mk] = b
                        continue
                    if mk not in owned:
                        a = m[mk] = [*a]
                        owned.add(mk)
                    _fold_bucket(a, b)
            if sil is None:
                return [(*a[:_SIPS], ", ".join(a[_SIPS]) or None, *a[_SIPS + 1:]) for a in m.values()]
            return [(*a[:_SIPS], ", ".join(a[_SIPS]) or None, *a[_SIPS + 1:], mk[1]) for mk, a in m.items()]

    def scan(self, sil: silence.Silencer) -> list[tuple]:
        """The buckets one silence matcher (a candidate rule, for the dialog's preview) would take, over the whole
        window, as (alert name, client, server, port, alerts, first alert id, hour): no copy of the window."""
        out: list[tuple] = []
        with self._lock:
            for hour in sorted(self._hours):
                for key, b in self._hours[hour].b.items():
                    if sil.silence_ids(key[1], b[_C], b[_S], b[_PORT], key[5], b[_FIRST], b[_LAST]):
                        out.append((key[1], b[_C], b[_S], b[_PORT], b[_N], b[_ID], hour))
        return out

    def host_buckets(self, ip: str) -> list[tuple]:
        """The buckets that name this IP as client or server, through the per-hour index of the hosts."""
        return self._rows(ip)

    def _rows(self, ip: str | None) -> list[tuple]:
        with self._lock:
            out = []
            for hour in sorted(self._hours):
                bs = self._hours[hour].b
                keys = bs if ip is None else self._hours[hour].by_ip.get(ip, ())
                for key in sorted(keys):
                    b = bs[key]
                    out.append((*b[:_SIPS], ", ".join(b[_SIPS]) or None, *b[_SIPS + 1:]))
            return out

    def host_alerts(self, ip: str, limit: int = 200) -> list[tuple]:
        """The newest raw alerts of a host, newest first: at most `raw_per_host` (20 under pressure). A ring is cut
        when it reaches twice that, so it can hold up to twice as many between two cuts."""
        with self._lock:
            ring = self._rings.get(ip)
            if not ring:
                return []
            out = sorted((r for r in ring if (r[_TS] or 0) >= self._cut_ms), key=_newest)
            return out[:min(limit, self._ring_cap())]

    def find_raw(self, alert_id: str) -> tuple | None:
        """The raw alert with this id while it is still in a host's ring (what a page lists), else None."""
        with self._lock:
            for ring in self._rings.values():
                for r in ring:
                    if r[_ID] == alert_id and (r[_TS] or 0) >= self._cut_ms:
                        return r
        return None

    def raw(self) -> list[tuple] | None:
        """Every alert of the window while there are at most `classic_max` of them (and none was ever left out),
        else None: the classic board needs the raw alerts."""
        with self._lock:
            if self._missing or self.alerts > self.classic_max:
                return None
            return [r for hour in sorted(self._hours) for r in self._hours[hour].raw if (r[_TS] or 0) >= self._cut_ms]

    # ---- trimming and the budget ------------------------------------------------------------------------------

    def trim(self, now: float) -> None:
        with self._lock:
            cut = (now - self.retention_s) * 1000
            self._cut_ms = cut
            for hour in [hr for hr in self._hours if (hr + 1) * HOUR_MS < cut]:
                self.alerts -= self._hours.pop(hour).n
                self._missing.discard(hour)
            for ip in list(self._rings):
                ring = [r for r in self._rings[ip] if (r[_TS] or 0) >= cut]
                if ring:
                    self._rings[ip] = ring
                else:
                    del self._rings[ip]

    def forget_ids(self, before_ms: float) -> None:
        """Drop the alert ids of the hours that ended before `before_ms`: a poll only reads again from the newest
        alert minus its overlap, so no alert of those hours can come twice (2M ids are about 140 MB)."""
        with self._lock:
            for hour, h in self._hours.items():
                if (hour + 1) * HOUR_MS <= before_ms and h.ids:
                    h.ids = set()

    def degrade(self, level: int) -> None:
        """Set the degradation level (0-3) and thin what is held to it; see the module docstring."""
        with self._lock:
            level = max(0, min(3, level))
            self.level = level
            cap = self._ring_cap()
            for ring in self._rings.values():
                if len(ring) > cap:
                    self._compact(ring, cap)
            if level >= 2 and self.classify is not None:
                for h in self._hours.values():
                    self._thin(h, level)

    def _thin(self, h: _Hour, level: int) -> None:
        old, h.b, h.by_ip, h.sil = h.b, {}, {}, None
        for key, b in sorted(old.items()):
            cls = self.classify(b[_NAME], b[_TAC], b[_RID])
            keep = True
            if cls == "D":
                key, b, keep = (*key[:3], "", "", ""), [*b], False
                b[_S] = b[_PORT] = b[_PROTO] = None
            elif cls == "C" and level >= 3:
                keep = False
            self._absorb(h, key, b, b[_N], b[_FIRST], b[_LAST], keep)
        h.tgt = sum(len(b[_SIPS]) for b in h.b.values())

    def mem_bytes(self) -> int:
        """An estimate of what the window holds (see the module docstring); it grows with buckets, ids and rings."""
        with self._lock:
            total = 0
            for h in self._hours.values():
                total += len(h.b) * BUCKET_B + h.tgt * TARGET_B + len(h.ids) * ID_B + len(h.raw) * (RAW_B + LIST_REF_B)
            total += sum(len(r) for r in self._rings.values()) * RING_SLOT_B + len(self._rings) * RING_B
            return total

    def stats(self) -> dict:
        with self._lock:
            return {"alerts": self.alerts, "buckets": sum(len(h.b) for h in self._hours.values()),
                    "ids": sum(len(h.ids) for h in self._hours.values()),
                    "hours": len(self._hours), "hosts": len(self._rings), "level": self.level,
                    "mem_bytes": self.mem_bytes()}


def _fold_bucket(a: list, b: list) -> None:
    """Fold a later hour's bucket `b` of the same key into `a` (Window.rows), as _absorb folds an alert."""
    a[_N] += b[_N]
    a[_FIRST] = min(a[_FIRST], b[_FIRST])
    a[_LAST] = a[_TS] = max(a[_LAST], b[_LAST])
    if a[_SEV] is None or _SEV_W.get(b[_SEV], 0) > _SEV_W.get(a[_SEV], 0):
        a[_SEV] = b[_SEV]
    if a[_THR] is None or _THR_W.get(b[_THR], 0) > _THR_W.get(a[_THR], 0):
        a[_THR] = b[_THR]
    if b[_UP] is not None:
        a[_UP] = (a[_UP] or 0) + b[_UP]
    if b[_DOWN] is not None:
        a[_DOWN] = (a[_DOWN] or 0) + b[_DOWN]
    a[_SESS] = max(a[_SESS], b[_SESS])
    a[_UNIQ] = max(a[_UNIQ], b[_UNIQ])
    if a[_SASN] in _EMPTY and b[_SASN] not in _EMPTY:
        a[_SASN], a[_SCC] = b[_SASN], b[_SCC]
    if a[_CASN] in _EMPTY and b[_CASN] not in _EMPTY:
        a[_CASN], a[_CCC] = b[_CASN], b[_CCC]
    for i in _FILL:
        if a[i] in _EMPTY and b[i] not in _EMPTY:
            a[i] = b[i]
    have = a[_SIPS]
    if b[_SIPS] and len(have) < MAX_TARGETS:
        extra = [t for t in b[_SIPS] if t not in have]
        if extra:
            a[_SIPS] = have + tuple(extra[:MAX_TARGETS - len(have)])


def _newest(r: tuple) -> tuple:
    return (-(r[_TS] or 0), r[_ID] or "")


def _row_values(b: tuple) -> list:
    """What one bucket adds to its day's row: [n, first, last, up, down, sev, thr, asn, targets, rule id], severity
    and threshold as the scoring weights (0 = none), the targets as an ordered set."""
    return [b[_N], b[_FIRST], b[_LAST], b[_UP] or 0, b[_DOWN] or 0, _SEV_W.get(b[_SEV], 0), _THR_W.get(b[_THR], 0),
            ev._int(b[_SASN]) or ev._int(b[_CASN]) or None, dict.fromkeys(targets_of(b[_SIPS])), b[_RID] or None]


def _combine(a: list, v: list) -> None:
    """Fold the values of another bucket (or hour) of the same day key into `a`."""
    a[0] += v[0]
    a[1], a[2] = min(a[1], v[1]), max(a[2], v[2])
    a[3] += v[3]
    a[4] += v[4]
    a[5], a[6] = max(a[5], v[5]), max(a[6], v[6])
    a[7] = a[7] or v[7]
    if len(a[8]) < MAX_TARGETS:
        for t in v[8]:
            a[8].setdefault(t)
            if len(a[8]) >= MAX_TARGETS:
                break
    a[9] = a[9] or v[9]


def _row(key: tuple, a: list) -> tuple:
    """A day's row for the store: (rule, client, server, port, n, first_ms, last_ms, up, down, sev, thr, asn, targets
    as JSON or None, rule id or None)."""
    return (*key, *a[:7], a[7], json.dumps(sorted(a[8])[:MAX_TARGETS]) if a[8] else None, a[9])


def day_findings(buckets: list[tuple]) -> list[tuple]:
    """A day's rows for the store: (rule, client, server, port, n, first_ms, last_ms, up, down, sev, thr, asn,
    targets, rule_id), one per (alert name, client, server, port), summed from the buckets: the strongest severity
    and threshold, the first ASN and template id, the union of the targets (64 at most)."""
    agg: dict[tuple, list] = {}
    for b in buckets:
        key = (b[_NAME] or "", b[_C] or "", b[_S] or "", b[_PORT] or "")
        a = agg.get(key)
        if a is None:
            agg[key] = _row_values(b)
        else:
            _combine(a, _row_values(b))
    return [_row(k, a) for k, a in agg.items()]


class DayFold:
    """A backfilled day, folded one hour at a time: each hour goes through the hourly buckets and then into one
    running aggregate keyed like day_findings (rule, client, server, port); the hour's buckets are dropped. What is
    held is the distinct keys of the day (plus the hour in hand), never a bucket per hour."""

    def __init__(self) -> None:
        self.alerts = 0
        self.peak = 0                    # most entries held at once: day keys plus the hour's buckets
        self._agg: dict[tuple, list] = {}

    def add_hour(self, rows: list[tuple]) -> None:
        hour = Window(10**9, 0, 0, dedup=False)          # no ids, no rings: the hours of a day never overlap
        self.alerts += hour.add(rows)
        buckets = hour.buckets()
        folded: dict[tuple, list] = {}
        for b in buckets:
            key = (b[_NAME] or "", b[_C] or "", b[_S] or "", b[_PORT] or "")
            a = folded.get(key)
            if a is None:
                folded[key] = _row_values(b)
            else:
                _combine(a, _row_values(b))
        for key, v in folded.items():
            a = self._agg.get(key)
            if a is None:
                self._agg[key] = v
            else:
                _combine(a, v)
        self.peak = max(self.peak, len(self._agg) + len(buckets))

    def rows(self) -> list[tuple]:
        return [_row(k, a) for k, a in self._agg.items()]


# ---- a big past day as Sycope's own aggregate (spec call 10) -------------------------------------------------------

COUNT_NQL = " | aggr n=count(id)"
AGG_NQL = (" | aggr n=count(id), up=sum(sumClientBytes), down=sum(sumServerBytes), first=min(timestamp), "
           "last=max(timestamp) by alertName, alertRuleId, clientIp, serverIp, serverPort | limit 100000")
_MIN_WINDOW_S = 60


def day_count(client, start: float, end: float, nql: str) -> int:
    """How many alerts the window holds (one aggregate record, ~0.1 s on the lab)."""
    rows, _ = client.query_rows(start, end, nql + COUNT_NQL)
    return int((rows[0] if rows else {}).get("n") or 0)


def _agg_windows(client, start: float, end: float, nql: str):
    rows, total = client.query_rows(start, end, nql)
    if total < RESULT_CAP or end - start <= _MIN_WINDOW_S:
        if total >= RESULT_CAP:
            log.warning("the alert aggregate of %d s is still cut at %d records: the day is short of some keys",
                        end - start, total)
        yield rows
        return
    mid = start + (end - start) / 2          # the answer was cut: ask the halves (a key in both is summed)
    yield from _agg_windows(client, start, mid, nql)
    yield from _agg_windows(client, mid, end, nql)


def _key_part(v) -> str:
    return "" if v is None else str(v)


def aggregated_day(client, start: float, end: float, nql: str) -> tuple[list[tuple], int]:
    """A past day's rows for the store from Sycope's aggregate by (alertName, alertRuleId, clientIp, serverIp,
    serverPort): n, the byte sums and the first and last time, keyed like day_findings (rule, client, server, port;
    a null or empty element is ""), the first template id of the key in sorted order. Severity, threshold, ASN and
    targets are not in the aggregate: None, as in a row stored before v1.0 (the History never reads them; a replay
    counts them as unknown). The port is serverPort only (the plain path falls back to the first of serverPorts).
    Returns (rows, alerts)."""
    agg: dict[tuple, list] = {}
    for rows in _agg_windows(client, start, end, nql + AGG_NQL):
        for r in rows:
            ident = r.get("_id")
            if not isinstance(ident, list) or len(ident) < 5:
                continue
            name, rid, cl, sv, port = ident[:5]
            key = (_key_part(name), _key_part(cl), _key_part(sv), _key_part(port))
            v = [ev._int(r.get("n")), ev._int(r.get("first")), ev._int(r.get("last")), ev._int(r.get("up")),
                 ev._int(r.get("down")), rid or None]
            a = agg.get(key)
            if a is None:
                agg[key] = v
                continue
            a[0] += v[0]
            a[1], a[2] = min(a[1], v[1]), max(a[2], v[2])
            a[3] += v[3]
            a[4] += v[4]
            if v[5] and (not a[5] or str(v[5]) < str(a[5])):
                a[5] = v[5]
    out = [(*k, *a[:5], None, None, None, None, a[5]) for k, a in sorted(agg.items())]
    return out, sum(r[4] for r in out)
