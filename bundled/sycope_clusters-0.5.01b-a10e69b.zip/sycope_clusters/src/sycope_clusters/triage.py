"""What the triage pages read (JSON views of the evidence board) and the analyst's actions.

The board is rebuilt after every poll; the analyst's state (triage, exceptions) lives in the store. A handled host
leaves the queue until it shows something it did not show when it was handled (a new family, a new chain rule, a
higher verdict): "snooze until change", the thing that keeps yesterday's noise off today's board.
"""

from __future__ import annotations

import ipaddress
import re
from collections import Counter, defaultdict

from sycope_clusters import evidence as ev
from sycope_clusters import fmt, silence
from sycope_clusters.addresses import AddressBook, prefix
from sycope_clusters.params import FACTORY, Params, factory
from sycope_clusters.rules import DIRECTIONS, FAMILIES, STAGES, Catalog, stored_rule

# The analyst's state of a host. In progress and Escalated keep it in the queue (with an owner); Seen and the three
# closures take it out until it shows something new. "resolved" is the 0.2-0.4 closure, read as a true positive.
STATUS = {"investigating": "In progress", "escalated": "Escalated", "ack": "Seen", "tp": "Closed: true positive",
          "benign": "Closed: benign", "fp": "Closed: false positive", "resolved": "Resolved"}
ACTION_STATUSES = (*STATUS, "open")        # what an analyst action can set; the audit actions are <scope>:<status>
EXC_DECISIONS = ("approve", "reject")     # the second person's answer to a proposed exception: exception:<decision>
CLOSED = ("tp", "benign", "fp", "resolved")
REASONS = {
    "tp": ["Contained or isolated", "Credentials reset", "Blocked at the firewall", "Handed to incident response",
           "Other"],
    "benign": ["Authorized scanner or pentest", "Backup or sync job", "Admin activity", "Known business service",
               "Other"],
    "fp": ["The rule fires on normal traffic", "A download, not an upload", "Stale threat intel",
           "Shared cloud or CDN address", "Other"],
}
EXC_DAYS = (1, 7, 30, 90)       # the options of an exception's expiry; the longest is store.EXC_MAX_DAYS
# Families whose exceptions need a second person (principle 5): credential attack, exfiltration and C2 channel. So does
# every threat-intelligence-backed finding (see ti_backed), whatever the family or class of the rule says.
PROTECTED_FAMILIES = ("CL-02", "CL-05", "CL-06")
I_ID, I_TS, I_NAME, I_SEV, I_TAC, I_DEF, I_C, I_S = (ev.IX[k] for k in ("id", "timestamp", "alertName",
                                                                       "alertSeverity", "alertMitreTactic",
                                                                       "alertDefId", "clientIp", "serverIp"))
I_RID = ev.IX["alertRuleId"]
I_PROTO = ev.IX["protocolName"]
I_THR, I_UP, I_DOWN = ev.IX["alertFlagThresholdLevel"], ev.IX["sumClientBytes"], ev.IX["sumServerBytes"]


class ActionError(ValueError):
    pass


# ---- pieces ------------------------------------------------------------------------------------------------------

def stage_marks(findings: list, p: Params = FACTORY) -> list[str]:
    """Per kill-chain stage: c = confirmed (>= 2 bits), s = suspected (some evidence), '' = nothing."""
    out = ["", "", "", ""]
    for f in findings:
        if f.stage is None or f.bits <= 0:
            continue
        if f.bits >= p["confirm_bits"]:
            out[f.stage] = "c"
        elif not out[f.stage]:
            out[f.stage] = "s"
    return out


def stage_line(marks: list[str], conf: float = 1.0, p: Params = FACTORY) -> str:
    """The stage a host shows in its header: the highest stage on its attack path. One meaning of "confirmed":
    the evidence reaches confirm_bits AND the host confidence is high (wording.conf_high). Evidence at confirm_bits
    under a lower confidence is "<Stage>-stage evidence"; weaker evidence is "<Stage> suspected"."""
    top = max((i for i, m in enumerate(marks) if m == "c"), default=None)
    sus = max((i for i, m in enumerate(marks) if m == "s"), default=None)
    parts = []
    if top is not None:
        parts.append(f"{ev.STAGES[top]} confirmed" if conf >= p["wording.conf_high"]
                     else f"{ev.STAGES[top]}-stage evidence")
    if sus is not None and (top is None or sus > top):
        parts.append(f"{ev.STAGES[sus]} suspected")
    return ", ".join(parts) or "no stage"


def low_why(e: ev.Entity, p: Params = FACTORY) -> str:
    """For a low-confidence host at Act now or Investigate: what carries the verdict (the row says "low, but ...")."""
    if e.conf >= 0.5 or e.verdict not in ("act", "investigate"):
        return ""
    if e.severe:
        return f"{ev.STAGES[e.confirmed]}-stage evidence" if e.confirmed == len(ev.STAGES) - 1 \
            else "command-channel evidence"
    if e.crown:
        return "a crown jewel"
    if e.chains:
        return "a chain rule"
    if e.confirmed is not None:
        return f"{ev.STAGES[e.confirmed]}-stage evidence" if e.conf < p["wording.conf_high"] \
            else f"{ev.STAGES[e.confirmed]} confirmed"
    return "see why"


ACTIVE_MS = 15 * 60 * 1000


def _mb(n: float) -> str:
    return f"{n / 1e6:g} MB" if n >= 1e6 else f"{n / 1e3:g} KB"


def act_needs(e: ev.Entity, p: Params = FACTORY) -> list[str]:
    """For a host below Act now: the decision-table lines it does not meet yet, in plain words, with the numbers
    of the parameters the board was scored with."""
    if e.verdict == "act":
        return []
    ids = {c for c, _, _ in e.chains}
    impact, crown = f"{p['verdict.impact_conf'] * 100:.0f}%", f"{p['verdict.crown_stage_conf'] * 100:.0f}%"
    out = []
    if not e.severe:
        out.append(f"a command channel (a beacon, a covert channel or a listed C2 address) or Objectives (an upload of "
                   f"{_mb(p['exfil_floor_bytes'])} or more) with evidence and confidence {impact} or more")
    elif e.conf < p["verdict.impact_conf"]:
        # "confirmed" only when the evidence and a high confidence are both there (see ev.stage_claim)
        what = ev.severe_what(e)
        have = f"the confirmed {what}" if e.conf >= p["wording.conf_high"] else (
            f"the {what}-stage evidence" if what != "command channel" else "the command-channel evidence")
        out.append(f"confidence {impact} or more for {have} (now {ev.conf_text(e.conf)})")
    chains = sorted(c for c in p["act_chains"] if c in ev.CHAINS)
    names = {"CR-01": "C2 with exfiltration", "CR-02": "three of the four kill-chain families",
             "CR-04": "staging then exfiltration", "CR-05": "C2 with intel"}
    out.append("a chain rule " + ", ".join(chains[:-1]) + (" or " if len(chains) > 1 else "") + chains[-1]
               + " (" + ", ".join(names.get(c) or ev.CHAINS[c][0] for c in chains) + ")" if chains else
               "a chain rule that means a compromise (none is set)")
    for c in ("CR-08", "CR-09"):
        if c in ids:
            out.append(f"{ev.CHAINS[c][0]} with the second step against a host the first step touched")
            break
    if e.crown and not e.severe:
        out.append(f"on a crown jewel: a command channel or Objectives with evidence (any confidence), or Lateral "
                   f"evidence with confidence {crown} or more")
    return out


LOC_TIP = "Location from the Sycope lookup that matched this address"


def entity_context(b: ev.Board, ip: str) -> dict:
    """What the board knows about the subject besides its address, and where each piece comes from (a tooltip per
    tag). Only what a source gave: no source, no key. A name from the hostnames file or the lookup is the admin's
    or Sycope's; a role says whether it is admin's, the lookup's or learned (and from how many days)."""
    out: dict = {}
    if b.names.get(ip) and b.name_src.get(ip):
        out["name_src"] = b.name_src[ip]
    tips = b.role_tips.get(ip)
    if tips:
        out["tag_tips"] = dict(tips)
    if b.locs.get(ip):
        out["loc_tip"] = LOC_TIP
    if getattr(b, "netnames", {}).get(ip):
        out["net_tip"] = "Network name from the networks file"
    return out


def host_item(b: ev.Board, e: ev.Entity, t: dict | None) -> dict:
    return {"type": "host", "key": e.ip, "ip": e.ip, "name": b.names.get(e.ip), "verdict": e.verdict,
            "reason": e.reason, "conf": round(e.conf, 3), "risk": e.risk, "E": e.E, "stage": e.confirmed,
            "rank": ev.rank(e), "suspected": e.suspected, "stages": (sm := stage_marks(e.findings, b.params)),
            "stage_line": stage_line(sm, e.conf, b.params), "low_why": low_why(e, b.params),
            "stage_confirmed": e.conf >= b.params["wording.conf_high"], "conf_word": ev.conf_word(e.conf, b.params),
            "families": [k for k, f in e.families.items() if f.bits >= 1], "headline": e.headline, "path": e.path,
            "novelty": e.novelty, "days_active": e.days_active, "depth": b.history["depth"], "last": e.last,
            "first": e.first, "alerts": e.alerts, "crown": e.crown, "tags": e.tags, "loc": b.locs.get(e.ip),
            "chains": [c for c, _, _ in e.chains], "triage": ev.overlay(e, t), "story": e.story,
            "active": b.now * 1000 - e.last < ACTIVE_MS, "net": getattr(b, "netnames", {}).get(e.ip),
            "ctx": entity_context(b, e.ip)}


def target_item(b: ev.Board, ti: ev.TargetIncident, t: dict | None) -> dict:
    """A host attacked from outside as a queue row: shaped like a host row, flagged as a target (no confidence,
    no stage of its own; the attempts against it marked as suggested Recon or Foothold)."""
    marks = ["s" if "scan" in ti.kinds else "", "s" if set(ti.kinds) & {"brute", "cred", "remote", "exposure", "ti"} else "",
             "", ""]
    return {"type": "host", "target": True, "key": ti.ip, "ip": ti.ip, "name": b.names.get(ti.ip),
            "verdict": ti.verdict, "reason": ti.reason, "conf": None, "risk": ti.risk, "E": 0, "stage": None,
            "suspected": None, "stages": marks, "families": ti.families, "headline": ti.headline,
            "path": ti.headline, "novelty": "", "days_active": 0, "depth": b.history["depth"], "last": ti.last,
            "first": ti.first, "alerts": ti.alerts, "crown": ti.crown, "tags": ["target"], "loc": b.locs.get(ti.ip),
            "chains": [], "triage": ev.overlay(ti, t), "story": None, "active": b.now * 1000 - ti.last < ACTIVE_MS,
            "net": getattr(b, "netnames", {}).get(ti.ip), "ctx": {**entity_context(b, ti.ip),
                                                                    "tag_tips": {"target": "A host attacked from outside"}}}


def story_item(b: ev.Board, s: dict, triage: dict) -> dict:
    members = [b.entities[ip] for ip in s["members"]]
    ov = [ev.overlay(m, triage.get(m.ip)) for m in members]
    handled = sum(1 for o in ov if o and o["handled"])
    changed = sum(1 for o in ov if o and o["changed"])
    owned = [o for o in ov if o and not o["changed"] and o["status"] in ("investigating", "escalated")]
    marks = ["", "", "", ""]
    for m in members:
        for i, x in enumerate(stage_marks(m.findings, b.params)):
            if x == "c" or (x == "s" and not marks[i]):
                marks[i] = x
    fams = Counter(f for m in members for f in m.pattern if not f.startswith("CR-"))
    return {"type": "story", "key": s["key"], "title": s["title"], "verdict": s["verdict"], "count": s["count"],
            "open": s["count"] - handled, "handled": handled, "changed": changed, "nets": s["nets"],
            "spread": s["spread"], "conf": round(s["conf"], 3), "conf_word": ev.conf_word(s["conf"], b.params), "risk": s["risk"], "last": s["last"],
            "first": s["first"], "new": s["new"], "stage": s["confirmed"], "rank": s["rank"], "suspected": s["suspected"],
            "stages": marks, "families": [f for f, _ in fams.most_common(5)], "sample": s["sample"][:2],
            "crown": s["crown"], "chains": [c for c in s["pattern"] if c.startswith("CR-")],
            "top": [m.ip for m in members[:6]], "active": sum(1 for m in members if b.now * 1000 - m.last < ACTIVE_MS),
            "in_progress": sum(1 for o in owned if o["status"] == "investigating"),
            "escalated_n": sum(1 for o in owned if o["status"] == "escalated"),
            "owners": sorted({o["owner"] for o in owned if o.get("owner")}),
            "why": _why_review(s, members) if s["verdict"] == "review" else None,
            "ips": list(s["members"]) if len(s["members"]) <= 2000 else []}   # for actions on ticked incidents


def _why_review(s: dict, members: list) -> str:
    """Why a group is only Review, in words: a big yellow group looks dangerous until it says so."""
    fams = [FAMILIES[f][0] for f in s["pattern"] if not f.startswith("CR-") and f in FAMILIES]
    if not fams:
        fams = [FAMILIES[f][0] for f, _ in Counter(k for m in members for k, f in m.families.items()
                                                   if f.bits >= 1).most_common(2)]
    chains = [c for c in s["pattern"] if c.startswith("CR-")]
    what = (f"each host: only {fams[0].lower()}" if len(fams) == 1 else
            f"each host: {', '.join(f.lower() for f in fams[:3])}" if fams else "weak evidence on each host")
    return (what + ("" if chains else ", no chain rule") + ", no command channel, nothing at Objectives"
            + f", confidence up to {ev.conf_text(s['conf'])}")


def campaign_item(c: dict, children: list[dict], params: Params = FACTORY) -> dict:
    """A campaign as one incident: more hosts of one network segment at Investigate or above than chance explains,
    made of its child incidents (the stories and single hosts that mostly sit in it). Its numbers are the sums of the
    children, so no host counts twice."""
    marks = ["", "", "", ""]
    for x in children:
        for i, m in enumerate(x["stages"]):
            if m == "c" or (m == "s" and not marks[i]):
                marks[i] = m
    hosts = sum(x.get("count", 1) for x in children)
    handled = sum(x["handled"] if x["type"] == "story" else int(bool(x["triage"] and x["triage"]["handled"]))
                  for x in children)
    stages = [x["stage"] for x in children if x.get("stage") is not None]
    return {"type": "campaign", "key": c["net"], "net": c["net"], "title": f"Campaign in {c['net']}",
            "verdict": c["verdict"], "count": hosts, "open": hosts - handled, "handled": handled,
            "changed": sum(x["changed"] if x["type"] == "story" else int(bool(x.get("changed"))) for x in children),
            "children_n": len(children), "conf": max(x["conf"] for x in children),
            "conf_word": ev.conf_word(max(x["conf"] for x in children), params),
            "risk": max(x["risk"] for x in children), "stage": max(stages) if stages else None,
            "rank": max((x["rank"] for x in children if x.get("rank") is not None), default=None), "stages": marks,
            "last": max(x["last"] for x in children), "first": min(x["first"] for x in children),
            "new": sum(x["new"] if x["type"] == "story" else int(x.get("novelty") == "new") for x in children),
            "active": sum(x["active"] if x["type"] == "story" else int(bool(x["active"])) for x in children),
            "families": [k for k, _ in c["families"][:5]], "chains": [k for k, _ in c["chains"][:4]],
            "nets": c["nets24"], "crown": sum(x["crown"] if x["type"] == "story" else int(bool(x["crown"]))
                                              for x in children),
            "pcap_hosts": sum(x.get("pcap_hosts", 0) if x["type"] == "story"
                              else int(bool((x.get("pcap") or {}).get("done"))) for x in children),
            "in_progress": sum(x.get("in_progress", 0) if x["type"] == "story"
                               else int(_st(x) == "investigating") for x in children),
            "escalated_n": sum(x.get("escalated_n", 0) if x["type"] == "story" else int(_st(x) == "escalated")
                               for x in children),
            "owners": sorted({o for x in children for o in (x.get("owners") or ([_owner(x)] if _owner(x) else []))}),
            "by_verdict": dict(Counter(x["verdict"] for x in children)),
            "why": c.get("why", ""), "reason": c.get("reason", ""), "p": c.get("p"), "n": c.get("n"), "n_source": c.get("n_source")}


def _st(x: dict) -> str | None:
    t = x.get("triage")
    return t["status"] if t and not t.get("changed") else None


def _owner(x: dict) -> str | None:
    t = x.get("triage")
    return t.get("owner") if t and not t.get("changed") and t["status"] in ("investigating", "escalated") else None


# no alerts this long: lower inside its verdict and stage, never a lower verdict (factory value of quiet_h)
QUIET_MS = factory("quiet_h") * 3600 * 1000


def _sort(items: list[dict], order: str, now_ms: float | None = None, p: Params = FACTORY) -> None:
    quiet_ms = p["quiet_h"] * 3600 * 1000

    def stage_of(x: dict) -> int:
        r = x["rank"] if x.get("rank") is not None else x.get("stage")     # a command channel ranks with Objectives
        return r if r is not None else -1

    def quiet(x: dict) -> bool:
        return bool(now_ms) and now_ms - (x.get("last") or 0) >= quiet_ms

    if order == "stage":
        items.sort(key=lambda x: (-ev.VRANK[x["verdict"]], -(x["type"] == "campaign"), -bool(x.get("changed")),
                                  -stage_of(x), quiet(x), -x["risk"], -x["last"]))
    else:
        items.sort(key=lambda x: (-ev.VRANK[x["verdict"]], -(x["type"] == "campaign"), -bool(x.get("changed")),
                                  -round(x["risk"], 1), quiet(x), -x["risk"], -x["last"]))


def incidents(b: ev.Board, triage: dict, pcap: dict | None = None) -> tuple[list[dict], dict[str, list[dict]]]:
    """Every incident on the board: stories and single hosts, each with "parent" set to the campaign it mostly sits in
    (a story counts as the campaign's when half or more of its hosts are campaign members). Returns the incidents and
    the campaign items with their children."""
    pcap = pcap or {}
    built = []
    members_of: dict[str, list[str]] = {}
    for it in b.items:
        if it["type"] == "story":
            s = b.stories[it["key"]]
            x = story_item(b, s, triage)
            members_of[x["key"]] = s["members"]
            x["pcap_hosts"] = sum(1 for m in s["members"] if (pcap.get(m) or {}).get("done"))
        elif it["type"] == "target":
            x = target_item(b, b.target_inc[it["key"]], triage.get(it["key"]))
            o = x["triage"]
            x["changed"] = bool(o and o["changed"])
            x["pcap"] = pcap.get(it["key"])
        else:
            e = b.entities[it["key"]]
            x = host_item(b, e, triage.get(e.ip))
            o = x["triage"]
            x["changed"] = bool(o and o["changed"])
            x["pcap"] = pcap.get(e.ip)
        x["parent"] = None
        built.append(x)
    campaigns: dict[str, list[dict]] = {}
    for c in b.campaigns:
        mem = set(c.get("members") or ())
        kids = []
        for x in built:
            if x["parent"]:
                continue
            if x["type"] == "host":
                inside = x["ip"] in mem
            else:
                ms = members_of[x["key"]]
                inside = 2 * sum(1 for m in ms if m in mem) >= len(ms)
            if inside:
                x["parent"] = c["net"]
                kids.append(x)
        if kids:
            campaigns[c["net"]] = [campaign_item(c, kids, b.params), kids]
    return built, campaigns


def queue(b: ev.Board, triage: dict, watch: bool = False, handled: bool = False, limit: int = 400,
          order: str = "stage", pcap: dict | None = None) -> dict:
    """The queue of incidents. A campaign is one row with its child incidents inside it; counts are incidents and
    the hosts in them (a campaign's hosts count under the campaign's verdict). order="risk": inside a verdict by risk
    (confidence x impact); order="stage": inside a verdict by the stage first, then risk (a command channel or Objectives always
    above Lateral, as in the expert-ranked reference cases)."""
    counts = {v: {"items": 0, "hosts": 0} for v in ev.VERDICTS}
    built, camps = incidents(b, triage, pcap)

    def state(x: dict) -> tuple[bool, int]:
        if x["type"] == "host":
            h = bool(x["triage"] and x["triage"]["handled"])
            return h, 0 if h else 1
        return x["open"] == 0, x["open"]

    def visible(x: dict) -> bool:
        return (handled or not state(x)[0]) and (watch or x["verdict"] != "watch")

    n_handled = sum(x["handled"] if x["type"] == "story" else int(state(x)[0]) for x in built)
    n_changed = sum(1 for x in built if x.get("changed"))
    top = [x for x in built if not x["parent"]]
    for item, kids in camps.values():
        item["children"] = [x for x in kids if visible(x)]
        _sort(item["children"], order, b.now * 1000, b.params)
        top.append(item)
    items = []
    for x in top:
        is_handled, hosts = state(x)
        if not is_handled:
            counts[x["verdict"]]["items"] += 1
            counts[x["verdict"]]["hosts"] += hosts
        if visible(x):
            items.append(x)
    _sort(items, order, b.now * 1000, b.params)
    return {"items": items[:limit], "more": max(0, len(items) - limit), "counts": counts, "handled": n_handled,
            "changed": n_changed}


def held(b: ev.Board, triage: dict, store=None) -> list[dict]:
    """Hosts an analyst holds (In progress, Escalated) that the queue no longer shows: no alerts left in the 24 h
    window, or below Review now. Taken work never disappears by itself: these stay in the queue, quiet, until someone
    closes them. Each carries its latest incident record (what it was) when there is one."""
    out = []
    for ip, t in triage.items():
        if t["status"] not in ("investigating", "escalated"):
            continue
        e = b.entities.get(ip)
        if (e is not None and e.verdict != "watch") or ip in getattr(b, "target_inc", {}):
            continue
        recs = store.incidents_of(f"ip:{ip}", 1) if store else []
        r = recs[0] if recs else None
        out.append({"type": "held", "key": ip, "ip": ip, "name": b.names.get(ip), "status": t["status"],
                    "owner": t.get("owner"), "who": t.get("who"), "at": t.get("at"), "note": t.get("note"),
                    "verdict": t.get("verdict") or "watch", "now": e.verdict if e is not None else None,
                    "last": e.last if e is not None else (r["last_ms"] if r else None),
                    "headline": (r["headline"] if r else None) or (e.headline if e is not None else None),
                    "rec": r["id"] if r else None, "rec_status": r["status"] if r else None,
                    "net": getattr(b, "netnames", {}).get(ip), "crown": bool(e is not None and e.crown)})
    out.sort(key=lambda x: (-ev.VRANK.get(x["verdict"], 0), -(x["at"] or 0)))
    return out


def funnel(b: ev.Board, q: dict) -> dict:
    """The funnel in incidents and hosts. act/investigate/review are the open hosts of the incidents at that
    verdict, *_items the incidents."""
    c = q["counts"]
    live = ("act", "investigate", "review")
    return {"alerts": b.alerts, "findings": b.findings, "service_alerts": b.counts["explained"],
            "services": len(b.tuning["services"]), "actors": b.counts["actors"],
            "stories": b.counts["stories"], "act": c["act"]["hosts"], "investigate": c["investigate"]["hosts"],
            "review": c["review"]["hosts"], "watch": c["watch"]["hosts"],
            "act_items": c["act"]["items"], "investigate_items": c["investigate"]["items"],
            "review_items": c["review"]["items"], "incidents": sum(c[v]["items"] for v in live),
            "incident_hosts": sum(c[v]["hosts"] for v in live)}


def _clean_text(v, n: int) -> str:
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(v or "")).strip()
    return s[:n]


def _ip(v) -> str:
    try:
        return str(ipaddress.ip_address(str(v or "").strip()))
    except ValueError:
        raise ActionError("not an IP address") from None


# ---- detail -----------------------------------------------------------------------------------------------------

def finding_json(f: ev.Finding, names: dict) -> dict:
    client, server = (f.cp, f.subject) if f.as_server else (f.subject, f.cp)
    return {"rule": f.rule.name, "family": f.family, "flabel": FAMILIES.get(f.family, ("?",))[0], "cls": f.cls,
            "kind": f.kind, "stage": f.stage, "direction": f.direction, "client": client, "server": server, "port": f.port, "cp": f.cp,
            "cp_label": ev.cp_label(f, names), "n": f.n, "first": f.first, "last": f.last, "base": round(f.base, 2),
            "bits": round(f.bits, 2), "caps": [{"what": w, "limit": v, "why": why} for w, v, why in f.caps],
            "deds": [{"what": w, "value": v, "why": why} for w, v, why in f.deds], "notes": f.notes,
            "counted": f.counted, "excepted": f.excepted, "days_seen": f.days_seen, "days_looked": f.days_looked,
            "days_skipped": f.days_skipped,
            "sev": ev.SEV_NAME.get(f.sev), "thr": ev.THR_NAME.get(f.thr), "up": f.up, "down": f.down,
            "asn": ev.asn_label(f.asn, f.country), "targets": sorted(f.targets)[:12], "ntargets": max(f.uniq,
                                                                                                    len(f.targets)),
            "sessions": f.sessions, "phrase": ev.phrase(f, names), "new": f.unseen,
            "ti": f.rule.ti, "attack": f.rule.attack, "attack_id": f.rule.technique, "attack_tactic": f.rule.tactic,
            "tpl_tag": f.tpl_tag,
            "sources": [dict(t) for t in f.trace]}


def heatmap(b: ev.Board, ip: str, store, catalog: Catalog, nets: AddressBook) -> dict:
    """Families of this host per day: the last 7 stored days and today (the current window)."""
    days = sorted(store.days())[-7:] if store else []
    today = ev.day_key(b.now * 1000)
    cols = [d for d in days if d < today] + [today]
    cells: dict[tuple, Counter] = defaultdict(Counter)
    for row in (store.ip_days(ip, cols[:-1]) if store else []):
        day, rule_name, client, server, _port, n = row[:6]
        rule = stored_rule(catalog, rule_name, ev.row_rule_id(row))
        rule, _dir = ev.resolve(rule, client or None, server or None, row[9] if len(row) > 9 else None, nets)
        for lane, subj, _cp in ev.attribute(rule, client or None, server or None, nets):
            if subj == ip:
                cells[(lane, rule.family)][day] += n
    e = b.entities.get(ip)
    for f in (e.findings if e else []):
        cells[("a", f.family)][today] += f.n
    for f in b.target_f.get(ip, []):
        cells[("t", f.rule.family)][today] += f.n
    for f in b.hyg_f.get(ip, []):
        cells[("h", f.rule.family)][today] += f.n
    order = {k: i for i, k in enumerate(FAMILIES)}
    rows = []
    # lanes: a = it acts, t = it is the target, h = hygiene, x = an outside address seen only with other outside
    # addresses (an external IP's own page)
    for (lane, fam), c in sorted(cells.items(), key=lambda kv: ({"a": 0, "t": 1, "h": 2, "x": 3}.get(kv[0][0], 9),
                                                                 order.get(kv[0][1], 99))):
        rows.append({"lane": lane, "family": fam, "label": FAMILIES.get(fam, ("?",))[0],
                     "cells": [c.get(d, 0) for d in cols]})
    return {"days": cols, "rows": rows}


SEV_RANK = {"Info": 1, "Low": 2, "Medium": 3, "High": 4, "Critical": 5}
THR_RANK = {"Minor": 1, "Major": 2, "Critical": 3}


def alert_groups(rows: list, ip: str, limit: int = 120, buckets: list | None = None) -> list[dict]:
    """The host's alerts grouped by rule and pair (client, server, port): one line per repeated alert, newest first.
    With `buckets` (the host's hourly buckets of ingest.py) the counts and times cover every alert of the window and
    `rows` (the raw ring) only gives the alert ids; without, `rows` are all the alerts."""
    groups: dict[tuple, dict] = {}

    def group(key: tuple, name, t: float, sev, thr) -> dict:
        g = groups.get(key)
        if g is None:
            g = groups[key] = {"name": name, "client": key[1], "server": key[2], "port": key[3], "n": 0,
                               "first": t, "last": t, "severity": sev, "thr": thr, "ids": [], "proto": None}
        return g

    def strongest(g: dict, sev, thr) -> None:
        if SEV_RANK.get(sev, 0) > SEV_RANK.get(g["severity"], 0):
            g["severity"] = sev
        if THR_RANK.get(thr, 0) > THR_RANK.get(g["thr"], 0):
            g["thr"] = thr

    # a group is keyed like a bucket: rule id first, else the name; alerts of one rule id that carry two names are one
    # group, shown under the first name (a bucket has None for an empty address)
    for b in buckets or ():
        g = group((b[I_RID] or b[I_NAME], b[I_C], b[I_S], ev._port(b) or None), b[I_NAME], b[-2], b[I_SEV], b[I_THR])
        g["n"] += b[-3]
        g["first"], g["last"] = min(g["first"], b[-2]), max(g["last"], b[-1])
        strongest(g, b[I_SEV], b[I_THR])
        g["proto"] = g["proto"] or silence.proto_of(b[I_PROTO]) or None
    ids: dict[tuple, list] = {}
    for r in rows:
        if r[I_C] != ip and r[I_S] != ip:
            continue
        key = (r[I_RID] or r[I_NAME], r[I_C] or None, r[I_S] or None, ev._port(r) or None)
        t = r[I_TS] or 0
        if buckets is None:
            g = group(key, r[I_NAME], t, r[I_SEV], r[I_THR])
            g["n"] += 1
            g["first"], g["last"] = min(g["first"], t), max(g["last"], t)
            strongest(g, r[I_SEV], r[I_THR])
            g["proto"] = g["proto"] or silence.proto_of(r[I_PROTO]) or None
        ids.setdefault(key, []).append((t, r[I_ID]))
    for key, lst in ids.items():
        if key in groups:
            groups[key]["ids"] = lst
    out = sorted(groups.values(), key=lambda g: -g["last"])[:limit]
    for g in out:
        g["ids"] = [i for _, i in sorted(g["ids"], reverse=True)[:40]]
    return out


def newest_alerts(rows: list, ip: str, limit: int = 150, total: int | None = None) -> tuple[list[dict], int]:
    """The newest alerts of a host and how many it has: `total` when the rows are only the host's raw ring."""
    hit = [r for r in rows if r[I_C] == ip or r[I_S] == ip]
    hit.sort(key=lambda r: r[I_TS] or 0, reverse=True)
    out = [{"t": r[I_TS], "name": r[I_NAME], "severity": r[I_SEV], "tactic": r[I_TAC], "client": r[I_C],
            "server": r[I_S], "port": ev._port(r) or None, "id": r[I_ID], "def_id": r[I_DEF],
            "proto": silence.proto_of(r[I_PROTO]) or None,
            "thr": r[I_THR], "up": r[I_UP], "down": r[I_DOWN]} for r in hit[:limit]]
    return out, len(hit) if total is None else max(total, len(hit))


def host_detail(b: ev.Board, ip: str, store, rows: list, catalog: Catalog, nets: AddressBook,
                buckets: list | None = None, full: bool = False) -> dict | None:
    """The host page. `rows` are the host's raw alerts (its ring); `buckets` its hourly buckets: the counts of the
    page then cover every alert of the window, not only the ring. `full`: the viewer is an admin, who reads the note
    and detail of configuration lines in the host's history."""
    e = b.entities.get(ip)
    t_f = b.target_f.get(ip) or []
    h_f = b.hyg_f.get(ip) or []
    x = b.ext.get(ip)
    if not (e or t_f or h_f or x):
        return None
    tri = store.triage().get(ip) if store else None
    out = {"ip": ip, "name": b.names.get(ip), "loc": b.locs.get(ip), "crown": bool(e and e.crown),
           "tags": b.roles.get(ip, []), "internal": nets.internal(ip), "now": b.now, "depth": b.history["depth"],
           "ctx": entity_context(b, ip)}
    if e:
        steps, back = ev.narrative(e, b.names, b.params)
        fam_rows = [{"family": k, "label": FAMILIES[k][0], "bits": round(f.bits, 2), "stage": f.stage,
                     "rule": f.rule.name} for k, f in sorted(e.families.items(), key=lambda kv: -kv[1].bits)]
        out["actor"] = {
            "verdict": e.verdict, "reason": e.reason, "conf": round(e.conf, 4), "risk": e.risk, "E": e.E,
            "prior": b.params["prior_bits"], "stage": e.confirmed, "suspected": e.suspected,
            "stages": (sm := stage_marks(e.findings, b.params)), "stage_line": stage_line(sm, e.conf, b.params),
            "low_why": low_why(e, b.params), "stage_confirmed": e.conf >= b.params["wording.conf_high"],
            "conf_word": ev.conf_word(e.conf, b.params),
            "chains": [{"id": c, "title": ev.CHAINS[c][0], "what": ev.CHAINS[c][2], "bits": bb, "continuity": t}
                       for c, bb, t in e.chains],
            "progression": e.progression, "families": fam_rows, "narrative": steps, "background": back[:6],
            "headline": e.headline, "novelty": e.novelty, "days_active": e.days_active,
            "impact": ev.impact_of(e, b.params), "impact_why": ev.impact_why(e, b.params),
            "trace": [finding_json(f, b.names) for f in sorted(e.findings, key=lambda f: (-f.counted, -f.bits,
                                                                                        -f.n))[:120]],
            "findings": len(e.findings), "alerts": e.alerts, "first": e.first, "last": e.last, "story": e.story,
            "act_needs": act_needs(e, b.params), "active": b.now * 1000 - e.last < ACTIVE_MS,
            "recurring": {"n": e.recur_n, "bits": e.recur_bits} if e.recur_bits else None,
            "held": {"text": e.held, "raw": e.raw_verdict, "raw_reason": e.raw_reason} if e.held else None}
        out["triage"] = ev.overlay(e, tri)
    else:
        out["triage"] = ({"status": tri["status"], "who": tri.get("who"), "note": tri.get("note"),
                          "at": tri.get("at"), "changed": False, "handled": tri["status"] in ev.HANDLED}
                         if tri else None)
    # silenced findings are not dropped from the page: a folded section lists them with the rule that took each
    sil = sorted((f for f in [*(e.findings if e else ()), *t_f, *h_f] if f.excepted), key=lambda f: (-f.n, f.rule.name))
    if sil:
        out["silenced"] = {"n": sum(f.n for f in sil), "total": len(sil),
                           "findings": [finding_json(f, b.names) for f in sil[:60]]}
    if t_f:
        summary = next((t for t in b.targets if t["ip"] == ip), None)
        att: dict[str, dict] = {}
        for f in t_f:
            a = att.setdefault(f.cp or "?", {"ip": f.cp, "internal": nets.internal(f.cp), "n": 0, "rules": Counter(),
                                             "first": f.first, "last": f.last, "families": set(), "down": 0,
                                             "ti": sorted((b.ext.get(f.cp) or {}).get("ti", ()))})
            a["n"] += f.n
            a["rules"][f.rule.name] += f.n
            a["families"].add(f.rule.family)
            a["first"] = min(a["first"], f.first)
            a["last"] = max(a["last"], f.last)
            a["down"] += f.down
        top = sorted(att.values(), key=lambda a: -a["n"])[:40]
        out["target"] = {**(summary or {}), "attackers_list": [
            {**a, "rules": a["rules"].most_common(3), "families": sorted(a["families"]),
             "verdict": b.entities[a["ip"]].verdict if a["ip"] in b.entities else None} for a in top],
            "attackers_total": len(att)}
    if h_f:
        out["hygiene"] = [{"rule": f.rule.name, "family": f.rule.family, "cp": f.cp, "port": f.port, "n": f.n,
                           "first": f.first, "last": f.last} for f in sorted(h_f, key=lambda f: -f.n)[:30]]
    if x:
        out["external"] = {"ti": sorted(x["ti"]), "asn": ev.asn_label(x["asn"], x["country"]),
                           "in_hosts": sorted(x["in_hosts"])[:60], "out_hosts": sorted(x["out_hosts"])[:60],
                           "rules": x["rules"].most_common(6), "n": x["n"], "first": x["first"], "last": x["last"],
                           "up": x["up"], "down": x["down"]}
    ti = getattr(b, "target_inc", {}).get(ip)
    if ti is not None and not e:
        out["target_inc"] = {"verdict": ti.verdict, "headline": ti.headline, "reason": ti.reason,
                             "attackers": ti.attackers, "ti": ti.ti, "answered": ti.answered, "first": ti.first,
                             "last": ti.last, "port": ti.port}
        out["triage"] = ev.overlay(ti, tri)
    out["heat"] = heatmap(b, ip, store, catalog, nets)
    out["alerts"], out["alerts_total"] = newest_alerts(rows, ip, total=sum(x[-3] for x in buckets)
                                                       if buckets is not None else None)
    out["alert_groups"] = alert_groups(rows, ip, buckets=buckets)
    out["net"] = getattr(b, "netnames", {}).get(ip)
    out["audit"] = store.audit(ip, 30, full) if store else []
    out["timeline"] = timeline(store, ip, full=full)
    return out


ACTION_WORDS = {"step:done": "checked a step", "step:undone": "unchecked a step",
                "record:ack": "saw an incident that had ended", "record:tp": "closed an ended incident as a true positive",
                "record:benign": "closed an ended incident as benign",
                "record:fp": "closed an ended incident as a false positive",
                "record:resolved": "resolved an ended incident", "record:open": "put an ended incident back as not reviewed",
                "record:investigating": "took an ended incident", "record:escalated": "escalated an ended incident",
                "triage:ack": "acknowledged", "triage:fp": "marked false positive", "triage:resolved": "resolved",
                "triage:investigating": "took it (investigating)", "triage:open": "reopened",
                "story:ack": "acknowledged a story", "story:fp": "marked a story false positive",
                "story:resolved": "resolved a story", "story:investigating": "took a story (investigating)",
                "story:open": "reopened a story", "story:tp": "closed a story as a true positive",
                "story:benign": "closed a story as benign", "story:escalated": "escalated a story", "hosts:ack": "acknowledged hosts of an incident",
                "hosts:fp": "marked hosts of an incident false positive",
                "hosts:resolved": "resolved hosts of an incident",
                "hosts:investigating": "took hosts of an incident (investigating)",
                "hosts:open": "reopened hosts of an incident", "exception:add": "added an exception",
                "exception:remove": "removed an exception", "triage:tp": "closed it as a true positive",
                "triage:benign": "closed it as benign", "triage:escalated": "escalated it",
                "triage:undo": "undid the last action", "hosts:tp": "closed hosts of an incident as true positives",
                "hosts:benign": "closed hosts of an incident as benign", "hosts:escalated": "escalated hosts of an incident",
                "hosts:undo": "undid an action on hosts of an incident", "comment": "noted",
                "webhook:failed": "a webhook delivery failed",
                "exception:propose": "proposed an exception", "exception:approve": "approved an exception",
                "exception:reject": "rejected an exception", "exception:expire": "ended exceptions that were no longer needed",
                "exception:edit": "changed a silence rule", "exception:extend": "extended a silence rule",
                "silence:expired": "a silence rule expired", "silence:first-hit": "a silence rule silenced it for the first time",
                "silence:spike": "a silence rule is hiding a spike",
                # the administrator's side (Configuration tab) and the service's own lines
                "crown:add": "marked a host as a crown jewel", "crown:remove": "removed a crown jewel mark",
                "crown:import": "loaded crown jewels from the critical hosts file",
                "profile:freeze": "froze the learned profile", "profile:unfreeze": "unfroze the learned profile",
                "profile:override": "set a learned value by hand", "profile:internal": "marked an address as inside or outside",
                "catalog:set": "changed a rule of the catalog", "config:draft": "saved a configuration draft",
                "config:import": "imported a configuration as a draft", "config:publish": "published a configuration",
                "config:rollback": "rolled the configuration back", "config:file": "loaded the configuration from its file",
                "suggestion:answer": "answered a configuration suggestion", "suggestion:accept": "accepted a suggestion",
                "suggestion:reject": "rejected a suggestion", "lookup:changed": "the Sycope lookup changed",
                "backup:restored": "restored the state database from a backup",
                "backup:unchecked": "started on a state database that could not be checked",
                "scoring:migrate": "moved the clusters to the current scoring model"}
SCOPE_RE = re.compile(r"^(s:(act|investigate|review|watch):[A-Za-z0-9+-]{1,180}|c:[0-9a-fA-F.:]{3,45}/\d{1,3}|sel)$")


def timeline(store, ip: str, limit: int = 120, full: bool = False) -> list[dict]:
    """The host's history: the system's decisions and the analysts' actions, newest first."""
    if not store:
        return []
    out = [{"at": r["at"], "who": "system", "kind": r["kind"], "verdict": r["verdict"], "prev": r["prev"],
            "text": r["reason"] or "", "conf": r["conf"], "detail": r["detail"]} for r in store.verdict_history(ip)]
    for a in store.audit(ip, limit, full):
        d = a.get("detail") or {}
        text = ACTION_WORDS.get(a["action"], a["action"])
        if a["action"] == "triage:investigating" and d.get("owner") and d["owner"] != a["who"]:
            text = f"assigned it to {d['owner']}"
        elif a["action"] == "triage:escalated" and d.get("owner"):
            text = f"escalated it to {d['owner']}"
        elif a["action"] == "triage:undo" and "restored" in d:
            text = f"undid the last action: back to {STATUS.get(d['restored'], d['restored']) if d['restored'] else 'New'}"
        if d.get("reason"):
            text += f" ({d['reason']})"
        out.append({"at": a["at"], "who": a["who"], "kind": "action", "action": a["action"], "text": text,
                    "note": a.get("note") or "", "story": d.get("story"), "detail": d, "verified": a.get("verified")})
    out.sort(key=lambda x: -x["at"])
    return out[:limit]


def group_history(store, scope: str, legacy_key: str | None = None, limit: int = 60) -> list[dict]:
    """The analysts' actions on a group incident as a whole (a story or a campaign), newest first."""
    if not store:
        return []
    out = []
    for a in store.audit_scope(scope, legacy_key, limit):
        d = a.get("detail") or {}
        out.append({"at": a["at"], "who": a["who"], "action": a["action"], "note": a.get("note") or "",
                    "hosts": d.get("hosts"), "text": ACTION_WORDS.get(a["action"], a["action"]),
                    "verified": a.get("verified")})
    return out


def parents(b: ev.Board, ip: str) -> dict:
    """Where a host sits: its story (group incident) and the campaign around it, for the page's breadcrumb."""
    out: dict = {}
    e = b.entities.get(ip)
    if e and e.story and e.story in b.stories:
        s = b.stories[e.story]
        out["story"] = {"key": s["key"], "title": s["title"], "count": s["count"], "verdict": s["verdict"]}
    net = next((c for c in b.campaigns if ip in (c.get("members") or ())), None)
    if net and (not out.get("story") or _story_in(b.stories[e.story], net)):
        out["campaign"] = {"net": net["net"], "hosts": len(net.get("members") or ()), "verdict": net["verdict"]}
    return out


def _story_in(s: dict, c: dict) -> bool:
    mem = set(c.get("members") or ())
    return 2 * sum(1 for m in s["members"] if m in mem) >= len(s["members"])


def story_detail(b: ev.Board, key: str, triage: dict, store=None, pcap: dict | None = None) -> dict | None:
    s = b.stories.get(key)
    if not s:
        return None
    pcap = pcap or {}
    members = [b.entities[ip] for ip in s["members"]]
    out = story_item(b, s, triage)
    out["members"] = [host_item(b, m, triage.get(m.ip)) for m in members[:500]]
    for m in out["members"]:
        m["pcap"] = pcap.get(m["ip"])
    out["pcap_hosts"] = sum(1 for m in s["members"] if (pcap.get(m) or {}).get("done"))
    camp = next((c for c in b.campaigns if _story_in(s, c)), None)
    out["campaign"] = {"net": camp["net"], "verdict": camp["verdict"]} if camp else None
    out["history"] = group_history(store, "s:" + key, key)
    # the scope: networks, crown jewels, the outside counterparts the hosts talked to
    out["all_nets"] = Counter(prefix(m.ip) for m in members).most_common(12)
    out["crown_hosts"] = [m.ip for m in members if m.crown][:20]
    outside: dict[str, set] = defaultdict(set)
    for m in members:
        for f in m.findings:
            if f.cp and f.bits >= b.params["confirm_bits"] and f.cp in b.ext:
                outside[f.cp].add(m.ip)
    out["outside"] = [{"ip": ip, "hosts": len(hs), "ti": sorted((b.ext.get(ip) or {}).get("ti", ())),
                       "asn": ev.asn_label((b.ext.get(ip) or {}).get("asn"), (b.ext.get(ip) or {}).get("country"))}
                      for ip, hs in sorted(outside.items(), key=lambda kv: -len(kv[1]))[:8]]
    out["chain_words"] = [{"id": c, "title": ev.CHAINS[c][0], "what": ev.CHAINS[c][2]} for c in out["chains"]]
    # the shared path: the families most members confirmed, in their usual order
    order = Counter()
    for m in members:
        steps, _ = ev.narrative(m, b.names, b.params)
        for i, st in enumerate(s for s in steps if s["confirmed"]):
            order[(i, st["family"])] += 1
    path, seen = [], set()
    for (i, fam), n in sorted(order.items(), key=lambda kv: (kv[0][0], -kv[1])):
        if fam not in seen and n >= max(2, len(members) // 4):
            path.append({"family": fam, "label": FAMILIES[fam][0], "hosts": n})
            seen.add(fam)
    out["path"] = path[:6]
    targets = Counter(f.cp for m in members for f in m.findings if f.cp and f.bits >= b.params["confirm_bits"])
    out["common_targets"] = targets.most_common(8)
    return out


def campaign_detail(b: ev.Board, net: str, triage: dict, store=None, pcap: dict | None = None,
                    order: str = "stage") -> dict | None:
    """A campaign page: its summary, its child incidents (stories and single hosts) and every host in it."""
    c = next((c for c in b.campaigns if c["net"] == net), None)
    if not c:
        return None
    _built, camps = incidents(b, triage, pcap)
    if net not in camps:
        return None
    item, kids = camps[net]
    kids = list(kids)
    _sort(kids, order, b.now * 1000, b.params)
    out = dict(item)
    out["children"] = kids
    ips = []
    for x in kids:
        ips.extend(b.stories[x["key"]]["members"] if x["type"] == "story" else [x["ip"]])
    hosts = [host_item(b, b.entities[ip], triage.get(ip)) for ip in ips if ip in b.entities]
    for h in hosts:
        h["pcap"] = (pcap or {}).get(h["ip"])
    _sort(hosts, order, b.now * 1000, b.params)
    out["hosts"] = hosts[:1000]
    out["chain_words"] = [{"id": k, "title": ev.CHAINS[k][0], "what": ev.CHAINS[k][2]} for k in out["chains"]]
    out["all_nets"] = Counter(prefix(ip) for ip in ips).most_common(16)
    out["history"] = group_history(store, "c:" + net)
    return out


def ti_backed(rule) -> bool:
    """A finding backed by a threat list: any rule of the threat-intel family (CL-01, in any class), any rule that names
    a threat-list category (TOR, anonymous proxy, botnet domain...) and class A."""
    return rule.family == "CL-01" or bool(rule.ti) or rule.cls == "A"


def _protected_labels(rule) -> set[str]:
    """Why a rule, in any direction it can be seen in, is one whose exceptions need a second person: a threat-intel
    match (class A), or a credential, exfiltration or C2 family (the family a variant resolves to counts, e.g. SMB
    going out is exfiltration)."""
    out = set()
    for r in (rule, *(rule.for_direction(d) for d in DIRECTIONS)):
        if ti_backed(r):
            out.add("threat intelligence match")
        if r.family in PROTECTED_FAMILIES:
            out.add(FAMILIES[r.family][0].lower())
    return out


def exception_scope(b: ev.Board | None, catalog: Catalog | None, kind: str, rule: str | None, server: str | None,
                    port: str | None, actor: str | None) -> dict:
    """What an exception would take the weight off, on the board now (the last 24 hours), found with the matcher the
    scoring uses, and what that means for who may add it: findings, hosts, alerts, how many hosts are at Act now or
    Investigate, the protected reasons (it needs a second person) and whether it is big (it needs an admin).
    The server decides with this at creation and again at approval; the dialog shows the same numbers."""
    cand = {"kind": kind, "rule": rule or "*", "server": server, "port": port or "", "actor": actor}
    hosts, alerts, findings, act = set(), 0, 0, set()
    why: set[str] = set()
    if kind == "host" or not rule or rule == "*":
        why.add("every alert family of the host" if kind != "service" else "every rule on that server")
    elif catalog is not None:
        r = catalog.rules.get(rule)
        if r is not None:
            why |= _protected_labels(r)
    for ip, e in (b.entities.items() if b else ()):
        for f in e.findings:
            if ev._exception_for(f, [cand]) is None:
                continue
            hosts.add(ip)
            alerts += f.n
            findings += 1
            if e.verdict in ("act", "investigate"):
                act.add(ip)
            if ti_backed(f.rule) or f.family == "CL-01":
                why.add("threat intelligence match")
            if f.family in PROTECTED_FAMILIES:
                why.add(FAMILIES[f.family][0].lower())
    p = b.params if b is not None else FACTORY
    max_alerts, max_hosts = int(p["exception.big_alerts"]), int(p["exception.big_hosts"])
    return {"hosts": len(hosts), "alerts": alerts, "findings": findings, "act_or_investigate": len(act),
            "sample": sorted(hosts)[:8], "protected": sorted(why), "second": bool(why),
            "big": alerts > max_alerts or len(hosts) > max_hosts,
            "limits": {"alerts": max_alerts, "hosts": max_hosts}}


def silence_scope(b: ev.Board | None, catalog: Catalog | None, f: dict, matches: list[tuple]) -> dict:
    """exception_scope for a silence rule: what the rule would take over the whole window, from the buckets it matches
    (`matches`: (alert name, client, server, port, alerts, first alert id, hour), Window.scan). Same shape as
    exception_scope, plus the alert names it would silence (the busiest first) and the reasons of a second person: a
    credential, exfiltration, C2 or threat-intelligence rule among them, an address wider than /24 (v6 /64), no alert
    name at all, or a big preview."""
    hosts, act, pairs = set(), set(), set()
    alerts = 0
    names: Counter = Counter()
    why: set[str] = set(silence.wide_reasons(f))
    if not f.get("rule"):
        why.add("every alert family of the matched hosts")
    for name, client, server, port, n, _aid, _hour in matches:
        alerts += n
        names[name] += n
        pairs.add((client, server, name, port))
        for ip in (client, server):
            if b is not None and ip and (ip in b.entities or ip in b.target_f):
                hosts.add(ip)
                e = b.entities.get(ip)
                if e is not None and e.verdict in ("act", "investigate"):
                    act.add(ip)
    for name in names:
        r = catalog.rules.get(name) if catalog is not None else None
        if r is not None:
            why |= _protected_labels(r)
    p = b.params if b is not None else FACTORY
    max_alerts, max_hosts = int(p["exception.big_alerts"]), int(p["exception.big_hosts"])
    return {"hosts": len(hosts), "alerts": alerts, "findings": len(pairs), "act_or_investigate": len(act),
            "sample": sorted(hosts)[:8], "protected": sorted(why), "second": bool(why),
            "big": alerts > max_alerts or len(hosts) > max_hosts,
            "limits": {"alerts": max_alerts, "hosts": max_hosts},
            "names": [{"name": k, "alerts": v} for k, v in names.most_common(6)]}


def _silence_fields(body: dict, catalog: Catalog) -> dict:
    """The fields of a silence rule from a request: cleaned, known alert name, the shape guard rails."""
    try:
        f = silence.clean(body)
        silence.check_shape(f)
    except silence.RuleError as exc:
        raise ActionError(str(exc)) from None
    if f["rule"] and f["rule"] not in catalog.rules and f["rule"] not in catalog.unknown():
        raise ActionError("unknown alert name")
    return f


def _silence_days(body: dict) -> int:
    if body.get("days") in (None, ""):
        raise ActionError(f"choose how long it lasts (1 to {silence.MAX_DAYS} days, {silence.DEFAULT_DAYS} by default)")
    try:
        days = int(body["days"])
    except (TypeError, ValueError):
        raise ActionError("days must be a number") from None
    if not 1 <= days <= silence.MAX_DAYS:
        raise ActionError(f"a silence rule lasts 1 to {silence.MAX_DAYS} days: it is renewed on purpose, never forever")
    return days


def _big_text(scope: dict) -> str:
    lim = scope["limits"]
    return (f"this exception would cover {scope['alerts']:,} alerts and {scope['hosts']:,} hosts in the last 24 hours "
            f"(more than {lim['alerts']:,} alerts or {lim['hosts']:,} hosts)")


def exception_preview(b: ev.Board, kind: str, rule: str | None, server: str | None, port: str | None,
                      actor: str | None, catalog: Catalog | None = None) -> dict:
    """The dialog's view of exception_scope, shown before the analyst saves it."""
    return exception_scope(b, catalog, kind, rule, server, port, actor)


_HEAT = {"hot": "exposure high", "warm": "exposure medium", "service": "a busy service", "noted": "exposure low"}


def search(b: ev.Board, store, q: str, limit: int = 8) -> dict:
    """One search over everything the analyst can open: the incidents now, every host with alerts, the targets,
    the outside addresses and the history. An IP finds itself and what it is part of, a network (CIDR) its hosts and
    campaigns, a word host names, incident titles and rule names."""
    q = (q or "").strip()[:100]
    out: dict = {"q": q, "groups": []}
    if len(q) < 2:
        return out
    ql = q.lower()
    ip = net = None
    try:
        ip = str(ipaddress.ip_address(q))
    except ValueError:
        if "/" in q:
            try:
                net = ipaddress.ip_network(q, strict=False)
            except ValueError:
                net = None

    def hit(addr: str) -> bool:
        if ip:
            return addr == ip
        if net:
            try:
                return ipaddress.ip_address(addr) in net
            except ValueError:
                return False
        return addr.startswith(q) or ql in (b.names.get(addr) or "").lower()

    def host_row(e: ev.Entity, why: str = "") -> dict:
        return {"key": "h:" + e.ip, "label": e.ip + (f" ({b.names[e.ip]})" if b.names.get(e.ip) else ""),
                "sub": why or e.headline, "verdict": e.verdict}

    groups = []
    words = not (ip or net)
    inc, seen = [], set()
    if ip and ip in b.entities:   # an address: the host itself first, then what it is part of
        e = b.entities[ip]
        groups.append({"name": "This host", "rows": [host_row(e)], "more": 0})
        seen.add(ip)
    # incidents on the board: hosts, groups of hosts, campaigns
    for c in b.campaigns:
        if (ip or net) and any(hit(m) for m in c.get("members") or ()) or (words and ql in c["net"]):
            inc.append({"key": "c:" + c["net"], "label": f"Campaign in {c['net']}", "sub": fmt.plural(c['hosts'], "host"),
                        "verdict": c["verdict"]})
    for key, st in b.stories.items():
        if st["verdict"] == "watch":
            continue
        inside = [m for m in st["members"] if hit(m)] if (ip or net) else []
        if inside or (words and ql in st["title"].lower()):
            inc.append({"key": "s:" + key, "label": st["title"], "verdict": st["verdict"],
                        "sub": fmt.plural(st['count'], "host") + (f", with {inside[0]}" if inside else "")})
    for ip_, ti in getattr(b, "target_inc", {}).items():
        if hit(ip_) or (words and ql in ti.headline.lower()):
            row = {"key": "h:" + ip_, "label": ip_ + (f" ({b.names[ip_]})" if b.names.get(ip_) else ""),
                   "sub": ti.headline, "verdict": ti.verdict}
            if ip and ip_ == ip and not groups:
                groups.append({"name": "This host", "rows": [row], "more": 0})
            else:
                inc.append(row)
            seen.add(ip_)
    hosts = sorted((e for e in b.entities.values() if hit(e.ip) or (words and ql in (e.headline or "").lower())),
                   key=lambda e: (-ev.VRANK[e.verdict], -e.risk))
    for e in hosts:
        if e.verdict != "watch" and not e.story and e.ip not in seen:
            inc.append(host_row(e))
            seen.add(e.ip)
    inc.sort(key=lambda x: -ev.VRANK.get(x["verdict"], 0))
    if inc:
        groups.append({"name": "Part of" if ip else "Incidents now", "rows": inc[:limit],
                       "more": max(0, len(inc) - limit)})
    rest = [host_row(e, ("in a group: " + b.stories[e.story]["title"]) if e.story and e.story in b.stories
                     else "") for e in hosts if e.ip not in seen]
    if words and len(rest) < limit:   # a rule name: the hosts whose evidence has it
        named = {e.ip for e in hosts}
        for e in sorted(b.entities.values(), key=lambda e: (-ev.VRANK[e.verdict], -e.risk)):
            if e.ip not in named and any(ql in f.rule.name.lower() for f in e.findings):
                rule = next(f.rule.name for f in e.findings if ql in f.rule.name.lower())
                rest.append(host_row(e, f"{rule} · {e.headline}"))
                if len(rest) > 3 * limit:
                    break
    if rest:
        groups.append({"name": "Hosts with alerts", "rows": rest[:limit], "more": max(0, len(rest) - limit)})
    tg = [t for t in b.targets if hit(t["ip"])] if not words or len(ql) >= 3 else []
    if tg:
        groups.append({"name": "Under attack", "more": max(0, len(tg) - limit), "rows": [
            {"key": "h:" + t["ip"], "label": t["ip"] + (f" ({t['name']})" if t.get("name") else ""),
             "sub": f"{fmt.plural(t['attackers'], 'attacker')} · {_HEAT.get(t['heat'], t['heat'])}", "verdict": None}
            for t in tg[:limit]]})
    xs = [x for x in b.externals if hit(x["ip"]) or (words and ql in (x.get("asn_label") or "").lower())]
    if xs:
        groups.append({"name": "Outside addresses", "more": max(0, len(xs) - limit), "rows": [
            {"key": "h:" + x["ip"], "label": x["ip"], "verdict": None,
             "sub": " · ".join(p for p in (", ".join(x.get("ti") or []), x.get("asn_label"), x.get("rating")) if p)}
            for x in xs[:limit]]})
    if store is not None:
        rows, total = store.history_query(0, q=ip or (str(net) if net else q), limit=limit)
        if rows:
            groups.append({"name": "History", "more": max(0, total - len(rows)), "rows": [
                {"key": f"i:{r['id']}", "label": r["headline"] or r["label"], "verdict": r["verdict_peak"],
                 "sub": f"#{r['id']} · " + ("active" if r["status"] == "open" else "ended")
                 + (f" · {r['outcome']}" if r.get("outcome") else ""), "at": r["opened_at"]} for r in rows]})
    out["groups"] = groups
    return out


SUGGEST_MIN, SUGGEST_SHARE = 3, 0.8


def suggestions(b: ev.Board, triage: dict) -> dict:
    """Feedback-driven suppression, without learning: where the team keeps closing the same thing as a false
    positive or benign, say so and offer the exception (the analyst still decides, with the preview). A service: one
    rule to one server:port on hosts the team closed (3 or more, 80% or more of the hosts that have it). A rule: closed
    on 80% or more of the hosts that have it, 5 or more: a rule to tune in Sycope."""
    closed = {ip: t for ip, t in triage.items() if t["status"] in ("fp", "benign")}
    if not closed:
        return {"services": [], "rules": []}
    by_sig: dict[tuple, set] = defaultdict(set)
    by_rule: dict[str, set] = defaultdict(set)
    for ip, e in b.entities.items():
        for f in e.findings:
            if f.excepted or f.bits <= 0:
                continue
            by_rule[f.rule.name].add(ip)
            server = f.subject if f.as_server else f.cp
            if server and f.kind != "scan":
                by_sig[(f.rule.name, server, f.port or "")].add(ip)
    covered = [x for x in b.tuning["exceptions"] if x["kind"] == "service"]

    def stats(hosts: set) -> dict:
        cl = sorted(h for h in hosts if h in closed)
        reasons = Counter(closed[h].get("reason") for h in cl if closed[h].get("reason"))
        return {"hosts": len(hosts), "closed": len(cl), "fp": sum(1 for h in cl if closed[h]["status"] == "fp"),
                "benign": sum(1 for h in cl if closed[h]["status"] == "benign"), "rate": len(cl) / max(1, len(hosts)),
                "reasons": reasons.most_common(2), "sample": cl[:5]}

    services = []
    for (rule, server, port), hosts in by_sig.items():
        st = stats(hosts)
        if st["closed"] < SUGGEST_MIN or st["rate"] < SUGGEST_SHARE:
            continue
        if any(x["rule"] in (rule, "*") and x["server"] == server and (x["port"] or "") in ("", port) for x in covered):
            continue
        services.append({"rule": rule, "server": server, "port": port, **st})
    rules = []
    for rule, hosts in by_rule.items():
        st = stats(hosts)
        if st["closed"] >= 5 and st["rate"] >= SUGGEST_SHARE:
            rules.append({"rule": rule, **st})
    services.sort(key=lambda x: (-x["closed"], -x["rate"]))
    rules.sort(key=lambda x: (-x["closed"], -x["rate"]))
    return {"services": services[:20], "rules": rules[:10]}


def lane(b: ev.Board, name: str, limit: int = 200) -> dict:
    if name == "targets":
        ti = getattr(b, "target_inc", {})
        rows = [{**t, "incident": ti[t["ip"]].verdict if t["ip"] in ti else None} for t in b.targets[:limit]]
        return {"rows": rows, "total": len(b.targets), "in_queue": len(ti),
                "heat": dict(Counter(t["heat"] for t in b.targets))}
    if name == "external":
        rows = [x for x in b.externals if x["rating"] != "context"]
        return {"rows": rows[:limit], "total": len(rows), "context": len(b.externals) - len(rows),
                "rating": dict(Counter(x["rating"] for x in b.externals))}
    if name == "hygiene":
        return {"rows": b.hygiene, "hosts": b.counts["hygiene_hosts"]}
    if name == "tuning":
        rules = sorted(b.rule_stats.values(), key=lambda r: -r["alerts"])
        return {"services": b.tuning["services"], "exceptions": b.tuning["exceptions"], "rules": rules,
                "alerts": b.alerts, "explained": b.counts["explained"], "unknown": b.unknown_rules}
    raise KeyError(name)


# ---- actions ----------------------------------------------------------------------------------------------------

def act(body: dict, b: ev.Board | None, store, catalog: Catalog, approval: bool = False, scan=None) -> dict:
    """One analyst action. Raises ActionError with a message for the page. approval: exceptions from analysts wait
    for an admin (SC_EXCEPTION_APPROVAL); the page says who is an admin, from the Sycope login. `scan(fields)`: the
    window's buckets a silence rule with those fields would take (Live passes Window.scan; None: nothing matched)."""
    if not isinstance(body, dict):
        raise ActionError("send a JSON object")
    op = body.get("op")
    who = _clean_text(body.get("who"), 40) or "analyst"
    note = _clean_text(body.get("note"), 500)
    if op == "restore":
        return _restore(body, b, store, who, note)
    if op == "comment":
        return _comment(body, store, who)
    if op == "step":
        return _step_check(body, store, who)
    if op == "record":
        return _record_review(body, store, who, note)
    if op in ("triage", "story", "hosts"):
        status = body.get("status")
        if status not in ACTION_STATUSES:
            raise ActionError("status must be one of: " + ", ".join(ACTION_STATUSES))
        owner = _clean_text(body.get("owner"), 40) or None
        if status == "investigating" and not owner:
            owner = who
        if status == "escalated" and not owner:
            owner = "L2"
        if status not in ("investigating", "escalated"):
            owner = None
        reason = _clean_text(body.get("reason"), 80) or None
        if reason and status in REASONS and reason not in REASONS[status]:
            raise ActionError("unknown reason for " + STATUS[status])
        group = None   # the line for the group as a whole; each host also gets its own line
        if op == "triage":
            ips, scope = [_ip(body.get("ip"))], None
        elif op == "story":
            s = (b.stories.get(str(body.get("key") or "")) if b else None)
            if not s:
                raise ActionError("no such story on the board (it may have changed: refresh)")
            ips, scope = list(s["members"]), s["key"]
            group = (who, f"story:{status}", s["title"], note, {"key": s["key"], "hosts": len(ips)})
        else:
            # the hosts the analyst saw and chose, named one by one: the scope of a bulk action is never implicit
            raw = body.get("ips")
            if not isinstance(raw, list) or not raw:
                raise ActionError("ips must be a non-empty list of hosts")
            if len(raw) > 2000:
                raise ActionError("at most 2000 hosts in one action")
            ips = list(dict.fromkeys(_ip(x) for x in raw))
            scope = str(body.get("scope") or "sel")
            if not SCOPE_RE.match(scope):
                raise ActionError("scope must be s:<story key>, c:<network> or sel")
            label = _clean_text(body.get("label"), 200) or scope
            group = (who, f"hosts:{status}", label, note, {"scope": scope, "hosts": len(ips)})
        before = store.triage()
        previous = [{"ip": ip, **{k: before[ip].get(k) for k in ("status", "who", "note", "fingerprint", "verdict",
                                                                 "owner", "reason")}}
                    if ip in before else {"ip": ip, "status": None} for ip in ips]
        writes = []
        for ip in ips:
            e = (b.entities.get(ip) or b.target_inc.get(ip)) if b else None
            writes.append((ip, None if status == "open" else (status, who, note, e.fingerprint if e else [],
                                                              e.verdict if e else "watch", owner, reason),
                           (who, f"triage:{status}", ip, note, {"verdict": e.verdict if e else None,
                                                                "fingerprint": e.fingerprint if e else [],
                                                                "story": scope, "owner": owner, "reason": reason})))
        if group:
            group[4].update(owner=owner, reason=reason)
        store.triage_many(writes, group)   # one transaction: an incident of 250 hosts is one write
        return {"ok": True, "op": op, "status": status, "hosts": len(ips), "previous": previous}
    if op == "exception-add" and body.get("kind") == "silence":
        return _silence_add(body, b, store, catalog, approval, scan, who)
    if op == "exception-edit":
        return _silence_edit(body, b, store, catalog, approval, scan, who)
    if op == "exception-extend":
        return _silence_extend(body, b, store, catalog, scan, who)
    if op == "exception-add":
        kind = body.get("kind")
        if kind not in ("service", "host-rule", "host"):
            raise ActionError("kind must be service, host-rule, host or silence")
        reason = _clean_text(body.get("reason"), 300)
        if not reason:
            raise ActionError("say why (the reason is kept in the audit log)")
        if body.get("days") in (None, ""):
            raise ActionError("choose how long it lasts: " + ", ".join(str(d) for d in EXC_DAYS) + " days")
        try:
            days = int(body["days"])
        except (TypeError, ValueError):
            raise ActionError("days must be a number") from None
        if days not in EXC_DAYS:
            raise ActionError(f"an exception lasts {', '.join(str(d) for d in EXC_DAYS[:-1])} or {EXC_DAYS[-1]} days "
                              f"at most")
        rule = _clean_text(body.get("rule"), 120) or None
        if rule and rule != "*" and rule not in catalog.rules and rule not in catalog.unknown():
            raise ActionError("unknown alert name")
        server = actor = port = None
        if kind == "service":
            if not rule:
                raise ActionError("a known service needs the alert name")
            server = _ip(body.get("server"))
            port = str(body.get("port") or "").strip()
            if port and not (port.isdigit() and 0 < int(port) < 65536):
                raise ActionError("port must be 1-65535")
        else:
            actor = _ip(body.get("actor"))
            if kind == "host-rule" and not rule:
                raise ActionError("an allowed behaviour needs the alert name")
        # what it would cover decides who may add it (the server, not the dialog): a big one needs an admin, a
        # credential, exfiltration, C2 or threat-intel one needs a second person even with approval off
        admin = body.get("admin") is True
        verified = admin or body.get("verified") is True      # the service sets both from the Sycope pass, never the page
        if b is None and not admin:
            raise ActionError("the board is not ready yet: try again in a moment")
        scope = exception_scope(b, catalog, kind, rule, server, port or None, actor)
        if scope["big"] and not admin:
            raise ActionError(_big_text(scope) + ": an admin adds it")
        second = scope["second"]
        if second and not verified:
            raise ActionError("this exception needs two people Sycope has confirmed (" + ", ".join(scope["protected"])
                              + "): reload the page inside Sycope so it can confirm who you are, then propose it again")
        # an identity nobody confirmed only proposes: a verified person decides (principle 5: it needs a human)
        pending = second or not verified or (approval and not admin)
        ex_id = store.add_exception(kind, rule, server, port or None, actor, reason, who, days, pending=pending,
                                    second=second, verified=verified)
        target = server or actor or ""
        store.log(who, "exception:propose" if pending else "exception:add", target, reason,
                  {"id": ex_id, "kind": kind, "rule": rule, "server": server, "port": port, "actor": actor,
                   "days": days, "pending": pending, "second_person": second, "protected": scope["protected"],
                   "alerts": scope["alerts"], "hosts": scope["hosts"], "verified": verified})
        return {"ok": True, "op": op, "id": ex_id, "rescore": not pending, "pending": pending,
                "second_person": second, "unverified": not verified}
    if op == "exception-decide":
        try:
            ex_id = int(body.get("id"))
        except (TypeError, ValueError):
            raise ActionError("id must be a number") from None
        decision = body.get("decision")
        if decision not in EXC_DECISIONS:
            raise ActionError("decision must be approve or reject")
        row = store.pending_exception(ex_id)
        if row is None:
            raise ActionError("no such exception waiting for approval")
        admin = body.get("admin") is True
        if b is None and not admin:
            raise ActionError("the board is not ready yet: try again in a moment")
        scope = (silence_scope(b, catalog, row, scan(row) if scan else [])
                 if row["kind"] == "silence" else
                 exception_scope(b, catalog, row["kind"], row["rule"], row["server"], row["port"], row["actor"]))
        # a verified user decides; an admin when approval is on, and always for a second-person or a big exception
        if not (admin or body.get("verified") is True):
            raise ActionError("Sycope has not confirmed who you are: reload the page inside Sycope, then decide")
        if (approval or row.get("second") or scope["second"] or scope["big"]) and not admin:
            raise ActionError("only an admin approves or rejects an exception")
        # "another person" compares confirmed identities: a proposal nobody confirmed has none, any confirmed user is another
        if decision == "approve" and row.get("verified") and (row["who"] or "").casefold() == who.casefold():
            raise ActionError("a second person approves it: you proposed this exception yourself")
        # a proposal nobody confirmed may not become a second-person exception (it turned protected after it was made,
        # or it predates the check): without a confirmed proposer there is no first person to be second to
        if decision == "approve" and not row.get("verified") and (row.get("second") or scope["second"]):
            raise ActionError("this exception needs two confirmed people: reject it and propose it again from Sycope")
        r = store.decide_exception(ex_id, decision == "approve", who, note)
        if r is None:
            raise ActionError("no such exception waiting for approval")
        store.log(who, f"exception:{decision}", r["server"] or r["actor"] or r.get("dst") or r.get("src") or "", note,
                  {"id": ex_id, "proposed_by": row["who"], "proposer_verified": bool(row.get("verified")), "second_person": bool(row.get("second") or scope["second"]),
                   "alerts": scope["alerts"], "hosts": scope["hosts"], **r})
        return {"ok": True, "op": op, "id": ex_id, "rescore": decision == "approve"}
    if op == "exception-remove":
        try:
            ex_id = int(body.get("id"))
        except (TypeError, ValueError):
            raise ActionError("id must be a number") from None
        if not store.remove_exception(ex_id, who):
            raise ActionError("no such active exception")
        row = store.exception(ex_id) or {}
        store.log(who, "exception:remove", str(ex_id), note, {"id": ex_id, "kind": row.get("kind"),
                                                              "rule": silence.describe(row) if row else None})
        return {"ok": True, "op": op, "id": ex_id, "rescore": True}
    raise ActionError("unknown op")


def _restore(body: dict, b, store, who: str, note: str) -> dict:
    """Undo: put back the states a just-made action replaced (the page sends them back, as the action returned)."""
    rows = body.get("rows")
    if not isinstance(rows, list) or not rows or len(rows) > 2000:
        raise ActionError("rows must be a list of up to 2000 hosts")
    writes = []
    for r in rows:
        if not isinstance(r, dict):
            raise ActionError("each row is an object")
        ip, st = _ip(r.get("ip")), r.get("status")
        if st is None:
            state = None
        elif st in STATUS:
            fp = r.get("fingerprint") or []
            if not isinstance(fp, list) or len(fp) > 60 or not all(isinstance(x, str) and len(x) <= 12 for x in fp):
                raise ActionError("bad fingerprint")
            verdict = r.get("verdict") if r.get("verdict") in ev.VERDICTS else "watch"
            state = (st, _clean_text(r.get("who"), 40) or who, _clean_text(r.get("note"), 500), fp, verdict,
                     _clean_text(r.get("owner"), 40) or None, _clean_text(r.get("reason"), 80) or None)
        else:
            raise ActionError("unknown status in a row")
        writes.append((ip, state, (who, "triage:undo", ip, note, {"restored": st, "story": body.get("scope")
                                                                 if isinstance(body.get("scope"), str)
                                                                 and SCOPE_RE.match(body["scope"]) else None})))
    scope = body.get("scope") if isinstance(body.get("scope"), str) and SCOPE_RE.match(body["scope"]) else None
    group = (who, "hosts:undo", _clean_text(body.get("label"), 200) or "hosts", note,
             {"scope": scope, "hosts": len(writes)}) if scope else None
    store.triage_many(writes, group)
    return {"ok": True, "op": "restore", "hosts": len(writes)}


def _record_review(body: dict, store, who: str, note: str) -> dict:
    """Seen, closed, taken or escalated on an incident that ended with nobody having looked at it (its record, by
    id); status "open" puts it back as not reviewed (undo, release)."""
    from sycope_clusters import history  # history imports this module
    try:
        rec = int(body.get("rec"))
    except (TypeError, ValueError):
        raise ActionError("rec must be the number of an incident record") from None
    status = body.get("status")
    if status not in ("ack", *CLOSED, "investigating", "escalated", "open"):
        raise ActionError("status must be one of: ack, " + ", ".join(CLOSED) + ", investigating, escalated, open")
    owner = _clean_text(body.get("owner"), 40) or None
    reason = _clean_text(body.get("reason"), 80) or None
    if reason and status in REASONS and reason not in REASONS[status]:
        raise ActionError("unknown reason for " + STATUS[status])
    try:
        r = history.review(store, rec, status, who, note, reason, owner=owner)
    except ValueError as exc:
        raise ActionError(str(exc)) from None
    kind, value = r["subject"].split(":", 1)
    key = r["ui_key"] or ""
    store.log(who, f"record:{status}", value if kind == "ip" else (r["label"] or key), note,
              {"incident": rec, "reason": reason, "owner": owner,
               "scope": key if key[:2] in ("s:", "c:") else None})
    prev = r["previous"]["outcome"]
    return {"ok": True, "op": "record", "rec": rec, "status": status,
            "previous": "open" if prev in (None, "expired") else prev, "previous_owner": r["previous_owner"]}


def _step_check(body: dict, store, who: str) -> dict:
    """A next step checked (done) or unchecked on an open incident record, or on one that ended quiet; the audit log
    and the incident's own history get a line."""
    try:
        rec = int(body.get("rec"))
    except (TypeError, ValueError):
        raise ActionError("rec must be the number of an open incident") from None
    step = _clean_text(body.get("step"), 160)
    if not step:
        raise ActionError("step is required")
    title = _clean_text(body.get("title"), 300) or step
    done = body.get("done", True) is not False
    o = store.incident(rec, product="triage")      # a Clusters incident is not found here
    from sycope_clusters import history  # history imports this module
    if not o or not history.workable(o):
        raise ActionError("this incident is not open any more: refresh the page")
    key = o.get("ui_key") or ""
    # a host's step kept under its group incident still goes into the host's own timeline
    ip = _ip(body["ip"]) if body.get("ip") else None
    target = ip or (key[2:] if key.startswith("h:") else key or str(rec))
    store.set_step(rec, step, done, who, title, (who, "step:done" if done else "step:undone", target, title,
                                                 {"incident": rec, "step": step,
                                                  "scope": key if key[:2] in ("s:", "c:") else None}))
    return {"ok": True, "op": "step", "rec": rec, "step": step, "done": done, "title": title}


def _comment(body: dict, store, who: str) -> dict:
    """A note on an incident without changing its state: in its history and in the audit log."""
    target = str(body.get("target") or "")
    text = _clean_text(body.get("text"), 1000)
    if not text:
        raise ActionError("write the note")
    kind, _, value = target.partition(":")
    if kind == "h":
        store.log(who, "comment", _ip(value), text, {})
    elif kind == "s" and SCOPE_RE.match(target):
        store.log(who, "comment", _clean_text(body.get("label"), 200) or value, text, {"scope": target})
    elif kind == "c":
        try:
            net = str(ipaddress.ip_network(value, strict=False))
        except ValueError:
            raise ActionError("not a network") from None
        store.log(who, "comment", "campaign " + net, text, {"scope": "c:" + net})
    else:
        raise ActionError("target must be h:<ip>, s:<story> or c:<network>")
    return {"ok": True, "op": "comment", "target": target}


def stage_name(i: int | None) -> str:
    return STAGES[i] if i is not None else "none"


def activity(store, limit: int = 40, full: bool = False) -> list[dict]:
    """The team's recent actions; a story's hosts are one line (their own entries stay in each host's history).
    `full`: an admin reads the note and detail of configuration lines too."""
    rows = store.audit(limit=limit * 10, full=full)
    return [r for r in rows if not (r.get("detail") or {}).get("story")][:limit]


# ---- silence rules (1.4): the actions behind POST /action -------------------------------------------------------------

def _silence_gate(f: dict, b, catalog, scan, body: dict, approval: bool) -> tuple[dict, bool, bool, bool]:
    """(scope, second, verified, admin) of a rule about to be added or changed: what it would take decides who may."""
    admin = body.get("admin") is True
    verified = admin or body.get("verified") is True      # set by the service from the Sycope pass, never the page
    if b is None and not admin:
        raise ActionError("the board is not ready yet: try again in a moment")
    scope = silence_scope(b, catalog, f, scan(f) if scan else [])
    if scope["big"] and not admin:
        raise ActionError(_big_text(scope) + ": an admin adds it")
    return scope, scope["second"], verified, admin


def _silence_add(body: dict, b, store, catalog: Catalog, approval: bool, scan, who: str) -> dict:
    reason = _clean_text(body.get("reason"), 300)
    if not reason:
        raise ActionError("say why (the reason is kept in the audit log)")
    days = _silence_days(body)
    f = _silence_fields(body, catalog)
    scope, second, verified, admin = _silence_gate(f, b, catalog, scan, body, approval)
    if second and not verified:
        raise ActionError("this rule needs two people Sycope has confirmed (" + ", ".join(scope["protected"])
                          + "): reload the page inside Sycope so it can confirm who you are, then propose it again")
    pending = second or not verified or (approval and not admin)
    ex_id = store.add_exception("silence", f["rule"], None, f["port"], None, reason, who, days, pending=pending,
                                second=second, verified=verified, src=f["src"], dst=f["dst"], proto=f["proto"],
                                win_days=f["win_days"], win_from=f["win_from"], win_to=f["win_to"])
    store.log(who, "exception:propose" if pending else "exception:add", f["dst"] or f["src"] or f["rule"] or "", reason,
              {"id": ex_id, "kind": "silence", "rule": f["rule"], "fields": silence.describe({**f, "kind": "silence"}),
               "days": days, "pending": pending, "second_person": second, "protected": scope["protected"],
               "alerts": scope["alerts"], "hosts": scope["hosts"], "verified": verified})
    return {"ok": True, "op": "exception-add", "id": ex_id, "rescore": not pending, "pending": pending,
            "second_person": second, "unverified": not verified}


def _silence_edit(body: dict, b, store, catalog: Catalog, approval: bool, scan, who: str) -> dict:
    try:
        ex_id = int(body.get("id"))
    except (TypeError, ValueError):
        raise ActionError("id must be a number") from None
    row = store.exception(ex_id)
    if row is None or row["kind"] != "silence" or not (row["active"] or row["pending"]):
        raise ActionError("no such silence rule in force or waiting for approval")
    reason = _clean_text(body.get("reason"), 300)
    if not reason:
        raise ActionError("say why (the reason is kept in the audit log)")
    days = _silence_days(body) if body.get("days") not in (None, "") else None
    f = _silence_fields(body, catalog)
    scope, second, verified, admin = _silence_gate(f, b, catalog, scan, body, approval)
    needs = second or not verified or (approval and not admin)
    if needs and row["active"] and not row["pending"]:
        raise ActionError("this change needs a second person (" + (", ".join(scope["protected"]) or "an unconfirmed "
                          "identity or the approval setting") + "): remove this rule and propose the new one instead")
    before = store.edit_exception(ex_id, f, reason, who, days)
    if before is None:
        raise ActionError("no such silence rule in force or waiting for approval")
    store.log(who, "exception:edit", f["dst"] or f["src"] or f["rule"] or str(ex_id), reason,
              {"id": ex_id, "was": silence.describe(before), "now": silence.describe({**f, "kind": "silence"}),
               "days": days, "alerts": scope["alerts"], "hosts": scope["hosts"]})
    return {"ok": True, "op": "exception-edit", "id": ex_id, "rescore": bool(row["active"] and not row["pending"])}


def _silence_extend(body: dict, b, store, catalog: Catalog, scan, who: str) -> dict:
    try:
        ex_id = int(body.get("id"))
    except (TypeError, ValueError):
        raise ActionError("id must be a number") from None
    row = store.exception(ex_id)
    if row is None or row["kind"] != "silence" or not row["active"] or row["pending"]:
        raise ActionError("no such silence rule in force")
    days = _silence_days(body)
    admin = body.get("admin") is True
    if not (admin or body.get("verified") is True):
        raise ActionError("Sycope has not confirmed who you are: reload the page inside Sycope, then extend it")
    if not admin:    # a rule that needed a second person (or an admin) is renewed by an admin, as it was approved
        scope = silence_scope(b, catalog, row, scan(row) if scan else [])
        if row.get("second") or scope["second"] or scope["big"]:
            raise ActionError("this rule needed a second person to approve it: an admin extends it")
    before = store.extend_exception(ex_id, days, who)
    if before is None:
        raise ActionError("no such silence rule in force")
    store.log(who, "exception:extend", str(ex_id), _clean_text(body.get("note"), 500),
              {"id": ex_id, "days": days, "was_expires": before.get("expires"), "rule": silence.describe(before)})
    return {"ok": True, "op": "exception-extend", "id": ex_id, "rescore": True}
