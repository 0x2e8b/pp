"""The Sycope look, copied from sycope_recorder (src/sycope_recorder/pages.py, v0.4b4) so both tools match.

Copied, not imported: the recorder is a separate product. Keep in step by hand: CSS tokens, logo, fonts, the
(i) tooltip, menu and time scripts. Only the logo's product name differs ("Security Triage", set after a thin separator).
"""

from __future__ import annotations

import base64
from pathlib import Path

_CSS = """
:root{--bg:#060725;--panel:#20213f;--panel2:#2d2e55;--head:#50516a;--head2:#616179;--row:#2d2e55;--hover:#37385e;
--line:#20213f;--hsep:#20213f;--hline:#808297;--fg:#fff;--mut:#97a1ba;--blue:#1c48f7;--blue2:#2330cf;--bar:#276edb;--cube:#d44ad8;--nul:#808297;
--green:#00a01a;--orange:#ff7a00;--red:#e0122d;--ink:#222957;--pop:#3a3c6e;
--ok:#3ecf72;--okbg:#14382a;--warn:#ff8a3d;--warnbg:#4a2a18;--bad:#ff5d5d;--badbg:#4a1d28;--info:#0f8bfd;--infobg:#17325a}
*{box-sizing:border-box}
html{background:#08092b}body{margin:0;min-height:100vh;background:linear-gradient(270.34deg,#060725 .33%,#090a30 99.74%) fixed;color:var(--fg);font:14px/1.4 "Kumbh Sans",-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
button,input,select,textarea{font-family:inherit}
a{color:var(--info);text-decoration:none}a:hover{text-decoration:underline}
code,.mono{font-family:"Roboto Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px}
.top{position:relative;z-index:70;display:flex;align-items:center;gap:14px;padding:0 16px 0 22px;height:48px;background:var(--panel)}
/* Scrollbars as in Sycope dark mode (its styles.css): thin grey thumb on a muted track, wider on hover. The bar keeps
   one width (a bar that widens on hover narrows the content next to it, which then reflows and jumps); the thumb
   looks wider on hover by dropping its transparent border. Firefox gets scrollbar-color only: in Chrome the
   standard property would switch the ::-webkit-scrollbar rules off. */
::-webkit-scrollbar{background:transparent;width:10px;height:10px}
::-webkit-scrollbar-thumb{background:rgb(143,143,157);background-clip:padding-box;border:1px solid transparent;border-radius:2px}
*:hover::-webkit-scrollbar-thumb{border-width:0}
::-webkit-scrollbar-track{background:rgb(75,75,99);border-radius:2px}::-webkit-scrollbar-corner{background:rgb(75,75,99)}
@supports (-moz-appearance:none){*{scrollbar-width:thin;scrollbar-color:rgb(143,143,157) rgb(75,75,99)}}
.logo{display:inline-flex;align-items:center;gap:10px;line-height:1}.logo:hover{text-decoration:none}.logo svg{height:26px;width:auto;margin-top:4px}.logo .lname{font-size:20px;font-weight:400;color:#fff}.logo .lsep{align-self:center;width:1px;height:24px;margin:0 4px;background:#ffffff40}
.top .sub{color:var(--mut)}.top .sp{flex:1}
.tzsw{display:inline-flex;align-items:center;gap:8px;white-space:nowrap;flex:none}.tzseg{display:inline-flex;border:1px solid var(--head);border-radius:4px;overflow:hidden}
.tzb{font:inherit;line-height:1.35;color:var(--mut);background:transparent;border:0;padding:2px 9px;cursor:pointer}.tzb+.tzb{border-left:1px solid var(--head)}
.tzb:hover{background:var(--panel2);color:var(--fg)}.tzb[aria-pressed=true]{background:var(--blue);color:#fff;cursor:default}
.rf{margin:0}.rf button{display:flex;align-items:center;justify-content:center;width:36px;height:34px;padding:0;background:var(--blue);color:#fff;border:0;border-radius:3px;cursor:pointer}
.rf button:hover{background:#3a62ff}
.rfg{position:relative;display:flex;align-items:center;gap:0}.rfg .rf button{border-radius:3px 0 0 3px}
.menu{position:relative}.menu summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:center;width:36px;height:36px;border-radius:4px;background:none;color:#e6e8f0}
.menu summary::-webkit-details-marker{display:none}.menu summary:hover{background:var(--panel2)}
.menup{position:absolute;right:0;top:40px;z-index:20;min-width:200px;display:flex;flex-direction:column;background:var(--panel2);border:1px solid var(--pop);border-radius:5px;padding:6px;box-shadow:0 6px 24px #0008}
.menup a{padding:7px 12px;border-radius:4px;color:var(--fg)}.menup a.cur{background:var(--blue);color:#fff}.menup a:hover{background:var(--head);text-decoration:none}
.dot{display:inline-block;width:11px;height:11px;border-radius:50%;background:var(--mut)}.dot.ok{background:var(--ok)}.dot.warn{background:var(--warn)}.dot.fail{background:var(--bad)}.dot.unknown{background:var(--mut)}
.sysgrid{display:grid;grid-template-columns:180px 1fr;gap:6px 16px;align-items:start}.sysgrid h2{margin:6px 0}
.warnbox{background:var(--warnbg);border:1px solid var(--warn);border-radius:6px;padding:8px 12px;margin-bottom:8px}
.info{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px;margin-left:4px;border:1px solid var(--mut);border-radius:50%;color:var(--mut);font:italic 700 10px Georgia,serif;cursor:help;vertical-align:middle;text-transform:none}
.info:hover,.info:focus{color:#fff;border-color:var(--info);outline:0}
#tip{position:fixed;z-index:50;display:none;max-width:420px;padding:10px 12px;background:var(--bg);border:1px solid var(--info);border-radius:6px;box-shadow:0 6px 24px #000a;color:var(--fg);font:12px/1.5 inherit;font-weight:400;white-space:pre-line;text-transform:none;letter-spacing:0}
.rfd{display:inline-block}.rfg summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:center;width:30px;height:34px;background:var(--blue2);color:#fff;border-radius:0 3px 3px 0}
.rfg summary::-webkit-details-marker{display:none}.rfg summary:hover{background:#2c3ce0}
.rfp{position:absolute;right:0;top:34px;z-index:20;display:flex;align-items:center;gap:12px;white-space:nowrap;background:var(--bg);border:1px solid var(--line);border-radius:6px;padding:14px 18px;box-shadow:0 6px 24px #0008}
.rfp input[type=number],.rfp select{background:var(--panel2);color:var(--fg);border:1px solid var(--line);border-radius:5px;padding:6px 8px;font:inherit}
.rfp input[type=number]{width:64px}
.sw{position:relative;display:inline-block;width:42px;height:22px}.sw input{opacity:0;width:0;height:0}
.sw span{position:absolute;inset:0;border-radius:22px;background:var(--head);cursor:pointer;transition:.15s}
.sw span::before{content:"";position:absolute;left:3px;top:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.15s}
.sw input:checked+span{background:var(--blue)}.sw input:checked+span::before{transform:translateX(20px)}
.rfst{color:var(--mut);font-size:12px}
.wrap{max-width:1680px;margin:0 auto;padding:16px 32px}
.card{background:var(--panel);border:0;border-radius:5px;padding:16px;margin-bottom:16px}
.card.s-done{border-left:4px solid var(--ok)}.card.s-queued,.card.s-running{border-left:4px solid var(--warn)}
.card.s-miss,.card.s-failed{border-left:4px solid var(--bad)}.card.s-cancelled{border-left:4px solid var(--mut)}.card.s-unknown{border-left:4px solid var(--mut)}
h1{font-size:18px;margin:0 0 8px;font-weight:600}h2{font-size:13px;margin:0 0 8px;color:var(--mut);text-transform:uppercase;letter-spacing:.6px}
.mut{color:var(--mut)}.null{color:var(--nul)}
.ftag{font:12px "Roboto Mono",monospace;color:var(--mut)}
.badge{color:#fff;background:#3a3c6e;display:inline-flex;align-items:center;height:20px;padding:0 8px;border-radius:3px;border:0;font:400 12px/1 "Roboto Mono",ui-monospace,Menlo,monospace;text-transform:uppercase;white-space:nowrap}
.b-done{color:#fff;background:var(--green)}
.b-queued,.b-running,.b-retry,.b-redelivered,.b-window{color:var(--ink);background:var(--orange)}
.b-miss{color:var(--ink);background:#e5a823}
.b-failed{color:#fff;background:var(--red)}
.b-cancelled{color:#fff;background:var(--head)}
.b-critical{color:#fff;background:#9c1237}
.b-high{color:#fff;background:var(--red)}
.b-medium{color:var(--ink);background:var(--orange)}
.b-low{color:var(--ink);background:#e5c100}
.b-info{color:#fff;background:var(--bar)}
.dl{display:inline-flex;align-items:center;height:20px;padding:0 8px;border-radius:3px;background:var(--green);color:#fff;white-space:nowrap}
.dl:hover{background:#12b42c;text-decoration:none}
.dlbig{display:inline-block;padding:10px 20px 9px;border-radius:5px;background:var(--blue);color:#fff;line-height:1}
.dlbig:hover{background:#3a62ff;text-decoration:none}
.b-unknown{color:var(--mut);background:var(--panel2);border-color:var(--line)}
.hits{position:absolute;top:8px;right:8px;z-index:3;background:var(--green);color:#fff;border-radius:3px;padding:2px 6px;font-size:12px;line-height:1.2;pointer-events:none}
.chips{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 10px}
.chip{display:inline-flex;align-items:center;height:33px;padding:0 14px;border-radius:5px;background:var(--panel2);border:1px solid transparent;color:var(--fg)}
.chip.on{background:var(--blue);border-color:var(--blue);color:#fff}.chip:hover{text-decoration:none;background:var(--head)}
.grid{overflow-x:auto}
.pv>input[type=radio]{position:absolute;opacity:0;pointer-events:none}
.pv-bar{margin:0 0 10px;justify-content:space-between}.pv-bar label.chip{cursor:pointer}
#pv-1:checked~.pv-bar label[for=pv-1],#pv-2:checked~.pv-bar label[for=pv-2]{background:var(--blue);border-color:var(--blue);color:#fff}
#pv-1:focus-visible~.pv-bar label[for=pv-1],#pv-2:focus-visible~.pv-bar label[for=pv-2]{outline:2px solid var(--info)}
.cfg-bar{margin:0 0 10px;justify-content:flex-end}
#pv-1:checked~.pv-syc,#pv-2:checked~.pv-pcap{display:none}
.pv-cap{margin:0 0 8px}
table{border-collapse:collapse;width:100%;min-width:760px}
th{background:var(--head);color:#fff;text-align:left;font-weight:400;font-size:12px;height:40px;padding:0 10px;white-space:nowrap;border-left:1px solid var(--hsep);border-bottom:1px solid var(--hline);position:sticky;top:0;z-index:3}
td{padding:8px 10px;font-size:12px;border-top:1px solid var(--line);border-left:1px solid var(--line);vertical-align:top;background:var(--row)}
th:first-child,td:first-child{border-left:0}
tr:hover td{background:var(--hover)}
.tpk{display:flex;align-items:center;height:36px;padding:0 4px 0 2px;border-radius:5px;background:var(--panel2)}
.tpk .dd.tlr>summary{height:36px;gap:8px;padding:0 8px;background:none;border:0}.tpk .dd.tlr>summary:hover{background:var(--head)}
.tpk .cal{color:#fff;flex:none}.tld{display:flex;flex-direction:column;font-size:13px;line-height:15px;letter-spacing:.2px}
.tclr{display:flex;align-items:center;justify-content:center;width:24px;height:24px;color:#e9ebf3;font-size:18px}.tclr:hover{color:#fff;text-decoration:none}
.dd.tlr .mi.off{opacity:.35;pointer-events:none}
.tcus{display:flex;flex-direction:column;gap:8px;padding:4px 10px 8px}.tcus label{display:flex;flex-direction:column;gap:3px;font-size:12px;color:var(--mut)}
.tcus input{color-scheme:dark}
.toast{position:fixed;top:60px;right:20px;z-index:60;display:flex;align-items:center;gap:10px;max-width:460px;padding:12px 14px;border-radius:5px;background:var(--panel2);border-left:4px solid var(--green);box-shadow:0 6px 24px #000a;transition:opacity .3s}
.toast.out{opacity:0}.toast .tk{color:var(--green)}.toast .tx{margin-left:auto;background:none;border:0;color:var(--mut);font-size:18px;cursor:pointer}.toast .tx:hover{color:#fff}
.c-kb{justify-content:center;padding:0!important}.kb{width:28px;height:26px;border:0;border-radius:4px;background:none;color:#e9ebf3;font-size:18px;line-height:1;cursor:pointer}.kb:hover{background:var(--head)}
.kmenu{position:fixed;z-index:65;min-width:190px}.kmenu[hidden]{display:none}
.rxb{display:inline-flex;align-items:center;height:16px;margin-left:6px;padding:0 5px;border-radius:3px;background:#3a3c6e;color:#dadce6;font-size:10px;flex:none}
dialog.modal{width:min(680px,94vw);padding:0;border:0;border-radius:5px;background:var(--panel);color:var(--fg);box-shadow:0 12px 48px #000c}
dialog.modal::backdrop{background:rgba(6,7,37,.72)}
.modal .mh{display:flex;align-items:center;justify-content:space-between;padding:16px 20px 0}.modal .mh .ct{margin:0}
.modal .tx{background:none;border:0;color:var(--mut);font-size:20px;cursor:pointer}.modal .tx:hover{color:#fff}
.modal .mb{padding:4px 20px 8px;max-height:70vh;overflow:auto}.modal h4{margin:16px 0 8px;font-size:14px;font-weight:500}
.modal .mf{display:flex;justify-content:flex-end;gap:10px;padding:14px 20px;border-top:1px solid var(--line)}
.rxrow{display:flex;flex-wrap:wrap;align-items:flex-end;gap:12px;margin:8px 0}.rxrow label{display:flex;flex-direction:column;gap:4px;font-size:12px;color:var(--mut)}
.rxrow input[type=number]{width:120px}.rxq{display:flex;gap:6px}.rxq button,.lnk{background:var(--panel2);border:0;border-radius:5px;color:var(--fg);padding:6px 10px;font-size:12px;cursor:pointer}.rxq button:hover,.lnk:hover{background:var(--head)}
.rxr{display:flex;align-items:center;gap:8px;margin:6px 0;font-size:13px}.rxr code{color:var(--mut)}
.rxh{display:flex;gap:8px;align-items:center;margin:6px 0}.rxh input{flex:1}
.rxp{padding:10px 12px;border-radius:5px;background:var(--panel2);font:12px/1.6 "Roboto Mono",monospace;overflow-wrap:anywhere}.rxp.bad{color:#ff8b98}.rxp .warn{font-family:inherit}
.btn-pri{background:var(--blue);color:#fff;border:0;border-radius:5px;padding:9px 18px;cursor:pointer}.btn-pri:hover{background:#3a62ff}.btn-pri:disabled{background:#1a318e;color:#9899b3;cursor:default}
.btn-sec{background:var(--panel2);color:#fff;border:0;border-radius:5px;padding:9px 18px;cursor:pointer}.btn-sec:hover{background:var(--head)}
.fchips{display:flex;flex-wrap:wrap;gap:6px}.fchip{display:inline-flex;align-items:center;height:33px;border-radius:5px;background:var(--blue);color:#fff;font-size:12px;line-height:1.1;overflow:hidden}
.fchip .fced{display:flex;align-items:center;height:100%;padding:0;border:0;background:none;color:#fff;font:inherit;cursor:pointer}.fchip .fced:hover{background:var(--blue2)}
.fadd{width:33px;height:33px;border:0;border-radius:5px;background:var(--panel2);color:#fff;font-size:20px;line-height:1;cursor:pointer}.fadd:hover{background:var(--head)}
.fpop{position:fixed;z-index:66;width:340px;display:flex;flex-direction:column;gap:10px;padding:16px;border-radius:5px;background:#090a30;border:1px solid var(--pop);box-shadow:0 10px 36px #000c}.fpop[hidden]{display:none}
.fpop select,.fpop input[type=text]{width:100%;height:36px}.fp-n{font-size:12px;color:var(--mut);text-align:right}
.fp-list{flex:1 1 auto;min-height:60px;max-height:300px;overflow:auto;display:flex;flex-direction:column;gap:2px}
.fp-it{display:grid;grid-template-columns:22px 1fr auto;align-items:center;gap:4px 10px;padding:6px 6px;border-radius:4px;cursor:pointer}.fp-it:hover{background:var(--panel)}
.fp-it .bar{grid-column:2/4;height:4px;border-radius:2px;background:#1c1d3b}.fp-it .bar i{display:block;height:100%;border-radius:2px;background:var(--blue)}
.fp-it span.v{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.fp-it span.p{font-size:12px;color:var(--mut)}
.fp-foot{display:flex;justify-content:flex-end;gap:10px;border-top:1px solid var(--line);padding-top:12px}
.fchip .fk{padding:0 6px 0 10px;opacity:.85}.fchip .fvv{padding:0 4px;font-family:"Roboto Mono",monospace}.fchip a{display:flex;align-items:center;height:100%;padding:0 9px;color:#fff;font-size:16px}.fchip a:hover{background:var(--blue2);text-decoration:none}
a.fv{color:inherit}a.fv:hover{text-decoration:underline dotted}
.acts{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:4px 0 12px}
.bact{display:inline-flex;align-items:center;height:33px;padding:0 16px;border:0;border-radius:5px;background:var(--blue);color:#fff;font:inherit;font-size:13px;line-height:1;white-space:nowrap;cursor:pointer}
.bact:hover{background:#3a62ff;text-decoration:none}.bact.red{background:var(--red)}.bact.red:hover{background:#f02a43}
.chiprow{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px}.chiprow .chips{flex:1;margin:0}
.tlctl{display:flex;align-items:center;gap:8px}.dd.tlr .ddp{left:auto;right:0;min-width:240px}.dd.tlr .mi b{display:inline-block;width:34px;font-weight:400;font-family:"Roboto Mono",monospace;font-size:12px;color:var(--mut)}
.dd.tlr>summary{gap:10px}.tlp{display:inline-flex;align-items:center;height:20px;padding:0 6px;border-radius:3px;background:#d3dae6;color:var(--panel);font:12px/1 "Roboto Mono",monospace}.tls{font-size:12px;line-height:1.15}
.tlbtn{display:inline-flex;align-items:center;justify-content:center;width:33px;height:33px;border-radius:5px;background:var(--panel2);color:var(--fg);font-size:18px}.tlbtn:hover{background:var(--head);text-decoration:none}
.tlnav.off,.tlbtn.off{opacity:.3;cursor:default}
.tl{flex-basis:100%;display:flex;align-items:stretch;height:190px;margin-top:14px}
.tlnav{flex:none;width:26px;display:flex;align-items:center;justify-content:center;color:var(--mut);font-size:28px;line-height:1}.tlnav:hover{color:#fff;text-decoration:none}
.tly{flex:none;width:44px;position:relative}.tlyl{position:absolute;left:0;top:50%;transform:translateY(-50%) rotate(180deg);writing-mode:vertical-rl;font-size:12px;color:var(--mut)}
.tlp2{flex:1;position:relative;border-bottom:1px solid var(--hline);cursor:crosshair;user-select:none}
.tlg i{position:absolute;left:0;right:0;font-style:normal;border-top:1px solid rgba(255,255,255,.08)}.tlg b{position:absolute;right:100%;margin-right:8px;transform:translateY(-50%);font-weight:400;font-size:11px;color:var(--mut)}
.tlb{position:absolute;inset:0;display:flex;align-items:flex-end;gap:2px}.tlb div{flex:1;background:var(--bar)}.tlb div:hover{background:#4a8af0}.tlb div.z{background:transparent}
.brush{position:absolute;top:0;bottom:0;display:none;background:rgba(15,139,253,.2);border:1px solid var(--info);pointer-events:none}
.tlx{flex-basis:100%;position:relative;height:18px;margin:5px 26px 0 70px}.tlx span{position:absolute;transform:translateX(-50%);font-size:11px;color:var(--mut);white-space:nowrap}
.tlcap{flex-basis:100%;font-size:11px;margin-top:2px}
.jhead>span[draggable=true]{cursor:grab}.jhead>span.drag{opacity:.45}.jhead>span.dropl{box-shadow:inset 3px 0 var(--info)}.jhead>span.dropr{box-shadow:inset -3px 0 var(--info)}
.msg{margin:6px 0 0;font-size:14px}.warn{color:var(--warn)}
.jobs{overflow:auto;max-height:calc(100vh - 150px);min-height:240px}
.jhead{position:sticky;top:0;z-index:6}
.jhead,.job summary{display:grid;grid-template-columns:var(--cols);gap:0;align-items:stretch;min-width:var(--minw);padding:0}
.jhead>span,.job summary>span{position:relative;display:flex;align-items:center;min-width:0;min-height:30px;padding:0 10px;border-left:1px solid var(--line);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.job summary>span>.ell{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;min-width:0}
.jhead>span:first-child,.job summary>span:first-child{border-left:0}
.jhead{background:var(--head);color:#fff;border-bottom:1px solid var(--hline)}.jhead>span{flex-direction:column;justify-content:center;align-items:flex-start;min-height:48px;padding:5px 10px;border-left-color:var(--hsep);overflow:visible}
.jhead .hl{display:block;font-weight:400;font-size:13px;line-height:17px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.jhead .fld{display:block;font-size:11px;line-height:14px;color:#dadce6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.rsz{position:absolute;top:0;right:-4px;width:8px;height:100%;cursor:col-resize;z-index:2}.rsz:hover,.rsz.on{background:linear-gradient(90deg,transparent 3px,var(--info) 3px,var(--info) 5px,transparent 5px)}
body.resizing{cursor:col-resize;user-select:none}
.jhead a{color:inherit}.jhead a:hover{text-decoration:underline}.jhead .arr{color:var(--info);font-size:10px}
.jhead>span.c-sel,.job summary>span.c-sel{flex-direction:row;align-items:center;justify-content:flex-start;gap:8px;padding-left:12px}
.fpop input[type=checkbox]{width:20px!important;height:20px!important}
.jobs input[type=checkbox],.dd input[type=checkbox],.selbar input[type=checkbox],.fpop input[type=checkbox]{-webkit-appearance:none;appearance:none;width:20px;height:20px;border:2px solid rgba(255,255,255,.2);border-radius:5px;background:var(--panel2);cursor:pointer;position:relative;flex:none;margin:0}
.jobs input[type=checkbox]:checked,.dd input[type=checkbox]:checked,.selbar input[type=checkbox]:checked,.fpop input[type=checkbox]:checked{background:var(--blue);border-color:var(--blue)}
.jobs input[type=checkbox]:checked::after,.dd input[type=checkbox]:checked::after,.selbar input[type=checkbox]:checked::after,.fpop input[type=checkbox]:checked::after{content:"";position:absolute;left:5px;top:1px;width:4px;height:9px;border:solid #fff;border-width:0 2px 2px 0;transform:rotate(45deg)}
.dd input[type=checkbox]:disabled{opacity:.5;cursor:default}
.tools{display:flex;align-items:center;gap:12px;margin:0 0 10px;flex-wrap:wrap}.tools .sp{flex:1}
.dd{position:relative}
.dd>summary{list-style:none;cursor:pointer;display:flex;align-items:center;gap:12px;height:33px;padding:0 12px;border:1px solid transparent;border-radius:5px;background:var(--panel2);color:var(--fg);font-size:14px;white-space:nowrap}
.dd>summary::-webkit-details-marker{display:none}.dd>summary:hover{background:var(--head)}
.dd.act>summary{background:#1a318e;color:#9899b3;gap:0;padding:0}.dd.act>summary .al{padding:0 20px 0 22px}.dd.act>summary .chev{box-sizing:content-box;padding:0 12px;border-left:1px solid #112473;height:33px;background:#18287d;border-radius:0 5px 5px 0}
.dd.act>summary.on{background:var(--blue);color:#fff}.dd.act>summary.on .chev{background:var(--blue2);border-left-color:#1a26a8}
.chev{flex:none;opacity:.85}
.ddp{position:absolute;left:0;top:36px;z-index:30;min-width:200px;max-height:70vh;overflow:auto;display:flex;flex-direction:column;background:var(--panel2);border:1px solid var(--pop);border-radius:5px;padding:6px;box-shadow:0 6px 24px #0008}
.dd.cols .ddp,.dd.views .ddp,.dd.gear .ddp{left:auto;right:0}
.mi{display:flex;align-items:center;gap:8px;padding:7px 10px;border-radius:4px;color:var(--fg);background:none;border:0;font:inherit;text-align:left;cursor:pointer;white-space:nowrap}
.mi:hover{background:var(--head);text-decoration:none}.mi:disabled{color:var(--mut);cursor:default;background:none}
.mi.del:not(:disabled){color:#ff7b86}.mi.cur{font-weight:700;cursor:default}
.gh{padding:6px 10px 2px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--mut)}
.vrow{justify-content:space-between}.vrow a{color:var(--fg);flex:1}
.vx{background:none;border:0;color:var(--mut);cursor:pointer;font-size:16px;line-height:1}.vx:hover{color:var(--bad)}
.srch{position:relative;display:flex;align-items:center;margin:0}.srch .lupa{position:absolute;left:12px;width:18px;height:18px;color:var(--mut);pointer-events:none}
.srch input[type=search]{height:33px;width:236px;padding:0 30px 0 40px;border:1px solid transparent;border-radius:5px;background:var(--panel2);color:var(--fg);font:inherit;font-size:14px}.srch input::placeholder{color:var(--mut)}
.srch input[type=search]:focus{outline:0;border-color:var(--info)}.srch input[type=search]::-webkit-search-cancel-button{display:none}
.srch .clr{position:absolute;right:9px;color:var(--mut);font-size:16px;line-height:1}
.vh{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
.dd.gear>summary{width:33px;padding:0;justify-content:center;color:#e9ebf3}
.selbar{display:flex;align-items:center;gap:14px;padding:6px 12px;margin:0 0 8px;background:var(--panel2);border:1px solid var(--line);border-radius:5px}
.selbar[hidden]{display:none}
.job:has(.row-chk:checked){background:linear-gradient(0deg,rgba(15,139,253,.25),rgba(15,139,253,.25)),var(--row)}
.job{border-bottom:1px solid var(--line);background:var(--row)}
.job summary{cursor:pointer;list-style:none}.job summary::-webkit-details-marker{display:none}
.job summary:hover{background:var(--hover)}.job[open]>summary{background:var(--hover)}
.caret{flex:none;width:0;height:0;border-left:6px solid var(--mut);border-top:5px solid transparent;border-bottom:5px solid transparent;transition:transform .1s}
.job[open] .caret{transform:rotate(90deg);border-left-color:var(--info)}
.more{padding:10px 14px 14px 36px;border-top:1px solid var(--line);background:var(--panel)}
.kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:8px 18px;margin:0 0 12px}
.more h3{font-size:12px;margin:10px 0 6px;color:var(--mut);text-transform:uppercase;letter-spacing:.6px}
.nm{font-weight:400}
.kv>.desc{min-width:0}.kv>.desc[open]{grid-column:1/-1}
.desc>summary,.job .desc>summary{display:block;min-width:0;padding:0;background:none!important;cursor:pointer;list-style:none;font-size:12px;color:var(--mut)}
.desc>summary::-webkit-details-marker{display:none}.desc>summary::before{content:"\\25B8";display:inline-block;width:14px;color:var(--info)}.desc[open]>summary::before{content:"\\25BE"}
.desc>summary:hover{color:var(--info)}.desc p{margin:6px 0 0;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;max-width:110ch;color:var(--fg);text-transform:none;letter-spacing:0;font-size:13px}
.kv .mut{display:block;font-size:12px}
.kv code{overflow-wrap:anywhere}.empty{padding:14px;color:var(--mut)}
.sel-count{color:var(--mut);font-size:12px}
.sel-opt{font-size:12px;color:var(--mut);display:flex;align-items:center;gap:4px;cursor:pointer}
.btn-del{background:var(--red);color:#fff;border:0;border-radius:5px;padding:7px 14px;font-size:12px;cursor:pointer}
.btn-del:hover{background:#f02a43}
input[type=file]{color:var(--mut)}input[type=file]::file-selector-button{background:var(--panel2);color:var(--fg);border:0;border-radius:5px;padding:6px 12px;margin-right:8px;cursor:pointer}input[type=file]::file-selector-button:hover{background:var(--head)}
input[type=text],input[type=password],input[type=number],select,textarea{background:var(--panel2);color:var(--fg);border:1px solid transparent;border-radius:5px;padding:6px 8px;font:inherit}
input[type=text]:focus,input[type=password]:focus,input[type=number]:focus,select:focus,textarea:focus{outline:0;border-color:var(--info)}
.star-f{display:inline;margin:0;padding:0}
.star-btn{background:none;border:0;color:var(--mut);font-size:14px;cursor:pointer;padding:0 3px;line-height:1;vertical-align:middle}
.star-btn:hover,.star-btn.on{color:#ffd700}
.b-persistent{color:#ffd700;background:#423812;border-color:#8a7522}
.pbar{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:10px 4px 0;font-size:12px;color:var(--mut)}.pbar .recs{margin-left:auto;color:var(--info)}
.pbar a{padding:2px 8px;border-radius:5px;border:1px solid var(--line);background:var(--panel2);color:var(--fg)}
.pbar a.on{background:var(--blue);border-color:var(--blue);color:#fff}
.pbar a:hover{text-decoration:none;border-color:var(--info)}
.pbar .dim{color:var(--nul);padding:2px 8px}
.pbar .sizes{display:flex;align-items:center;gap:6px}
.pbar .pages{display:flex;align-items:center;gap:4px}
.ptitle{font-size:22px;font-weight:400;margin:2px 0 14px}
.ct{font-size:17px;font-weight:500;margin:0 0 14px;color:#fff;text-transform:none;letter-spacing:0}
.cth{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}.cth .ct{margin:0}
.srow{display:grid;grid-template-columns:1.6fr 1fr 1.6fr;gap:8px;margin-bottom:8px}.srow .card{margin:0}
.st{font:12px "Roboto Mono",monospace;white-space:nowrap}.st-ok{color:var(--green)}.st-warn{color:var(--orange)}.st-fail{color:var(--red)}.st-unk{color:var(--nul)}
.tiles{display:flex;align-items:flex-start;justify-content:center;gap:10px;margin-top:6px}.tiles em{font-style:normal;color:var(--mut);margin-top:12px}
.tiles div{display:flex;flex-direction:column;align-items:center;gap:8px}.tiles b{display:inline-flex;align-items:center;justify-content:center;min-width:42px;height:42px;padding:0 6px;border-radius:3px;background:var(--green);font-weight:400;font-size:24px}
.tiles span{font-size:12px;color:var(--fg)}.tilecap{text-align:center;margin-top:12px;font-size:12px}
.res{display:grid;grid-template-columns:1fr 48px;align-items:center;gap:6px 12px;margin-bottom:14px}.res h4{grid-column:1/-1;margin:0;font-size:14px;font-weight:500}
.rd{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:8px;background:var(--blue)}.rd.m{background:#6f7fa8}.rd.c{background:#00bff8}
.rp{text-align:right;font-size:13px}
.ubar{height:8px;border-radius:4px;background:#1c1d3b}.ubar i{display:block;height:100%;background:var(--blue);border-radius:4px}.ubar i.mid{background:var(--orange)}.ubar i.hi{background:var(--red)}
.utext{display:flex;justify-content:space-between;gap:12px;margin-top:6px;font-size:12px}.utext b{font-weight:600}
.dtab td{vertical-align:middle;padding:10px}.dtab td:nth-child(3){width:70px;text-align:right}.upct{font-size:18px}.dline{display:block;font-size:12px}
.ubar{position:relative}.umark{position:absolute;top:-3px;width:2px;height:14px;background:var(--red)}
.idl{display:block;color:var(--mut);font-size:11px}
@media (max-width:1100px){.srow{grid-template-columns:1fr}}
@media (max-width:640px){.wrap{padding:12px 8px}td,th{padding:5px 6px}}
"""

def _font_face(family: str, file: str, weight: str) -> str:
    """An @font-face with the woff2 inline: the pages need no extra route (Passthrough, allowlists)."""
    path = Path(__file__).with_name("fonts") / file
    try:
        data = base64.b64encode(path.read_bytes()).decode()
    except OSError:  # a missing file only loses the font, the fallback stack takes over
        return ""
    return (f'@font-face{{font-family:"{family}";src:url(data:font/woff2;base64,{data}) format("woff2");'
            f"font-weight:{weight};font-style:normal;font-display:swap}}")

_MENU_JS = (
    '<script>(function(){var q=".menu,.rfd,.dd";function all(){return document.querySelectorAll(q)}'
    'document.addEventListener("click",function(e){all().forEach(function(d){'
    'if(d.open&&!d.contains(e.target))d.open=false})});'
    'document.addEventListener("keydown",function(e){if(e.key==="Escape")all().forEach(function(d){d.open=false})});'
    'all().forEach(function(d){d.addEventListener("toggle",function(){if(d.open)all().forEach(function(o){'
    'if(o!==d)o.open=false})})})})();</script>')

_INFO_JS = (
    '<div id="tip" role="tooltip"></div><script>(function(){var t=document.getElementById("tip");'
    'function show(e,txt){var r=e.getBoundingClientRect();t.textContent=txt||e.dataset.tip;t.style.display="block";'
    'var w=t.offsetWidth,h=t.offsetHeight,x=Math.min(Math.max(8,r.left-8),innerWidth-w-8),'
    'y=r.bottom+8;if(y+h>innerHeight-8)y=Math.max(8,r.top-h-8);t.style.left=x+"px";t.style.top=y+"px"}'
    'function hide(){t.style.display="none"}'
    'document.querySelectorAll(".info").forEach(function(e){e.addEventListener("mouseenter",function(){show(e)});'
    'e.addEventListener("focus",function(){show(e)});e.addEventListener("mouseleave",hide);'
    'e.addEventListener("blur",hide);e.addEventListener("click",function(ev){ev.stopPropagation();show(e)})});'
    'document.addEventListener("click",hide);window.addEventListener("scroll",hide,true);'
    # A cut cell (.ell) shows its whole text on hover; the alert name always does (it carries the id).
    'document.addEventListener("mouseover",function(ev){var e=ev.target.closest&&ev.target.closest(".ell");'
    'if(!e||e.contains(ev.relatedTarget))return;if(e.dataset.always||e.scrollWidth>e.clientWidth+1)'
    'show(e,e.dataset.full||e.textContent)});'
    'document.addEventListener("mouseout",function(ev){var e=ev.target.closest&&ev.target.closest(".ell");'
    'if(e&&!e.contains(ev.relatedTarget))hide()})})();</script>')

_REFRESH = ('<svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" '
            'stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19.5 10.5A7.7 7.7 0 0 0 '
            '6 6.6L4.5 8.2"/><path d="M4.5 4v4.2h4.2"/><path d="M4.5 13.5A7.7 7.7 0 0 0 18 17.4l1.5-1.6"/>'
            '<path d="M19.5 20v-4.2h-4.2"/></svg>')

_LOGO_SVG = ('<svg viewBox="0 0 491.7 127.6" aria-hidden="true"><defs><linearGradient id="lgo-g" gradientUnits="userSpaceO'
         'nUse" x1="213.056" y1="58.1443" x2="314.8241" y2="58.1443"><stop offset="0" stop-color="#00C1F8"/><stop offs'
         'et="1" stop-color="#143DFB"/></linearGradient></defs><path fill="url(#lgo-g)" d="M290.3,4.1L221.2,44c-10.9,6'
         '.3-10.9,22,0,28.3l69.1,39.9c10.9,6.3,24.5-1.6,24.5-14.1V18.2 C314.8,5.7,301.2-2.2,290.3,4.1z M275.6,83.6C261'
         '.5,83.6,250,72.1,250,58c0-14.1,11.4-25.5,25.5-25.5c14.1,0,25.5,11.4,25.5,25.5 C301.1,72.1,289.7,83.6,275.6,8'
         '3.6z"/><path fill="#fff" d="M48.9,95.3H3.1V81.7h45.8c3.7,0,6.7-3,6.7-6.7c0-3.1-2.1-5.8-5.1-6.5L18,60.6C8.8,5'
         '8.4,2.4,50.3,2.4,40.8 v-0.3c0-11.2,9.1-20.3,20.3-20.3h41.2v13.6H22.7c-3.7,0-6.7,3-6.7,6.7v0.3c0,3.1,2.1,5.8,'
         '5.1,6.5l32.5,7.8 c9.2,2.2,15.6,10.3,15.6,19.8C69.2,86.2,60.1,95.3,48.9,95.3z"/><path fill="#fff" d="M364.9,1'
         '8.7c-9.9,0-18.7,4.2-25.6,10.5V21h-13.6v103.3h13.6V88c6.9,5.9,15.8,9.4,25.6,9.4 c21.7,0,39.4-17.6,39.4-39.4C4'
         '04.3,36.3,386.7,18.7,364.9,18.7z M364.9,83.6c-14.1,0-25.5-11.4-25.5-25.5 c0-14.1,11.4-25.5,25.5-25.5c14.1,0,'
         '25.5,11.4,25.5,25.5C390.5,72.1,379,83.6,364.9,83.6z"/><path fill="#fff" d="M490.4,60.1c0-0.7,0.1-1.4,0.1-2.1'
         'c0-24.2-15.9-39.4-37.7-39.4c-21.7,0-39.4,17.6-39.4,39.4 c0,21.7,17.6,39.4,39.4,39.4c14.5,0,27.2-7.9,34-19.6l'
         '-11.4-7.2c-4.3,7.3-13,12.9-22.6,12.9c-13.4,0-24.4-10.3-25.4-23.4 L490.4,60.1z M452.7,31.2c11.1,0,20.5,7.8,24'
         ',18h-48C432.3,39,441.7,31.2,452.7,31.2z"/><path fill="#fff" d="M135.9,20.3l-22.5,55.2L90.8,20.3H75.1l30.4,74'
         '.6l-0.1,0.1c-3.8,9.4-12.9,15.5-23,15.5v13.9 c15.8,0,29.9-9.5,35.9-24.1l32.6-80H135.9z"/><path fill="#fff" d='
         '"M190.7,83.6c-14.1,0-25.5-11.4-25.5-25.5s11.4-25.5,25.5-25.5c6.9,0,13.1,2.7,17.7,7.2l12.3-7.1 c-7.2-8.5-18-1'
         '3.9-30.1-13.9c-21.7,0-39.4,17.6-39.4,39.4s17.6,39.4,39.4,39.4c12,0,22.7-5.4,30-13.8l-12.3-7.1 C203.8,80.8,19'
         '7.6,83.6,190.7,83.6z"/></svg>'
         '<span class="lsep" aria-hidden="true"></span>')


def logo(product: str, compare: bool = True) -> str:
    """The Sycope mark and the product name; the link goes to that product's start page. Without the compare
    mode the second product is the Episodes view."""
    name, href = (("Security Clusters", "clusters") if product == "clusters" and compare
                  else ("Security Episodes", "episodes") if product in ("clusters", "episodes")
                  else ("Security Triage", "./"))
    return (f'<a class="logo" href="{href}" title="Sycope {name}" aria-label="Sycope {name}">{_LOGO_SVG}'
            f'<span class="lname">{name}</span></a>')


_CAL = ('<svg class="cal" width="18" height="18" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" '
        'stroke-width="1.6" stroke-linecap="round"><rect x="3.5" y="5" width="17" height="15" rx="2"/>'
        '<path d="M3.5 10h17M8 3v4M16 3v4"/><circle cx="16" cy="15.5" r="2.6"/><path d="M16 14.3v1.3l.9.6"/></svg>')

def _gear(px: int) -> str:
    return (f'<svg width="{px}" height="{px}" viewBox="0 0 24 24" aria-hidden="true" fill="none" '
            'stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">'
            '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 '
            '2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 '
            '9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 '
            '0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 '
            '2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 '
            '1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 '
            '1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>')

_CHEV = ('<svg class="chev" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true">'
         '<path d="M1.5 3.5 5 7l3.5-3.5" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>')

_LUPA = ('<svg class="lupa" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="6.5" '
         'cy="6.5" r="4.6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M10 10l4.2 4.2" '
         'stroke="currentColor" stroke-width="1.4" fill="none"/></svg>')

# Sycope's own fonts (OFL, see fonts/README.txt), so the pages render like its UI.
_FONT_CSS = _font_face("Kumbh Sans", "KumbhSans.woff2", "400 600") + _font_face("Roboto Mono", "RobotoMono.woff2", "400")
