"""The service's memory, one SQLite file in the state directory.

    day_findings  past days (UTC), one row per (rule, client, server, port): count, first/last alert, bytes, and
                  (v1.0) the strongest severity and threshold level (the scoring weights, 0 = none), the
                  counterpart's ASN, the targets listed (JSON, 64 at most) and the template's rule id, which keeps a
                  renamed template one rule in the history.
                  Filled whole from Sycope by the backfill, never from the in-memory window, so a restart or a
                  late alert cannot double count. The novelty (was this host doing this before?) and the rarity
                  (how many hosts do this on a normal day?) of every finding are read from it.
    days          which days are complete
    triage        the analyst's state per host: acknowledged, investigating, false positive, resolved, with the
                  fingerprint of what the host showed at that moment (a change brings the host back)
    exceptions    known services and allowed behaviours, with author, reason and expiry
    audit         every action, newest first on the pages
    verdict_log   what the system decided about a host and when (entered the queue, escalated, came back after
                  being handled): with the analysts' actions it is the host's history
    incidents     every incident the queue showed, kept as it was at the time: subject (an entity key, see
                  entities.py: ip:..., pattern:..., subnet:..., one day host:/user:/mac:), peak verdict and its
                  reason, outcome (who handled it, how, when), a snapshot of the evidence, the lifecycle events
    day_flows_srv, day_flows_cli  netflow per UTC day: per internal service (server, port) the busiest hour's distinct
                  clients and the bytes each way, per internal host the outside peers and bytes towards them; built
                  hour by hour (flowagg.py), `flow_hours` says which hours are merged in
    incident_members  which entities a group incident or a campaign held (so a host finds every incident it was in)
    profile_snapshots the learned environment profile of each day (profile.py), one of them possibly frozen
    crown         crown jewels the admin keeps (crown.py): entity ip:/subnet:, source, who, when, removed or not;
                  `crown_history` keeps every closed interval (added, removed) so a replay sees earlier ones
    suggestion_answers  what the admin answered to a suggestion of the profile (accept/reject, with the evidence
                  text it was answered on); `meta` key profile_frozen says whether the profile is frozen
    config_versions   the administrator's configuration, one row per version (confplane.py); `meta` key
                  config_active points at the published one. Incidents, verdict_log and audit lines carry the
                  config_version and profile_day they were written under (replay)
    cluster_triage  the analyst's state per Clusters work object (`cl:<episode id>`, `ct:<ip>`), the Clusters
                  counterpart of `triage`; a table of its own because triage.ip is the primary key.
                  incidents, verdict_log and audit carry a `product` ('triage' or 'clusters') instead, so every
                  Triage read (the default) leaves the Clusters rows out
    meta          small keys: config_active, profile_frozen, chain_ids ("2" once the chain rule ids of an older database
                  were renumbered, chain_migration.py)
    cluster_episodes  the Clusters board's identity of a cluster: one row per (anchor, time range) with a stable id
                  that survives the window moving; an episode the window now chains into an older one is `merged_into`
                  it (clusters.py, match_episodes)

A few MB for weeks of history. One connection, one lock: the poller, the backfill and the request threads share it.
"""

from __future__ import annotations

import calendar
import contextvars
import json
import sqlite3
import threading
import time
from pathlib import Path

from sycope_clusters import chain_migration, scoring

_SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS day_findings(
  day TEXT NOT NULL, rule TEXT NOT NULL, client TEXT NOT NULL, server TEXT NOT NULL, port TEXT NOT NULL,
  n INTEGER NOT NULL, first_ms INTEGER, last_ms INTEGER, up INTEGER, down INTEGER,
  sev INTEGER, thr INTEGER, asn INTEGER, targets TEXT, rule_id TEXT,
  PRIMARY KEY(day, rule, client, server, port));
CREATE TABLE IF NOT EXISTS days(day TEXT PRIMARY KEY, alerts INTEGER, findings INTEGER, fetched_at REAL);
CREATE TABLE IF NOT EXISTS day_flows_srv(
  day TEXT NOT NULL, ip TEXT NOT NULL, port TEXT NOT NULL, clients INTEGER, up INTEGER, down INTEGER, ext INTEGER,
  PRIMARY KEY(day, ip, port));
CREATE TABLE IF NOT EXISTS day_flows_cli(
  day TEXT NOT NULL, ip TEXT NOT NULL, peers INTEGER, up_ext INTEGER, down_ext INTEGER, ext INTEGER DEFAULT 0,
  PRIMARY KEY(day, ip));
CREATE TABLE IF NOT EXISTS flow_hours(hour_start INTEGER PRIMARY KEY, srv_rows INTEGER, cli_rows INTEGER, at REAL);
CREATE TABLE IF NOT EXISTS triage(ip TEXT PRIMARY KEY, status TEXT NOT NULL, who TEXT, note TEXT, at REAL,
  fingerprint TEXT, verdict TEXT);
CREATE TABLE IF NOT EXISTS exceptions(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, rule TEXT,
  server TEXT, port TEXT, actor TEXT, reason TEXT, who TEXT, created REAL, expires REAL, active INTEGER DEFAULT 1,
  removed_by TEXT, removed_at REAL);
CREATE TABLE IF NOT EXISTS silence_hits(rule_id INTEGER NOT NULL, hour INTEGER NOT NULL, alerts INTEGER NOT NULL,
  hosts INTEGER, host_list TEXT, first_ms INTEGER, last_ms INTEGER, sample_ids TEXT, PRIMARY KEY(rule_id, hour));
CREATE TABLE IF NOT EXISTS silence_hosts(rule_id INTEGER NOT NULL, host TEXT NOT NULL, first_at REAL NOT NULL,
  PRIMARY KEY(rule_id, host));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL, who TEXT, action TEXT, target TEXT,
  note TEXT, detail TEXT);
CREATE INDEX IF NOT EXISTS audit_target ON audit(target);
CREATE TABLE IF NOT EXISTS verdict_log(id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL, ip TEXT NOT NULL, kind TEXT,
  verdict TEXT, prev TEXT, reason TEXT, conf REAL, detail TEXT);
CREATE INDEX IF NOT EXISTS verdict_log_ip ON verdict_log(ip);
CREATE INDEX IF NOT EXISTS verdict_log_at ON verdict_log(at);
CREATE TABLE IF NOT EXISTS incidents(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, subject TEXT NOT NULL,
  label TEXT, ui_key TEXT, parent TEXT, opened_at REAL NOT NULL, last_seen REAL NOT NULL, closed_at REAL,
  first_ms INTEGER, last_ms INTEGER, verdict_peak TEXT, verdict_last TEXT, conf_peak REAL, risk_peak REAL,
  stage_peak INTEGER, headline TEXT, reason TEXT, families TEXT, chains TEXT, members_n INTEGER, identifiers TEXT,
  resolution TEXT, status TEXT NOT NULL, outcome TEXT, outcome_by TEXT, outcome_at REAL, outcome_note TEXT,
  handled_n INTEGER, snapshot TEXT, snapshot_at REAL, events TEXT, search TEXT, outcome_reason TEXT, end_reason TEXT, peak_n INTEGER,
  peak_at REAL, reopened_at REAL);
CREATE INDEX IF NOT EXISTS incidents_status ON incidents(status);
CREATE INDEX IF NOT EXISTS incidents_opened ON incidents(opened_at);
CREATE INDEX IF NOT EXISTS incidents_closed ON incidents(closed_at);
CREATE INDEX IF NOT EXISTS incidents_outcome_at ON incidents(outcome_at);
CREATE TABLE IF NOT EXISTS incident_members(incident_id INTEGER NOT NULL, entity TEXT NOT NULL,
  PRIMARY KEY(incident_id, entity));
CREATE INDEX IF NOT EXISTS incident_members_entity ON incident_members(entity);
CREATE TABLE IF NOT EXISTS profile_snapshots(day TEXT PRIMARY KEY, body TEXT NOT NULL, frozen INTEGER DEFAULT 0,
  at REAL, vals TEXT);
CREATE TABLE IF NOT EXISTS config_versions(id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL, who TEXT, note TEXT,
  parent_id INTEGER, status TEXT, body TEXT, schema_version INTEGER);
CREATE TABLE IF NOT EXISTS crown(entity TEXT PRIMARY KEY, source TEXT, reason TEXT, who TEXT, at REAL,
  active INTEGER DEFAULT 1, removed_by TEXT, removed_at REAL);
CREATE TABLE IF NOT EXISTS crown_history(entity TEXT NOT NULL, source TEXT, reason TEXT, who TEXT, added_at REAL,
  removed_at REAL, removed_by TEXT);
CREATE INDEX IF NOT EXISTS crown_history_entity ON crown_history(entity);
CREATE TABLE IF NOT EXISTS suggestion_answers(key TEXT PRIMARY KEY, answer TEXT, who TEXT, at REAL, evidence TEXT);
CREATE TABLE IF NOT EXISTS cluster_episodes(id INTEGER PRIMARY KEY AUTOINCREMENT, anchor TEXT NOT NULL,
  first_ms INTEGER NOT NULL, last_ms INTEGER NOT NULL, merged_into INTEGER, seen_at REAL);
CREATE INDEX IF NOT EXISTS cluster_episodes_anchor ON cluster_episodes(anchor);
CREATE TABLE IF NOT EXISTS cluster_triage(key TEXT PRIMARY KEY, status TEXT NOT NULL, who TEXT, note TEXT, at REAL,
  verdict TEXT, owner TEXT, reason TEXT);
CREATE TABLE IF NOT EXISTS incident_steps(incident_id INTEGER NOT NULL, step TEXT NOT NULL, done INTEGER NOT NULL,
  who TEXT, at REAL, title TEXT, PRIMARY KEY(incident_id, step));
"""
EXC_MAX_DAYS = 90      # the longest an exception lasts (S-5); it is renewed on purpose, not by default

# Whether the name on the audit lines being written was confirmed by Sycope (identity.py): 1 yes, 0 the page said so,
# None for the service's own lines. The app sets it around one action.
VERIFIED: contextvars.ContextVar[int | None] = contextvars.ContextVar("audit_verified", default=None)
_AUDIT_INSERT = ("INSERT INTO audit(at, who, action, target, note, detail, verified, config_version, profile_day) "
                 "VALUES (?,?,?,?,?,?,?,?,?)")      # product left to its default, 'triage' (the replay helpers use it)
_AUDIT_INSERT_P = ("INSERT INTO audit(at, who, action, target, note, detail, verified, config_version, profile_day, "
                   "product) VALUES (?,?,?,?,?,?,?,?,?,?)")
_TRIAGE_UPSERT = ("INSERT OR REPLACE INTO triage(ip, status, who, note, at, fingerprint, verdict, owner, reason) "
                  "VALUES (?,?,?,?,?,?,?,?,?)")
# an ended incident an analyst took or escalated after it ended (no NULLs, so NOT (...) is safe in the prune)
_TAKEN = ("(status = 'closed' AND COALESCE(end_reason, '') = 'quiet' AND parent IS NULL AND "
          "COALESCE(outcome, '') IN ('investigating', 'escalated') "
          "AND COALESCE(outcome_at, 0) > COALESCE(closed_at, 0))")
DAY_COLS = ("day", "rule", "client", "server", "port", "n", "first_ms", "last_ms", "up", "down")
DAY_EXTRA = (("sev", "INTEGER"), ("thr", "INTEGER"), ("asn", "INTEGER"), ("targets", "TEXT"), ("rule_id", "TEXT"))
_DAY_SELECT = ", ".join((*DAY_COLS, *(c for c, _ in DAY_EXTRA)))
_JSON = ("families", "chains", "identifiers", "resolution", "snapshot", "events")
_INC_COLS = ("kind", "subject", "label", "ui_key", "parent", "opened_at", "last_seen", "closed_at", "first_ms",
             "last_ms", "verdict_peak", "verdict_last", "conf_peak", "risk_peak", "stage_peak", "headline", "reason",
             "families", "chains", "members_n", "identifiers", "resolution", "status", "outcome", "outcome_by",
             "outcome_at", "outcome_note", "handled_n", "snapshot", "snapshot_at", "events", "search", "outcome_reason",
             "end_reason", "config_version", "profile_day", "product", "peak_n", "peak_at", "reopened_at")



def _day_start(day: str) -> int:
    """Epoch seconds of 00:00 UTC of a day 'YYYY-MM-DD'."""
    y, m, d = (int(x) for x in day.split("-"))
    return calendar.timegm((y, m, d, 0, 0, 0))


_AUDIT_COLS = "at, who, action, target, note, detail, verified, config_version, profile_day, product"
# Audit lines of configuration work: everyone sees that it happened, who and when, but only an admin reads the note and
# the detail (R49). Every audit reader hides them unless it is told `full`.
REDACTED_PREFIXES = ("config:", "profile:", "catalog:", "crown:", "suggestion:")
_REDACTED_SQL = " AND ".join("action NOT LIKE '" + p + "%'" for p in REDACTED_PREFIXES)


def _audit_row(r: tuple, full: bool = False) -> dict:
    a, w, ac, t, n, d, v, cv, pd, pr = r
    for old, new in scoring.WIRE.items():       # lines written before the presets got neutral ids
        if old != new and d and old in d:
            d = d.replace(f'"{old}"', f'"{new}"')
    hide = not full and ac.startswith(REDACTED_PREFIXES)
    return {"at": a, "who": w, "action": ac, "target": t, "note": "" if hide else n,
            "detail": {} if hide else json.loads(d or "{}"), "verified": v, "config_version": cv, "profile_day": pd,
            "product": pr}


def _only(product: str | None, where: list[str], args: list) -> None:
    """Narrow a query to one product ('triage' or 'clusters'); None leaves it on all of them."""
    if product is not None:
        where.append("product = ?")
        args.append(product)


def _values_of(body: dict | str) -> str:
    """The learned values of a profile snapshot as {parameter: value} JSON (an unreadable body has none)."""
    try:
        d = json.loads(body) if isinstance(body, str) else body
        vals = d.get("values") or {}
        return json.dumps({k: v["value"] for k, v in sorted(vals.items()) if isinstance(v, dict) and "value" in v},
                          separators=(",", ":"))
    except (ValueError, AttributeError, TypeError):
        return "{}"


# the incident fields whose change the remembered decisions (memory.py) can see: an update that touches none of them
# (the board's every-minute refresh of an open record) leaves the decision generation alone
DECISION_FIELDS = frozenset(("kind", "subject", "parent", "status", "outcome", "outcome_at", "end_reason", "closed_at",
                             "opened_at", "verdict_peak"))
MEMO_KEEP = 8      # results the store keeps per kind of cached read


class VerdictWindow:
    """What the verdict log says about every host since `w`, read once (a few grouped scans, not one query per host):
    the newest row (`last`: verdict, kind), when the verdict last changed (`changed`), the row in force when the window
    began (`pre`: (at, rank)) and the rows since (`log`: (at, rank), oldest first). Valid for any `since >= w`; the
    store keeps one per (product, w) until a write to the log or the incidents."""

    __slots__ = ("changed", "last", "log", "pre", "w")

    def __init__(self, w: float, last: dict, changed: dict, pre: dict, log: dict) -> None:
        self.w, self.last, self.changed, self.pre, self.log = w, last, changed, pre, log

    def trail(self, ip: str, since: float) -> tuple:
        """((at, rank), ...) of the host's verdicts that count for a window beginning at `since`: the rows since, and the
        verdict in force at `since` (the newest row before it)."""
        rows = self.log.get(ip, ())
        older = [x for x in rows if x[0] < since]
        before = older[-1] if older else self.pre.get(ip)
        return ((before,) if before is not None else ()) + tuple(x for x in rows if x[0] >= since)

    def shown(self, ip: str, since: float, after: float = 0.0) -> int:
        """The highest verdict rank shown in the window beginning at `since` (-1 none): its rows and the verdict in
        force at its start. With an analyst's action at `after` only what was logged after the action counts, whatever
        its age, never what was in force before it (a release stays a release)."""
        return max((r for a, r in self.trail(ip, since) if a > after), default=-1)


class Store:
    def __init__(self, path: str | Path | None) -> None:
        self.path = str(path) if path else ":memory:"
        if path:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
        self._lock = threading.Lock()
        self.stamp: tuple[int | None, str | None] = (None, None)   # (config_version, profile_day) of what is live now
        # write counters: `gen` moves on every write to incidents, steps, the verdict log, statuses and exceptions;
        # `decision_gen` only on those the remembered decisions can see (see DECISION_FIELDS). Cached reads key on them.
        self.gen = 0
        self.decision_gen = 0
        self._memo: dict = {}
        with self._lock:
            if path:
                self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA synchronous=NORMAL")
            self._db.executescript(_SCHEMA)
            cols = {r[1] for r in self._db.execute("PRAGMA table_info(triage)")}
            for col in ("owner", "reason"):  # v0.5: who the incident is assigned to, why it was closed
                if col not in cols:
                    self._db.execute(f"ALTER TABLE triage ADD COLUMN {col} TEXT")
            inc_cols = {r[1] for r in self._db.execute("PRAGMA table_info(incidents)")}
            if "outcome_reason" not in inc_cols:
                self._db.execute("ALTER TABLE incidents ADD COLUMN outcome_reason TEXT")
            if "end_reason" not in inc_cols:   # v0.6: why it closed (quiet, exception, regrouped, merged)
                self._db.execute("ALTER TABLE incidents ADD COLUMN end_reason TEXT")
            if "peak_n" not in inc_cols:   # v1.2: the size of a group or campaign at its peak (members_n only grows)
                self._db.execute("ALTER TABLE incidents ADD COLUMN peak_n INTEGER")
            if "peak_at" not in inc_cols:   # v1.2: when the peak verdict was reached (the SLA clock; events are capped)
                self._db.execute("ALTER TABLE incidents ADD COLUMN peak_at REAL")
            if "reopened_at" not in inc_cols:   # v1.2: when new evidence last lifted an analyst's status (restarts the SLA clock)
                self._db.execute("ALTER TABLE incidents ADD COLUMN reopened_at REAL")
            have_df = {r[1] for r in self._db.execute("PRAGMA table_info(day_findings)")}
            for col, typ in DAY_EXTRA:   # v1.0: what a replay and the rule identity need
                if col not in have_df:
                    self._db.execute(f"ALTER TABLE day_findings ADD COLUMN {col} {typ}")
            if "ext" not in {r[1] for r in self._db.execute("PRAGMA table_info(day_flows_cli)")}:
                # v1.0: public clients with many outside peers (one of ours seen from outside, profile.py)
                self._db.execute("ALTER TABLE day_flows_cli ADD COLUMN ext INTEGER DEFAULT 0")
            if "verified" not in {r[1] for r in self._db.execute("PRAGMA table_info(audit)")}:
                self._db.execute("ALTER TABLE audit ADD COLUMN verified INTEGER")   # v0.5.1: name confirmed by Sycope
            for table in ("incidents", "verdict_log", "audit"):   # v1.0: what the record was scored under (replay)
                have_cols = {r[1] for r in self._db.execute(f"PRAGMA table_info({table})")}
                for col, typ in (("config_version", "INTEGER"), ("profile_day", "TEXT")):
                    if col not in have_cols:
                        self._db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
            for table in ("incidents", "verdict_log", "audit"):   # v1.1: which product's work the record is
                if "product" not in {r[1] for r in self._db.execute(f"PRAGMA table_info({table})")}:
                    self._db.execute(f"ALTER TABLE {table} ADD COLUMN product TEXT NOT NULL DEFAULT 'triage'")
            if "vals" not in {r[1] for r in self._db.execute("PRAGMA table_info(profile_snapshots)")}:
                # v1.0: the learned values of a snapshot on their own (the Profile card's history reads only them)
                self._db.execute("ALTER TABLE profile_snapshots ADD COLUMN vals TEXT")
            for (day,) in self._db.execute("SELECT day FROM profile_snapshots WHERE vals IS NULL").fetchall():
                body = self._db.execute("SELECT body FROM profile_snapshots WHERE day = ?", (day,)).fetchone()[0]
                self._db.execute("UPDATE profile_snapshots SET vals = ? WHERE day = ?", (_values_of(body), day))
            have = {r[1] for r in self._db.execute("PRAGMA table_info(exceptions)")}
            for col, typ in (("pending", "INTEGER DEFAULT 0"), ("days", "INTEGER"), ("decided_by", "TEXT"),
                             ("decided_at", "REAL"), ("decision_note", "TEXT"),
                             ("second", "INTEGER DEFAULT 0"),
                             ("verified", "INTEGER DEFAULT 0")):  # v0.5: exceptions an admin approves; v1.2: second person, proposer confirmed
                if col not in have:
                    self._db.execute(f"ALTER TABLE exceptions ADD COLUMN {col} {typ}")
            if "verified" not in have:
                self._backfill_verified()
            fresh = "src" not in have
            for col, typ in (("src", "TEXT"), ("dst", "TEXT"), ("proto", "TEXT"), ("win_days", "TEXT"),
                             ("win_from", "INTEGER"), ("win_to", "INTEGER"), ("edited_by", "TEXT"),
                             ("edited_at", "REAL"), ("pruned_alerts", "INTEGER DEFAULT 0")):   # v1.4: silence rules
                if col not in have:
                    self._db.execute(f"ALTER TABLE exceptions ADD COLUMN {col} {typ}")
            if fresh:     # v1.4 (once): the 1.0 kinds read as silence rules: service = name + dst + port, host-rule = name + src
                self._db.execute("UPDATE exceptions SET dst = server WHERE kind = 'service'")
                self._db.execute("UPDATE exceptions SET src = actor WHERE kind IN ('host-rule', 'host')")
            chain_migration.run(self._db)   # 0.5.01b (once): the chain rules were renumbered, see chain_migration.py

    def _touch(self, decision: bool = True) -> None:
        """Count a write (call it with the lock held, after the write succeeded)."""
        self.gen += 1
        if decision:
            self.decision_gen += 1

    def memoized(self, key: tuple, gen: int, build):
        """`build()` once per `gen` for `key`: the cached result while no write moved the counter (the caller reads
        the counter before it asks, so a write during the build leaves the entry stale, never wrong). Results are
        shared: read-only for the caller."""
        with self._lock:
            hit = self._memo.get(key)
        if hit is not None and hit[0] == gen:
            return hit[1]
        value = build()
        with self._lock:
            self._memo[key] = (gen, value)
            same = [k for k in self._memo if k[0] == key[0]]
            for k in same[:-MEMO_KEEP]:
                del self._memo[k]
        return value

    def _backfill_verified(self) -> None:
        """v1.2 (once, when the column is added): a proposal that was pending under 1.1.2 has no `verified` flag. Its
        audit line ("exception:propose") knows whether Sycope had confirmed the proposer's name (audit.verified = 1):
        carry that over, so such a proposal can still be approved. The others stay unverified (they need proposing again
        by a confirmed person; README, upgrade notes)."""
        ids = set()
        for detail, in self._db.execute("SELECT detail FROM audit WHERE action = 'exception:propose' AND verified = 1"):
            try:
                ids.add(int(json.loads(detail or "{}").get("id")))
            except (TypeError, ValueError, AttributeError):
                continue
        for ex_id in sorted(ids):
            self._db.execute("UPDATE exceptions SET verified = 1 WHERE id = ? AND pending = 1", (ex_id,))

    # ---- history ------------------------------------------------------------------------------------------

    def put_day(self, day: str, rows: list[tuple], alerts: int) -> None:
        """Replace one day: rows of (rule, client, server, port, n, first_ms, last_ms, up, down[, sev, thr, asn,
        targets, rule_id]); a shorter row leaves the last columns empty."""
        width = len(DAY_COLS) - 1 + len(DAY_EXTRA)
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                cur.execute("DELETE FROM day_findings WHERE day = ?", (day,))
                cur.executemany(f"INSERT INTO day_findings({_DAY_SELECT}) VALUES ({','.join('?' * (width + 1))})",
                                [(day, *r, *(None,) * (width - len(r))) for r in rows])
                cur.execute("INSERT OR REPLACE INTO days VALUES (?,?,?,?)", (day, alerts, len(rows), time.time()))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise

    def days(self) -> dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT day, alerts, findings, fetched_at FROM days ORDER BY day").fetchall()
        return {d: {"alerts": a, "findings": f, "fetched_at": t} for d, a, f, t in rows}

    def day_rows(self, days: list[str]) -> list[tuple]:
        """(day, rule, client, server, port, n, first_ms, last_ms, up, down, sev, thr, asn, targets, rule_id) of
        these days; the last five are None in a row stored before v1.0."""
        if not days:
            return []
        q = f"SELECT {_DAY_SELECT} FROM day_findings WHERE day IN ({','.join('?' * len(days))})"
        with self._lock:
            return self._db.execute(q, days).fetchall()

    def iter_day_rows(self, days: list[str], chunk: int = 0):
        """The rows of day_rows, one day at a time (only one day is ever held): 14 stored days of a 2M-alert network
        are 2.8M rows, 1.6 GB as one list. The lock is taken per day, never across the reader's work.
        With `chunk` the day itself is read `chunk` rows at a time (keyset pages on the primary key, the lock taken
        per page): a day is 200k rows, ~100 MB as python tuples, and a reader that runs while the window is big wants
        less than that.
        A reader keeping keys (the History) would keep a copy of an IP or rule name per row: the day, rule, client,
        server and port of every row are one shared string each for the whole read."""
        memo: dict[str, str] = {}
        one = memo.setdefault
        base = f"SELECT {_DAY_SELECT} FROM day_findings WHERE day = ?"
        for d in sorted(set(days)):
            after: tuple = ()
            while True:
                if not chunk:
                    q, args = base, (d,)
                elif after:
                    q = f"{base} AND (rule, client, server, port) > (?, ?, ?, ?) ORDER BY rule, client, server, port LIMIT ?"
                    args = (d, *after, chunk)
                else:
                    q, args = f"{base} ORDER BY rule, client, server, port LIMIT ?", (d, chunk)
                with self._lock:
                    rows = self._db.execute(q, args).fetchall()
                if chunk and rows:
                    after = tuple(rows[-1][1:5])
                for r in rows:
                    rule, client, server, port = r[1:5]
                    yield (d, one(rule, rule) if rule else rule, one(client, client) if client else client,
                           one(server, server) if server else server, one(port, port) if port else port, *r[5:])
                if not chunk or len(rows) < chunk:
                    break
            del rows

    def ip_days(self, ip: str, days: list[str]) -> list[tuple]:
        """The history rows that name one IP (as client or server)."""
        if not days:
            return []
        q = (f"SELECT {_DAY_SELECT} FROM day_findings WHERE day IN ({','.join('?' * len(days))}) "
             f"AND (client = ? OR server = ?)")
        with self._lock:
            return self._db.execute(q, [*days, ip, ip]).fetchall()

    def prune(self, keep_from_day: str) -> int:
        with self._lock:
            n = self._db.execute("DELETE FROM day_findings WHERE day < ?", (keep_from_day,)).rowcount
            self._db.execute("DELETE FROM days WHERE day < ?", (keep_from_day,))
            for t in ("day_flows_srv", "day_flows_cli"):
                self._db.execute(f"DELETE FROM {t} WHERE day < ?", (keep_from_day,))
            self._db.execute("DELETE FROM flow_hours WHERE hour_start < ?", (_day_start(keep_from_day),))
            self._db.execute("DELETE FROM profile_snapshots WHERE day < ? AND frozen = 0", (keep_from_day,))
        return n

    # ---- cluster episodes (clusters.py) -------------------------------------------------------------------

    def match_episodes(self, items: list[tuple[str, int, int]], delta_ms: int, now: float) -> list[tuple[int, list[int]]]:
        """The episode id of each (anchor, start_ms, end_ms), in the order given, as (id, merged ids). A stored,
        not merged episode of the same anchor whose range touches the cluster's (within delta) is the same episode,
        and its range becomes the union: the window moving, the first alert leaving, changes nothing. Several
        match: the smallest id wins and the others become `merged_into` it. None: a new id.
        Several clusters may touch one stored episode when the window now splits it (lean mode, a smaller delta).
        The earliest of them keeps the id and the stored range is replaced by its own, not widened: the others get
        new ids, and once the earlier part ages out the later part still finds its own episode. Clusters are
        taken in (anchor, start) order whatever the order given, so the ids do not depend on it. One transaction,
        one read of the stored episodes at or after the oldest cluster."""
        if not items:
            return []
        floor = min(it[1] for it in items) - delta_ms
        order = sorted(range(len(items)), key=lambda i: items[i][:2])
        out: list[tuple[int, list[int]]] = [(0, [])] * len(items)
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                stored: dict[str, list[list]] = {}
                for eid, anchor, first, last in cur.execute(
                        "SELECT id, anchor, first_ms, last_ms FROM cluster_episodes "
                        "WHERE merged_into IS NULL AND last_ms >= ? ORDER BY id", (floor,)):
                    stored.setdefault(anchor, []).append([eid, first, last])
                # who touches what, on the stored ranges as they are now (before this call changes any)
                cand: list[list[list]] = []
                claims: dict[int, int] = {}
                for anchor, start, end in items:
                    mine = [e for e in stored.get(anchor, ()) if e[1] <= end + delta_ms and e[2] >= start - delta_ms]
                    for e in mine:
                        claims[e[0]] = claims.get(e[0], 0) + 1
                    cand.append(mine)
                taken: set[int] = set()
                touched: dict[int, tuple[int, int]] = {}     # id -> its new range
                merged: list[tuple[int, int]] = []           # (loser, winner)
                for i in order:
                    anchor, start, end = items[i]
                    mine = [e for e in cand[i] if e[0] not in taken]
                    if not mine:
                        cur.execute("INSERT INTO cluster_episodes(anchor, first_ms, last_ms, seen_at) VALUES (?,?,?,?)",
                                    (anchor, start, end, now))
                        out[i] = (cur.lastrowid, [])
                        continue
                    win = mine[0]                            # stored by id: the smallest
                    taken.update(e[0] for e in mine)
                    own = [e for e in mine if claims[e[0]] == 1]      # a shared one is not ours to widen to
                    touched[win[0]] = (min([start, *(e[1] for e in own)]), max([end, *(e[2] for e in own)]))
                    merged.extend((e[0], win[0]) for e in mine[1:])
                    out[i] = (win[0], [e[0] for e in mine[1:]])
                # nothing reads seen_at but the row's age, so an episode whose range did not change is not rewritten
                was = {e[0]: (e[1], e[2]) for es in stored.values() for e in es}
                cur.executemany("UPDATE cluster_episodes SET first_ms = ?, last_ms = ?, seen_at = ? WHERE id = ?",
                                [(f, l, now, eid) for eid, (f, l) in touched.items() if was[eid] != (f, l)])
                cur.executemany("UPDATE cluster_episodes SET merged_into = ?, seen_at = ? WHERE id = ?",
                                [(w, now, lo) for lo, w in merged])
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return out

    def resolve_episode(self, eid: int, hops: int = 32) -> int:
        """The episode an id ended up in: follows `merged_into` to the last winner (an id never merged, or unknown,
        answers itself). Bounded and cycle-safe."""
        seen = {eid}
        with self._lock:
            for _ in range(hops):
                row = self._db.execute("SELECT merged_into FROM cluster_episodes WHERE id = ?", (eid,)).fetchone()
                if not row or row[0] is None or row[0] in seen:
                    break
                eid = row[0]
                seen.add(eid)
        return eid

    def prune_episodes(self, before_ms: int) -> int:
        """Forget episodes that ended before `before_ms`, and with them the Clusters statuses that nobody can reach
        any more: a `cl:<id>` row whose episode is gone, and a `ct:<ip>` row idle since before the same time. A status
        somebody owns (In progress, Escalated) is never pruned. One system audit line counts what was removed."""
        owned = "status NOT IN ('investigating', 'escalated')"
        with self._lock:
            n = self._db.execute("DELETE FROM cluster_episodes WHERE last_ms < ?", (before_ms,)).rowcount
            cl = self._db.execute("DELETE FROM cluster_triage WHERE key LIKE 'cl:%' AND " + owned + " AND "
                                  "CAST(SUBSTR(key, 4) AS INTEGER) NOT IN (SELECT id FROM cluster_episodes)").rowcount
            ct = self._db.execute("DELETE FROM cluster_triage WHERE key LIKE 'ct:%' AND " + owned +
                                  " AND COALESCE(at, 0) < ?", (before_ms / 1000,)).rowcount
            if cl or ct:
                self._db.execute(_AUDIT_INSERT_P, self._audit_args(
                    time.time(), "system", "prune:statuses", "", "", {"count": cl + ct, "cl": cl, "ct": ct},
                    product="clusters"))
        return n

    # ---- netflow aggregate (flowagg.py) -------------------------------------------------------------------

    def merge_flow_hour(self, hour_start: int, srv_rows: list[tuple], cli_rows: list[tuple]) -> bool:
        """Add one complete hour to its UTC day: server rows (ip, port, clients, up, down, ext), client rows (ip,
        peers, up_ext, down_ext[, ext], ext 0 when left out). Bytes are summed, distinct clients and peers (a count
        of one hour, not additive) are the maximum of the hours, ext is OR-ed. An hour already merged changes
        nothing and answers False."""
        day = time.strftime("%Y-%m-%d", time.gmtime(hour_start))
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                if cur.execute("SELECT 1 FROM flow_hours WHERE hour_start = ?", (hour_start,)).fetchone():
                    cur.execute("ROLLBACK")
                    return False
                cur.executemany(
                    "INSERT INTO day_flows_srv VALUES (?,?,?,?,?,?,?) ON CONFLICT(day, ip, port) DO UPDATE SET "
                    "clients = max(clients, excluded.clients), up = up + excluded.up, down = down + excluded.down, "
                    "ext = max(ext, excluded.ext)", [(day, *r) for r in srv_rows])
                cur.executemany(
                    "INSERT INTO day_flows_cli(day, ip, peers, up_ext, down_ext, ext) VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(day, ip) DO UPDATE SET peers = max(peers, excluded.peers), "
                    "up_ext = up_ext + excluded.up_ext, down_ext = down_ext + excluded.down_ext, "
                    "ext = max(COALESCE(ext, 0), excluded.ext)",
                    [(day, *c[:4], c[4] if len(c) > 4 else 0) for c in cli_rows])
                cur.execute("INSERT INTO flow_hours VALUES (?,?,?,?)",
                            (hour_start, len(srv_rows), len(cli_rows), time.time()))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return True

    def day_flows(self, days: list[str]) -> tuple[list[tuple], list[tuple]]:
        """(server rows, client rows) of the days, each row starting with its day, ordered by day, ip, port. Server
        rows (day, ip, port, clients, up, down, ext), client rows (day, ip, peers, up_ext, down_ext, ext)."""
        if not days:
            return [], []
        q = ",".join("?" * len(days))
        with self._lock:
            srv = self._db.execute(f"SELECT day, ip, port, clients, up, down, ext FROM day_flows_srv "
                                   f"WHERE day IN ({q}) ORDER BY day, ip, port", list(days)).fetchall()
            cli = self._db.execute(f"SELECT day, ip, peers, up_ext, down_ext, COALESCE(ext, 0) FROM day_flows_cli "
                                   f"WHERE day IN ({q}) ORDER BY day, ip", list(days)).fetchall()
        return srv, cli

    def flow_days(self) -> list[str]:
        """Days that have any aggregated netflow."""
        with self._lock:
            rows = self._db.execute("SELECT day FROM day_flows_srv UNION SELECT day FROM day_flows_cli "
                                    "ORDER BY day").fetchall()
        return [r[0] for r in rows]

    def flow_coverage(self, day: str) -> int:
        """Hours of the UTC day merged in that had any netflow (an hour asked and found empty does not count)."""
        t = _day_start(day)
        with self._lock:
            return self._db.execute("SELECT COUNT(*) FROM flow_hours WHERE hour_start >= ? AND hour_start < ? "
                                    "AND srv_rows + cli_rows > 0", (t, t + 86400)).fetchone()[0]

    def flow_newest_data(self) -> int | None:
        """Start (epoch) of the newest hour merged in that had any netflow, None when there is none."""
        with self._lock:
            return self._db.execute("SELECT MAX(hour_start) FROM flow_hours WHERE srv_rows + cli_rows > 0"
                                    ).fetchone()[0]

    def flow_hours_done(self, since: int) -> set[int]:
        """Hour starts (epoch) from `since` on that were asked already, empty ones included."""
        with self._lock:
            return {r[0] for r in self._db.execute("SELECT hour_start FROM flow_hours WHERE hour_start >= ?",
                                                   (since,))}

    # ---- triage -------------------------------------------------------------------------------------------

    def triage(self) -> dict[str, dict]:
        with self._lock:
            rows = self._db.execute("SELECT ip, status, who, note, at, fingerprint, verdict, owner, reason "
                                    "FROM triage").fetchall()
        return {ip: {"status": s, "who": w, "note": n, "at": a, "fingerprint": json.loads(f or "[]"), "verdict": v,
                     "owner": o, "reason": r} for ip, s, w, n, a, f, v, o, r in rows}

    def set_triage(self, ip: str, status: str, who: str, note: str, fingerprint: list, verdict: str,
                   owner: str | None = None, reason: str | None = None) -> None:
        with self._lock:
            self._db.execute(_TRIAGE_UPSERT, (ip, status, who, note, time.time(), json.dumps(fingerprint), verdict,
                                              owner, reason))
            self._touch()

    def triage_many(self, writes: list[tuple], extra_log: tuple | None = None) -> None:
        """(ip, (status, who, note, fingerprint, verdict[, owner, reason]) or None to clear, (who, action, target,
        note, detail)) for many hosts in one transaction."""
        now = time.time()
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                for ip, state, logrow in writes:
                    if state is None:
                        cur.execute("DELETE FROM triage WHERE ip = ?", (ip,))
                    else:
                        status, who, note, fp, verdict, *more = state
                        owner, reason = (list(more) + [None, None])[:2]
                        cur.execute(_TRIAGE_UPSERT,
                                    (ip, status, who, note, now, json.dumps(fp), verdict, owner, reason))
                    if logrow:
                        w, action, target, n, detail = logrow
                        cur.execute(_AUDIT_INSERT_P, self._audit_args(now, w, action, target, n, detail))
                if extra_log:
                    w, action, target, n, detail = extra_log
                    cur.execute(_AUDIT_INSERT_P, self._audit_args(now, w, action, target, n, detail))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                self._touch()

    def clear_triage(self, ip: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM triage WHERE ip = ?", (ip,))
            self._touch()

    # ---- cluster triage (the Clusters product's own status space) -------------------------------------------

    def cluster_triage(self) -> dict[str, dict]:
        """Status of every Clusters work object by key (`cl:<episode id>`, `ct:<ip>`)."""
        with self._lock:
            rows = self._db.execute("SELECT key, status, who, note, at, verdict, owner, reason FROM cluster_triage"
                                    ).fetchall()
        return {k: {"status": s, "who": w, "note": n, "at": a, "verdict": v, "owner": o, "reason": r}
                for k, s, w, n, a, v, o, r in rows}

    def cluster_triage_many(self, writes: list[tuple], extra_log: tuple | None = None) -> None:
        """triage_many for Clusters: (key, (status, who, note, fingerprint, verdict[, owner, reason]) or None to clear,
        (who, action, target, note, detail)), audit lines labelled 'clusters'. The shape is Triage's so the work layer
        passes the same tuples; a cluster has no fingerprint, so that slot is not stored."""
        now = time.time()
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                for key, state, logrow in writes:
                    if state is None:
                        cur.execute("DELETE FROM cluster_triage WHERE key = ?", (key,))
                    else:
                        status, who, note, _fp, verdict, *more = state
                        owner, reason = (list(more) + [None, None])[:2]
                        cur.execute("INSERT OR REPLACE INTO cluster_triage(key, status, who, note, at, verdict, owner, "
                                    "reason) VALUES (?,?,?,?,?,?,?,?)",
                                    (key, status, who, note, now, verdict, owner, reason))
                    if logrow:
                        w, action, target, n, detail = logrow
                        cur.execute(_AUDIT_INSERT_P, self._audit_args(now, w, action, target, n, detail,
                                                                    product="clusters"))
                if extra_log:
                    w, action, target, n, detail = extra_log
                    cur.execute(_AUDIT_INSERT_P, self._audit_args(now, w, action, target, n, detail, product="clusters"))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise

    def move_cluster_triage(self, src: str, dst: str) -> bool:
        """Hand a status to another key (a merged episode's status goes to the episode it merged into). True when
        moved. A winner's own status is not overwritten: when `dst` has one, the loser's row is deleted (it would
        be an orphan under an id nobody opens any more) and False is returned. One exception: a status somebody owns
        (In progress, Escalated) on the loser beats a winner status nobody owns (a closed or seen one), because
        dropping it would lose work in flight; the loser's row then replaces the winner's and True is returned. Either
        way a system audit line (product clusters) names both keys and the statuses, so what was dropped can be read
        back."""
        now = time.time()
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                row = cur.execute("SELECT status FROM cluster_triage WHERE key = ?", (src,)).fetchone()
                if row is None:
                    cur.execute("ROLLBACK")
                    return False
                kept = cur.execute("SELECT status FROM cluster_triage WHERE key = ?", (dst,)).fetchone()
                owned = ("investigating", "escalated")
                if kept and row[0] in owned and kept[0] not in owned:
                    cur.execute("DELETE FROM cluster_triage WHERE key = ?", (dst,))
                    cur.execute("UPDATE cluster_triage SET key = ? WHERE key = ?", (dst, src))
                    line = ("merge:dropped", {"from": src, "to": dst, "dropped": kept[0], "dropped_key": dst,
                                              "kept": row[0]})
                    kept = None
                elif kept:
                    cur.execute("DELETE FROM cluster_triage WHERE key = ?", (src,))
                    line = ("merge:dropped", {"from": src, "to": dst, "dropped": row[0], "kept": kept[0]})
                else:
                    cur.execute("UPDATE cluster_triage SET key = ? WHERE key = ?", (dst, src))
                    line = ("merge:moved", {"from": src, "to": dst, "status": row[0]})
                cur.execute(_AUDIT_INSERT_P, self._audit_args(now, "system", line[0], dst, "", line[1],
                                                              product="clusters"))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return not kept

    def merged_episodes(self) -> dict[int, int]:
        """{merged episode id: the episode it ended up in} for every merged episode still stored, each followed to
        its last winner (what the work layer reads on every pass, so a crash between the merge and the move of its
        status leaves nothing behind)."""
        with self._lock:
            direct = dict(self._db.execute("SELECT id, merged_into FROM cluster_episodes WHERE merged_into IS NOT NULL"))
        out = {}
        for eid, first in direct.items():
            seen, cur = {eid}, first
            while cur in direct and cur not in seen:
                seen.add(cur)
                cur = direct[cur]
            out[eid] = cur
        return out

    # ---- exceptions ---------------------------------------------------------------------------------------

    def exceptions(self, active_only: bool = True) -> list[dict]:
        q = "SELECT * FROM exceptions" + (" WHERE active = 1" if active_only else "") + " ORDER BY id DESC"
        with self._lock:
            cur = self._db.execute(q)
            cols = [c[0] for c in cur.description]
            rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        now = time.time()
        for r in rows:
            r["expired"] = bool(r["expires"] and r["expires"] < now)
        return [r for r in rows if not (active_only and r["expired"])]

    def add_exception(self, kind: str, rule: str | None, server: str | None, port: str | None, actor: str | None,
                      reason: str, who: str, days: int, pending: bool = False, second: bool = False,
                      verified: bool = False, *, src: str | None = None, dst: str | None = None,
                      proto: str | None = None, win_days: str | None = None, win_from: int | None = None,
                      win_to: int | None = None) -> int:
        """A new exception, active at once, or pending: it counts only once an admin approves it. `second`: it is
        pending because a second person has to approve it whatever the approval setting (credential, exfiltration
        and C2 families, threat intelligence, a wide network). `verified`: Sycope confirmed the proposer's identity (an
        identity nobody confirmed only proposes; the approver must be another confirmed one). The keyword fields are
        a silence rule's (kind "silence"); a service and a host-rule keep their src / dst for the listing."""
        now = time.time()
        if kind == "service" and dst is None:
            dst = server
        if kind in ("host-rule", "host") and src is None:
            src = actor
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO exceptions(kind, rule, server, port, actor, reason, who, created, expires, active, "
                "pending, days, second, verified, src, dst, proto, win_days, win_from, win_to) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (kind, rule, server, port, actor, reason, who, now, now + days * 86400, 0 if pending else 1,
                 int(pending), days, int(second), int(verified), src, dst, proto, win_days, win_from, win_to))
            self._touch()
            return int(cur.lastrowid)

    def exception(self, ex_id: int) -> dict | None:
        with self._lock:
            cur = self._db.execute("SELECT * FROM exceptions WHERE id = ?", (ex_id,))
            row = cur.fetchone()
            return dict(zip([c[0] for c in cur.description], row)) if row else None

    def edit_exception(self, ex_id: int, fields: dict, reason: str, who: str, days: int | None = None) -> dict | None:
        """Change a silence rule in place (its id, author, approval and hit log stay): the fields, the reason and,
        with `days`, the expiry counted from now. Returns the row before the change, None when it is not an active
        or waiting silence rule."""
        keys = ("rule", "src", "dst", "port", "proto", "win_days", "win_from", "win_to")
        now = time.time()
        with self._lock:
            cur = self._db.execute("SELECT * FROM exceptions WHERE id = ? AND kind = 'silence' AND (active = 1 OR "
                                   "pending = 1)", (ex_id,))
            row = cur.fetchone()
            if row is None:
                return None
            before = dict(zip([c[0] for c in cur.description], row))
            sets = [f"{k} = ?" for k in keys] + ["reason = ?", "edited_by = ?", "edited_at = ?"]
            args = [fields.get(k) for k in keys] + [reason, who, now]
            if days is not None:
                sets += ["expires = ?", "days = ?"]
                args += [now + days * 86400, days]
            self._db.execute(f"UPDATE exceptions SET {', '.join(sets)} WHERE id = ?", (*args, ex_id))
            self._touch()
        return before

    def extend_exception(self, ex_id: int, days: int, who: str) -> dict | None:
        """Expiry = now + days for an approved, not removed silence rule, also one that has expired (it counts again
        from the next build). Returns the row before, None when there is no such rule."""
        now = time.time()
        with self._lock:
            cur = self._db.execute("SELECT * FROM exceptions WHERE id = ? AND kind = 'silence' AND active = 1 AND "
                                   "pending = 0", (ex_id,))
            row = cur.fetchone()
            if row is None:
                return None
            before = dict(zip([c[0] for c in cur.description], row))
            self._db.execute("UPDATE exceptions SET expires = ?, days = ?, edited_by = ?, edited_at = ? WHERE id = ?",
                             (now + days * 86400, days, who, now, ex_id))
            self._touch()
        return before

    def pending_exception(self, ex_id: int) -> dict | None:
        with self._lock:
            cur = self._db.execute("SELECT * FROM exceptions WHERE id = ? AND pending = 1", (ex_id,))
            row = cur.fetchone()
            return dict(zip([c[0] for c in cur.description], row)) if row else None

    def pending_exceptions(self) -> list[dict]:
        with self._lock:
            cur = self._db.execute("SELECT * FROM exceptions WHERE pending = 1 ORDER BY id")
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def decide_exception(self, ex_id: int, approve: bool, who: str, note: str) -> dict | None:
        """Approve (active from now, for the days asked) or reject a pending exception."""
        now = time.time()
        with self._lock:
            row = self._db.execute("SELECT days, kind, rule, server, port, actor, src, dst FROM exceptions WHERE id = ? "
                                   "AND pending = 1", (ex_id,)).fetchone()
            if not row:
                return None
            days = min(row[0] or 30, EXC_MAX_DAYS)    # a proposal made under the older 365-day option is cut to the maximum
            self._db.execute("UPDATE exceptions SET pending = 0, active = ?, decided_by = ?, decided_at = ?, "
                             "decision_note = ?, expires = ? WHERE id = ?",
                             (int(approve), who, now, note, now + days * 86400, ex_id))
            self._touch()
        return {"days": days, "kind": row[1], "rule": row[2], "server": row[3], "port": row[4], "actor": row[5],
                "src": row[6], "dst": row[7]}

    def remove_exception(self, ex_id: int, who: str) -> bool:
        with self._lock:
            n = self._db.execute("UPDATE exceptions SET active = 0, removed_by = ?, removed_at = ? WHERE id = ? "
                                 "AND active = 1", (who, time.time(), ex_id)).rowcount
            self._touch()
        return n > 0

    # ---- silence hit log (silence.py) ---------------------------------------------------------------------

    def silence_record(self, hits: dict, now: float | None = None) -> list[tuple[int, str]]:
        """Merge one pass over the window into the hit log. `hits`: {(rule_id, hour): [alerts, hosts (set), first_ms,
        last_ms, sample ids, hosts past the cap]}, counted from the whole window, so a second pass over the same alerts
        writes the same numbers: an hour keeps the larger of what it had and what the pass counted (a window that begins
        mid-hour sees part of that hour), the samples it had first. Returns the (rule, host) pairs seen for the first
        time, oldest first, for the audit's "first silenced" lines."""
        now = time.time() if now is None else now
        new_pairs: list[tuple[int, str]] = []
        if not hits:
            return new_pairs
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                have = {(r[0], r[1]): r for r in cur.execute(
                    "SELECT rule_id, hour, alerts, hosts, host_list, first_ms, last_ms, sample_ids FROM silence_hits "
                    "WHERE hour >= ? AND hour <= ?", (min(h for _, h in hits), max(h for _, h in hits)))}
                ids = ",".join(str(int(i)) for i in {k[0] for k in hits})
                known = {(r[0], r[1]) for r in cur.execute(
                    f"SELECT rule_id, host FROM silence_hosts WHERE rule_id IN ({ids})")}
                rows, hosts_new = [], []
                for (rid, hour), (n, hosts, first, last, samples, extra) in sorted(hits.items()):
                    old = have.get((rid, hour))
                    hl = sorted(hosts)
                    if old:
                        old_hosts = json.loads(old[4] or "[]")
                        hl = sorted(set(old_hosts) | set(hl))[:200]
                        n_alerts = max(old[2], n)
                        first, last = min(old[5] or first, first), max(old[6] or last, last)
                        samples = json.loads(old[7] or "[]") or samples
                        total_hosts = max(old[3] or 0, len(hl) + extra)
                    else:
                        n_alerts, total_hosts = n, len(hl) + extra
                    rows.append((rid, hour, n_alerts, total_hosts, json.dumps(hl), first, last, json.dumps(samples[:20])))
                    for h in hosts:
                        if (rid, h) not in known:
                            known.add((rid, h))
                            hosts_new.append((rid, h, now))
                            new_pairs.append((rid, h))
                cur.executemany("INSERT OR REPLACE INTO silence_hits VALUES (?,?,?,?,?,?,?,?)", rows)
                cur.executemany("INSERT OR IGNORE INTO silence_hosts VALUES (?,?,?)", hosts_new)
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return new_pairs

    def silence_stats(self, now: float | None = None, offset_min: int = 0) -> dict[int, dict]:
        """Per rule: alerts today (the configured local day), 7 days (the last 168 hours) and in total (including what
        the pruning already folded into the rule), the last hit (epoch ms), the distinct hosts of the last 7 days (the
        most the hourly lists kept, so a lower bound on a very busy rule), the first hour recorded, and 14 daily counts
        for a sparkline (oldest first, local days)."""
        now = time.time() if now is None else now
        hour_now = int(now // 3600)
        local_midnight = (int((now + offset_min * 60) // 86400) * 86400) - offset_min * 60
        out: dict[int, dict] = {}
        with self._lock:
            pruned = dict(self._db.execute("SELECT id, COALESCE(pruned_alerts, 0) FROM exceptions"))
            rows = self._db.execute("SELECT rule_id, hour, alerts, hosts, host_list, last_ms FROM silence_hits").fetchall()
        for rid, hour, n, hosts, hl, last in rows:
            o = out.setdefault(rid, {"today": 0, "week": 0, "total": pruned.get(rid, 0), "last": None, "hosts": set(),
                                     "hosts_n": 0, "first_hour": hour, "days": [0] * 14})
            o["total"] += n
            o["first_hour"] = min(o["first_hour"], hour)
            if last and (o["last"] is None or last > o["last"]):
                o["last"] = last
            if hour * 3600 >= local_midnight:
                o["today"] += n
            if hour > hour_now - 168:
                o["week"] += n
                o["hosts"].update(json.loads(hl or "[]"))
                o["hosts_n"] = max(o["hosts_n"], hosts or 0)
            back = int((local_midnight - hour * 3600 + 86399) // 86400) if hour * 3600 < local_midnight else 0
            if back < 14:
                o["days"][13 - back] += n
        for rid, o in out.items():
            o["hosts"] = max(len(o["hosts"]), o["hosts_n"]) if o["hosts"] or o["hosts_n"] else 0
            del o["hosts_n"]
        for rid, v in pruned.items():
            if v and rid not in out:
                out[rid] = {"today": 0, "week": 0, "total": v, "last": None, "hosts": 0, "first_hour": None,
                            "days": [0] * 14}
        return out

    def silence_log(self, rule_id: int, limit: int = 200) -> list[dict]:
        """The hit log of one rule, newest hour first: {hour (epoch s), alerts, hosts, first, last, samples}."""
        with self._lock:
            rows = self._db.execute("SELECT hour, alerts, hosts, first_ms, last_ms, sample_ids FROM silence_hits "
                                    "WHERE rule_id = ? ORDER BY hour DESC LIMIT ?", (rule_id, limit)).fetchall()
        return [{"hour": h * 3600, "alerts": n, "hosts": hs, "first": f, "last": la, "samples": json.loads(sm or "[]")}
                for h, n, hs, f, la, sm in rows]

    def silence_hourly(self, rule_id: int, since_hour: int) -> list[tuple[int, int]]:
        with self._lock:
            return self._db.execute("SELECT hour, alerts FROM silence_hits WHERE rule_id = ? AND hour >= ? ORDER BY hour",
                                    (rule_id, since_hour)).fetchall()

    def silence_prune(self, before: float) -> int:
        """Forget hit hours older than `before` (epoch s; the retention is 90 days). What the rows counted is folded into
        the rule's total first, so the total of a long-lived rule does not fall."""
        hour = int(before // 3600)
        with self._lock:
            for rid, n in self._db.execute("SELECT rule_id, SUM(alerts) FROM silence_hits WHERE hour < ? "
                                           "GROUP BY rule_id", (hour,)).fetchall():
                self._db.execute("UPDATE exceptions SET pruned_alerts = COALESCE(pruned_alerts, 0) + ? WHERE id = ?",
                                 (n, rid))
            n = self._db.execute("DELETE FROM silence_hits WHERE hour < ?", (hour,)).rowcount
            self._db.execute("DELETE FROM silence_hosts WHERE first_at < ? AND rule_id NOT IN (SELECT id FROM exceptions "
                             "WHERE active = 1 AND (expires IS NULL OR expires > ?))", (before, time.time()))
        return n

    # ---- audit --------------------------------------------------------------------------------------------

    def _audit_args(self, at: float, who: str, action: str, target: str, note: str, detail: dict | None,
                    stamp: tuple | None = None, product: str = "triage") -> tuple:
        return (at, who, action, target, note, json.dumps(detail or {}), VERIFIED.get(), *(stamp or self.stamp),
                product)

    def log(self, who: str, action: str, target: str, note: str = "", detail: dict | None = None,
            stamp: tuple[int | None, str | None] | None = None, product: str = "triage") -> None:
        """One audit line, stamped with the live (config_version, profile_day), or with `stamp` when the line belongs
        to another version than the one the last rebuild stamped (the activation of a configuration)."""
        with self._lock:
            self._db.execute(_AUDIT_INSERT_P,
                             self._audit_args(time.time(), who, action, target, note, detail, stamp, product))

    def audit(self, target: str | None = None, limit: int = 100, full: bool = False,
              product: str | None = "triage") -> list[dict]:
        """Newest first. `full` shows the note and detail of configuration lines (REDACTED_PREFIXES): admins only.
        `product` None reads every product's lines."""
        where: list[str] = ["target = ?"] if target else []
        args: list = [target] if target else []
        _only(product, where, args)
        q = f"SELECT {_AUDIT_COLS} FROM audit" + (" WHERE " + " AND ".join(where) if where else "")
        q += " ORDER BY id DESC LIMIT ?"
        args.append(limit)
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        return [_audit_row(r, full) for r in rows]

    def audit_scope(self, scope: str, legacy_key: str | None = None, limit: int = 60,
                    full: bool = False, product: str | None = "triage") -> list[dict]:
        """The lines a group action wrote for the group as a whole: scope "s:<story key>" or "c:<network>" (for a
        story also the older op=story lines, which carry its key). Newest first."""
        def like(field: str, value: str) -> str:
            v = json.dumps(value).replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            return f'%"{field}": {v}%'

        groupwide = ("((action LIKE 'hosts:%' OR action = 'comment' OR action LIKE 'step:%') AND detail LIKE ? "
                     "ESCAPE '\\')")
        where, args = [groupwide], [like("scope", scope)]
        if legacy_key:
            where.append("(action LIKE 'story:%' AND detail LIKE ? ESCAPE '\\')")
            args.append(like("key", legacy_key))
        cond, cargs = ["(" + " OR ".join(where) + ")"], list(args)
        _only(product, cond, cargs)
        with self._lock:
            rows = self._db.execute(f"SELECT {_AUDIT_COLS} FROM audit WHERE " + " AND ".join(cond) +
                                    " ORDER BY id DESC LIMIT ?", [*cargs, limit]).fetchall()
        return [_audit_row(r, full) for r in rows]

    def audit_query(self, who: str = "", action: str = "", q: str = "", since: float = 0, bulk: bool = False,
                    limit: int = 200, offset: int = 0, full: bool = False,
                    product: str | None = "triage") -> tuple[list[dict], int]:
        """Filtered audit rows (newest first) and the total that matched. bulk=False leaves out the per-host lines
        a story action writes (the story's own line stays). Without `full` the note of a configuration line is
        hidden and q does not search it, so counts cannot give it away either."""
        where, args = ["at >= ?"], [since]
        _only(product, where, args)
        if who:
            where.append("who = ?")
            args.append(who)
        if action:
            where.append("action LIKE ?")
            args.append(action + "%")
        if q:
            where.append("(target LIKE ? OR (note LIKE ?" + ("" if full else f" AND {_REDACTED_SQL}") +
                         ") OR who LIKE ?)")
            args += [f"%{q}%"] * 3
        if not bulk:
            where.append("(detail NOT LIKE '%\"story\": \"%' OR detail IS NULL)")
        cond = " WHERE " + " AND ".join(where)
        with self._lock:
            total = self._db.execute("SELECT COUNT(*) FROM audit" + cond, args).fetchone()[0]
            rows = self._db.execute(f"SELECT {_AUDIT_COLS} FROM audit" + cond +
                                    " ORDER BY id DESC LIMIT ? OFFSET ?", [*args, limit, offset]).fetchall()
        return ([_audit_row(r, full) for r in rows], total)

    def audit_facets(self) -> dict:
        """Who acted and which actions exist, over both products (the audit tab shows both)."""
        with self._lock:
            who = [r[0] for r in self._db.execute("SELECT DISTINCT who FROM audit ORDER BY who").fetchall()]
            act = [r[0] for r in self._db.execute("SELECT DISTINCT action FROM audit ORDER BY action").fetchall()]
        return {"who": who, "actions": act}

    # ---- the incident history ------------------------------------------------------------------------------

    @staticmethod
    def _inc(row: tuple, cols: list[str]) -> dict:
        d = dict(zip(cols, row, strict=True))
        for k in _JSON:
            if k in d:
                d[k] = json.loads(d[k]) if d[k] else ([] if k in ("families", "chains", "events") else {})
        return d

    def _inc_select(self, where: str = "", args: tuple | list = (), tail: str = "", light: bool = False) -> list[dict]:
        cols = ["id", *(c for c in _INC_COLS if not (light and c in ("snapshot", "events", "search")))]
        rows = self._db.execute(f"SELECT {', '.join(cols)} FROM incidents {where} {tail}", list(args)).fetchall()
        return [self._inc(r, cols) for r in rows]

    def open_incidents(self, product: str | None = "triage") -> list[dict]:
        """The open incidents with their members (a set of entity keys), for the recorder."""
        where, args = ["status = 'open'"], []
        _only(product, where, args)
        cond = " AND ".join(where)
        with self._lock:
            out = self._inc_select("WHERE " + cond, args, light=False)
            mem: dict[int, set] = {}
            for iid, ent in self._db.execute("SELECT incident_id, entity FROM incident_members WHERE incident_id IN "
                                             f"(SELECT id FROM incidents WHERE {cond})", args):
                mem.setdefault(iid, set()).add(ent)
        for o in out:
            o["members"] = mem.get(o["id"], set())
        return out

    def sla_rows(self, since: float = 0.0, product: str | None = "triage") -> list[dict]:
        """The top-level incidents the SLA reads (sla.py), light: the open ones and those opened, ended or handled
        since `since`. No snapshot, no members; the events carry the clock and the analyst's actions. Cached until the
        next write to the incidents, the steps, the log or the statuses (every board's refresh and every analyst action
        is one), so the requests of one board share one read; the rows are shared: read-only for the caller."""
        return self.memoized(("sla", product, since), self.gen, lambda: self._read_sla_rows(since, product))

    def _read_sla_rows(self, since: float, product: str | None) -> list[dict]:
        cols = ["id", "kind", "subject", "label", "ui_key", "parent", "opened_at", "last_seen", "closed_at",
                "verdict_peak", "verdict_last", "status", "outcome", "outcome_by", "outcome_at", "end_reason", "events",
                "chains", "peak_at", "reopened_at"]
        where = ["parent IS NULL", ("(status = 'open' OR opened_at >= ? OR COALESCE(closed_at, 0) >= ? "
                                    "OR COALESCE(outcome_at, 0) >= ?)")]
        args: list = [since, since, since]
        _only(product, where, args)
        with self._lock:
            rows = self._db.execute(f"SELECT {', '.join(cols)} FROM incidents WHERE {' AND '.join(where)} "
                                    "ORDER BY id", args).fetchall()
        out = []
        for r in rows:
            d = dict(zip(cols, r, strict=True))
            for k in ("events", "chains"):
                d[k] = json.loads(d[k]) if d[k] else []
            out.append(d)
        return out

    def apply_incidents(self, creates: list[tuple[dict, list[str]]],
                        updates: list[tuple[int, dict, list[str]]]) -> list[int]:
        """One transaction: new incidents (fields, members) and changes to open ones (id, fields, new members).
        Returns the ids of the new incidents."""
        def enc(d: dict) -> dict:
            return {k: (json.dumps(v) if k in _JSON and v is not None else v) for k, v in d.items() if k in _INC_COLS}

        ids = []
        seen = False      # whether a field the remembered decisions read changed (store.DECISION_FIELDS)
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                for fields_, members in creates:
                    f = enc(fields_)
                    seen = seen or f.get("status", "open") != "open" or bool(f.get("outcome"))
                    cur.execute(f"INSERT INTO incidents({', '.join(f)}) VALUES ({', '.join('?' * len(f))})",
                                list(f.values()))
                    iid = cur.lastrowid
                    ids.append(iid)
                    cur.executemany("INSERT OR IGNORE INTO incident_members VALUES (?, ?)", [(iid, m) for m in members])
                for iid, fields_, members in updates:
                    f = enc(fields_)
                    seen = seen or bool(members) or not DECISION_FIELDS.isdisjoint(f)
                    if f:
                        cur.execute(f"UPDATE incidents SET {', '.join(k + ' = ?' for k in f)} WHERE id = ?",
                                    [*f.values(), iid])
                    if members:
                        cur.executemany("INSERT OR IGNORE INTO incident_members VALUES (?, ?)",
                                        [(iid, m) for m in members])
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                self._touch(decision=seen)
        return ids

    def history_query(self, since: float = 0, kind: str = "", verdict: str = "", outcome: str = "", q: str = "",
                      limit: int = 100, offset: int = 0, product: str | None = "triage") -> tuple[list[dict], int]:
        """Incidents opened since `since` or still open, newest first, filtered; and how many matched. The search
        goes over the subject, its identifiers, the headline, the families and the member entities."""
        where, args = ["(opened_at >= ? OR status = 'open')"], [since]
        _only(product, where, args)
        if kind:
            where.append("kind = ?")
            args.append(kind)
        if verdict:
            where.append("verdict_peak = ?")
            args.append(verdict)
        if outcome == "open":
            where.append("status = 'open' AND outcome IS NULL")
        elif outcome == "none":
            where.append("outcome IS NULL")
        elif outcome:
            where.append("outcome = ?")
            args.append(outcome)
        if q:
            like = "%" + q.lower().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
            where.append("(search LIKE ? ESCAPE '\\' OR id IN (SELECT incident_id FROM incident_members "
                         "WHERE entity LIKE ? ESCAPE '\\'))")
            args += [like, like]
        cond = "WHERE " + " AND ".join(where)
        with self._lock:
            total = self._db.execute("SELECT COUNT(*) FROM incidents " + cond, args).fetchone()[0]
            rows = self._inc_select(cond, [*args, limit, offset], "ORDER BY opened_at DESC, id DESC LIMIT ? OFFSET ?",
                                    light=True)
        return rows, total

    def history_rows(self, since: float = 0, product: str | None = "triage") -> list[dict]:
        """The light rows of every incident opened since `since` (for the numbers above the list)."""
        where, args = ["(opened_at >= ? OR status = 'open')"], [since]
        _only(product, where, args)
        with self._lock:
            return self._inc_select("WHERE " + " AND ".join(where), args, light=True)

    def history_changed(self, since: float, product: str | None = "triage") -> list[dict]:
        """The light rows of every incident that opened, was handled or closed since `since`, or is open."""
        where, args = ["(opened_at >= ? OR status = 'open' OR closed_at >= ? OR outcome_at >= ?)"], [since] * 3
        _only(product, where, args)
        with self._lock:
            return self._inc_select("WHERE " + " AND ".join(where), args, "ORDER BY opened_at DESC", light=True)

    def unreviewed(self, since: float, product: str | None = "triage") -> list[dict]:
        """Top-level incidents that peaked at Act now or Investigate, went quiet and closed with nobody having
        looked at them (closed since `since`), newest first."""
        where = [("status = 'closed' AND outcome = 'expired' AND end_reason = 'quiet' AND parent IS NULL AND "
                  "verdict_peak IN ('act', 'investigate') AND closed_at >= ?")]
        args: list = [since]
        _only(product, where, args)
        with self._lock:
            return self._inc_select("WHERE " + " AND ".join(where), args, "ORDER BY closed_at DESC", light=True)

    def taken_records(self, product: str | None = "triage") -> list[dict]:
        """Ended incidents (closed, quiet, top level) that an analyst took or escalated after they ended (the
        outcome is later than the close: a group taken while live and closed since is not one), newest first. No
        age limit: work taken stays until someone closes it."""
        where, args = [_TAKEN], []
        _only(product, where, args)
        with self._lock:
            return self._inc_select("WHERE " + " AND ".join(where), args, "ORDER BY outcome_at DESC", light=True)

    def team_activity(self, since: float, product: str | None = "triage") -> list[tuple[float, str]]:
        """When the team did something and who (any audit line), newest first."""
        where, args = ["at >= ?"], [since]
        _only(product, where, args)
        with self._lock:
            return self._db.execute("SELECT at, who FROM audit WHERE " + " AND ".join(where) + " ORDER BY at DESC",
                                    args).fetchall()

    def audit_first(self, ignore_who: tuple = (), ignore_prefix: str = "",
                    product: str | None = "triage") -> float | None:
        """When the oldest audit line was written (how far back the team's rhythm can be read), leaving out the
        lines of the given authors and of authors starting with `ignore_prefix` (the service's own lines). One
        product's lines by default: the Triage team's rhythm does not start when Clusters is first used."""
        where: list[str] = []
        args: list = []
        _only(product, where, args)
        q = "SELECT MIN(at) FROM audit WHERE 1" + "".join(f" AND {w}" for w in where)
        if ignore_who:
            q += f" AND COALESCE(who, '') NOT IN ({','.join('?' * len(ignore_who))})"
            args += list(ignore_who)
        if ignore_prefix:
            q += " AND COALESCE(who, '') NOT LIKE ? ESCAPE '\\'"
            args.append(ignore_prefix.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%")
        with self._lock:
            return self._db.execute(q, args).fetchone()[0]

    def incident_facts(self, product: str | None = "triage") -> list[dict]:
        """Every stored incident, light: id, kind, subject, status, outcome, verdict_peak, opened_at, last_seen,
        closed_at and its member entities (sorted). What the learner needs to leave incident hosts out."""
        where, args = [], []
        _only(product, where, args)
        cond = " WHERE " + where[0] if where else ""
        with self._lock:
            rows = self._db.execute("SELECT id, kind, subject, status, outcome, verdict_peak, opened_at, last_seen, "
                                    f"closed_at FROM incidents{cond} ORDER BY id", args).fetchall()
            mem: dict[int, list] = {}
            for iid, ent in self._db.execute("SELECT incident_id, entity FROM incident_members "
                                             f"WHERE incident_id IN (SELECT id FROM incidents{cond}) "
                                             "ORDER BY incident_id, entity", args):
                mem.setdefault(iid, []).append(ent)
        cols = ("id", "kind", "subject", "status", "outcome", "verdict_peak", "opened_at", "last_seen", "closed_at")
        return [{**dict(zip(cols, r, strict=True)), "members": mem.get(r[0], [])} for r in rows]

    def incident(self, iid: int, product: str | None = None) -> dict | None:
        """One incident by id, with its members. `product` set: only if it is that product's (an id of the other
        product is not found), so a page of one product never opens the other's record."""
        where, args = ["id = ?"], [iid]
        _only(product, where, args)
        with self._lock:
            rows = self._inc_select("WHERE " + " AND ".join(where), args)
            mem = [r[0] for r in self._db.execute("SELECT entity FROM incident_members WHERE incident_id = ? "
                                                  "ORDER BY entity", (iid,))]
        if not rows:
            return None
        rows[0]["members"] = mem
        return rows[0]

    def incidents_of(self, entity: str, limit: int = 20, product: str | None = "triage") -> list[dict]:
        """Every incident about an entity or with it among its members, newest first."""
        where, args = ["(subject = ? OR id IN (SELECT incident_id FROM incident_members WHERE entity = ?))"], [entity, entity]
        _only(product, where, args)
        with self._lock:
            return self._inc_select("WHERE " + " AND ".join(where), [*args, max(1, limit)],
                                    "ORDER BY opened_at DESC LIMIT ?", light=True)

    def steps(self, incident_id: int, product: str | None = None) -> dict[str, dict]:
        """The next steps an analyst checked on an incident: step id -> who, when. `product` set: none for an
        incident of the other product."""
        q, args = "SELECT step, done, who, at, title FROM incident_steps WHERE incident_id = ?", [incident_id]
        if product is not None:
            q += " AND incident_id IN (SELECT id FROM incidents WHERE product = ?)"
            args.append(product)
        with self._lock:
            rows = self._db.execute(q, args).fetchall()
        return {s: {"done": bool(d), "who": w, "at": a, "title": t} for s, d, w, a, t in rows}

    def set_step(self, incident_id: int, step: str, done: bool, who: str, title: str, log: tuple,
                 product: str = "triage") -> None:
        """Check or uncheck one step, with its audit line, in one transaction."""
        now = time.time()
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                cur.execute("INSERT OR REPLACE INTO incident_steps VALUES (?,?,?,?,?,?)",
                            (incident_id, step, int(done), who, now, title))
                w, action, target, n, detail = log
                cur.execute(_AUDIT_INSERT_P, self._audit_args(now, w, action, target, n, detail, product=product))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                self._touch(decision=False)

    def open_incident_by_key(self, ui_key: str, product: str | None = "triage") -> dict | None:
        where, args = ["status = 'open' AND ui_key = ?"], [ui_key]
        _only(product, where, args)
        with self._lock:
            rows = self._inc_select("WHERE " + " AND ".join(where), args, "ORDER BY id DESC LIMIT 1")
        return rows[0] if rows else None

    def prune_incidents(self, before: float, product: str | None = "triage") -> int:
        where, args = ["status = 'closed' AND COALESCE(closed_at, last_seen) < ? AND NOT (" + _TAKEN + ")"], [before]
        _only(product, where, args)
        with self._lock:
            old = [r[0] for r in self._db.execute("SELECT id FROM incidents WHERE " + " AND ".join(where), args)]
            for i in range(0, len(old), 500):
                part = old[i:i + 500]
                marks = ",".join("?" * len(part))
                self._db.execute(f"DELETE FROM incident_members WHERE incident_id IN ({marks})", part)
                self._db.execute(f"DELETE FROM incident_steps WHERE incident_id IN ({marks})", part)
                self._db.execute(f"DELETE FROM incidents WHERE id IN ({marks})", part)
            if old:
                self._touch()
        return len(old)

    # ---- the system's own decisions -------------------------------------------------------------------------

    def log_verdicts(self, rows: list[tuple]) -> None:
        """(at, ip, kind, verdict, prev, reason, conf, detail dict[, product]) in one transaction, stamped with the
        live config_version and profile_day."""
        if not rows:
            return
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                cur.executemany("INSERT INTO verdict_log(at, ip, kind, verdict, prev, reason, conf, detail, "
                                "config_version, profile_day, product) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                                [(*r[:7], json.dumps(r[7] or {}), *self.stamp, r[8] if len(r) > 8 else "triage")
                                 for r in rows])
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                self._touch()

    def last_verdicts(self, product: str | None = "triage") -> dict[str, str]:
        """The newest logged verdict per host (what the service last said about it, across restarts)."""
        where, args = ["kind != 'reopened'"], []
        _only(product, where, args)
        with self._lock:
            rows = self._db.execute("SELECT ip, verdict FROM verdict_log WHERE id IN (SELECT MAX(id) FROM verdict_log "
                                    "WHERE " + " AND ".join(where) + " GROUP BY ip)", args).fetchall()
        return dict(rows)

    _VRANK_SQL = "CASE {c} WHEN 'act' THEN 3 WHEN 'investigate' THEN 2 WHEN 'review' THEN 1 WHEN 'watch' THEN 0 END"

    def verdict_window(self, w: float, product: str | None = "triage") -> VerdictWindow:
        """What the verdict log says about every host since `w` (see VerdictWindow), cached until the next write to the
        log or to the incidents. One grouped scan of the table and one range read of the rows since `w`."""
        return self.memoized(("vwin", product, w), self.decision_gen, lambda: self._read_verdict_window(w, product))

    def _read_verdict_window(self, w: float, product: str | None) -> VerdictWindow:
        where, args = ["kind != 'reopened'"], []
        _only(product, where, args)
        base = " AND ".join(where)
        rank = self._VRANK_SQL.format(c="verdict")
        with self._lock:
            # per host: the newest row, when the verdict last changed (a held row counts only when it moved it) and the
            # newest row before the window; joined back to the rows for their verdict, kind and rank
            got = self._db.execute(
                "SELECT g.ip, l.verdict, l.kind, g.changed, g.pre_at, " + self._VRANK_SQL.format(c="p.verdict") + " "
                "FROM (SELECT ip, MAX(id) AS last_id, MAX(CASE WHEN kind != 'held' OR COALESCE(prev, '') != "
                "COALESCE(verdict, '') THEN at END) AS changed, MAX(CASE WHEN at < ? THEN id END) AS pre_id, "
                "MAX(CASE WHEN at < ? THEN at END) AS pre_at "
                f"FROM verdict_log WHERE {base} GROUP BY ip) g "
                "JOIN verdict_log l ON l.id = g.last_id LEFT JOIN verdict_log p ON p.id = g.pre_id",
                [w, w, *args]).fetchall()
            rows = self._db.execute(f"SELECT ip, at, {rank} FROM verdict_log WHERE {base} AND at >= ? ORDER BY id",
                                    [*args, w]).fetchall()
        last = {ip: (v, k) for ip, v, k, _c, _a, _r in got}
        changed = {ip: c for ip, _v, _k, c, _a, _r in got if c}
        pre = {ip: (a, r) for ip, _v, _k, _c, a, r in got if a is not None and r is not None}
        log: dict[str, list] = {}
        for ip, at, r in rows:
            log.setdefault(ip, []).append((at, -1 if r is None else r))
        return VerdictWindow(w, last, changed, pre, {ip: tuple(v) for ip, v in log.items()})

    def verdict_state(self, since: float, product: str | None = "triage",
                      analyst: dict | None = None) -> dict[str, dict]:
        """Per host, what the hysteresis (evidence.apply_hold) needs of the verdict log: the verdict last shown
        (`verdict`, with the `kind` of that row), when it last changed (`changed_at`: entered, escalated,
        de-escalated, left, or a held row that moved it) and the highest verdict rank shown since `since`
        (`shown`: the verdict in force at `since` and every verdict logged after it; -1 none). One read, grouped
        scans; a restart gives the same answer as the process that wrote the rows. `analyst` (host -> time of the
        analyst's last action): for such a host `shown` counts only the rows logged after the action, whatever its
        age, never the verdict in force before it, so a release stays a release."""
        win = self.verdict_window(since, product)
        analyst = analyst or {}
        return {ip: {"verdict": v, "kind": k, "changed_at": win.changed.get(ip) or 0.0,
                     "shown": win.shown(ip, since, analyst.get(ip, 0.0))} for ip, (v, k) in win.last.items()}

    def held_verdicts(self, product: str | None = "triage") -> dict[str, str]:
        """The hosts whose newest verdict row is a hold, with the verdict it kept them at (live.py seeds from it)."""
        where, args = ["kind != 'reopened'"], []
        _only(product, where, args)
        with self._lock:
            rows = self._db.execute("SELECT ip, verdict FROM verdict_log WHERE kind = 'held' AND id IN (SELECT MAX(id) "
                                    "FROM verdict_log WHERE " + " AND ".join(where) + " GROUP BY ip)", args).fetchall()
        return dict(rows)

    def decision_facts(self, since: float, product: str | None = "triage") -> list[dict]:
        """The incidents that opened, closed or were decided since `since`, light, with their member entities: what
        the habit days and the recurrence count read (memory.py)."""
        where, args = [("id IN (SELECT id FROM incidents WHERE opened_at >= ? UNION SELECT id FROM incidents WHERE "
                        "closed_at >= ? UNION SELECT id FROM incidents WHERE outcome_at >= ?)")], [since] * 3
        _only(product, where, args)
        cond = " AND ".join(where)
        cols = ("id", "kind", "subject", "parent", "status", "outcome", "end_reason", "verdict_peak", "opened_at",
                "last_seen", "closed_at", "outcome_at")
        with self._lock:
            rows = self._db.execute(f"SELECT {', '.join(cols)} FROM incidents WHERE {cond}", args).fetchall()
            mem: dict[int, list] = {}
            for iid, ent in self._db.execute("SELECT incident_id, entity FROM incident_members WHERE incident_id IN "
                                             f"(SELECT id FROM incidents WHERE {cond})", args):
                mem.setdefault(iid, []).append(ent)
        return [{**dict(zip(cols, r, strict=True)), "members": mem.get(r[0], [])} for r in rows]

    def prune_verdicts(self, before: float, product: str | None = "triage") -> int:
        where, args = ["at < ?"], [before]
        _only(product, where, args)
        with self._lock:
            n = self._db.execute("DELETE FROM verdict_log WHERE " + " AND ".join(where), args).rowcount
            self._touch()
            return n

    def reopened_keys(self, product: str | None = "triage") -> set[tuple]:
        where, args = ["kind = 'reopened'"], []
        _only(product, where, args)
        with self._lock:
            rows = self._db.execute("SELECT ip, detail FROM verdict_log WHERE " + " AND ".join(where), args).fetchall()
        return {(ip, json.loads(d or "{}").get("handled_at")) for ip, d in rows}

    def verdict_history(self, ip: str, limit: int = 100, product: str | None = "triage") -> list[dict]:
        where, args = ["ip = ?"], [ip]
        _only(product, where, args)
        with self._lock:
            rows = self._db.execute("SELECT at, kind, verdict, prev, reason, conf, detail FROM verdict_log "
                                    "WHERE " + " AND ".join(where) + " ORDER BY id DESC LIMIT ?",
                                    [*args, limit]).fetchall()
        return [{"at": a, "kind": k, "verdict": v, "prev": p, "reason": r, "conf": c, "detail": json.loads(d or "{}")}
                for a, k, v, p, r, c, d in rows]

    # ---- the environment profile (profile.py) -------------------------------------------------------------

    def put_profile(self, day: str, body: dict, at: float | None = None) -> bool:
        """Store the profile learned for a day (replacing that day's earlier one). A frozen snapshot is never
        replaced: False then."""
        with self._lock:
            cur = self._db.execute(
                "INSERT INTO profile_snapshots(day, body, frozen, at, vals) VALUES (?,?,0,?,?) ON CONFLICT(day) DO "
                "UPDATE SET body = excluded.body, at = excluded.at, vals = excluded.vals WHERE frozen = 0",
                (day, json.dumps(body, sort_keys=True, separators=(",", ":")), time.time() if at is None else at,
                 _values_of(body)))
            return cur.rowcount > 0

    def profile(self, day: str | None = None) -> dict | None:
        """The snapshot of one day, or (no day) the one in use: the frozen one when an admin froze one, else the
        newest. The body with "frozen" set from the row."""
        q = ("SELECT body, frozen FROM profile_snapshots WHERE day = ?" if day is not None else
             "SELECT body, frozen FROM profile_snapshots ORDER BY frozen DESC, day DESC LIMIT 1")
        with self._lock:
            row = self._db.execute(q, (day,) if day is not None else ()).fetchone()
        if not row:
            return None
        return {**json.loads(row[0]), "frozen": bool(row[1])}

    def profile_values(self, pid: str) -> list[tuple[str, object]]:
        """(day, value) of a learned parameter in every stored daily snapshot, oldest first (days without it left
        out)."""
        with self._lock:     # the small values column only: a body is ~10 MB at 50k hosts, 37 of them kept
            rows = self._db.execute("SELECT day, vals FROM profile_snapshots ORDER BY day").fetchall()
        out = []
        for day, vals in rows:
            v = json.loads(vals or "{}").get(pid)
            if v is not None:
                out.append((day, v))
        return out

    def profile_days(self) -> list[tuple[str, bool]]:
        """(day, frozen) of every stored snapshot, oldest first."""
        with self._lock:
            return [(d, bool(f)) for d, f in self._db.execute("SELECT day, frozen FROM profile_snapshots ORDER BY day")]

    def freeze_profile(self, frozen: bool) -> str | None:
        """Freeze the newest snapshot (it stays in use while learning goes on; freezing again keeps the one already
        frozen), or unfreeze. The day it concerned, None when there was nothing to freeze or unfreeze."""
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                if frozen:   # already frozen: that one stays (a second freeze does not move it)
                    row = cur.execute("SELECT day FROM profile_snapshots WHERE frozen = 1 ORDER BY day DESC "
                                      "LIMIT 1").fetchone()
                    if not row:
                        row = cur.execute("SELECT day FROM profile_snapshots ORDER BY day DESC LIMIT 1").fetchone()
                        if row:
                            cur.execute("UPDATE profile_snapshots SET frozen = 1 WHERE day = ?", (row[0],))
                else:
                    row = cur.execute("SELECT day FROM profile_snapshots WHERE frozen = 1 ORDER BY day DESC "
                                      "LIMIT 1").fetchone()
                    cur.execute("UPDATE profile_snapshots SET frozen = 0 WHERE frozen = 1")
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return row[0] if row else None

    # ---- crown jewels and suggestion answers (crown.py) -----------------------------------------------------

    def crown_rows(self) -> list[dict]:
        """Every crown jewel row, removed ones too, by entity."""
        with self._lock:
            cur = self._db.execute("SELECT entity, source, reason, who, at, active, removed_by, removed_at FROM crown "
                                   "ORDER BY entity")
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def crown_put(self, entity: str, source: str, reason: str, who: str, at: float) -> None:
        """Add a crown jewel, or bring a removed one back (a new interval). Adding one that is active keeps its
        first `at`."""
        with self._lock:
            self._db.execute(
                "INSERT INTO crown(entity, source, reason, who, at, active) VALUES (?,?,?,?,?,1) ON CONFLICT(entity) "
                "DO UPDATE SET source = excluded.source, reason = excluded.reason, who = excluded.who, "
                "at = CASE WHEN crown.active = 1 THEN crown.at ELSE excluded.at END, active = 1, removed_by = NULL, "
                "removed_at = NULL", (entity, source, reason, who, at))

    def crown_import(self, entity: str, source: str, reason: str, who: str, at: float) -> bool:
        """Add a crown jewel only when the entity has no row yet (removed ones count): True when added."""
        with self._lock:
            return self._db.execute("INSERT OR IGNORE INTO crown(entity, source, reason, who, at, active) "
                                    "VALUES (?,?,?,?,?,1)", (entity, source, reason, who, at)).rowcount > 0

    def crown_remove(self, entity: str, who: str, at: float) -> bool:
        """Remove an active crown jewel; the closed interval goes to `crown_history`."""
        with self._lock:
            row = self._db.execute("SELECT source, reason, who, at FROM crown WHERE entity = ? AND active = 1",
                                   (entity,)).fetchone()
            if row is None:
                return False
            self._db.execute("UPDATE crown SET active = 0, removed_by = ?, removed_at = ? WHERE entity = ?",
                             (who, at, entity))
            self._db.execute("INSERT INTO crown_history(entity, source, reason, who, added_at, removed_at, "
                             "removed_by) VALUES (?,?,?,?,?,?,?)", (entity, *row, at, who))
            return True

    def crown_history(self) -> list[dict]:
        """The closed intervals of crown jewels, oldest first."""
        with self._lock:
            cur = self._db.execute("SELECT entity, source, reason, who, added_at, removed_at, removed_by FROM "
                                   "crown_history ORDER BY added_at, entity")
            cols = [c[0] for c in cur.description]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def answer_put(self, key: str, answer: str, who: str, at: float, evidence: str) -> None:
        with self._lock:
            self._db.execute("INSERT OR REPLACE INTO suggestion_answers(key, answer, who, at, evidence) "
                             "VALUES (?,?,?,?,?)", (key, answer, who, at, evidence))

    def answers(self) -> dict[str, dict]:
        """key -> {answer, who, at, evidence} of every answered suggestion."""
        with self._lock:
            rows = self._db.execute("SELECT key, answer, who, at, evidence FROM suggestion_answers ORDER BY key")
            return {k: {"answer": a, "who": w, "at": t, "evidence": e} for k, a, w, t, e in rows.fetchall()}

    def answers_stamp(self) -> tuple[int, float]:
        """(number of answers, newest answer time): changes whenever an answer is given or changed."""
        with self._lock:
            n, t = self._db.execute("SELECT COUNT(*), COALESCE(MAX(at), 0) FROM suggestion_answers").fetchone()
        return int(n), float(t)

    def meta(self, key: str, value: str | None = None) -> str | None:
        with self._lock:
            if value is not None:
                self._db.execute("INSERT OR REPLACE INTO meta VALUES (?,?)", (key, value))
                return value
            row = self._db.execute("SELECT v FROM meta WHERE k = ?", (key,)).fetchone()
        return row[0] if row else None

    # ---- the configuration plane (confplane.py) -----------------------------------------------------------

    @staticmethod
    def _config_row(r: tuple, body: bool = True) -> dict:
        d = {"id": r[0], "created_at": r[1], "who": r[2], "note": r[3], "parent_id": r[4], "status": r[5],
             "schema_version": r[7]}
        if body:
            d["body"] = json.loads(r[6])
        return d

    def add_config(self, who: str, note: str, parent_id: int | None, status: str, body: dict, schema_version: int,
                   now: float | None = None) -> int:
        with self._lock:
            cur = self._db.execute("INSERT INTO config_versions(created_at, who, note, parent_id, status, body, "
                                   "schema_version) VALUES (?,?,?,?,?,?,?)",
                                   (time.time() if now is None else now, who, note, parent_id, status,
                                    json.dumps(body, sort_keys=True, separators=(",", ":")), schema_version))
            return cur.lastrowid

    def prune_drafts(self, before: float) -> int:
        """Delete drafts created before `before` that were never published (previews nobody went on with). A
        published or retired version, and the one in force, are never touched."""
        active = self.active_config_id() or 0
        with self._lock:
            return self._db.execute("DELETE FROM config_versions WHERE status = 'draft' AND created_at < ? AND id != ?",
                                    (before, active)).rowcount

    def config(self, vid: int) -> dict | None:
        with self._lock:
            r = self._db.execute("SELECT id, created_at, who, note, parent_id, status, body, schema_version "
                                 "FROM config_versions WHERE id = ?", (vid,)).fetchone()
        return self._config_row(r) if r else None

    def configs(self, limit: int = 50, with_body: bool = False) -> list[dict]:
        """The versions, newest first (without their bodies unless asked)."""
        with self._lock:
            rows = self._db.execute("SELECT id, created_at, who, note, parent_id, status, body, schema_version "
                                    "FROM config_versions ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [self._config_row(r, with_body) for r in rows]

    def active_config_id(self) -> int | None:
        v = self.meta("config_active")
        return int(v) if v else None

    def activate_config(self, vid: int) -> bool:
        """One transaction: the draft `vid` becomes published and active, the version that was published becomes
        retired. False (nothing changed) when `vid` does not exist or is not a draft."""
        with self._lock:
            cur = self._db.cursor()
            cur.execute("BEGIN")
            try:
                ok = cur.execute("UPDATE config_versions SET status = 'published' WHERE id = ? AND status = 'draft'",
                                 (vid,)).rowcount == 1
                if ok:
                    cur.execute("UPDATE config_versions SET status = 'retired' WHERE status = 'published' "
                                "AND id != ?", (vid,))
                    cur.execute("INSERT OR REPLACE INTO meta VALUES ('config_active', ?)", (str(vid),))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        return ok
