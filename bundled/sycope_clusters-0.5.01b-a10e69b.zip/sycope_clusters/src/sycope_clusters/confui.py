"""The Configuration tab of the Triage page (spec 7): CSS and JS that ui.py builds into the page.

Nothing here is served as markup. The page asks /whoami with its pass; only when Sycope says admin does it show the
tab, and the cards are drawn from the admin-only JSON routes (/config, /profile, /crown, /catalog, /exceptions).
Every change to the configuration is drafted in the browser, then goes draft -> /config-preview (the diff of the
incidents that would change) -> publish; the ops of Task 14 do the writing, the service checks the pass again.

The JS runs inside the IIFE of ui.py (it uses its helpers: $, esc, num, post, dlg, toast, toastUndo, laneTable ...).
"""

from sycope_clusters.profile import WANT_DAYS

CSS = """
.modb{display:inline-flex;align-items:center;height:22px;padding:0 9px;margin-right:8px;border:0;border-radius:11px;background:#423812;color:#ffd700;font:600 11px/1 "Kumbh Sans",sans-serif;letter-spacing:.3px;text-transform:uppercase;cursor:pointer}
.pbn{margin:0 0 10px;padding:8px 12px;border-radius:5px;background:#17325a;color:#cfe3ff;font-size:13px}.pbn b{color:#fff}
.cfg .lead1{margin-bottom:6px}.cfbar{position:sticky;top:0;z-index:7;display:flex;flex-wrap:wrap;align-items:center;gap:8px 10px;margin:0 0 4px;padding:9px 12px;border:1px solid #c9a05b88;border-radius:6px;background:#2a2748;box-shadow:0 6px 18px #0007}
.cfbar .sp{flex:1}.cfbar b{color:#ffd98a}.cfhead{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;margin:0 0 10px;color:#cfd4e6;font-size:13px}.cfhead .sp{flex:1}
.cfb h4{margin:16px 0 6px;font-size:13px;font-weight:600;color:#fff;text-transform:none;letter-spacing:0}.cfb h4 .mut{font-weight:400}
.cfb .qt.lt td{vertical-align:top}.cfb .qt{min-width:0}.cfin{width:130px;height:30px;padding:0 8px;border:1px solid var(--panel2);border-radius:4px;background:var(--panel);color:#fff;font:13px "Roboto Mono",monospace}
.cfin.bad{border-color:var(--bad);background:var(--badbg)}.cfin.txt{width:220px}tr.cfchg td{background:#2c2a14}tr.cfchg td:first-child{box-shadow:inset 4px 0 0 #e5c100}
.cfl{margin:6px 0 10px;padding-left:18px;font-size:13px}.cfl li{margin:0 0 3px}.cfb .fold{margin:8px 0 0}.cfb .fold>summary{color:#fff;font-size:13.5px}
.cfb .fold .qwrap{margin-top:6px}.cfck{display:inline-flex;align-items:center;gap:5px;margin-right:10px;font-size:12.5px;color:#cfd4e6;white-space:nowrap}
.tg.s-learned{background:#14382a;color:var(--ok)}.tg.s-admin{background:#423812;color:#ffd700}.tg.s-env{background:#283458;color:#a9bdff}.tg.s-factory,.tg.s-prior{background:#34344f;color:#a8aec4}
.tg.s-missingdata{background:#4a2a18;color:#ffb27a}.tg.s-lookup,.tg.s-file,.tg.s-suggestion,.tg.s-manual{background:#173d3a;color:#5fe0c4}
.cfstale{margin:6px 0 0;padding:8px 10px;border-radius:5px;background:#4a3a12;color:#ffd98a;font-size:12.5px;line-height:1.5}.cfstale q{color:#fff;quotes:none}
.cfpb td.stp{width:34%}.cfpb .pt{color:#fff;font-size:13.5px}.cfpb .pw{color:var(--mut);font-size:12px;margin-top:2px}.cfpb tr.hid td.stp{opacity:.5;text-decoration:line-through}
.cfpb .kd{display:inline-block;min-width:44px;margin-right:6px;font:600 10.5px "Roboto Mono",monospace;text-transform:uppercase;letter-spacing:.4px;color:#8cc4ff}.cfpb .kd.ask{color:#e0b86a}.cfpb .kd.act{color:#ff8b98}
.spk{display:block}.cfh{white-space:nowrap}.cfdiff td.vv{white-space:nowrap}.dlg.wide{width:min(1000px,100%)}.dlg.wide .dlg-b{max-height:56vh;overflow:auto}.dlg .qt{min-width:0}.dlg .qt.lt td{vertical-align:top}
.dlg-b pre.math{max-height:50vh;margin:6px 0}.cfx{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px}.cfx select,.cfx input[type=search]{height:30px;padding:0 8px;border:1px solid var(--panel2);border-radius:4px;background:var(--panel);color:#fff;font:inherit;font-size:13px}
.cfx .sp{flex:1}.cfb .empty{padding:14px;text-align:center;color:var(--mut)}.cfwarn{margin:0 0 8px;padding:8px 10px;border-radius:5px;background:#4a3a12;color:#ffd98a;font-size:12.5px}.cfwarn li{margin:2px 0}
"""

JS = r"""
// ---- Configuration tab (admin only, confui.py): cards over the admin-only routes; every change is drafted, previewed, published ----
S.admin=false;S.adminKnown=false;
var CF={bad:{},health:null,pbopen:{},cfg:null,prof:null,crown:null,cat:null,exc:null,draft:null,base:null,xf:{state:"active",q:""},xsel:{},cq:"",drafts:false,err:"",fail:{}};
var RHY={factory:"not enough activity to measure",shifts:"working in shifts","24/7":"around the clock"};
var XSTATE={active:"Active",pending:"Waiting for approval",rejected:"Rejected",expired:"Expired",removed:"Removed",lookup:"From the Sycope lookup",all:"All"};
var PGROUP={pcap:"Recorded packets",crown:"Crown jewels",verdict:"Verdict",target:"Hosts attacked from outside",group:"Groups of hosts",campaign:"Campaigns"};
var PGRP=[["class_bits.","Evidence per class of rule"],["sev_adj.","Adjustment for Sycope severity"],["thr_adj.","Adjustment for the threshold level"],
  ["confirm_bits","Confidence and impact"],["prior_bits","Confidence and impact"],["impact.","Confidence and impact"],["crown_mult","Confidence and impact"],["ti_min_cap_bits","Confidence and impact"],
  ["chain.","Chain rules"],["act_chains","Chain rules"],["p1_chains","Chain rules"],["verdict.","Verdict thresholds"],
  ["exfil_floor_bytes","Evidence limits"],["answer_floor_bytes","Evidence limits"],["persist_days","Evidence limits"],["week_share","Evidence limits"],["cloud_asns","Evidence limits"],["edge_forbidden_rules","Evidence limits"],["shared_infra_extra","Evidence limits"],["chain_days","Evidence limits"],
  ["campaign_","Groups and campaigns"],["segment_min_hosts","Groups and campaigns"],
  ["quiet_h","Queue and timing"],["grace_min","Queue and timing"],["shift_h","Queue and timing"],["unreviewed_days","Queue and timing"],["health.","Health"],["own_public_min_clients","Queue and timing"]];
function cfJ(x){return JSON.stringify(x===undefined?null:x)}
function cfClone(x){return JSON.parse(JSON.stringify(x))}
function cfHas(o,k){return Object.prototype.hasOwnProperty.call(o,k)}
function cfKeys(a,b){var m={};Object.keys(a||{}).forEach(function(k){m[k]=1});Object.keys(b||{}).forEach(function(k){m[k]=1});return Object.keys(m).sort()}
function cfBase(){return (CF.cfg&&CF.cfg.body)||{params:{},catalog:{},playbook:[],internal:{}}}
function cfReg(id){var L=(CF.cfg&&CF.cfg.registry)||[];for(var i=0;i<L.length;i++)if(L[i].id===id)return L[i];return null}
function srcTag(s){return '<span class="tg s-'+esc(String(s||"").replace(/[^a-z]/g,""))+'">'+esc(s||"")+'</span>'}
function cfNum(v){return typeof v==="number"?String(+v.toPrecision(6)):String(v)}
function cfFmt(r,v){if(v==null)return '<span class="mut">none</span>';
  if(Array.isArray(v))return r&&r.id==="cloud_asns"?num(v.length)+' networks':esc(v.join(", "));
  if(typeof v!=="number")return esc(v);
  if(r&&r.unit==="bytes")return esc(bytes(v));return esc(cfNum(v)+(r&&r.unit?" "+r.unit:""))}
function cfBounds(r){return r.lo==null?"":"allowed "+cfNum(r.lo)+" to "+cfNum(r.hi)+(r.unit?" "+r.unit:"")}
function cfAlert(msg,title){return dlg({title:title||"That did not work",body:'<p>'+esc(msg)+'</p>',ok:"OK"})}
function cfFail(e){if(e&&e.status===403){S.adminKnown=false;adminCheck()}return cfAlert((e&&e.message)||String(e))}
// ---- who is an admin: Sycope's word through the service (/whoami with the pass), never the page's own ----
function getA(u){var p=passFor(ME.name),h={Accept:"application/json"};if(p)h["X-SC-Pass"]=p.pass;
  return fetch(u,{credentials:"same-origin",headers:h}).then(function(r){return r.json().then(function(j){if(!r.ok){var e=new Error(j.error||("HTTP "+r.status));e.status=r.status;throw e}return j})})}
function adminCheck(){if(INC)return Promise.resolve();if(!passFor(ME.name)){S.adminKnown=true;cfgSetAdmin(false);return Promise.resolve()}
  return getA("whoami").then(function(j){S.adminKnown=true;cfgSetAdmin(!!(j&&j.verified&&j.admin))}).catch(function(){S.adminKnown=true;cfgSetAdmin(false)})}
function cfgSetAdmin(v){var was=S.admin;S.admin=v;if(!v){CF.draft=null;CF.cfg=null;cfgBadge(null)}
  if(S.data)tabs(S.data);
  if(S.tab==="config"){if(v&&was)return;render()}
  if(v&&!was)getA("config").then(function(c){CF.cfg=c;cfgBadge(c)}).catch(function(){})}
function cfgBadge(c){var b=$("#modb");if(!b)return;var bd=c&&c.body||{},n=(c&&c.modified||[]).length,extra=Object.keys(bd.catalog||{}).length+(bd.playbook||[]).length+Object.keys(bd.internal||{}).length;
  b.hidden=!(n||extra);if(b.hidden)return;
  b.title=(n?"Scoring settings changed from the factory: "+c.modified.join(", ")+". ":"")+(extra?extra+" rule, playbook or address edits. ":"")+"Click to open the Configuration tab.";
  b.textContent="modified"}
function cfgShow(){var v=$("#view");
  if(!S.adminKnown){v.innerHTML='<div class="loading">Asking Sycope whether you are an admin…</div>';return}
  if(!S.admin){S.tab="queue";sync();render();return}
  if(v.querySelector(":scope>.cfg"))return;
  v.innerHTML=cfgSkeleton();cfgLoad()}
function cfCard(id,title,tip,fold){return '<div class="sec" data-sec="cf-'+id+'"'+(fold?' data-fold="1"':"")+'><h3>'+esc(title)+ii(tip)+'</h3><div class="cfb" id="cfb-'+id+'"><div class="loading">Loading…</div></div></div>'}
function cfgSkeleton(){return '<div class="cfg"><p class="lead1">What your team may change. Every change is previewed on today\'s incidents before it is published, and every version stays in the list to go back to.</p>'
  +'<div class="cfbar" id="cfbar" hidden></div>'
  +cfCard("health","Health of the configuration","Which configuration is in force, whether it differs from the shipped one, and what needs an admin: errors, playbook edits that point nowhere, suggestions waiting. The operational health (fields, memory, polling) is on the System page.")
  +cfCard("profile","Profile","How the triage learns what is normal on your network. A value you set here replaces the learned one until you reset it. The change shows after the next learning when it is about how the profile learns.")
  +cfCard("crown","Crown jewels","The hosts and networks whose compromise matters most. Their stages weigh more and they reach Act now sooner.",true)
  +cfCard("silenced","Silenced","Every exception: those the team made, those waiting for approval, expired and removed ones, and the read-only list from the Sycope lookup.",true)
  +cfCard("scoring","Scoring","The numbers behind every verdict. Each shows the value the product ships with, so you can see what you changed.",true)
  +cfCard("playbooks","Playbooks","The next steps an incident lists. Edit the text of a step, hide it, move it, or add your own with a link into your tools.",true)
  +cfCard("catalog","Rule catalog","What each Sycope alert rule means to the triage: family, class, stage and ATT&CK technique. Rules it does not know are scored from their MITRE tactic until you classify them.",true)
  +cfCard("versions","Versions","Every published configuration. Roll back, export to move the setup to another instance, or import one.",true)+'</div>'}
// what the tab reads: [CF field, route, the card that shows its failure (null: the tab cannot work without it)]
var CF_ROUTES=[["cfg","config",null],["prof","profile","profile"],["crown","crown","crown"],["cat","catalog","catalog"],["exc","exceptions","silenced"],["health","health-data?tz="+(-new Date().getTimezoneOffset()),"health"]];
function cfgLoad(){return Promise.allSettled(CF_ROUTES.map(function(r){return getA(r[1])})).then(function(res){
    var deny=null,whole=null;CF.fail={};
    res.forEach(function(x,i){var r=CF_ROUTES[i];if(x.status==="fulfilled"){CF[r[0]]=x.value;return}
      if(x.reason&&x.reason.status===403)deny=x.reason;if(r[2])CF.fail[r[2]]=x.reason;else whole=x.reason});
    if(deny||whole){var e=deny||whole,v=$("#view>.cfg");if(v)v.insertAdjacentHTML("beforeend",'<div class="errbox">Cannot read the configuration: '+esc(e.message)+'</div>');if(deny)cfFail(deny);return}
    if(!CF.draft||CF.base!==CF.cfg.active){CF.draft=cfClone(cfBase());CF.base=CF.cfg.active}
    ["params","catalog","internal"].forEach(function(k){if(!CF.draft[k])CF.draft[k]={}});if(!CF.draft.playbook)CF.draft.playbook=[];
    cfgBadge(CF.cfg);cfgDraw()})}
// a card whose data could not be read shows why in its own box; the others are drawn
function cfgDraw(){if(!CF.cfg)return;CF.bad={};[cfHealth,cfProfile,cfCrown,cfSilenced,cfScoring,cfPlaybooks,cfCatalog,cfVersions].forEach(function(f){var id=f.name.slice(2).toLowerCase(),b=$("#cfb-"+id),bad=(CF.fail||{})[id];
  if(bad){if(b)b.innerHTML='<div class="errbox">Cannot read this part: '+esc(bad.message||String(bad))+'</div>';return}
  try{f()}catch(e){if(b)b.innerHTML='<div class="errbox">'+esc(e.message)+'</div>'}});cfgBar();cfClassifyLink()}
// the System page links an unknown alert name here (?tab=config&classify=<name>): open the Rule catalog card and the
// classify dialog for it, once
function cfClassifyLink(){var n=typeof P!=="undefined"?P.get("classify"):null;if(!n||CF.linked===n||!CF.cat)return;CF.linked=n;
  var u=new URL(location.href);u.searchParams.delete("classify");history.replaceState(null,"",u.pathname+u.search+u.hash);
  var sec=$('[data-sec="cf-catalog"]');if(sec){secSet(sec,false,false);sec.scrollIntoView({block:"start"})}
  catEdit(n,!(CF.cat.rules||[]).some(function(x){return x.name===n}))}
function cfBox(id){return $("#cfb-"+id)}
// ---- what is changed and not published yet ----
function cfChanges(){if(!CF.draft||!CF.cfg)return [];var a=cfBase(),d=CF.draft,out=[];
  cfKeys(a.params,d.params).forEach(function(k){if(cfJ(a.params[k])!==cfJ(d.params[k])){var r=cfReg(k),area=/^(profile\.|calendar\.|shift_gap_h)/.test(k)?"Profile":"Scoring";
    out.push({area:area,text:k+": "+(cfHas(a.params,k)?cfPlain(a.params[k]):"ships "+cfPlain(r&&r.factory))+" → "+(cfHas(d.params,k)?cfPlain(d.params[k]):"back to "+(r?cfPlain(r.value):"default"))})}});
  cfKeys(a.internal,d.internal).forEach(function(k){if(cfJ(a.internal[k])!==cfJ(d.internal[k]))out.push({area:"Profile",text:k+": "+(cfHas(d.internal,k)?(d.internal[k]?"treated as internal":"treated as outside"):"no longer declared")})});
  cfKeys(a.catalog,d.catalog).forEach(function(k){if(cfJ(a.catalog[k])!==cfJ(d.catalog[k]))out.push({area:"Rule catalog",text:k+(cfHas(d.catalog,k)?": classified by you":": back to the shipped class")})});
  var A=(a.playbook||[]).map(cfJ),D=(d.playbook||[]).map(cfJ),add=D.filter(function(x){return A.indexOf(x)<0}).length,del=A.filter(function(x){return D.indexOf(x)<0}).length;
  if(add||del)out.push({area:"Playbooks",text:add+" edit"+(add===1?"":"s")+" added or changed, "+del+" undone"});return out}
function cfPlain(v){return Array.isArray(v)?v.join(", "):String(v)}
function cfgBar(){var b=$("#cfbar");if(!b)return;var ch=cfChanges(),nb=Object.keys(CF.bad).length;b.hidden=!ch.length&&!nb;
  if(b.hidden){b.innerHTML="";return}
  b.innerHTML=(ch.length?'<b>'+hp(ch.length,"change")+' not published yet</b><span class="mut">'+ch.slice(0,5).map(function(c){return esc(c.area+": "+c.text)}).join(" · ")+(ch.length>5?" · …":"")+'</span>':"")
    +(nb?'<b style="color:#ffb3c0">'+hp(nb,"field")+' with a value that is not allowed (red): fix it or reset it before you preview</b>':"")+'<span class="sp"></span>'
    +'<button type="button" class="b2 pri" data-cf="preview"'+(nb||!ch.length?" disabled":"")+'>Preview and publish…</button><button type="button" class="b2" data-cf="discard">Discard</button>'}
// ---- change -> preview -> publish ----
function cfPreviewHtml(pv,notes){var h="";
  if(!pv.scored)h+='<p>Nothing is scored yet, so there is no board to compare. You can still publish; the next score uses the new setup.</p>';
  else if(!pv.n)h+='<p><b>No incident changes its verdict</b> with this setup on today\'s data.</p>';
  else{var vc=function(v){return VL[v]?vp(v):'<span class="mut">'+esc(v==="none"?"not on the board":v)+'</span>'};
    h+='<p><b>'+hp(pv.n,"incident")+'</b> would change verdict'+(pv.n>pv.changed.length?' (the first '+num(pv.changed.length)+' are listed)':"")+'.</p>'
      +laneTable(["Incident","From","To","Why"],pv.changed.map(function(c){return '<tr class="qr nk" style="--vc:'+(VC[c.to]||"#2f3060")+'"><td class="mono">'+esc(c.label)+'</td><td class="vv">'+vc(c.from)+'</td><td class="vv">'+vc(c.to)+'</td><td class="w">'+esc(c.why)+'</td></tr>'}).join(""),"")}
  (notes||[]).forEach(function(n){h+='<p class="mut">'+esc(n)+'</p>'});return h}
function cfNotes(body){var ks=Object.keys((body&&body.params)||{}),n=[];
  if(ks.some(function(k){return /^(profile\.|calendar\.)/.test(k)}))n.push("Some of these change how the profile learns (profile.* and calendar.* values). The preview keeps today's learned profile, so their effect shows after the next learning, not in this list.");return n}
function cfReview(id,o){return getA("config-preview?draft="+id).then(function(pv){
  return dlg({title:o.title||"What would change",body:cfPreviewHtml(pv,(pv.notes||[]).concat(cfNotes(o.body))),ok:o.ok||"Publish",wide:true}).then(function(v){if(!v)return null;return o.commit(id)})})}
// body -> a draft version of the service -> the diff -> the commit; the version in force is checked first
function cfDraftAndReview(body,note,o){return getA("config").then(function(c){
    if(c.active!==CF.base){CF.cfg=c;CF.draft=null;CF.base=null;return cfAlert("Version "+c.active+" was published while you were editing. Your unpublished changes were dropped; the page shows the new setup.","Someone else changed the configuration").then(function(){return cfgLoad().then(function(){return null})})}
    return post({op:"config:draft",body:body,note:note}).then(function(d){o.body=body;return cfReview(d.id,o)})})}
function cfAfter(res,prev,msg){var vid=(res&&(res.version||res.id))||"";
  return cfgLoad().then(function(){
    toastUndo(msg||("Published version "+vid),null,{undo:function(){
      return (prev!=null?post({op:"config:rollback",id:prev}):post({op:"config:draft",body:{schema_version:1,params:{},catalog:{},playbook:[],internal:{}},note:"undo: back to the shipped setup"}).then(function(d){return post({op:"config:publish",id:d.id})}))
        .then(function(){return cfgLoad()})}});
    refreshAll()})}
function cfPublishDraft(){var ch=cfChanges();if(!ch.length)return Promise.resolve();
  if(Object.keys(CF.bad).length)return cfAlert("Some fields hold a value that is not allowed (shown in red). Fix or reset them first.","Not yet");var prev=CF.cfg.active;
  return dlg({title:"Preview this change",body:'<p>You are changing:</p><ul class="cfl">'+ch.map(function(c){return '<li><b>'+esc(c.area)+'</b>: '+esc(c.text)+'</li>'}).join("")+'</ul><p class="mut">Nothing is published yet. Next you see which incidents would change.</p>',ok:"Preview",
    fields:[{name:"note",label:"What is this change for?",type:"textarea",required:true,max:300}]}).then(function(v){if(!v)return;
    return cfDraftAndReview(cfClone(CF.draft),v.note,{title:"Publish "+hp(ch.length,"change")+"?",commit:function(id){return post({op:"config:publish",id:id})}}).then(function(res){if(res)return cfAfter(res,prev)})}).catch(cfFail)}
// ---- the Health card: what is about the configuration (the operational health is on the System page) ----
function cfHealth(){var h=CF.health,box=cfBox("health");if(!box||!h)return;var cw=h.config_warnings||[],mod=h.modified;
  box.innerHTML=(cw.length?'<div class="cfwarn"><ul>'+cw.map(function(w){return '<li>'+esc(w)+'</li>'}).join("")+'</ul></div>':'<p class="mut">Nothing in the configuration needs attention.</p>')
    +'<div class="hstat"><span>Configuration <b>'+(h.config_version!=null?"version "+num(h.config_version):"shipped")+'</b>'+(mod?" · <b>modified</b> from the shipped setup":" · as shipped")+'</span>'
    +'<span>Suggestions waiting <b>'+num(h.suggestions)+'</b></span><span>Profile <b>'+num(h.profile_days)+' of @@WANT_DAYS@@ days</b>'+(h.profile_frozen?" · frozen":"")+'</span>'
    +'<span>Alert names not in the catalog <b>'+num((h.unknown_rules||[]).length)+'</b></span></div>'}
// ---- the Profile card ----
function cfParamInput(r,val){var id=esc(r.id);
  if(r.id==="shared_infra_extra")return '<input class="cfin txt" type="text" data-cft="'+id+'" value="'+esc((val||[]).join("; "))+'" title="Networks in CIDR form separated by semicolons">';
  if(r.id==="edge_forbidden_rules")return '<input class="cfin txt" type="text" data-cft="'+id+'" value="'+esc((val||[]).join("; "))+'" title="Alert names separated by semicolons">';
  if(Array.isArray(r.factory)&&r.id!=="cloud_asns"){var set={};(val||[]).forEach(function(c){set[c]=1});
    return ((CF.cfg.playbook&&CF.cfg.playbook.chains)||[]).map(function(c){return '<label class="cfck" title="'+esc(c.title)+'"><input type="checkbox" data-cfl="'+id+'" value="'+esc(c.id)+'"'+(set[c.id]?" checked":"")+'>'+esc(c.id)+'</label>'}).join("")}
  if(Array.isArray(r.factory))return '<input class="cfin txt" type="text" data-cfa="'+id+'" value="'+esc((val||[]).join(", "))+'" title="AS numbers separated by commas">';
  return '<input class="cfin" type="number" step="any" data-cfp="'+id+'" value="'+esc(cfNum(val))+'"'+(r.lo!=null?' min="'+esc(r.lo)+'" max="'+esc(r.hi)+'"':"")+' title="'+esc(cfBounds(r))+'">'}
function cfParamRow(r,learned){var d=CF.draft.params,has=cfHas(d,r.id),val=has?d[r.id]:r.value,a=cfBase().params,chg=cfJ(d[r.id])!==cfJ(a[r.id]);
  var src=srcTag(r.source)+(learned&&r.n?'<div class="mut">'+num(r.n)+' host-days'+(r.conf!=null?', norm confidence '+num(r.conf,2):"")+'</div>'+(r.conf!=null&&r.conf<0.5?'<div><span class="tg ch" title="Few observations behind this value: shipped norms fill the gap">low norm confidence</span></div>':""):"");
  return '<tr class="qr nk'+(chg?" cfchg":"")+'" style="--vc:#2f3060" data-cfrow="'+esc(r.id)+'"><td><span class="mono">'+esc(r.id)+'</span><div class="mut">'+esc(r.help)+'</div></td><td>'+cfFmt(r,r.value)+'</td><td>'+src+'</td>'+(learned?'<td class="cfh" data-hist="'+esc(r.id)+'"><span class="mut">…</span></td>':"")+'<td>'+cfFmt(r,r.factory)+'<div class="mut">'+esc(cfBounds(r))+'</div></td><td>'+cfParamInput(r,val)
    +'</td><td><button type="button" class="b2" data-cf="reset" data-id="'+esc(r.id)+'"'+(has?"":" hidden")+' title="Take your value away: the shipped or learned one is used again">Reset</button></td></tr>'}
var PHEAD=["Setting","Now","Where from","Ships as","Your value",""],PHEADL=["Setting","Now","Where from","Last change","Ships as","Your value",""];
// the value of a learned parameter in each daily snapshot: a small line and the day it last changed
function cfSpark(h,id){if(!h.length)return '<span class="mut">no history yet</span>';
  var vs=h.map(function(p){return +p.value}),lo=Math.min.apply(null,vs),hi=Math.max.apply(null,vs),W=84,H=22,n=h.length,
    pt=vs.map(function(v,i){return (n>1?i/(n-1)*(W-4)+2:W/2)+","+(hi===lo?H/2:H-3-(v-lo)/(hi-lo)*(H-6))}).join(" "),since=h[0].day;
  for(var i=h.length-1;i>0;i--){if(h[i].value!==h[i-1].value){since=h[i].day;return '<svg class="spk" width="'+W+'" height="'+H+'" role="img" aria-label="Value per day"><polyline points="'+pt+'" fill="none" stroke="#8cc4ff" stroke-width="1.6"/></svg><div class="mut">changed '+esc(since)+'</div>'}}
  return '<svg class="spk" width="'+W+'" height="'+H+'" role="img" aria-label="Value per day"><polyline points="'+pt+'" fill="none" stroke="#8cc4ff" stroke-width="1.6"/></svg><div class="mut">unchanged since '+esc(since)+'</div>'}
function cfHistFill(){$$("td[data-hist]").forEach(function(td){var id=td.dataset.hist;getA("profile?history="+encodeURIComponent(id)).then(function(h){td.innerHTML=cfSpark(h,id)}).catch(function(){td.innerHTML='<span class="mut">-</span>'})})}
function cfProfile(){var P=CF.prof,box=cfBox("profile"),h="";
  h+='<div class="cfhead"><span>Learned from <b>'+num((P.days||[]).length)+'</b> of @@WANT_DAYS@@ days'+(P.profile_day?' · as of '+esc(P.profile_day):"")+' · team rhythm: <b>'+esc(RHY[P.rhythm]||P.rhythm||"unknown")+'</b></span><span class="sp"></span>'
    +(P.frozen?'<span class="tg ch" title="Learning goes on, but the board uses the frozen profile">frozen</span><button type="button" class="b2" data-cf="freeze" data-v="0">Unfreeze…</button>':'<button type="button" class="b2" data-cf="freeze" data-v="1" title="Keep today\'s profile while you test or an incident goes on">Freeze…</button>')+'</div>';
  h+='<h4>Values it learns, and the settings of the learning <span class="mut">The profile keeps its other norms (per host, per role) by itself; these are the numbers you can set.</span></h4>'
    +tcard(laneTable(PHEADL,(P.learned||[]).map(function(x){return cfParamRow(x,true)}).join(""),"Nothing learned yet."));
  var inn=CF.draft.internal||{},ips=Object.keys(inn).sort();
  h+='<h4>Addresses you declared <span class="mut">Public addresses that are really yours, or private ones that are not</span></h4>'
    +'<div class="cfx"><button type="button" class="b2" data-cf="internal-add">Declare an address…</button></div>'
    +tcard(laneTable(["Address","Treated as","",""],ips.map(function(ip){return '<tr class="qr nk'+(cfJ(inn[ip])!==cfJ(cfBase().internal[ip])?" cfchg":"")+'" style="--vc:#2f3060"><td class="mono">'+esc(ip)+'</td><td>'+(inn[ip]?"inside your network":"outside your network")+'</td><td><button type="button" class="b2" data-cf="internal-del" data-ip="'+esc(ip)+'">Remove</button></td></tr>'}).join(""),"None declared.",3));
  var conf=P.confirmed||{},cips=Object.keys(conf).sort();
  if(cips.length)h+='<h4>Roles you confirmed</h4>'+tcard(laneTable(["Host","Role"],cips.map(function(ip){return '<tr class="qr nk" style="--vc:#2f3060"><td class="mono">'+esc(ip)+'</td><td>'+esc(conf[ip])+'</td></tr>'}).join(""),""));
  var sg=P.suggestions||[];
  h+='<h4>Suggestions waiting <span class="mut">'+num(sg.length)+'. A rejected one stays quiet until its evidence changes.</span></h4>'
    +tcard(laneTable(["Suggestion","Why","",""],sg.map(function(s){return '<tr class="qr nk" style="--vc:#3ecf72"><td>'+esc(cfSugText(s))+'</td><td class="w">'+esc(s.reason)+'</td><td><span class="btns"><button type="button" class="b2 pri" data-cf="sug" data-key="'+esc(s.key)+'" data-a="accept">Accept…</button><button type="button" class="b2" data-cf="sug" data-key="'+esc(s.key)+'" data-a="reject">Reject…</button></span></td></tr>'}).join(""),"Nothing waiting.",4));
  box.innerHTML=h;cfHistFill()}
function cfSugText(s){if(s.kind==="internal-ip")return s.subject+" is inside your network";if(s.kind==="role")return s.subject+" is "+wa(s.role||"special")+" host";return s.subject}
// ---- the Crown jewels card ----
function cfCrown(){var C0=CF.crown,box=cfBox("crown"),rows={};(C0.rows||[]).forEach(function(r){if(r.active)rows[r.entity]=r});
  var eff=(C0.effective||[]).map(function(x){var ent=(x.entity.indexOf("/")>=0?"subnet:":"ip:")+x.entity,r=rows[ent]||{};return '<tr class="qr nk" style="--vc:#ffd700"><td class="mono">'+esc(x.entity)+'</td><td>'+srcTag(x.source)+'</td><td class="w">'+esc(r.reason||(x.source==="lookup"?"listed in the Sycope lookup":""))+'</td><td>'+(r.who?esc(r.who)+'<div class="mut">'+tm(r.at*1000,"dhm")+'</div>':"")+'</td><td>'
    +(x.source==="lookup"?'<span class="mut">read-only</span>':'<button type="button" class="b2 warn" data-cf="crown-del" data-e="'+esc(ent)+'">Remove…</button>')+'</td></tr>'}).join("");
  var cand=(C0.candidates||[]).map(function(c){return '<tr class="qr nk" style="--vc:#3ecf72"><td class="mono">'+esc(c.subject)+'</td><td class="w">'+esc(c.reason)+'</td><td><span class="btns"><button type="button" class="b2 pri" data-cf="sug" data-key="'+esc(c.key)+'" data-a="accept">Accept…</button><button type="button" class="b2" data-cf="sug" data-key="'+esc(c.key)+'" data-a="reject">Reject…</button></span></td></tr>'}).join("");
  box.innerHTML='<div class="cfx"><span class="mut">'+num((C0.effective||[]).length)+' in force</span><span class="sp"></span><button type="button" class="b2 pri" data-cf="crown-add">Add a crown jewel…</button></div>'
    +tcard(laneTable(["Host or network","Source","Why","Added by",""],eff,"No crown jewels yet."))
    +'<h4>Candidates the profile found <span class="mut">'+num((C0.candidates||[]).length)+'</span></h4>'+tcard(laneTable(["Host or network","Why it looks critical",""],cand,"No candidates."))}
// ---- the Silenced card ----
function cfXRows(){var f=CF.xf;return (CF.exc.rows||[]).filter(function(x){return (f.state==="all"||x.state===f.state)&&(!f.q||[x.rule,x.server,x.actor,x.reason,x.who,x.kind,x.id].join(" ").toLowerCase().indexOf(f.q.toLowerCase())>=0)})}
function cfSilenced(){var box=cfBox("silenced"),f=CF.xf,rows=cfXRows();
  var counts={};(CF.exc.rows||[]).forEach(function(x){counts[x.state]=(counts[x.state]||0)+1});
  box.innerHTML='<div class="cfx"><select id="cfxs" aria-label="Which exceptions">'+Object.keys(XSTATE).map(function(k){return '<option value="'+k+'"'+(f.state===k?" selected":"")+'>'+esc(XSTATE[k])+(k==="all"?"":" ("+num(counts[k]||0)+")")+'</option>'}).join("")+'</select>'
    +'<input type="search" id="cfxq" placeholder="rule, host, reason, who…" value="'+esc(f.q)+'"><span class="sp"></span><span id="cfxsel" class="mut"></span><button type="button" class="b2 warn" data-cf="expire" id="cfxb" disabled>Expire selected…</button></div>'
    +tcard('<div id="cfxt">'+cfXTable(rows)+'</div>')+(CF.exc.approval?'<p class="mut">Exceptions need an admin to approve them here (SC_EXCEPTION_APPROVAL).</p>':"");cfXSel()}
function cfXTable(rows){var soon=Date.now()/1000+7*86400;
  return laneTable(['<input type="checkbox" class="qx" data-cfxall="1" aria-label="Tick all shown">',"#","Kind","Rule","Where","Why","By","State"],rows.slice(0,300).map(function(x){var live=x.state==="active"&&!x.source;
    return '<tr class="qr nk" style="--vc:'+(x.state==="active"?"#4aa3ff":x.state==="pending"?"#e0a8ff":"#2f3060")+'"><td>'+(live?'<input type="checkbox" class="qx" data-cfx="'+esc(x.id)+'"'+(CF.xsel[x.id]?" checked":"")+'>':"")+'</td><td>#'+esc(x.id)+'</td><td>'+esc(x.kind)+'</td><td>'+esc(x.rule||"*")+'</td><td class="mono">'+esc(x.server||x.actor||"")+(x.port?":"+esc(x.port):"")+'</td><td class="w">'+esc(x.reason)+'</td><td>'+esc(x.who)+(x.created?'<div class="mut">'+tm(x.created*1000,"dhm")+'</div>':"")+'</td><td>'
      +esc(XSTATE[x.state]||x.state)+(x.state==="active"&&x.expires?'<div class="'+(x.expires<soon?"st-exp":"mut")+'">until '+tm(x.expires*1000,"dhm")+'</div>':"")+(x.state==="removed"?'<div class="mut">'+esc(x.removed_by||"")+' '+(x.removed_at?tm(x.removed_at*1000,"dhm"):"")+'</div>':"")+'</td></tr>'}).join(""),"No exception matches.")+(rows.length>300?'<p class="mut">The first 300 of '+num(rows.length)+' are shown: narrow the filter.</p>':"")}
function cfXSel(){var n=Object.keys(CF.xsel).length,b=$("#cfxb"),s=$("#cfxsel");if(b)b.disabled=!n;if(s)s.textContent=n?num(n)+" ticked":""}
// ---- the Scoring card: the parameters that are not learned ----
function cfGroupOf(id){for(var i=0;i<PGRP.length;i++)if(id.indexOf(PGRP[i][0])===0)return PGRP[i][1];return "Other"}
function cfScoring(){var box=cfBox("scoring"),g={},order=[];
  CF.cfg.registry.forEach(function(r){if(r.learnable||/^(profile\.|calendar\.)/.test(r.id))return;var k=cfGroupOf(r.id);if(!g[k]){g[k]=[];order.push(k)}g[k].push(r)});
  box.innerHTML='<div class="cfhead"><span>'+num(order.reduce(function(n,k){return n+g[k].length},0))+' settings. The value you type replaces the shipped one; Reset takes it away again.</span></div>'
    +order.map(function(k){var chg=g[k].filter(function(r){return cfHas(CF.draft.params,r.id)||cfHas(cfBase().params,r.id)}).length;
      return '<details class="fold"><summary>'+esc(k)+' <span class="mut">('+num(g[k].length)+(chg?", "+num(chg)+" set by you":"")+')</span></summary>'+tcard(laneTable(PHEAD,g[k].map(function(r){return cfParamRow(r,false)}).join(""),""))+'</details>'}).join("")}
function cfSetParam(x){var id=x.dataset.cfp,r=cfReg(id),v=x.value.trim()===""?NaN:+x.value,msg="";
  if(!isFinite(v)||(r.lo!=null&&(v<r.lo||v>r.hi)))msg="Not allowed: "+cfBounds(r);
  else if(r.type==="int"&&Math.floor(v)!==v)msg="A whole number, please";
  x.classList.toggle("bad",!!msg);
  if(msg){x.title=msg;CF.bad[id]=1;cfgBar();return}                    // a value that is not allowed blocks Preview
  delete CF.bad[id];x.title=cfBounds(r);
  if(v===r.value&&!cfHas(cfBase().params,id))delete CF.draft.params[id];else CF.draft.params[id]=v;cfRowMark(x,id)}
function cfRowMark(x,id){var tr=x.closest("tr");if(tr){tr.classList.toggle("cfchg",cfJ(CF.draft.params[id])!==cfJ(cfBase().params[id]));var b=tr.querySelector('[data-cf="reset"]');if(b)b.hidden=!cfHas(CF.draft.params,id)}cfgBar()}
function cfSetList(x){var id=x.dataset.cfl,boxes=$$('[data-cfl="'+id+'"]',x.closest("tr")),v=boxes.filter(function(b){return b.checked}).map(function(b){return b.value});
  var r=cfReg(id),same=cfJ(v.slice().sort())===cfJ(r.value.slice().sort());if(same&&!cfHas(cfBase().params,id))delete CF.draft.params[id];else CF.draft.params[id]=v;cfRowMark(x,id)}
function cfSetAsns(x){var id=x.dataset.cfa,parts=x.value.split(/[\s,]+/).filter(Boolean),v=parts.map(Number),bad=v.some(function(n){return !(n>0)||Math.floor(n)!==n});
  x.classList.toggle("bad",bad);if(bad){x.title="AS numbers are whole numbers above 0";CF.bad[id]=1;cfgBar();return}delete CF.bad[id];CF.draft.params[id]=v;cfRowMark(x,id)}
function cfSetTexts(x){var id=x.dataset.cft,v=x.value.split(";").map(function(t){return t.trim()}).filter(Boolean);CF.draft.params[id]=v;cfRowMark(x,id)}
// ---- the Playbooks card ----
function pbOps(t,kind){return (CF.draft.playbook||[]).filter(function(o){return o.op===kind&&o.template===t})}
function pbSet(t,kind,body){CF.draft.playbook=(CF.draft.playbook||[]).filter(function(o){return !(o.op===kind&&o.template===t)});if(body){var o={op:kind,template:t};Object.keys(body).forEach(function(k){o[k]=body[k]});CF.draft.playbook.push(o)}}
function pbAdded(){return (CF.draft.playbook||[]).filter(function(o){return o.op==="add"})}
function pbGroupTitle(g){var P=CF.cfg.playbook,hit=null,also=[];P.chains.concat(P.families).forEach(function(c){if(c.id===g)hit=c.title});P.templates.forEach(function(t){if(t.group===g)(t.also||[]).forEach(function(x){if(also.indexOf(x)<0)also.push(x)})});return hit?g+" "+hit+(also.length?" (its step also serves "+also.join(", ")+")":""):(PGROUP[g]||g)}
function cfPlaybooks(){var box=cfBox("playbooks"),P=CF.cfg.playbook,T={},groups=[],by={};
  P.templates.forEach(function(t){T[t.id]=t;if(!by[t.group]){by[t.group]=[];groups.push(t.group)}by[t.group].push(t)});
  var known=function(id){return T[id]||pbAdded().some(function(o){return o.id===id})},warn=[];
  (CF.draft.playbook||[]).forEach(function(o,i){["template","after"].forEach(function(f){if(o.op!=="add"&&typeof o[f]==="string"&&!known(o[f]))warn.push([i,o,f])})});
  var h='';
  if(warn.length)h+='<div class="cfwarn"><b>Edits that point at a step this release does not have</b> (renamed or removed by an upgrade). They do nothing.<ul>'+warn.map(function(w){return '<li>'+esc(w[1].op)+' '+esc(w[1][w[2]])+' <button type="button" class="lnk" data-cf="pb-drop" data-i="'+w[0]+'">remove this edit</button></li>'}).join("")+'</ul></div>';
  h+='<div class="cfx"><input type="search" id="cfpq" placeholder="find a step…" value="'+esc(CF.pbq||"")+'"><span class="sp"></span><button type="button" class="b2" data-cf="pb-add" data-bind="">Add a step…</button></div>';
  h+=groups.concat(Object.keys(pbAdded().reduce(function(m,o){var k=Object.keys(o.bind||{})[0]==="kind"?"kind:"+o.bind.kind:Object.values(o.bind||{})[0];if(groups.indexOf(k)<0)m[k]=1;return m},{}))).map(function(g){return cfPbGroup(g,by[g]||[],T)}).join("");
  box.innerHTML=h}
function cfPbGroup(g,list,T){var q=(CF.pbq||"").toLowerCase(),added=pbAdded().filter(function(o){var b=o.bind||{},k=b.kind!=null?"kind:"+b.kind:b.chain||b.family;return k===g}),rows="";
  var hit=function(t,w){return !q||(t+" "+w+" "+g).toLowerCase().indexOf(q)>=0};
  list.forEach(function(t){var ed=pbOps(t.id,"edit")[0],hid=pbOps(t.id,"hide").length,mv=pbOps(t.id,"move")[0],title=(ed&&ed.title)||t.title,why=(ed&&ed.why)||t.why,kind=(ed&&ed.kind)||t.kind;
    if(!hit(title,why))return;var stale=ed&&ed.factory_hash!==t.hash;
    rows+='<tr class="qr nk'+(ed||hid||mv?" cfchg":"")+(hid?" hid":"")+'" style="--vc:#2f3060"><td class="stp"><div class="pt"><span class="kd '+esc(kind)+'">'+esc(kind)+'</span>'+esc(title)+'</div><div class="pw">'+esc(why)+'</div>'
      +(stale?'<div class="cfstale"><b>Factory step changed, review.</b> The shipped step now reads <q>'+esc(t.title)+'</q> (why: <q>'+esc(t.why)+'</q>). You edited it to <q>'+esc(ed.title||t.title)+'</q> (why: <q>'+esc(ed.why||t.why)+'</q>). <button type="button" class="lnk" data-cf="pb-keep" data-t="'+esc(t.id)+'">Keep my edit</button> · <button type="button" class="lnk" data-cf="pb-undo" data-t="'+esc(t.id)+'">Use the shipped text</button></div>':"")+'</td>'
      +'<td class="mono">'+esc(t.id)+'</td><td>'+(hid?'<span class="tg rec">hidden</span>':"")+(ed&&!stale?'<span class="tg jw">edited</span>':"")+(mv?'<span class="tg svc" title="After '+esc(mv.after)+'">moved</span>':"")+'</td><td><span class="btns">'
      +'<button type="button" class="b2" data-cf="pb-edit" data-t="'+esc(t.id)+'">Edit…</button><button type="button" class="b2" data-cf="pb-hide" data-t="'+esc(t.id)+'">'+(hid?"Show":"Hide")+'</button><button type="button" class="b2" data-cf="pb-move" data-t="'+esc(t.id)+'" data-g="'+esc(g)+'">Move…</button>'
      +(ed||hid||mv?'<button type="button" class="b2" data-cf="pb-undo" data-t="'+esc(t.id)+'">Undo</button>':"")+'</span></td></tr>'});
  added.forEach(function(o){if(!hit(o.title,o.why))return;rows+='<tr class="qr nk cfchg" style="--vc:#e5c100"><td class="stp"><div class="pt"><span class="kd '+esc(o.kind)+'">'+esc(o.kind)+'</span>'+esc(o.title)+'</div><div class="pw">'+esc(o.why)+(o.link?' <span class="mono">'+esc(o.link.label)+' → '+esc(o.link.url)+'</span>':"")+'</div></td><td class="mono">'+esc(o.id)+'</td><td><span class="tg st">your step</span></td><td><span class="btns"><button type="button" class="b2" data-cf="pb-edit" data-t="'+esc(o.id)+'" data-add="1">Edit…</button><button type="button" class="b2 warn" data-cf="pb-del" data-t="'+esc(o.id)+'">Remove</button></span></td></tr>'});
  if(!rows)return "";
  var n=list.length+added.length,mine=list.filter(function(t){return pbOps(t.id,"edit").length||pbOps(t.id,"hide").length||pbOps(t.id,"move").length}).length+added.length;
  return '<details class="fold cfpg" data-g="'+esc(g)+'"'+(CF.pbopen[g]||q||mine?" open":"")+'><summary>'+esc(pbGroupTitle(g))+' <span class="mut">('+num(n)+(mine?", "+num(mine)+" yours":"")+')</span></summary><div class="cfx"><button type="button" class="b2" data-cf="pb-add" data-bind="'+esc(g)+'">Add a step here…</button></div><div class="cfpb">'+tcard(laneTable(["Step","Id","State",""],rows,"",4))+'</div></details>'}
function pbEdit(tid,isAdd){var P=CF.cfg.playbook,t=P.templates.filter(function(x){return x.id===tid})[0],ed=pbOps(tid,"edit")[0],add=isAdd?pbAdded().filter(function(o){return o.id===tid})[0]:null,cur=add||{title:(ed&&ed.title)||t.title,why:(ed&&ed.why)||t.why,kind:(ed&&ed.kind)||t.kind};
  var f=[{name:"title",label:"Step (placeholders in braces fill in per incident: "+P.placeholders.map(function(x){return "{"+x+"}"}).join(" ")+")",type:"textarea",required:true,value:cur.title,max:300},{name:"why",label:"Why (shown under the step)",type:"textarea",required:true,value:cur.why,max:1000},
    {name:"kind",label:"Kind",type:"select",options:P.kinds.map(function(k){return [k,{check:"check: look in Sycope or the recorded packets",ask:"ask: someone outside Sycope",act:"act: containment once a check confirms"}[k]||k]}),value:cur.kind}];
  if(add){f.push({name:"label",label:"Link label (optional)",value:(add.link&&add.link.label)||"",max:80},{name:"url",label:"Link address (optional; http or https, the host fixed, placeholders only after it)",value:(add.link&&add.link.url)||"",max:500})}
  return dlg({title:add?"Edit your step":"Edit a step",body:add?"":'<p class="mut">The shipped step is kept: Undo brings it back, and after an upgrade you see what changed.</p>',fields:f,ok:"Use this text"}).then(function(v){if(!v)return;
    if(add){add.title=v.title;add.why=v.why;add.kind=v.kind;if(v.url){add.link={label:v.label||"Open",url:v.url}}else delete add.link}
    else{var body={factory_hash:t.hash};if(v.title!==t.title)body.title=v.title;if(v.why!==t.why)body.why=v.why;if(v.kind!==t.kind)body.kind=v.kind;
      pbSet(tid,"edit",Object.keys(body).length>1?body:null)}
    cfPb()})}
function cfPb(){cfPlaybooks();cfgBar()}
function pbMove(tid,g){var P=CF.cfg.playbook,opts=P.templates.filter(function(x){return x.group===g&&x.id!==tid}).concat(pbAdded().filter(function(o){return o.id!==tid}));
  if(!opts.length){toast("There is no other step in this section to move it after");return}
  return dlg({title:"Move a step",body:'<p class="mut">Choose the step it should come after.</p>',ok:"Move",fields:[{name:"after",label:"After",type:"select",options:opts.map(function(x){return [x.id,x.title]}),value:(pbOps(tid,"move")[0]||{}).after||opts[0].id}]}).then(function(v){if(!v)return;pbSet(tid,"move",{after:v.after});cfPb()})}
function pbAddStep(bind){var P=CF.cfg.playbook,kinds=cfFindingKinds(),binds=[].concat(P.chains.map(function(c){return ["chain:"+c.id,"Chain rule "+c.id+" "+c.title]}),P.families.map(function(c){return ["family:"+c.id,"Family "+c.id+" "+c.title]}),kinds.map(function(k){return ["kind:"+k,"Any finding of kind "+k]}));
  var pre=/^CR-/.test(bind)?"chain:"+bind:/^CL-/.test(bind)?"family:"+bind:"";
  return dlg({title:"Add your own step",body:'<p class="mut">It appears on incidents that have this chain rule, family or kind of finding, after the shipped steps of that section.</p>',ok:"Add",fields:[
    {name:"bind",label:"On incidents with",type:"select",options:binds,value:pre},{name:"id",label:"Short name (letters, digits, _ : - ; no dot)",required:true,max:80,placeholder:"call-the-owner"},
    {name:"kind",label:"Kind",type:"select",options:P.kinds.map(function(k){return [k,k]}),value:"ask"},{name:"title",label:"Step",type:"textarea",required:true,max:300},{name:"why",label:"Why",type:"textarea",required:true,max:1000},
    {name:"label",label:"Link label (optional)",max:80},{name:"url",label:"Link address (optional, e.g. https://tickets.example/new?host={ip})",max:500}]}).then(function(v){if(!v)return;
    var i=v.bind.indexOf(":"),b={};b[v.bind.slice(0,i)]=v.bind.slice(i+1);var o={op:"add",id:v.id,bind:b,kind:v.kind,title:v.title,why:v.why};if(v.url)o.link={label:v.label||"Open",url:v.url};
    if(pbAdded().some(function(x){return x.id===v.id})){return cfAlert("You already have a step with that short name.")}CF.draft.playbook.push(o);cfPb()})}
function cfFindingKinds(){var m={};((CF.cat&&CF.cat.rules)||[]).forEach(function(r){if(r.kind)m[r.kind]=1});return Object.keys(m).sort()}
// ---- the Rule catalog card ----
function cfCatKey(r){var c=CF.draft.catalog||{};return [r.name,r.rule_id,r.key].filter(function(k){return k&&cfHas(c,k)})[0]||r.name}
function cfCatalog(){var box=cfBox("catalog"),K=CF.cat,q=(CF.cq||"").toLowerCase(),fam=function(k){return (K.families[k]||[k])[0]};
  var edited=function(r){return cfHas(CF.draft.catalog||{},cfCatKey(r))};
  var row=function(r){return '<tr class="qr nk'+(edited(r)?" cfchg":"")+'" style="--vc:'+((K.families[r.family]||[0,0,"#808297"])[2])+'"><td>'+esc(r.name)+(r.rule_id?'<div class="mut mono">'+esc(r.rule_id)+'</div>':"")+((K.live_ids||{})[r.name]?'<div class="mut mono" title="Sycope sent alerts of this rule with these template ids, not the one of the template sheet. The rule is matched by its name.">live: '+esc(K.live_ids[r.name].join(", "))+'</div>':"")+'</td><td>'+esc(fam(r.family))+'</td><td>'+esc(r.class)+'</td><td>'+esc(r.stage!=null?C.stages[r.stage]:"none")+'</td><td title="By direction: inbound, outbound and internal can read differently">'+esc(r.attack||"")+'</td><td>'+esc(r.subject)+'</td><td>'+esc(r.kind||"")+'</td><td>'+srcTag(r.source)+(edited(r)?' <span class="tg jw">edited</span>':"")+'</td><td><span class="btns"><button type="button" class="b2" data-cf="cat-edit" data-n="'+esc(r.name)+'">Edit…</button>'
    +(edited(r)||r.source==="admin"?'<button type="button" class="b2" data-cf="cat-reset" data-n="'+esc(r.name)+'">Reset</button>':"")+'</span></td></tr>'};
  var rules=K.rules.filter(function(r){return !q||[r.name,r.rule_id,r.family,fam(r.family),r.kind,r.source].join(" ").toLowerCase().indexOf(q)>=0});
  var unk=(K.unknown||[]).map(function(u){return '<tr class="qr nk" style="--vc:#c9a05b"><td>'+esc(u.name)+'</td><td>'+esc(u.tactic||"")+'</td><td>'+num(u.seen)+'</td><td><button type="button" class="b2 pri" data-cf="cat-classify" data-n="'+esc(u.name)+'">Classify…</button></td></tr>'}).join("");
  box.innerHTML='<h4>Rules the triage does not know <span class="mut">'+num((K.unknown||[]).length)+'. They are scored as weak evidence from their MITRE tactic.</span></h4>'+tcard(laneTable(["Alert name","MITRE tactic","Alerts seen",""],unk,"Every alert name is in the catalog."))
    +'<h4>All rules <span class="mut">'+num(rules.length)+' of '+num(K.rules.length)+'</span></h4><div class="cfx"><input type="search" id="cfcq" placeholder="rule, family, kind, who set it…" value="'+esc(CF.cq||"")+'"></div>'
    +tcard(laneTable(["Alert rule","Family","Class","Stage it can confirm","ATT&CK","Subject","Kind","Where from",""],rules.slice(0,400).map(row).join(""),"No rule matches.")+(rules.length>400?'<p class="mut">The first 400 are shown: narrow the search.</p>':""))}
function catEdit(name,unknown){var K=CF.cat,r=K.rules.filter(function(x){return x.name===name})[0];
  var cur=r||{name:name,family:"UNK",class:"C",stage:null,subject:"client",kind:"",ti:"",source:"fallback"},ex=(CF.draft.catalog||{})[cfCatKey(cur)]||{};
  var val=function(f,d){return ex[f]!==undefined?ex[f]:d},liked=null;
  // "Classify like...": a rule the catalog knows lends its family, class, stage, subject, kind, technique, tactic and
  // threat-intel list to the form (typed or picked from the list); every field can still be changed before saving
  var likeNames=K.rules.map(function(x){return x.name}).filter(function(n){return n!==name}).sort(function(a,b){return a.toLowerCase()<b.toLowerCase()?-1:1});
  var applyLike=function(w){var m=K.rules.filter(function(x){return x.name===w.querySelector("#dlg-like").value.trim()})[0];if(!m)return;liked=m;
    var put=function(f,v){var el=w.querySelector("#dlg-"+f);if(el)el.value=v==null?"":String(v)};
    put("family",m.family);put("class",m.class);put("stage",m.stage==null?"":m.stage);put("subject",m.subject);put("kind",m.kind||"");put("technique",m.technique||"");put("tactic",m.tactic||"");put("c2",m.c2?"yes":"no")};
  return dlg({title:(unknown?"Classify ":"Edit ")+name,setup:function(w){var l=w.querySelector("#dlg-like");l.addEventListener("input",function(){applyLike(w)});l.addEventListener("change",function(){applyLike(w)})},body:'<p class="mut">Family says what kind of behaviour it is, class how much evidence one alert carries (A indicator, B attack behaviour, C weak, D hygiene), stage how far an attacker got when it fires.</p>',ok:"Use this",fields:[
    {name:"like",label:"Classify like… (type or pick a rule: its family, class, stage, subject, kind and ATT&CK reading fill the form below)",max:80,list:likeNames,value:""},
    {name:"family",label:"Family",type:"select",options:Object.keys(K.families).map(function(k){return [k,k+" "+K.families[k][0]]}),value:val("family",cur.family)},
    {name:"class",label:"Class",type:"select",options:[["A","A indicator match"],["B","B attack behaviour"],["C","C weak or ambiguous"],["D","D hygiene or policy"]],value:val("class",cur.class)},
    {name:"stage",label:"Stage it can confirm",type:"select",options:[["","none"]].concat(C.stages.map(function(s,i){return [String(i),s]})),value:String(val("stage",cur.stage)==null?"":val("stage",cur.stage))},
    {name:"subject",label:"Who it is about",type:"select",options:[["client","the client"],["server","the server"],["ti","the listed address"]],value:val("subject",cur.subject)},
    {name:"kind",label:"Kind (scan, brute, beacon, exfil, ti, ...; empty if none)",max:40,value:val("kind",cur.kind||"")},
    {name:"technique",label:"ATT&CK technique id (such as T1133 or T1021.001; empty if none)",max:12,value:val("technique",cur.technique||"")},
    {name:"tactic",label:"ATT&CK tactic",type:"select",options:[["","none"]].concat((K.tactics||[]).map(function(t){return [t,t]})),value:val("tactic",cur.tactic||"")},
    {name:"c2",label:"Threat-intel rule whose listed address is a command-and-control one",type:"select",options:[["no","no"],["yes","yes"]],value:val("c2",cur.c2)?"yes":"no"}]}).then(function(v){if(!v)return;
    var e=cfClone(ex),set=function(f,x,now){if(String(x)!==String(now==null?"":now)||cfHas(e,f))e[f]=x};
    set("family",v.family,r?r.family:"UNK");set("class",v.class,r?r.class:"C");set("subject",v.subject,r?r.subject:"client");set("kind",v.kind,r?r.kind||"":"");
    set("technique",v.technique.trim(),r?r.technique||"":"");set("tactic",v.tactic,r?r.tactic||"":"");
    var c2=v.c2==="yes";if(c2!==!!(r&&r.c2)||cfHas(e,"c2"))e.c2=c2;
    if(liked&&liked.ti&&(!r||liked.ti!==r.ti))e.ti=liked.ti;        // the threat-intel list of the rule it was classified like
    var st=v.stage===""?null:+v.stage;if(String(st)!==String(r?r.stage:null)||cfHas(e,"stage"))e.stage=st;
    if(!r){["family","class","subject","kind"].forEach(function(f){e[f]=v[f]});e.stage=st;e.technique=v.technique.trim();e.tactic=v.tactic}      // a new entry says everything it decides
    var key=cfCatKey(cur);if(Object.keys(e).length)CF.draft.catalog[key]=e;else delete CF.draft.catalog[key];cfCatalog();cfgBar()})}
(function(){var b=$("#modb");if(b)b.onclick=function(){S.tab="config";sync();render();HELP.manual=false;helpFollow()}})();
// ---- the Versions card ----
function cfVersions(){var box=cfBox("versions"),V=CF.cfg.versions||[],shown=V.filter(function(v){return CF.drafts||v.status!=="draft"||v.active}),hidden=V.length-shown.length;
  var row=function(v){var st=v.active?'<span class="tg st">in force</span>':v.status==="published"||v.status==="retired"?'<span class="tg rec">earlier</span>':'<span class="tg svc" title="Saved for a preview, never published">preview only</span>';
    return '<tr class="qr nk" style="--vc:'+(v.active?"#3ecf72":"#2f3060")+'"><td>#'+esc(v.id)+(v.parent_id?'<div class="mut">from #'+esc(v.parent_id)+'</div>':"")+'</td><td class="c-l">'+tm(v.created_at*1000,"dhm")+'</td><td>'+esc(v.who)+'</td><td class="w">'+esc(v.note||"")+'</td><td>'+st+'</td><td><span class="btns"><button type="button" class="b2" data-cf="ver-view" data-id="'+esc(v.id)+'">View</button><button type="button" class="b2" data-cf="ver-export" data-id="'+esc(v.id)+'">Export</button>'
      +(!v.active&&(v.status==="published"||v.status==="retired")?'<button type="button" class="b2" data-cf="ver-back" data-id="'+esc(v.id)+'">Roll back to this…</button>':"")+'</span></td></tr>'};
  box.innerHTML='<div class="cfx"><span class="mut">'+(CF.cfg.active?"Version "+num(CF.cfg.active)+" is in force":"The shipped setup is in force (nothing published yet)")+(CF.cfg.error?'. <b style="color:#ffb3c0">'+esc(CF.cfg.error)+'</b>':"")+'</span><span class="sp"></span>'
    +(hidden||CF.drafts?'<label><input type="checkbox" id="cfvd"'+(CF.drafts?" checked":"")+'> show previews that were never published ('+num(V.filter(function(v){return v.status==="draft"&&!v.active}).length)+')</label>':"")
    +'<button type="button" class="b2" data-cf="ver-import">Import a file…</button><input type="file" id="cfimp" accept="application/json,.json" hidden></div>'
    +tcard(laneTable(["Version","When","Who","Note","State",""],shown.map(row).join(""),"No version yet: the shipped setup is in force."))}
function cfDownload(id){var p=passFor(ME.name),h={};if(p)h["X-SC-Pass"]=p.pass;
  return fetch("config-export?id="+encodeURIComponent(id),{credentials:"same-origin",headers:h}).then(function(r){if(!r.ok)return r.json().then(function(j){throw new Error(j.error||("HTTP "+r.status))});return r.blob()}).then(function(b){
    var a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="sycope-security-triage-config-"+id+".json";document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500)})}
function cfKeepOrDrop(what){var n=cfChanges().length;if(!n)return Promise.resolve(true);
  return dlg({title:"Drop your unpublished changes?",body:'<p>You have '+hp(n,"change")+' that are not published. '+esc(what)+' replaces them: they are lost.</p>',ok:"Drop them and go on",danger:true}).then(function(v){return !!v})}
function cfImport(file){var rd=new FileReader();rd.onload=function(){var data;try{data=JSON.parse(String(rd.result))}catch(x){cfAlert("That file is not JSON: "+x.message);return}
    var prev=CF.cfg.active;
    cfKeepOrDrop("An import").then(function(go){return go?post({op:"config:import",data:data}):null}).then(function(d){
      if(!d)return null;return cfReview(d.id,{title:"Import "+file.name+"?",body:data,commit:function(id){return post({op:"config:publish",id:id})},ok:"Publish it"}).then(function(res){if(res)return cfAfter(res,prev,"Imported as version "+((res&&res.version)||""))})}).catch(cfFail)};rd.readAsText(file)}
// ---- one click handler for every button of the tab ----
function cfClick(x){var a=x.dataset.cf,id=x.dataset.id;
  if(a==="preview")return cfPublishDraft();
  if(a==="discard")return dlg({title:"Discard your changes?",body:'<p>The '+hp(cfChanges().length,"unpublished change")+' go away. Nothing published is touched.</p>',ok:"Discard",danger:true}).then(function(v){if(!v)return;CF.draft=cfClone(cfBase());cfgDraw()});
  if(a==="reset"){delete CF.draft.params[id];delete CF.bad[id];var tr=x.closest("tr"),rg=cfReg(id);if(tr&&rg){tr.outerHTML=cfParamRow(rg,!!x.closest("#cfb-profile"));cfHistFill()}cfgBar();return}
  if(a==="freeze"){var on=x.dataset.v==="1";return dlg({title:on?"Freeze the profile?":"Unfreeze the profile?",body:on?'<p>Learning goes on, but the board is scored with the profile of today until you unfreeze it. Use it while a test or an incident is running, so that unusual traffic does not become normal.</p>':'<p>The board is scored with the newest profile again.</p>',ok:on?"Freeze":"Unfreeze"}).then(function(v){if(!v)return;
      return post({op:"profile:freeze",frozen:on}).then(function(){toast(on?"Profile frozen":"Profile unfrozen");return cfgLoad()}).then(refreshAll)}).catch(cfFail)}
  if(a==="internal-add")return dlg({title:"Declare an address",body:'<p class="mut">Use it for a public address that is really yours, or a private one that is not. The preview shows what changes.</p>',ok:"Add",fields:[{name:"ip",label:"IP address",required:true,max:45},{name:"inside",label:"It is",type:"select",options:[["1","inside my network"],["0","outside my network"]],value:"1"}]}).then(function(v){if(!v)return;
      if(!IPRE.test(v.ip)){return cfAlert("That is not an IP address.")}CF.draft.internal[v.ip]=v.inside==="1";cfProfile();cfgBar()});
  if(a==="internal-del"){delete CF.draft.internal[x.dataset.ip];cfProfile();cfgBar();return}
  if(a==="sug"){var key=x.dataset.key,acc=x.dataset.a==="accept",kind=key.split(":")[0],role=key.split(":")[1];
    var txt=!acc?"It stays quiet until its evidence changes.":kind==="internal-ip"?"This publishes a new configuration version that treats the address as inside your network, and the board is scored again.":kind==="role"&&role==="scanner"?"This adds an exception for the scanning rules of that host for 90 days (reason: confirmed scanner), under your name.":kind==="crown"?"It becomes a crown jewel: its stages weigh more.":"The profile takes the role into account at its next learning.";
    return dlg({title:(acc?"Accept":"Reject")+" this suggestion?",body:'<p>'+esc(key)+'</p><p class="mut">'+esc(txt)+'</p>',ok:acc?"Accept":"Reject",danger:!acc,fields:[{name:"reason",label:"Why? (kept in the audit log, optional)",type:"textarea",max:300}]}).then(function(v){if(!v)return;
      return post({op:"suggestion:answer",key:key,answer:acc?"accept":"reject",reason:v.reason}).then(function(){toast(acc?"Accepted":"Rejected");return cfgLoad()}).then(refreshAll)}).catch(cfFail)}
  if(a==="crown-add")return dlg({title:"Add a crown jewel",body:'<p class="mut">A host, or a whole network such as a database VLAN.</p>',ok:"Add",fields:[{name:"e",label:"IP address or network (10.0.5.0/24)",required:true,max:50},{name:"reason",label:"Why is it critical?",type:"textarea",required:true,max:300}]}).then(function(v){if(!v)return;
      var ent=(v.e.indexOf("/")>=0?"subnet:":"ip:")+v.e;return post({op:"crown:add",entity:ent,reason:v.reason}).then(function(){toast("Crown jewel added");return cfgLoad()}).then(refreshAll)}).catch(cfFail);
  if(a==="crown-del")return dlg({title:"Remove "+x.dataset.e.replace(/^(ip|subnet):/,"")+" from the crown jewels?",ok:"Remove",danger:true,fields:[{name:"reason",label:"Why?",type:"textarea",required:true,max:300}]}).then(function(v){if(!v)return;
      return post({op:"crown:remove",entity:x.dataset.e,reason:v.reason}).then(function(){toast("Removed");return cfgLoad()}).then(refreshAll)}).catch(cfFail);
  if(a==="expire"){var ids=Object.keys(CF.xsel).map(Number);return dlg({title:"Expire "+hp(ids.length,"exception")+"?",body:'<p>Their alerts count again at once. Each one gets its own line in the audit log.</p>',ok:"Expire",danger:true,fields:[{name:"note",label:"Why?",type:"textarea",required:true,max:300}]}).then(function(v){if(!v)return;
      return post({op:"exception:expire",ids:ids,note:v.note}).then(function(r){CF.xsel={};toast(hp((r.expired||[]).length,"exception")+" expired"+((r.missing||[]).length?", "+(r.missing||[]).length+" were not active":""));return cfgLoad()}).then(refreshAll)}).catch(cfFail)}
  if(a==="pb-edit")return pbEdit(x.dataset.t,!!x.dataset.add);
  if(a==="pb-hide"){var t=x.dataset.t;pbSet(t,"hide",pbOps(t,"hide").length?null:{});cfPb();return}
  if(a==="pb-move")return pbMove(x.dataset.t,x.dataset.g);
  if(a==="pb-undo"){var u=x.dataset.t;["edit","hide","move"].forEach(function(k){pbSet(u,k,null)});cfPb();return}
  if(a==="pb-keep"){var k=pbOps(x.dataset.t,"edit")[0],tp=CF.cfg.playbook.templates.filter(function(z){return z.id===x.dataset.t})[0];if(k&&tp)k.factory_hash=tp.hash;cfPb();return}
  if(a==="pb-del"){var d=x.dataset.t;CF.draft.playbook=CF.draft.playbook.filter(function(o){return !(o.op==="add"&&o.id===d)&&o.after!==d&&!(o.op!=="add"&&o.template===d)});cfPb();return}
  if(a==="pb-drop"){CF.draft.playbook.splice(+x.dataset.i,1);cfPb();return}
  if(a==="pb-add")return pbAddStep(x.dataset.bind||"");
  if(a==="cat-edit")return catEdit(x.dataset.n,false);
  if(a==="cat-classify")return catEdit(x.dataset.n,true);
  if(a==="cat-reset"){var rr=CF.cat.rules.filter(function(z){return z.name===x.dataset.n})[0];delete CF.draft.catalog[cfCatKey(rr||{name:x.dataset.n})];cfCatalog();cfgBar();return}
  if(a==="ver-view")return getA("config-version?id="+encodeURIComponent(id)).then(function(v){var b=v.body||{};
      return dlg({title:"Version "+v.id+(v.active?" (in force)":""),wide:true,ok:"Close",body:'<p class="mut">'+esc(v.who)+', '+tm(v.created_at*1000,"dhm")+(v.note?' · '+esc(v.note):"")+'. '+num(Object.keys(b.params||{}).length)+' settings, '+num(Object.keys(b.catalog||{}).length)+' rules, '+num((b.playbook||[]).length)+' playbook edits, '+num(Object.keys(b.internal||{}).length)+' addresses.</p><pre class="math">'+esc(JSON.stringify(b,null,2).slice(0,12000))+'</pre>'})}).catch(cfFail);
  if(a==="ver-export")return cfDownload(id).catch(cfFail);
  if(a==="ver-back"){var prev=CF.cfg.active;return cfKeepOrDrop("Rolling back").then(function(go){if(!go)return null;return getA("config-version?id="+encodeURIComponent(id))}).then(function(v){if(!v)return null;
      return cfDraftAndReview(v.body,"preview of the roll back to version "+id,{title:"Roll back to version "+id+"?",ok:"Roll back",commit:function(){return post({op:"config:rollback",id:+id})}}).then(function(res){if(res)return cfAfter(res,prev,"Rolled back to version "+id)})}).catch(cfFail)}
  if(a==="ver-import"){var fi=$("#cfimp");if(fi){fi.value="";fi.click()}return}}
document.addEventListener("toggle",function(e){var d=e.target;if(d&&d.classList&&d.classList.contains("cfpg"))CF.pbopen[d.dataset.g]=d.open},true);
document.addEventListener("click",function(e){var x=e.target.closest&&e.target.closest("[data-cf]");if(!x||e.target.closest(".dlg-w"))return;e.preventDefault();e.stopPropagation();cfClick(x)},true);
document.addEventListener("change",function(e){var x=e.target,d=x.dataset||{};
  if(d.cfp!==undefined){cfSetParam(x);return}if(d.cfl!==undefined){cfSetList(x);return}if(d.cfa!==undefined){cfSetAsns(x);return}if(d.cft!==undefined){cfSetTexts(x);return}
  if(x.id==="cfxs"){CF.xf.state=x.value;cfSilenced();return}
  if(d.cfx!==undefined){if(x.checked)CF.xsel[d.cfx]=1;else delete CF.xsel[d.cfx];cfXSel();return}
  if(d.cfxall!==undefined){$$("[data-cfx]").forEach(function(c){c.checked=x.checked;if(x.checked)CF.xsel[c.dataset.cfx]=1;else delete CF.xsel[c.dataset.cfx]});cfXSel();return}
  if(x.id==="cfvd"){CF.drafts=x.checked;cfVersions();return}
  if(x.id==="cfimp"&&x.files&&x.files[0]){cfImport(x.files[0]);return}});
var CFT=null;document.addEventListener("input",function(e){var x=e.target;if(!x||!x.id)return;
  if(x.id==="cfxq"||x.id==="cfcq"||x.id==="cfpq"){clearTimeout(CFT);CFT=setTimeout(function(){var pos=x.selectionStart;
    if(x.id==="cfxq"){CF.xf.q=x.value;$("#cfxt").innerHTML=cfXTable(cfXRows())}
    else{if(x.id==="cfcq"){CF.cq=x.value;cfCatalog()}else{CF.pbq=x.value;cfPlaybooks()}var n=$("#"+x.id);if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(y){}}}},200)}});
""".replace("@@WANT_DAYS@@", str(WANT_DAYS))
