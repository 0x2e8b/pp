"""FastAPI app. Every route is one path segment (Sycope Passthrough allows ^/([A-Za-z0-9_-]+)?/?$ for GET and three
POST paths: scoring-model, pcap-request, action).

    /          triage (page)                 /board      the queue, funnel and campaigns (JSON)
    /host      one host: story, evidence     /story      one story and its hosts (JSON, ?key=)
    /campaign  one campaign: its incidents and hosts (JSON, ?net=)
    /incident  the page of one incident: ?ip= (a host), ?story= (a group of hosts), ?campaign= (a /16),
               ?history= (a record of the incident history, as it was)
    /history   the incident history (JSON or CSV)  /history-item  one record (JSON, ?id=)
    /lane      targets, external, hygiene, tuning (JSON, ?name=)
    /alertdefs Sycope's alert definitions by name (JSON), the silence dialog's Alert list
    /action    POST: triage state, exceptions (SC_TRIAGE_EDIT)
    /config /config-version /config-export /config-preview /profile /crown /catalog /exceptions /health-data /replay
               the Configuration pages' data (JSON), for a Sycope-confirmed admin only (admin.py)
    /whoami    who is acting, confirmed by Sycope (identity.py): a claim to prove, or the pass once it is proven
    /clusters  the Security Clusters board (page)  /data, /cluster   its JSON (/classic redirects here); /cluster?key=
               is cl:<episode id> (a cluster) or ct:<ip> (an Under attack entry), both with their work state and steps.
               Work on them is POST /action with "product": "clusters" (cluster_work.py); /history, /history-item
               and /handover take ?product=clusters
    /scoring   the models, explained (page)  /system    feed status (page)        /healthz   liveness
"""

from __future__ import annotations

import json
import logging
import os
import re
import time
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlencode, urlsplit

import polars as pl
from fastapi import FastAPI, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from sycope_clusters import (
    admin,
    cluster_work,
    clusters,
    episodes,
    evidence,
    guide,
    health,
    helpdoc,
    history,
    identity,
    pages,
    pipeline,
    playbook,
    scoring,
    silence,
    sla,
    store,
    ticket,
    triage,
    ui,
)
from sycope_clusters import confplane as cfg
from sycope_clusters import profile as profile_mod
from sycope_clusters.config import Settings
from sycope_clusters.ingest import BI
from sycope_clusters.live import Live, PreviewBusy, PreviewTooBig
from sycope_clusters.params import FACTORY
from sycope_clusters.sycope import SycopeError

HELP_DIR = Path(__file__).resolve().parent / "help"   # the help's screenshots (tools/help_shots.py)

_NOCACHE = {"Cache-Control": "no-store"}
LANE_MAX = 200      # entries of each Clusters lane in /data (the totals say how many there are)
PRODUCTS = ("triage", "clusters")
BODY_MAX, ADMIN_BODY_MAX = 20_000, 2 * 2**20     # bytes of a POST body; an admin op may carry a configuration
log = logging.getLogger(__name__)


def create_app(settings: Settings | None = None, start_poller: bool = True) -> FastAPI:
    # The engine turns naive UTC datetimes into epochs with .timestamp(), which reads them as local time.
    os.environ["TZ"] = "UTC"
    time.tzset()
    settings = settings or Settings.from_env()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    live = Live(settings)
    ident = identity.Identity(identity.load_key(settings.state_dir), lambda a, b: live.identity_audit(a, b),
                              lambda name: live.identity_user(name))

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        if start_poller:
            live.start()
        yield
        live.stop()

    app = FastAPI(lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
    app.state.live = live
    app.state.identity = ident

    def _model():
        """The numbers the board was scored with (the shipped ones before the first build): what the help states."""
        return live.board.params if live.board is not None else live.scoring_params()

    def _range(t: str) -> int:
        return pipeline.RANGES.get(t, pipeline.RANGES.get(settings.default_range, 21600))

    def _off() -> int:
        """The configured UTC offset in minutes: every page writes its times in it (window.SC_OFF)."""
        return int(live.params["calendar.utc_offset_min"])

    @app.get("/", response_class=HTMLResponse)
    def triage_page(view: str = Query("", max_length=8)) -> HTMLResponse:
        return HTMLResponse(ui.triage_page(settings, _off(), simple=view == "simple"), headers=_NOCACHE)

    @app.get("/incident", response_class=HTMLResponse)
    def incident(ip: str = Query("", max_length=64), story: str = Query("", max_length=200),
                 campaign: str = Query("", max_length=64), history: str = Query("", max_length=12),
                 view: str = Query("", max_length=8)) -> HTMLResponse:
        return HTMLResponse(ui.incident_page(settings, ip.strip(), story.strip(), campaign.strip(), history.strip(), _off(),
                                             simple=view == "simple"), headers=_NOCACHE)

    @app.get("/help", response_class=HTMLResponse)
    def help_page(from_: str = Query("", alias="from", max_length=12)) -> HTMLResponse:
        """`?from=clusters` (the links of the Clusters pages) keeps the top bar on Clusters; Triage is the default."""
        return HTMLResponse(guide.help_page(settings, _model(), from_ if from_ in ("clusters", "episodes") else "triage", _off()),
                            headers=_NOCACHE)

    @app.get("/helpdoc")
    def helpdoc_parts() -> JSONResponse:
        """Every part of the help, for the side panel the ? opens."""
        return JSONResponse(helpdoc.all_parts(f"helpimg?v={pages.VERSION}&n=", _model()), headers=_NOCACHE)

    @app.get("/helpimg")
    def helpimg(n: str = Query(..., max_length=40)):
        """One screenshot of the help (one path segment and a query: what the Passthrough's GET rule lets
        through)."""
        from fastapi.responses import FileResponse

        f = HELP_DIR / f"{n}.webp"
        if not re.fullmatch(r"[a-z0-9-]{1,40}", n) or not f.is_file():
            return JSONResponse({"error": "no such picture"}, status_code=404, headers=_NOCACHE)
        return FileResponse(f, media_type="image/webp", headers={"Cache-Control": "public, max-age=86400"})

    @app.get("/digest", response_class=HTMLResponse)
    def digest() -> HTMLResponse:
        return HTMLResponse(ui.digest_page(settings, live.board, live.store, _off()), headers=_NOCACHE)

    @app.get("/clusters", response_class=HTMLResponse)
    def live_page(view: str = Query("", max_length=8)) -> HTMLResponse:
        # the Episodes view unless the compare mode keeps the Clusters board with its own verdicts
        simple = view == "simple"
        return HTMLResponse(pages.live_page(settings, _off(), simple=simple) if settings.clusters_compare
                            else episodes.page(settings, _off(), simple=simple), headers=_NOCACHE)

    @app.get("/episodes", response_class=HTMLResponse)
    def episodes_page(view: str = Query("", max_length=8)) -> HTMLResponse:
        """The Episodes view in both modes; without the compare mode /clusters serves it too (old links keep working)."""
        return HTMLResponse(episodes.page(settings, _off(), simple=view == "simple"), headers=_NOCACHE)

    @app.get("/episodes-data")
    def episodes_data() -> JSONResponse:
        return JSONResponse(episodes.data(live), headers=_NOCACHE)

    def _clusters_off(request: Request, product: str, route: str) -> RedirectResponse | None:
        """Without the compare mode Clusters keeps no verdicts, statuses or history: what asks for them goes to the
        Triage equivalent (the same path without `product`, relative: the app sits under a path prefix)."""
        if product != "clusters" or settings.clusters_compare:
            return None
        q = urlencode([(k, v) for k, v in request.query_params.multi_items() if k != "product"])
        return RedirectResponse(route + (f"?{q}" if q else ""), status_code=307)

    def _data_off() -> JSONResponse | None:
        if settings.clusters_compare:
            return None
        return JSONResponse({"error": "Clusters runs without its own verdicts: use the Episodes view and Triage"},
                            status_code=404, headers=_NOCACHE)

    @app.get("/classic")
    def classic_moved() -> RedirectResponse:
        # the board's first address: bookmarks keep working; relative, the app sits under a path prefix
        return RedirectResponse("clusters", status_code=307)

    def _steps(steps: list[dict], keys: list[str]) -> dict:
        """The steps with what the team checked, kept under the first open incident of `keys`."""
        rec = next((o for o in (live.store.open_incident_by_key(k) for k in keys) if o), None)
        return {"list": steps, "rec": rec["id"] if rec else None, "rec_key": rec["ui_key"] if rec else None,
                "done": live.store.steps(rec["id"]) if rec else {}}

    def _is_admin(request: Request) -> bool:
        p = ident.check(request.headers.get("x-sc-pass"))
        return bool(p and p.get("a"))

    def _profile_depth() -> dict:
        """How many comparable days the learned profile rests on, of how many it wants (the banner under 14)."""
        prof = live.profile
        return {"days": len(prof.days) if prof is not None else 0, "want": profile_mod.WANT_DAYS,
                "frozen": live.store.meta("profile_frozen") == "1"}

    def _fresh() -> dict:
        st = _status()
        return {"built_at": live.board.built_at if live.board else None, "poll_ok": st["poll_ok"],
                "poll_msg": st["poll_msg"], "poll_s": st["poll_s"]}

    def _status() -> dict:
        b, last, bf = live.board, live.last, live.backfill
        return {"ready": b is not None, "poll_ok": last.ok, "poll_msg": last.message, "poll_at": last.at,
                "poll_s": settings.poll_seconds, "edit": settings.triage_edit, "version": pages.VERSION,
                "backfill": {"running": bf.running, "message": bf.message, "day": bf.day},
                "history": b.history if b else {"days": [], "depth": 0}, "profile": _profile_depth(),
                "shift_gap_h": _model()["shift_gap_h"], "utc_offset_min": _off()}

    @app.get("/board")
    def board(watch: int = Query(0), handled: int = Query(0)) -> JSONResponse:
        b = live.board
        if b is None:
            return JSONResponse({**_status(), "now": time.time(), "items": []}, headers=_NOCACHE)
        # the recorder's packets per host go on the rows (PCAP tag)
        tri = live.store.triage()
        q = triage.queue(b, tri, watch=bool(watch), handled=bool(handled),
                         order=settings.stage_order, pcap=live.pcap_by_ip)
        lanes = {"targets": sum(1 for t in b.targets if t["heat"] == "hot"),
                 "external": sum(1 for x in b.externals if x["rating"] == "hostile"),
                 "tuning": sum(1 for x in b.tuning["services"] if not x["excepted"]), "hygiene": len(b.hygiene)}
        days = sorted((d, v["alerts"] or 0) for d, v in live.store.days().items() if (v["alerts"] or 0) > 0)[-7:]
        return JSONResponse({**_status(), "now": b.now, "built_at": b.built_at, "took_s": b.took_s, **q,
                             "held": triage.held(b, tri, live.store),
                             "unreviewed": history.unreviewed(live.store, b, b.params["unreviewed_days"]),
                             "held_records": history.taken(live.store, b),
                             "away": history.shift_start(live.store, p=b.params),
                             "order": settings.stage_order,
                             "trend": [[d, n] for d, n in days],
                             "funnel": triage.funnel(b, q), "lanes": lanes, "silenced_alerts": live.silenced_alerts,
                             "silence_spikes": [{"id": x["id"], "text": x["text"], "day": x["day"]}
                                                for x in live.silence_spikes.values()],
                             "sla": sla.queue_map(live.store.sla_rows(b.now), b.params, b.now),
                             "campaigns": [{k: v for k, v in c.items() if k != "members"} for c in b.campaigns],
                             "families": {k: [v[0], v[1], v[2]] for k, v in triage.FAMILIES.items()}},
                            headers=_NOCACHE)

    def _safe_ticket(build) -> str:
        """The ticket text; a failure of it never takes the page down (the Copy button then has nothing)."""
        try:
            return build()
        except Exception:
            log.exception("building the ticket failed")
            return ""

    def _host_payload(ip: str, full: bool = False, recorder: bool = True) -> dict | None:
        """What the host page reads (/host), with the ticket text the Copy button and the webhook use."""
        b = live.board
        d = triage.host_detail(b, ip, live.store, live.window.host_alerts(ip, settings.raw_per_host), live.catalog,
                               live._nets(), buckets=live.window.host_buckets(ip), full=full) if b else None
        if d is None:
            return None
        jobs = live.recorder_jobs(ip) if settings.recorder_passthrough and recorder else {}
        idx = live.pcap_by_alert
        ids = ({r[0] for r in live.window.host_alerts(d["ip"], settings.raw_per_host)}
               | {k for k, v in idx.items() if d["ip"] in (v.get("client"), v.get("server"))}) if idx or jobs else set()
        known = {k: {"state": v["state"], "file": v["file"]} for k, v in idx.items() if k in ids}
        known.update({k: v for k, v in jobs.items() if k in ids or not idx})
        d["pcap"] = known
        listed = sorted(({"id": k, **idx.get(k, {}), **known[k]} for k in known), key=lambda j: -(j.get("t") or 0))
        d["pcap_summary"] = {"done": sum(1 for j in listed if j.get("state") == "done"),
                             "queued": sum(1 for j in listed if j.get("state") in ("queued", "running")),
                             "jobs": [{"id": j["id"], "t": j.get("t"), "name": j.get("name"), "state": j.get("state")}
                                      for j in listed[:8]]}
        d["recorder"] = {"on": bool(settings.recorder_passthrough), "request": bool(settings.recorder_destination),
                         "buffer": live.recorder_buffer() if settings.recorder_passthrough else {}}
        d["parents"] = triage.parents(b, d["ip"])
        d["fresh"] = _fresh()
        par = d["parents"]
        now_in = ["h:" + d["ip"], *(["s:" + par["story"]["key"]] if par.get("story") else []),
                  *(["c:" + par["campaign"]["net"]] if par.get("campaign") else [])]
        d["earlier"] = history.earlier(live.store, d["ip"], current=now_in)
        # next steps, kept under the incident the host is part of now (its own, else its group's or campaign's)
        e = b.entities.get(d["ip"])
        ti = b.target_inc.get(d["ip"]) if e is None or e.verdict == "watch" else None
        ov = live.playbook_overlay
        steps = (playbook.for_host(b, e, d["pcap_summary"]["done"], ov) if e is not None and e.verdict != "watch"
                 else playbook.for_target(b, ti, ov) if ti is not None else [])
        d["steps"] = _steps(steps, now_in)
        d["priority"] = (playbook.priority(e.verdict, e.crown, [c for c, _, _ in e.chains], b.params)
                         if e is not None and e.verdict != "watch"
                         else playbook.priority(ti.verdict, ti.crown, (), b.params) if ti is not None else None)
        d["ticket"] = _safe_ticket(lambda: ticket.host_text(d, live.ticket_ctx()))
        return d

    @app.get("/host")
    def host(request: Request, ip: str = Query(..., max_length=64)) -> JSONResponse:
        d = _host_payload(ip.strip(), _is_admin(request))
        if d is None:
            return JSONResponse({"error": "this IP has no alerts in the window"}, status_code=404, headers=_NOCACHE)
        return JSONResponse(d, headers=_NOCACHE)

    def _story_payload(key: str) -> dict | None:
        b = live.board
        d = triage.story_detail(b, key, live.store.triage(), live.store, live.pcap_by_ip) if b else None
        if d is None:
            return None
        d["fresh"] = _fresh()
        d["steps"] = _steps(playbook.for_story(b, b.stories[key], live.playbook_overlay), ["s:" + key])
        d["priority"] = playbook.priority(d["verdict"], bool(d.get("crown_hosts")), d.get("chains") or [], b.params)
        d["ticket"] = _safe_ticket(lambda: ticket.group_text(d, False, live.ticket_ctx()))
        return d

    @app.get("/story")
    def story(key: str = Query(..., max_length=200)) -> JSONResponse:
        d = _story_payload(key)
        if d is None:
            return JSONResponse({"error": "this incident is not on the board any more: its hosts changed verdict or "
                                          "pattern, or left the 24 h window"}, status_code=404, headers=_NOCACHE)
        return JSONResponse(d, headers=_NOCACHE)

    def _campaign_payload(net: str) -> dict | None:
        b = live.board
        d = triage.campaign_detail(b, net, live.store.triage(), live.store, live.pcap_by_ip,
                                   settings.stage_order) if b else None
        if d is None:
            return None
        d["fresh"] = _fresh()
        c = next(c for c in b.campaigns if c["net"] == d["net"])
        d["steps"] = _steps(playbook.for_campaign(b, c, d["children"], live.playbook_overlay), ["c:" + d["net"]])
        d["priority"] = playbook.priority(d["verdict"], d.get("crown") or 0, d.get("chains") or [], b.params)
        d["ticket"] = _safe_ticket(lambda: ticket.group_text(d, True, live.ticket_ctx()))
        return d

    @app.get("/campaign")
    def campaign(net: str = Query(..., max_length=64)) -> JSONResponse:
        d = _campaign_payload(net.strip())
        if d is None:
            return JSONResponse({"error": "no campaign in this network on the board now"}, status_code=404,
                                headers=_NOCACHE)
        return JSONResponse(d, headers=_NOCACHE)

    def _ticket_of(o: dict, ctx) -> str | None:
        """The live ticket of an incident record (the webhook): the page payload of its host, group or campaign while
        the board shows it, else None (the record's own text is used)."""
        key = o.get("ui_key") or ""
        d = None
        if key.startswith("h:"):
            d = _host_payload(key[2:], recorder=False)       # no recorder call per webhook event
        elif key.startswith("s:"):
            d = _story_payload(key[2:])
        elif key.startswith("c:"):
            d = _campaign_payload(key[2:])
        return d["ticket"] if d else None

    live.ticket_fn = _ticket_of

    @app.get("/lane")
    def lane(request: Request, name: str = Query(..., max_length=16)) -> JSONResponse:
        b = live.board
        if b is None:
            return JSONResponse({"error": "not ready"}, status_code=409, headers=_NOCACHE)
        try:
            d = triage.lane(b, name)
        except KeyError:
            return JSONResponse({"error": "no such lane"}, status_code=404, headers=_NOCACHE)
        if name == "tuning":
            d["audit"] = triage.activity(live.store, full=_is_admin(request))
            d["edit"] = settings.triage_edit
            d["suggest"] = triage.suggestions(b, live.store.triage())
            d["pending"] = [{**x, "big": (triage.silence_scope(b, live.catalog, x, live.silence_scan(x))
                                          if x["kind"] == "silence" else
                                          triage.exception_scope(b, live.catalog, x["kind"], x["rule"], x["server"],
                                                                 x["port"], x["actor"]))["big"]}
                            for x in live.store.pending_exceptions()]
            d["approval"] = settings.exception_approval
            now = time.time()
            d["silence"] = silence.rules_view(live.store, now, _off(), int(live.params["silence.remove_days"]))
            d["silence_now"] = now
            d["silence_remove_days"] = int(live.params["silence.remove_days"])
            d["silence_spikes"] = list(live.silence_spikes.values())
        return JSONResponse(d, headers=_NOCACHE)

    @app.get("/alertdefs")
    def alertdefs_data() -> JSONResponse:
        """Sycope's alert definitions by name, read by the poll (alertdefs.py): {defs: [{name, active, type, tactic,
        family}], read_at, error}. `family` is ours, from the rule catalog, "" when it does not know the name."""
        cache = live.alert_defs
        d = cache.view(lambda n: (r.family if (r := live.catalog.rules.get(n)) and r.family != "UNK" else ""))
        if d["error"] == "not read yet" and not (settings.sycope_url and settings.sycope_user):
            d["error"] = "Sycope is not configured"
        return JSONResponse(d, headers=_NOCACHE)

    @app.get("/audit")
    def audit(request: Request, who: str = Query("", max_length=40), action: str = Query("", max_length=40),
              q: str = Query("", max_length=80), days: int = Query(7, ge=0, le=3650), bulk: int = Query(0),
              limit: int = Query(100, ge=1, le=5000), offset: int = Query(0, ge=0),
              fmt: str = Query("json", alias="format", max_length=4)):
        """The team's actions, filtered; format=csv downloads them (bulk=1 adds the per-host lines of story actions)."""
        since = time.time() - days * 86400 if days else 0
        rows, total = live.store.audit_query(who, action, q, since, bool(bulk), limit if fmt != "csv" else 5000,
                                             offset if fmt != "csv" else 0, full=_is_admin(request),
                                             product=None)
        if fmt == "csv":
            import csv
            import io
            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow(["time_utc", "who", "action", "target", "note", "detail", "product", "who_confirmed_by_sycope"])
            for r in rows:
                w.writerow([time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(r["at"])), r["who"], r["action"],
                            r["target"], r["note"], json.dumps(r["detail"]), r.get("product") or "triage",
                            {1: "yes", 0: "no"}.get(r.get("verified"), "")])
            name = time.strftime("sycope-security-triage-audit-%Y%m%d.csv", time.gmtime())
            from fastapi.responses import Response
            return Response(buf.getvalue(), media_type="text/csv; charset=utf-8",
                            headers={**_NOCACHE, "Content-Disposition": f'attachment; filename="{name}"'})
        return JSONResponse({"rows": rows, "total": total, "facets": live.store.audit_facets(),
                             "words": {**triage.ACTION_WORDS, **cluster_work.ACTION_WORDS}}, headers=_NOCACHE)

    @app.get("/history")
    def incident_history(request: Request, days: int = Query(30, ge=0, le=3650), kind: str = Query("", max_length=16),
                         verdict: str = Query("", max_length=12), outcome: str = Query("", max_length=14),
                         q: str = Query("", max_length=80), limit: int = Query(100, ge=1, le=5000),
                         offset: int = Query(0, ge=0), fmt: str = Query("json", alias="format", max_length=4),
                         hours: int = Query(0, ge=0, le=24 * 14), product: str = Query("triage", max_length=8)):
        """Every incident the queue showed (open ones and closed ones, as they were), filtered; format=csv
        downloads them. `product` picks Triage's records (the default) or Clusters'."""
        moved = _clusters_off(request, product, "history")
        if moved:
            return moved
        if kind not in ("", "entity", "group", "campaign", "cluster", "cluster-target") \
                or verdict not in ("", *evidence.VERDICTS) or product not in PRODUCTS \
                or outcome not in ("", "open", "none", *history.TAKEN, "partial", "expired", "merged", "excepted"):
            return JSONResponse({"error": "unknown filter"}, status_code=400, headers=_NOCACHE)
        d = history.listing(live.store, days, kind, verdict, outcome, q.strip(), limit if fmt != "csv" else 5000,
                            offset if fmt != "csv" else 0, hours, product, live.board.params if live.board else FACTORY)
        if fmt == "csv":
            import csv
            import io
            buf = io.StringIO()
            w = csv.writer(buf)
            t = lambda x: time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(x)) if x else ""
            w.writerow(["opened_utc", "closed_utc", "kind", "subject", "label", "peak_verdict", "confidence", "stage",
                        "headline", "hosts", "status", "outcome", "outcome_reason", "outcome_by", "outcome_utc",
                        "minutes_to_handle", "parent", "stage_name"])
            for r in d["rows"]:
                w.writerow([t(r["opened_at"]), t(r["closed_at"]), r["kind"], r["subject"], r["label"], r["verdict"],
                            r["conf"], r["stage"], r["headline"], r["members_n"], r["status"], r["outcome"] or "",
                            r.get("outcome_reason") or "", r["outcome_by"] or "", t(r["outcome_at"]),
                            round(r["tth"] / 60) if r["tth"] else "", r["parent"] or "", r["stage_name"]])
            name = time.strftime("sycope-security-triage-incidents-%Y%m%d.csv", time.gmtime())
            from fastapi.responses import Response
            return Response(buf.getvalue(), media_type="text/csv; charset=utf-8",
                            headers={**_NOCACHE, "Content-Disposition": f'attachment; filename="{name}"'})
        return JSONResponse(d, headers=_NOCACHE)

    @app.get("/flows")
    def flows(c: str = Query("", max_length=45), s: str = Query("", max_length=45),
              port: int = Query(0, ge=0, le=65535),
              t0: float = Query(..., alias="from"), t1: float = Query(..., alias="to"),
              mode: str = Query("raw", max_length=6), limit: int = Query(40, ge=1, le=100)) -> JSONResponse:
        """Flows of a pair (mode raw) or of a host's counterparts (client, server) from Sycope's netflow stream,
        for the pages (times in ms)."""
        import ipaddress

        def addr(v: str) -> str | None:
            if not v:
                return None
            try:
                return str(ipaddress.ip_address(v.strip()))
            except ValueError:
                raise ValueError(f"not an IP address: {v[:45]}") from None

        try:
            ca, sa = addr(c), addr(s)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400, headers=_NOCACHE)
        if mode not in ("raw", "client", "server") or (mode == "client" and not ca) or (mode == "server" and not sa) \
                or not (ca or sa):
            return JSONResponse({"error": "say which host: c (client) or s (server)"}, status_code=400,
                                headers=_NOCACHE)
        start, end = t0 / 1000, t1 / 1000
        if not (0 < start < end) or end - start > 26 * 3600:
            return JSONResponse({"error": "the window must be under 26 hours"}, status_code=400, headers=_NOCACHE)
        if not settings.sycope_url:
            return JSONResponse({"error": "Sycope is not configured here"}, status_code=503, headers=_NOCACHE)
        try:
            rows = live.flows(ca, sa, port or None, start, end, mode, limit)
        except SycopeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=502, headers=_NOCACHE)
        return JSONResponse({"rows": rows, "mode": mode, "from": t0, "to": t1}, headers=_NOCACHE)

    @app.get("/search")
    def search(q: str = Query("", max_length=100)) -> JSONResponse:
        b = live.board
        if b is None:
            return JSONResponse({"q": q, "groups": []}, headers=_NOCACHE)
        return JSONResponse(triage.search(b, live.store, q), headers=_NOCACHE)

    @app.get("/handover")
    def handover(request: Request, hours: float | None = Query(None, gt=0, le=24 * 14),
                 product: str = Query("triage", max_length=8)):
        moved = _clusters_off(request, product, "handover")
        if moved:
            return moved
        # no hours: since the team was last here (the last action before a pause: a night, a weekend)
        since = time.time() - hours * 3600 if hours else None
        if product not in PRODUCTS:
            return JSONResponse({"error": "unknown product"}, status_code=400, headers=_NOCACHE)
        # the learned team rhythm (shift_gap_h) counts, as on /board
        tri = live.store.cluster_triage() if product == "clusters" else live.store.triage()
        return JSONResponse(history.handover(live.store, since, tri, p=_model(), product=product), headers=_NOCACHE)

    @app.get("/exception-preview")
    def exception_preview(kind: str = Query(..., max_length=10), rule: str = Query("", max_length=120),
                          server: str = Query("", max_length=64), port: str = Query("", max_length=12),
                          actor: str = Query("", max_length=64), src: str = Query("", max_length=64),
                          dst: str = Query("", max_length=64), proto: str = Query("", max_length=8),
                          win_days: str = Query("", max_length=40), win_from: str = Query("", max_length=5),
                          win_to: str = Query("", max_length=5)) -> JSONResponse:
        b = live.board
        if b is None or kind not in ("service", "host-rule", "host", "silence"):
            return JSONResponse({"error": "no board or unknown kind"}, status_code=400, headers=_NOCACHE)
        if kind == "silence":
            body = {"rule": rule, "src": src, "dst": dst, "port": port, "proto": proto, "win_days": win_days,
                    "win_from": win_from, "win_to": win_to}
            try:
                f = silence.clean(body)
            except silence.RuleError as exc:
                return JSONResponse({"refused": str(exc)}, headers=_NOCACHE)
            out = triage.silence_scope(b, live.catalog, f, live.silence_scan(f))
            try:
                silence.check_shape(f)
            except silence.RuleError as exc:
                out["refused"] = str(exc)
            if f["rule"] and f["rule"] not in live.catalog.rules and f["rule"] not in live.catalog.unknown():
                out["refused"] = "unknown alert name"
            out["fields"] = f
            return JSONResponse(out, headers=_NOCACHE)
        return JSONResponse(triage.exception_preview(b, kind, rule.strip() or None, server.strip() or None,
                                                     port.strip() or None, actor.strip() or None, live.catalog),
                            headers=_NOCACHE)

    @app.get("/silence-hits")
    def silence_hits(id: int = Query(..., ge=1), limit: int = Query(168, ge=1, le=2200)) -> JSONResponse:
        """The hit log of one silence rule, newest hour first: hours, alert counts, hosts, sample alert ids."""
        row = live.store.exception(id)
        if row is None:
            return JSONResponse({"error": "no such rule"}, status_code=404, headers=_NOCACHE)
        return JSONResponse({"rule": {**row, "label": silence.describe(row)}, "hours": live.store.silence_log(id, limit),
                             "stats": live.store.silence_stats(time.time(), _off()).get(id)}, headers=_NOCACHE)

    @app.get("/history-item")
    def incident_history_item(request: Request, id: int = Query(..., ge=1), product: str = Query("triage", max_length=8)):
        if product == "clusters" and not settings.clusters_compare:    # its ids mean nothing to Triage's history
            return JSONResponse({"error": "Clusters keeps no history: see the Triage history"}, status_code=404,
                                headers=_NOCACHE)
        if product not in PRODUCTS:
            return JSONResponse({"error": "unknown product"}, status_code=400, headers=_NOCACHE)
        if product == "clusters":
            d = cluster_work.item(live.store, id, live.store.cluster_triage())
            if d is not None:
                d["steps"] = cluster_work.record_steps(live.store, d)
        else:
            d = history.item(live.store, live.board, id, live.store.triage(),
                             p=live.board.params if live.board else FACTORY)
            if d is not None:
                d["steps"] = history.record_steps(live.store, d, live.catalog, live.playbook_overlay)
        if d is None:
            return JSONResponse({"error": "no such incident in the history"}, status_code=404, headers=_NOCACHE)
        return JSONResponse(d, headers=_NOCACHE)

    @app.get("/data")
    def data(request: Request, t: str = Query("6h", max_length=8), sort: str = Query("priority", max_length=16)) -> JSONResponse:
        if (off := _data_off()):
            return off
        cb = live.cboard
        snap, last = cb.snapshot if cb else None, live.last
        ctri = live.store.cluster_triage()
        # Under attack entries are work objects too: a verdict and the analyst's state on each
        params = _model()
        targets = [{**t, "verdict": cluster_work.target_verdict(t),
                    "state": cluster_work.state_row(cluster_work.target_verdict(t), ctri.get(t["key"])),
                    "p": playbook.priority(cluster_work.target_verdict(t), t.get("crown"), (), params)}
                   for t in (cb.targets[:LANE_MAX] if cb else [])]
        days = params["unreviewed_days"]
        status = {"ready": snap is not None, "lean": bool(cb and cb.lean), "poll_ok": last.ok, "poll_msg": last.message,
                  "poll_at": last.at, "delta_s": max(settings.delta_seconds, clusters.MIN_DELTA_S), "poll_s": settings.poll_seconds,
                  "edit": settings.triage_edit, "targets": targets, "targets_total": cb.lane_totals[0] if cb else 0,
                  "externals": cb.externals[:LANE_MAX] if cb else [], "externals_total": cb.lane_totals[1] if cb else 0,
                  # what ended with nobody having looked at it, and what is being worked after it ended
                  "ended": history.unreviewed(live.store, None, days, product="clusters"),
                  "held_records": history.taken(live.store, None, product="clusters")}
        if snap is None:
            now = time.time()
            return JSONResponse({**status, "now": now, "built_at": 0, "range_s": _range(t), "clusters": [],
                                 "alerts_in_range": 0, "alerts_total": 0, "phases": {}, "types": {}, "chronic_n": 0,
                                 "hist": pipeline.hist(pipeline.frame([]), now, _range(t))}, headers=_NOCACHE)
        dbg = settings.debug_models and _is_admin(request)
        out = pipeline.listing(snap, _range(t), sort, live.names, dbg)
        chronic = 0
        for c in out["clusters"]:     # memory is display only; chronic_n counts the ones the page folds away
            c["memory"] = cb.memory.get(c.get("key"))
            c["state"] = cluster_work.state_row(c.get("verdict"), ctri.get(c.get("key")))
            ch = cluster_work.chains_of(c, cb)
            c["chains"] = cluster_work.chains_view(ch)
            c["p"] = playbook.priority(c.get("verdict"), bool(c.get("critical_host")), [cr for cr, _m, _t in ch], params)
            chronic += bool(c["memory"] and c["memory"]["chronic"] and c.get("verdict") in ("act", "investigate"))
        return JSONResponse({**status, **out, "chronic_n": chronic}, headers=_NOCACHE)

    @app.get("/cluster")
    def cluster(request: Request, key: str = Query(..., max_length=80)) -> JSONResponse:
        if (off := _data_off()):
            return off
        if not cluster_work.valid_key(key):      # cl:<digits> or ct:<address>, ASCII only
            return JSONResponse({"error": "not a cluster key"}, status_code=400, headers=_NOCACHE)
        cb = live.cboard
        ctri = live.store.cluster_triage()
        if key.startswith("ct:"):        # an Under attack entry: no alerts of its own, the lane row and its work
            t = cluster_work.target_view(cb, key, live.store, ctri, live.catalog, dict(live.names),
                                         live.playbook_overlay, _model()) if cb else None
            if t is None:
                return JSONResponse({"error": "no such entry in Under attack"}, status_code=404, headers=_NOCACHE)
            return JSONResponse(t, headers=_NOCACHE)
        d = clusters.detail(cb, key, live.window) if cb else None
        if d is None and cb:
            # an episode the window merged into an older one: its old link opens the one it became
            won = live.store.resolve_episode(int(key[3:]))
            if f"cl:{won}" != key:
                d = clusters.detail(cb, f"cl:{won}", live.window)
        if d is None:
            return JSONResponse({"error": "no such cluster in memory"}, status_code=404, headers=_NOCACHE)
        pipeline.neutral_detail(d, settings.debug_models and _is_admin(request))
        d.update(cluster_work.cluster_view(cb, d, live.store, ctri, live.catalog, dict(live.names),
                                           live.playbook_overlay, _model()))
        jobs = live.recorder_jobs(d["cluster"]["anchor_ip"])
        d["pcap"] = {a["id"]: jobs[a["id"]] for a in d["alerts"] if a.get("id") in jobs}
        d["recorder"] = {"on": bool(settings.recorder_passthrough), "request": bool(settings.recorder_destination)}
        return JSONResponse(d, headers=_NOCACHE)

    def _guard(request: Request, enabled: bool, flag: str) -> JSONResponse | None:
        """Writes must come from our own page: JSON, the page's header, and no foreign Origin. A cross-site
        form cannot send JSON with a custom header without a CORS preflight, which this app never answers."""
        if not enabled:
            return JSONResponse({"error": f"disabled: set {flag}=true"}, status_code=403)
        if request.headers.get("x-sc-action") != "1" or "json" not in request.headers.get("content-type", ""):
            return JSONResponse({"error": "refused"}, status_code=403)
        site = request.headers.get("sec-fetch-site")
        if site and site not in ("same-origin", "none"):
            return JSONResponse({"error": "cross-site request refused"}, status_code=403)
        origin = request.headers.get("origin")
        if origin:
            allowed = {request.headers.get("host", "").lower(), request.headers.get("x-forwarded-host", "").lower(),
                       *(urlsplit(u).netloc.lower() for u in (settings.base_href, settings.sycope_url,
                                                              settings.sycope_ui_url) if u)}
            if urlsplit(origin).netloc.lower() not in allowed - {""}:
                return JSONResponse({"error": "cross-site request refused"}, status_code=403)
        return None

    async def _json(request: Request, admin_cap: bool = False) -> dict:
        """The JSON body: 20 kB at most; an admin op of a confirmed admin (admin_cap) 2 MB (an imported
        configuration with a large catalog). A body over the cap is refused before it is parsed."""
        raw = await request.body()
        if len(raw) > (ADMIN_BODY_MAX if admin_cap else BODY_MAX):
            raise ValueError("body too large")
        body = json.loads(raw or b"{}")
        if admin_cap and len(raw) > BODY_MAX and not (isinstance(body, dict) and body.get("op") in admin.OPS):
            raise ValueError("body too large")
        return body

    @app.get("/scoring-preview")
    def scoring_preview(model: str = Query("{}", max_length=6000), t: str = Query("6h", max_length=8)) -> JSONResponse:
        if (off := _data_off()):
            return off
        """What the board would look like with this model: verdicts, stage jumps, the top hosts before/after."""
        try:
            m = scoring.from_dict(json.loads(model))
        except (ValueError, scoring.ModelError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        snap = live.cboard.snapshot if live.cboard else None
        if snap is None or snap.empty:
            return JSONResponse({"error": "no clusters yet"}, status_code=409)
        now_cl = pipeline.in_range(snap, _range(t))
        new_cl = scoring.apply(now_cl, m)

        def summary(cl: pl.DataFrame) -> dict:
            hosts = cl.sort("score", descending=True).unique("anchor_ip", keep="first", maintain_order=True)
            return {"verdict_hosts": {v: int(n) for v, n in hosts.group_by("verdict").len().iter_rows()},
                    "stage_jumps": scoring.stage_jumps(cl),
                    "top": [{"ip": r["anchor_ip"], "priority": r["priority"], "verdict": r["verdict"],
                             "stage": r["highest_phase"], "type": r["cluster_type"], "lead": r["lead_alert"],
                             "severity": r["severity_max"]}
                            for r in hosts.head(15).iter_rows(named=True)]}
        return JSONResponse({"current": summary(now_cl), "preview": summary(new_cl), "model": scoring.public(m)},
                            headers=_NOCACHE)

    @app.post("/scoring-model")
    async def scoring_model(request: Request) -> JSONResponse:
        if not settings.clusters_compare:
            return JSONResponse({"error": "Clusters has no scoring model of its own: the verdict is Triage's"},
                                status_code=400)
        refused = _guard(request, settings.scoring_edit, "SC_SCORING_EDIT")
        if refused:
            return refused
        try:
            m = scoring.from_dict(await _json(request))
        except (ValueError, scoring.ModelError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        try:
            live.set_model(m)
        except OSError as exc:
            return JSONResponse({"error": f"cannot save the model: {exc}"}, status_code=500)
        return JSONResponse({"ok": True, "model": scoring.public(m), "saved": bool(live.model_path)})

    @app.get("/whoami")
    def whoami(request: Request) -> JSONResponse:
        """Who is acting, as Sycope confirmed it (identity.py). With a valid pass (X-SC-Pass): whom it names. With a
        claim (X-SC-Claim): the pass once Sycope's audit shows the claim's proof written, or pending. Else a new claim
        and the proof the page writes into the user's Sycope preferences."""
        p = ident.check(request.headers.get("x-sc-pass"))
        if p:
            return JSONResponse({"verified": True, "user": p["u"], "name": p.get("n") or "", "admin": bool(p.get("a")),
                                 "exp": p["exp"]}, headers=_NOCACHE)
        claim = request.headers.get("x-sc-claim", "")
        if not claim:
            return JSONResponse({"verified": False, **ident.challenge()}, headers=_NOCACHE)
        try:
            return JSONResponse(ident.redeem(claim), headers=_NOCACHE)
        except identity.IdentityError as exc:
            return JSONResponse({"verified": False, "error": str(exc)}, status_code=400, headers=_NOCACHE)
        except SycopeError as exc:
            log.info("whoami: %s", exc)
            return JSONResponse({"verified": False, "error": f"Sycope could not confirm it: {exc}"}, status_code=502,
                                headers=_NOCACHE)

    @app.post("/action")
    async def action(request: Request) -> JSONResponse:
        # the header, content-type and origin checks apply to every op; the SC_TRIAGE_EDIT switch is the analysts'
        # (a confirmed admin configures with it off, as break-glass and the pass are the admin's own gate)
        refused = _guard(request, True, "SC_TRIAGE_EDIT")
        if refused:
            return refused
        # the name and the admin role come from Sycope (a pass), never from what the page says; the pass is checked
        # before the body is read, so only a confirmed admin may send more than 20 kB
        p = ident.check(request.headers.get("x-sc-pass"))
        try:
            body = await _json(request, admin_cap=bool(p and p.get("a")))
        except (ValueError, RecursionError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        if not isinstance(body, dict):
            return JSONResponse({"error": "send a JSON object"}, status_code=400)
        if body.get("product") == "clusters" and not settings.clusters_compare:
            return JSONResponse({"error": "Clusters has no actions: the verdict and the status of a host are Triage's. "
                                          "Work it in Triage."}, status_code=400)
        op = body.get("op")
        is_admin_op = isinstance(op, str) and op in admin.OPS
        if not settings.triage_edit and not is_admin_op:
            return JSONResponse({"error": "disabled: set SC_TRIAGE_EDIT=true"}, status_code=403)
        if is_admin_op and not (p and p.get("a")):    # whatever SC_REQUIRE_VERIFIED_USER says
            return JSONResponse({"error": admin.NEEDS_ADMIN}, status_code=403)
        if p:
            body = {**body, "who": p["u"], "admin": bool(p.get("a")), "verified": True}
        elif settings.require_verified_user:
            return JSONResponse({"error": "Sycope has not confirmed who you are yet: reload the page inside Sycope "
                                          "(the check takes a few seconds)", "verify": True}, status_code=401)
        else:
            body = {**body, "admin": False, "verified": False}
        mark = store.VERIFIED.set(1 if p else 0)
        try:
            return JSONResponse(admin.act(live, body) if is_admin_op else live.act(body))
        except cfg.ConfigError as exc:
            return JSONResponse({"error": str(exc), "errors": exc.errors}, status_code=400)
        except (ValueError, triage.ActionError) as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        finally:
            store.VERIFIED.reset(mark)

    # ---- the Configuration pages' data: GET, admin only (a pass of a Sycope admin) ----------------------------

    def _admin_only(request: Request) -> JSONResponse | None:
        p = ident.check(request.headers.get("x-sc-pass"))
        if p and p.get("a"):
            return None
        return JSONResponse({"error": admin.NEEDS_ADMIN}, status_code=403, headers=_NOCACHE)

    def _answer(fn) -> JSONResponse:
        try:
            return JSONResponse(fn(), headers=_NOCACHE)
        except admin.NotFound as exc:
            return JSONResponse({"error": str(exc)}, status_code=404, headers=_NOCACHE)
        except PreviewBusy as exc:          # one preview or replay at a time
            return JSONResponse({"error": str(exc), "busy": True}, status_code=409, headers=_NOCACHE)
        except PreviewTooBig as exc:        # it would not fit SC_MEMORY_MB now
            return JSONResponse({"error": str(exc)}, status_code=503, headers=_NOCACHE)
        except cfg.ConfigError as exc:
            return JSONResponse({"error": str(exc), "errors": exc.errors}, status_code=400, headers=_NOCACHE)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400, headers=_NOCACHE)

    @app.get("/config")
    def config_data(request: Request) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.config_view(live))

    @app.get("/config-version")
    def config_version(request: Request, id: int = Query(..., ge=1)) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.version(live, id))

    @app.get("/config-export")
    def config_export(request: Request, id: int = Query(..., ge=1)):
        refused = _admin_only(request)
        if refused:
            return refused
        try:
            body = admin.export(live, id)
        except admin.NotFound as exc:
            return JSONResponse({"error": str(exc)}, status_code=404, headers=_NOCACHE)
        except cfg.ConfigError as exc:
            return JSONResponse({"error": str(exc), "errors": exc.errors}, status_code=400, headers=_NOCACHE)
        from fastapi.responses import Response
        name = f"sycope-security-triage-config-{id}.json"
        return Response(json.dumps(body, indent=2, sort_keys=True), media_type="application/json",
                        headers={**_NOCACHE, "Content-Disposition": f'attachment; filename="{name}"'})

    @app.get("/config-preview")
    def config_preview(request: Request, draft: int = Query(..., ge=1)) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.preview(live, draft))

    @app.get("/profile")
    def profile_data(request: Request, history: str = Query("", max_length=60)) -> JSONResponse:
        """The learned profile; ?history=<parameter> the value in each daily snapshot instead."""
        if history:
            return _admin_only(request) or _answer(lambda: admin.profile_history(live, history))
        return _admin_only(request) or _answer(lambda: admin.profile_view(live))

    @app.get("/exceptions")
    def exceptions_data(request: Request) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.exceptions_view(live))

    @app.get("/crown")
    def crown_data(request: Request) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.crown_view(live))

    @app.get("/catalog")
    def catalog_data(request: Request) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: admin.catalog_view(live))

    def _tz_param(request: Request) -> int | None:
        """The browser's offset from UTC in minutes (?tz=), None when absent or not a whole number in range."""
        try:
            v = int(request.query_params.get("tz", ""))
        except ValueError:
            return None
        return v if -840 <= v <= 840 else None

    @app.get("/health-data")
    def health_data(request: Request) -> JSONResponse:
        return _admin_only(request) or _answer(lambda: health.summary(live, browser_offset=_tz_param(request)))

    @app.get("/replay")
    def replay_data(request: Request, day: str = Query(..., max_length=10), config: int | None = Query(None, ge=1),
                    profile: str | None = Query(None, max_length=10), off: str = Query("", max_length=80)):
        """One stored day scored again with a recorded configuration version and profile snapshot (read-only)."""
        return _admin_only(request) or _answer(lambda: admin.replay(live, day, config, profile, off))

    @app.post("/pcap-request")
    async def pcap_request(request: Request) -> JSONResponse:
        refused = _guard(request, bool(settings.recorder_destination), "SC_RECORDER_DESTINATION")
        if refused:
            return refused
        try:
            body = await _json(request)
            alert_id = str(body.get("id") or "")
        except (ValueError, AttributeError):
            return JSONResponse({"error": "send {\"id\": \"<alert id>\"}"}, status_code=400)
        r = live.window.find_raw(alert_id) if alert_id else None
        if r is None:  # only alerts the pages list (a host's ring): no free-form ids into Sycope
            return JSONResponse({"error": "no such alert in memory"}, status_code=404)
        try:
            live.request_pcap({"id": alert_id, "def_id": r[BI["alertDefId"]], "t": r[BI["timestamp"]]})
        except SycopeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=502)
        return JSONResponse({"ok": True, "id": alert_id})

    @app.get("/scoring", response_class=HTMLResponse)
    def scoring_view():
        if not settings.clusters_compare:
            return RedirectResponse("./", status_code=307)       # the Clusters model has no place without its verdicts
        crit = live.crown_set(live._nets())
        return HTMLResponse(pages.scoring_page(settings, crit, live.model, live.board, _off()), headers=_NOCACHE)

    @app.get("/system", response_class=HTMLResponse)
    def system(from_: str = Query("", alias="from", max_length=12)) -> HTMLResponse:
        return HTMLResponse(pages.system_page(settings, live, product=from_ if from_ in ("clusters", "episodes") else "triage"),
                            headers=_NOCACHE)

    @app.get("/system-config")
    def system_config(request: Request) -> JSONResponse:
        denied = _admin_only(request)
        return denied or JSONResponse(pages.system_config(settings, live), headers=_NOCACHE)

    @app.get("/healthz")
    def healthz(request: Request) -> JSONResponse:
        last = live.last
        stale = bool(last.at) and time.time() - last.at > max(300, settings.poll_seconds * 5)
        body = {"status": "ok", "sycope": "ok" if last.ok else ("waiting" if not last.at else "failing"),
                "stale": stale, "clusters": len(live.cboard.snapshot.clusters) if live.cboard else 0,
                "alerts": live.window.alerts, "findings": live.board.findings if live.board else 0,
                "history_days": len(live.board.history["days"]) if live.board else 0, "version": pages.VERSION}
        return JSONResponse(body, headers=_NOCACHE)

    return app


app = create_app() if os.environ.get("SC_APP_AUTOSTART", "1") == "1" else None
