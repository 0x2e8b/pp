"""Alerts from Sycope -> the alert_cluster engine -> one immutable snapshot the pages read.

The engine (engine/, copied from alert_cluster) is run unchanged in the order of alert_cluster/main.py. This
module only renames the Sycope stream fields to the CSV column names the engine expects, gives clusters a
key that survives a recompute (anchor IP + first alert), and pre-computes what the pages ask for.
"""

from __future__ import annotations

import math
import time
from collections.abc import Collection
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from pathlib import Path

import polars as pl

from sycope_clusters import attack_map, scoring
from sycope_clusters.engine.clustering import build_clusters
from sycope_clusters.engine.clusters_def import ALERT_CLUSTER_MAP
from sycope_clusters.engine.features import (
    SEVERITY_MULTIPLIER,
    SEVERITY_WEIGHTS,
    add_burstiness_features,
    add_diversity_features,
    add_killchain_score,
    add_mitre_features,
    add_severity_features,
    add_threat_certainty_scores,
    add_threat_score,
)
from sycope_clusters.engine.mitre import PHASE_NAMES, TACTIC_PHASE
from sycope_clusters.rules import FAMILIES
from sycope_clusters.sycope import CLASSIC_FIELDS

# Sycope stream field -> the CSV column of a Sycope export, which is what the engine reads.
COLUMNS = {"timestamp": "Time", "alertName": "Alert Name", "alertSeverity": "Alert Severity",
           "alertMitreTactic": "Mitre Tactic", "alertMitreTechnique": "Mitre Technique",
           "alertMitreId": "Mitre Technique Id", "alertRuleType": "Rule Type", "alertRuleId": "Rule Id",
           "alertDefId": "Definition Id", "clientIp": "Client IP", "serverIp": "Server IP",
           "serverPort": "Server Port", "id": "Sycope Id", "clientLocation": "Client Location",
           "serverLocation": "Server Location", "clientFunction": "Client Function", "serverFunction": "Server Function"}

PHASE_IDX = {n: i for i, n in enumerate(PHASE_NAMES)}


def frame(rows: list[tuple]) -> pl.DataFrame:
    """Rows in sycope.FIELDS order -> the DataFrame load_alerts() would give for a CSV export. Only the classic
    fields: the engine never reads the v0.2 extras (bytes, ASN...), the evidence model takes them from the rows."""
    schema = {COLUMNS[f]: (pl.Int64 if f in ("timestamp", "serverPort") else pl.Utf8) for f in CLASSIC_FIELDS}
    clean = [tuple(_num(v) if f in ("timestamp", "serverPort") else _txt(v) for f, v in zip(CLASSIC_FIELDS, r))
             for r in rows]
    df = pl.DataFrame(clean, schema=schema, orient="row")
    return (df.with_columns(pl.from_epoch("Time", time_unit="ms").alias("Time"))
            .sort("Time").with_row_index("alert_id"))


def _num(v):
    try:
        return int(v) if v is not None and v != "" else None
    except (TypeError, ValueError):
        return None


def _txt(v):
    if isinstance(v, list):  # lookups (location, function) come as lists of names
        v = ", ".join(str(x) for x in v if x not in (None, ""))
    if v is None or v == "":
        return None
    return v if isinstance(v, str) else str(v)


@dataclass
class Snapshot:
    built_at: float
    took_s: float
    now: float
    alerts: pl.DataFrame
    clusters: pl.DataFrame
    cluster_alerts: pl.DataFrame
    related: pl.DataFrame
    critical_hosts: Collection[str] = field(default_factory=set)
    unknown_names: dict[str, int] = field(default_factory=dict)
    model: scoring.Model = field(default_factory=scoring.Model)
    hosts: dict[str, dict] = field(default_factory=dict)

    @property
    def empty(self) -> bool:
        return self.clusters.is_empty()


def critical_hosts(path: Path | None) -> set[str]:
    from sycope_clusters.engine.features import _load_critical_config
    return _load_critical_config(path)[0] if path else set()


def build(rows: list[tuple], now: float, delta_s: int = 3600, min_alerts: int = 2,
          critical_path: Path | None = None, model: scoring.Model | None = None,
          critical: Collection[str] | None = None,
          anchor_cols: tuple[str, ...] = ("Client IP", "Server IP")) -> Snapshot:
    """Raw alerts in sycope.FIELDS order -> a snapshot. `critical` (anything `ip in critical` answers, such as
    crown.CrownSet) replaces the critical hosts file. Clusters does not call this: it builds from finding buckets
    (clusters.build) and comes to build_frame()."""
    return build_frame(frame(rows), now, delta_s, min_alerts, critical, model, anchor_cols,
                       critical_path=critical_path)


def build_frame(alerts: pl.DataFrame, now: float, delta_s: int = 3600, min_alerts: int = 2,
                critical: Collection[str] | None = None, model: scoring.Model | None = None,
                anchor_cols: tuple[str, ...] = ("Client IP", "Server IP"),
                critical_path: Path | None = None, related: bool = True, sigma_fix=None) -> Snapshot:
    """The engine over a frame of alerts (frame(), or clusters.frame_from_buckets with its `_w` weights): chains per
    anchor, features, scores, the board's plain-language fields. `sigma_fix(clusters, cluster_alerts, alerts)` may
    replace the clusters' sigma_sev (the alert-type term) just before the scoring model reads it."""
    t0 = time.monotonic()
    crit = critical if critical is not None else critical_hosts(critical_path)
    if alerts.is_empty():
        return Snapshot(time.time(), 0.0, now, alerts, pl.DataFrame(), pl.DataFrame(), pl.DataFrame(), crit)
    clusters, cluster_alerts, related = build_clusters(alerts, timedelta(seconds=delta_s), min_alerts, anchor_cols,
                                                      related)
    if clusters.is_empty():
        return Snapshot(time.time(), time.monotonic() - t0, now, alerts, clusters, cluster_alerts, related, crit,
                        _unknown(alerts))
    # alert_cluster/main.py order; the threat/certainty "now" is the wall clock, not the newest alert.
    clusters = (
        clusters.pipe(add_severity_features, cluster_alerts, alerts)
        .pipe(add_mitre_features, cluster_alerts, alerts)
        .pipe(add_killchain_score, cluster_alerts, alerts)
        .pipe(add_diversity_features, cluster_alerts, alerts)
        .pipe(add_burstiness_features, cluster_alerts, alerts)
        .pipe(add_threat_certainty_scores, cluster_alerts, alerts, datetime.fromtimestamp(now, UTC))
        .pipe(add_threat_score, cluster_alerts, alerts, critical_path or Path("/nonexistent"), critical)
    )
    # Stable key: the cluster ids C_000000.. are renumbered on every run, the anchor and first alert are not.
    clusters = clusters.with_columns(
        pl.col("start_time").dt.epoch("ms").alias("start_ms"),
        pl.col("end_time").dt.epoch("ms").alias("end_ms"),
    ).with_columns((pl.col("anchor_ip") + "@" + pl.col("start_ms").cast(pl.Utf8)).alias("key"))
    model = model or scoring.preset("alert_cluster")
    clusters = add_board_fields(clusters, cluster_alerts, alerts)
    if sigma_fix is not None:
        clusters = sigma_fix(clusters, cluster_alerts, alerts)
    clusters = scoring.apply(clusters, model)
    return Snapshot(time.time(), time.monotonic() - t0, now, alerts, clusters, cluster_alerts, related, crit,
                    _unknown(alerts), model, host_info(alerts, set(clusters["anchor_ip"].to_list())))


def rescore(snap: Snapshot, model: scoring.Model) -> Snapshot:
    """The same snapshot ranked by another model (no new read from Sycope)."""
    return replace(snap, clusters=scoring.apply(snap.clusters, model), model=model)


def host_info(alerts: pl.DataFrame, ips: set[str]) -> dict[str, dict]:
    """Sycope's lookup names for each anchor: the location and function it has most often in its alerts."""
    if "Client Location" not in alerts.columns or not ips:
        return {}
    long = pl.concat([
        alerts.select(pl.col("Client IP").alias("ip"), pl.col("Client Location").alias("loc"),
                      pl.col("Client Function").alias("fn")),
        alerts.select(pl.col("Server IP").alias("ip"), pl.col("Server Location").alias("loc"),
                      pl.col("Server Function").alias("fn"))]).filter(pl.col("ip").is_in(list(ips)))
    out: dict[str, dict] = {}
    for col in ("loc", "fn"):
        top = (long.filter(pl.col(col).is_not_null()).group_by("ip", col).len()
               .sort(["ip", "len"], descending=[False, True]).unique("ip", keep="first", maintain_order=True))
        for ip, v, _n in top.iter_rows():
            out.setdefault(ip, {})[col] = v
    return out


# ---- the Threat Board's plain-language fields (not part of the engine, nothing here changes a score) ---------

def add_board_fields(clusters: pl.DataFrame, cluster_alerts: pl.DataFrame, alerts: pl.DataFrame) -> pl.DataFrame:
    """lead_alert (the alert type that set the highest phase), top_types, phases_seen, the scoring inputs
    (stage_idx, stage_sev = [stage, max severity weight] per stage, sigma_sev) and how often the anchor is the
    client (source) or the server (target) of its alerts."""
    weighted = "_w" in alerts.columns       # a row of the Clusters frame stands for `_w` alerts (a finding bucket)
    # what the analyst reads: the product's own tactic (the "Attack" key of the app's frames), else the template's
    tac = ("Attack" if "Attack" in alerts.columns else
           "Template Tactic" if "Template Tactic" in alerts.columns else "Mitre Tactic")
    cols = ["alert_id", "Alert Name", "Alert Severity", "Mitre Tactic", "Client IP", "Server IP"]
    j = (cluster_alerts.join(alerts.select(*cols, *(["_w"] if weighted else []), *([tac] if tac not in cols else [])),
                             on="alert_id")
         .join(clusters.select("cluster_id", "anchor_ip"), on="cluster_id")
         .with_columns(pl.col("Mitre Tactic").replace_strict(TACTIC_PHASE, default=None, return_dtype=pl.Int32)
                       .alias("ph"),
                       pl.col("Alert Severity").replace_strict(SEVERITY_WEIGHTS, default=0, return_dtype=pl.Int64)
                       .alias("w")))
    per_type = (j.group_by("cluster_id", "Alert Name")
                .agg(pl.col("ph").max(), pl.col("w").max(), (pl.col("_w").sum() if weighted else pl.len()).alias("n"),
                     pl.col(tac).first().alias("tactic")))
    lead = (per_type.sort(["cluster_id", "ph", "w", "n", "Alert Name"], descending=[False, True, True, True, False],
                          nulls_last=True)
            .group_by("cluster_id", maintain_order=True)
            .agg(pl.col("Alert Name").first().alias("lead_alert"), pl.col("tactic").first().alias("lead_tactic")))
    if tac == "Attack":
        lead = lead.with_columns(pl.col("lead_tactic").cast(pl.Utf8).str.split("|").list.get(0)
                                 .replace("", None).alias("lead_tactic"))
    top = (per_type.sort(["cluster_id", "n", "Alert Name"], descending=[False, True, False])
           .group_by("cluster_id", maintain_order=True)
           .agg(pl.col("Alert Name").head(3).alias("top_names"), pl.col("n").head(3).alias("top_counts")))
    seen = (j.filter(pl.col("ph").is_not_null()).group_by("cluster_id")
            .agg(pl.col("ph").unique().sort().alias("phases_idx")))
    stage_sev = (j.filter(pl.col("ph").is_not_null()).group_by("cluster_id", "ph").agg(pl.col("w").max())
                 .sort("cluster_id", "ph").group_by("cluster_id", maintain_order=True)
                 .agg(pl.concat_list("ph", "w").alias("stage_sev")))
    sigma = per_type.group_by("cluster_id").agg(pl.col("w").sum().alias("sigma_sev"))
    wt = pl.col("_w") if weighted else pl.lit(1)
    roles = j.group_by("cluster_id").agg(((pl.col("Client IP") == pl.col("anchor_ip")) * wt).sum().alias("as_client"),
                                         ((pl.col("Server IP") == pl.col("anchor_ip")) * wt).sum().alias("as_server"))
    out = (clusters.join(lead, on="cluster_id", how="left").join(top, on="cluster_id", how="left")
           .join(seen, on="cluster_id", how="left").join(roles, on="cluster_id", how="left")
           .join(stage_sev, on="cluster_id", how="left").join(sigma, on="cluster_id", how="left")
           # a cluster whose alerts set no phase (no tactic, or catalog rules without a stage) has no stage at all:
           # null, which the scoring keeps at Watch; a missing phase is not "Recon"
           .with_columns(pl.when(pl.col("highest_phase").is_null()).then(None)
                         .otherwise(pl.col("highest_phase").replace_strict(PHASE_IDX, default=0))
                         .cast(pl.Int32).alias("stage_idx")))
    return out.with_columns(
        pl.col("phases_idx").list.eval(pl.element().replace_strict(dict(enumerate(PHASE_NAMES)), return_dtype=pl.Utf8))
        .alias("phases_seen")).drop("phases_idx")


def _unknown(alerts: pl.DataFrame) -> dict[str, int]:
    vc = (alerts.filter(~pl.col("Alert Name").is_in(list(ALERT_CLUSTER_MAP)))
          .group_by("Alert Name").len().sort("len", descending=True))
    return {r["Alert Name"]: r["len"] for r in vc.iter_rows(named=True) if r["Alert Name"]}


# ---- what the pages read --------------------------------------------------------------------------------

RANGES = {"15m": 900, "1h": 3600, "6h": 21600, "12h": 43200, "24h": 86400}
SORTS = {"priority": "score", "alerts": "alert_count", "last": "end_ms", "impact": "impact_score",
         "certainty": "certainty_score"}
# the two reference models and their blend: only for an admin with SC_DEBUG_MODELS on (names are neutral on the wire)
DEBUG_SORTS = {"ref_a": "maciej_score", "ref_b": "pawel_score", "blend": "threat_score"}
_REF_COLS = {"maciej_score": "ref_a_score", "pawel_score": "ref_b_score", "maciej_norm": "ref_a_norm",
             "pawel_norm": "ref_b_norm", "threat_score": "blend_score"}


def neutral_cluster(c: dict, debug: bool = False) -> dict:
    """A cluster record as the pages get it: the reference-model columns are dropped, or in debug mode renamed."""
    for k, new in _REF_COLS.items():
        if k in c:
            v = c.pop(k)
            if debug:
                c[new] = v
    return c


def neutral_detail(d: dict, debug: bool = False) -> dict:
    """The same for one cluster's detail: the reference tables ride along only in debug mode."""
    neutral_cluster(d["cluster"], debug)
    s = d["score"]
    ref = {"ref_a": s.pop("maciej", None), "ref_b": s.pop("pawel", None),
           "ref_a_total": s.pop("maciej_total", None), "ref_b_total": s.pop("pawel_total", None)}
    if debug:
        s["ref"] = ref
    return d

_LIST_COLS = ["key", "episode_id", "cluster_id", "anchor_ip", "cluster_type", "cluster_label", "secondary_types", "start_ms",
              "end_ms", "duration_s", "alert_count", "severity_max", "highest_phase", "n_tactics", "tactics",
              "n_techniques", "n_alert_types", "alert_type_entropy", "killchain_progression_score", "burstiness",
              "alerts_per_minute_peak", "impact_score", "certainty_score", "critical_host", "maciej_score",
              "pawel_score", "maciej_norm", "pawel_norm", "threat_score", "sev_critical", "sev_high", "sev_medium",
              "sev_low", "sev_info", "mean_gap_s", "score", "priority", "verdict", "lead_alert", "lead_tactic",
              "top_names", "top_counts", "phases_seen", "as_client", "as_server",
              "chain_bonus"]


def alert_total(alerts: pl.DataFrame) -> int:
    """How many alerts a frame stands for: its rows, or the sum of `_w` when a row is a finding bucket."""
    return int(alerts["_w"].sum() or 0) if "_w" in alerts.columns else len(alerts)


def _clean(v):
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return None
    return v


def in_range(snap: Snapshot, seconds: int) -> pl.DataFrame:
    """Clusters active in the last `seconds` (their last alert inside the range)."""
    if snap.empty:
        return snap.clusters
    cut = int((snap.now - seconds) * 1000)
    return snap.clusters.filter(pl.col("end_ms") >= cut)


def listing(snap: Snapshot, seconds: int, sort: str = "priority", names: dict[str, str] | None = None,
            debug: bool = False) -> dict:
    """The live page's data: clusters in the range (sorted by the chosen column), counts, histogram."""
    cut_ms = int((snap.now - seconds) * 1000)
    al = snap.alerts.filter(pl.col("Time").dt.epoch("ms") >= cut_ms) if not snap.alerts.is_empty() else snap.alerts
    out = {"now": snap.now, "built_at": snap.built_at, "took_s": round(snap.took_s, 2), "range_s": seconds,
           "alerts_in_range": alert_total(al), "alerts_total": alert_total(snap.alerts), "clusters": [],
           "hist": hist(al, snap.now, seconds), "phases": {}, "types": {},
           "labels": {k: v[0] for k, v in FAMILIES.items()}, "colors": {k: v[2] for k, v in FAMILIES.items()},
           "critical_hosts": sorted(snap.critical_hosts), "verdicts": {}}
    if snap.empty:
        return out
    cl = in_range(snap, seconds)
    col = ({**SORTS, **DEBUG_SORTS} if debug else SORTS).get(sort, "score")
    cl = cl.sort([col, "score", "end_ms"], descending=True, nulls_last=True)
    recs = []
    for i, r in enumerate(cl.select([c for c in _LIST_COLS if c in cl.columns]).iter_rows(named=True)):
        r = neutral_cluster({k: _clean(v) for k, v in r.items()}, debug)
        r["rank"] = i + 1
        recs.append(r)
    out["clusters"] = recs
    out["anchors"] = cl["anchor_ip"].n_unique()
    out["phases"] = {p: int(n) for p, n in cl.group_by("highest_phase").len().iter_rows() if p}
    out["types"] = {t: int(n) for t, n in cl.group_by("cluster_type").len().iter_rows() if t}
    out["verdicts"] = {v: int(n) for v, n in cl.group_by("verdict").len().iter_rows() if v}
    out["verdict_hosts"] = {v: int(n) for v, n in cl.sort("score", descending=True).unique("anchor_ip", keep="first")
                            .group_by("verdict").len().iter_rows() if v}
    ids = snap.cluster_alerts.join(cl.select("cluster_id"), on="cluster_id").select("alert_id").unique()
    out["alerts_clustered"] = alert_total(snap.alerts.join(ids, on="alert_id")) if "_w" in snap.alerts.columns \
        else len(ids)
    anchors = set(cl["anchor_ip"].to_list())
    out["spark"] = spark(al, anchors, snap.now, seconds)
    out["hosts"] = {ip: {**snap.hosts.get(ip, {}), **({"name": names[ip]} if names and names.get(ip) else {})}
                    for ip in anchors if snap.hosts.get(ip) or (names and names.get(ip))}
    out["model"] = {"preset": scoring.wire(snap.model.preset), "label": scoring.PRESETS.get(snap.model.preset, {}).get("label",
                    "custom"), "strict": snap.model.strict, "bands": {"act": snap.model.act,
                    "investigate": snap.model.investigate, "review": snap.model.review}, "full": snap.model.full}
    out["stage_jumps"] = scoring.stage_jumps(cl)
    return out


SPARK_BARS = 24


def spark(alerts: pl.DataFrame, ips: set[str], now: float, seconds: int) -> dict[str, list[int]]:
    """Alerts per host (as client or server; a Clusters frame: as the acting host) in SPARK_BARS equal slices."""
    if alerts.is_empty() or not ips:
        return {}
    step = seconds / SPARK_BARS
    start = now - seconds
    w = ["_w"] if "_w" in alerts.columns else []
    sides = ["Actor IP"] if "Actor IP" in alerts.columns else ["Client IP", "Server IP"]
    long = pl.concat([alerts.select("Time", *w, pl.col(c).alias("ip")) for c in sides]).filter(
        pl.col("ip").is_in(list(ips)))
    g = (long.with_columns(((pl.col("Time").dt.epoch("ms") / 1000 - start) / step).floor().cast(pl.Int32).alias("b"))
         .filter((pl.col("b") >= 0) & (pl.col("b") < SPARK_BARS)).group_by("ip", "b")
         .agg(pl.col("_w").sum().alias("len") if w else pl.len()))
    out: dict[str, list[int]] = {}
    for ip, b, n in g.iter_rows():
        out.setdefault(ip, [0] * SPARK_BARS)[b] = int(n)
    return out


_BUCKETS = (60, 120, 300, 600, 900, 1800, 3600, 7200)


def hist(alerts: pl.DataFrame, now: float, seconds: int, bars: int = 72) -> dict:
    """Alerts per time bucket over the range, split by kill-chain phase of the alert's tactic."""
    step = next((b for b in _BUCKETS if seconds / b <= bars), _BUCKETS[-1])
    end = int(math.ceil(now / step) * step)
    start = end - math.ceil(seconds / step) * step
    n = (end - start) // step
    series = {p: [0] * n for p in [*PHASE_NAMES, "Other"]}
    if not alerts.is_empty():
        g = (alerts.with_columns(
            ((pl.col("Time").dt.epoch("s") - start) // step).alias("b"),
            pl.col("Mitre Tactic").replace_strict(TACTIC_PHASE, default=None, return_dtype=pl.Int32).alias("ph"))
            .filter((pl.col("b") >= 0) & (pl.col("b") < n)).group_by("b", "ph")
            .agg(pl.col("_w").sum().alias("len") if "_w" in alerts.columns else pl.len()))
        for b, ph, c in g.iter_rows():
            series[PHASE_NAMES[ph] if ph is not None else "Other"][b] += c
    return {"start": start, "step": step, "n": n, "series": series}


def detail(snap: Snapshot, key: str, max_alerts: int = 300) -> dict | None:
    """One cluster: every feature, the score broken into its terms, alert types, related IPs, newest alerts. A frame
    of finding buckets (a `_w` column) has no single alerts to list: `alerts` is empty and clusters.detail fills it."""
    if snap.empty:
        return None
    hit = snap.clusters.filter(pl.col("key") == key)
    if hit.is_empty():
        return None
    c = {k: _clean(v) for k, v in hit.row(0, named=True).items() if k not in ("start_time", "end_time")}
    cid = c["cluster_id"]
    ids = snap.cluster_alerts.filter(pl.col("cluster_id") == cid).select("alert_id")
    al = snap.alerts.join(ids, on="alert_id").sort("Time", descending=True)
    cols = al.columns
    weighted = "_w" in cols
    wt = pl.col("_w") if weighted else pl.lit(1)
    shown = pl.col("Template Tactic") if "Template Tactic" in cols else pl.col("Mitre Tactic")
    ours = "Attack" in cols           # the app's frames carry the product's own ATT&CK reading per row (attack_map)
    sev_w = pl.col("Alert Severity").replace_strict(SEVERITY_WEIGHTS, default=0, return_dtype=pl.Int64)
    types = (al.with_columns(sev_w.alias("w"))
             .group_by("Alert Name").agg(wt.sum().alias("count"), pl.col("w").max().alias("max_w"),
                                         pl.col("Mitre Tactic").first().alias("tactic"),
                                         shown.first().alias("shown_tactic"),
                                         (pl.col("Family") if "Family" in cols else pl.lit(None)).first().alias("family"),
                                         pl.col("Mitre Technique").first().alias("technique"),
                                         pl.col("Mitre Technique Id").first().alias("technique_id"),
                                         (pl.col("Attack").cast(pl.Utf8).unique().sort() if ours
                                          else pl.lit([], dtype=pl.List(pl.Utf8))).alias("attacks"),
                                         pl.col("Time").min().dt.epoch("ms").alias("first_ms"),
                                         pl.col("Time").max().dt.epoch("ms").alias("last_ms"))
             .sort(["max_w", "count"], descending=True))
    inv = {v: k for k, v in SEVERITY_WEIGHTS.items()}
    type_rows = []
    for r in types.iter_rows(named=True):
        ph = TACTIC_PHASE.get(r["tactic"])
        # the product's reading by direction (a rule can read two ways in one cluster); the template's own tag is
        # kept apart as "tpl_tag" and shown only as such
        reads = [attack_map.read_key(k) for k in r["attacks"]]
        tpl_tag = attack_map.tpl_tag(r["technique_id"], r["technique"], r["shown_tactic"])
        type_rows.append({"name": r["Alert Name"], "count": r["count"], "severity": inv.get(r["max_w"]),
                          "weight": r["max_w"],
                          "tactic": ", ".join(sorted({t for t, _, _ in reads if t})),   # ours; empty on the standalone path
                          "attack": "; ".join(dict.fromkeys(lb for _, _, lb in reads)) if ours else "",
                          "technique_id": ", ".join(sorted({i for _, i, _ in reads if i})) if ours else r["technique_id"],
                          "tpl_tag": tpl_tag, "phase": PHASE_NAMES[ph] if ph is not None else None,
                          "cluster_type": r["family"] or ALERT_CLUSTER_MAP.get(r["Alert Name"], "UNKNOWN"),
                          "first_ms": r["first_ms"], "last_ms": r["last_ms"]})
    rel = (snap.related.filter(pl.col("cluster_id") == cid).sort("occurrence_count", descending=True).head(25))
    roles = (al.select(pl.when(pl.col("Client IP") == c["anchor_ip"]).then(pl.lit("client"))
                       .when(pl.col("Server IP") == c["anchor_ip"]).then(pl.lit("server")).alias("r"), wt.alias("w"))
             .group_by("r").agg(pl.col("w").sum()))
    newest = al.head(0 if weighted else max_alerts).with_columns(pl.col("Time").dt.epoch("ms").alias("t"))
    alerts = [{"t": r["t"], "name": r["Alert Name"], "severity": r["Alert Severity"], "attack": "",
               "tpl_tag": attack_map.tpl_tag(r["Mitre Technique Id"], r["Mitre Technique"],
                                             r["Template Tactic"] if "Template Tactic" in cols else r["Mitre Tactic"]),
               "client": r["Client IP"], "server": r["Server IP"], "port": r["Server Port"], "id": r["Sycope Id"], "def_id": r["Definition Id"]}
              for r in newest.iter_rows(named=True)]
    model = snap.model
    ref = score_terms(c, type_rows)
    ref["model"] = scoring.terms(model, c)
    ref["model_label"] = scoring.PRESETS.get(model.preset, {}).get("label", "custom")
    ref["full"] = model.full
    ref["severity_source"], ref["strict"] = model.severity_source, model.strict
    return {"cluster": c, "score": ref, "types": type_rows,
            "related": [{"ip": r["ip"], "count": r["occurrence_count"]} for r in rel.iter_rows(named=True)],
            "roles": {r: int(n) for r, n in roles.iter_rows() if r},
            "alerts": alerts, "alerts_shown": len(alerts), "alerts_total": alert_total(al)}


def score_terms(c: dict, types: list[dict]) -> dict:
    """The two raw scores of engine/features.add_threat_score, term by term (same inputs, same formulas)."""
    phase = PHASE_IDX.get(c.get("highest_phase"), 0)
    crit = int(c.get("critical_host") or 0)
    sigma = float(sum(t["weight"] or 0 for t in types))
    prog = float(c.get("killchain_progression_score") or 0.0)
    mult = SEVERITY_MULTIPLIER.get(c.get("severity_max"), 0.0)
    bonus = float(c.get("chain_bonus") or 1.0)
    ref_a = [("phase", f"{phase} × 10000 × {mult} (severity_max {c.get('severity_max')})", phase * 10000 * mult),
              ("critical host", f"{crit} × 6000", crit * 6000),
              ("Σ max severity per type", f"{sigma:g} × 200", sigma * 200),
              ("kill-chain progression", f"{prog:.3f} × 1500", prog * 1500)]
    ref_b = [("phase", f"{phase} × 10000", phase * 10000), ("critical host", f"{crit} × 5000", crit * 5000),
             ("Σ max severity per type", f"min({sigma:g} × 30, 1999)", min(sigma * 30, 1999)),
             ("kill-chain progression", f"min({prog:.3f} × 999, 999)", min(prog * 999, 999))]
    return {"maciej": [{"term": a, "expr": b, "value": round(v, 1)} for a, b, v in ref_a],
            "pawel": [{"term": a, "expr": b, "value": round(v, 1)} for a, b, v in ref_b],
            "chain_bonus": bonus, "sigma_sev": sigma, "maciej_total": c.get("maciej_score"),
            "pawel_total": c.get("pawel_score")}
