"""The work layer of Security Clusters: statuses, notes, steps and the incident record of a cluster.

The work object is the cluster (one time episode of one acting host, key `cl:<episode id>`, clusters.py) or an
Under attack entry (a host that only receives, key `ct:<ip>`). Both use Triage's machinery with their own rows: the
analyst's state is in `cluster_triage`, the records in `incidents` (kind cluster / cluster-target, product
clusters), the lines in the one audit log with product clusters. Triage never reads them and Clusters never reads
Triage's, so closing host X in one product leaves it as it was in the other. Exceptions (silenced hosts and
signatures) are the one thing both share: Live.act sends them to triage.act.

A closed cluster that keeps growing stays closed. When its verdict rises above the one it had when it was closed it
is New again, with the line "reopened: rose from Review to Investigate after close" (state()). The record is kept
the same way Triage keeps its own: opened when the cluster first reaches Review, `last_seen` while it is on the
board, closed after the grace once it is not (quiet), or at once when its episode was merged into an older one.
"""

from __future__ import annotations

import logging
import re
from collections.abc import Sequence

import polars as pl

from sycope_clusters import cluster_chains, entities, fmt, history, playbook, rules, triage
from sycope_clusters import evidence as ev
from sycope_clusters.clusters import ClusterBoard

log = logging.getLogger("sycope_clusters.cluster_work")

PRODUCT = "clusters"
OPS = ("triage", "restore", "comment", "step", "record")    # the others (exceptions) are shared: triage.act
KEY_RE = re.compile(r"(cl:[0-9]{1,12}|ct:[0-9a-fA-F.:]{3,45})")     # ASCII only: \d would take other scripts' digits
CL_RE = re.compile(r"cl:[0-9]{1,12}")
SCOPE_RE = re.compile(r"[A-Za-z0-9:._/ -]{1,80}")
MAX_KEYS = 2000
TARGET_RECORDS = 300        # Under attack entries that get an incident record (the ones at Investigate), best first
FINDINGS_KEPT = 25          # buckets kept in a record's snapshot
ACTION_WORDS = {"prune:statuses": "removed statuses nobody can reach any more", "merge:moved": "its status came here from a cluster that was merged into this one",
         "merge:dropped": "the status of a cluster merged into this one was dropped (this one has its own)",
         "clusters:ack": "marked clusters seen", "clusters:fp": "marked clusters false positive",
         "clusters:tp": "closed clusters as true positives", "clusters:benign": "closed clusters as benign",
         "clusters:resolved": "resolved clusters", "clusters:investigating": "took clusters",
         "clusters:escalated": "escalated clusters", "clusters:open": "reopened clusters",
         "clusters:undo": "undid an action on clusters"}


def valid_key(key: object) -> bool:
    """A work key of the board: `cl:<digits>` or `ct:<address characters>`, ASCII only."""
    return isinstance(key, str) and KEY_RE.fullmatch(key) is not None


def target_verdict(t: dict) -> str:
    """An Under attack entry's verdict (Triage's rule for a victim): Investigate for a crown jewel or a host that
    answered, else Review."""
    return "investigate" if t.get("crown") or t.get("answered") else "review"


def state(item_verdict: str, t: dict | None) -> dict:
    """The analyst's state of a work object as the page shows it: {status, owner, reason, handled, reopened_from}.
    `t` is its cluster_triage row. Seen and the closures are `handled` until the verdict rises above the one the row
    was written at: then the object is New again and `reopened_from` names that verdict. In progress and Escalated
    stay as they are (somebody has it)."""
    new = {"status": "new", "owner": None, "reason": None, "handled": False, "reopened_from": None}
    if not t:
        return new
    status = t["status"]
    if status in (*triage.CLOSED, "ack"):
        stored = t.get("verdict") or "watch"
        if ev.VRANK.get(item_verdict, 0) > ev.VRANK.get(stored, 0):
            return {**new, "reopened_from": stored}
        return {"status": status, "owner": t.get("owner"), "reason": t.get("reason"), "handled": True,
                "reopened_from": None}
    return {"status": status, "owner": t.get("owner"), "reason": t.get("reason"), "handled": False,
            "reopened_from": None}


def state_row(item_verdict: str, t: dict | None) -> dict:
    """state() with who, when and the note of the row (what a card shows under the status)."""
    return {**state(item_verdict, t), "who": t.get("who") if t else None, "at": t.get("at") if t else None,
            "note": t.get("note") if t else None, "verdict": t.get("verdict") if t else None}


# ---- actions -----------------------------------------------------------------------------------------------------

def act(body: dict, cb: ClusterBoard | None, store, catalog: rules.Catalog | None = None) -> dict:
    """One analyst action on Clusters work objects (ops in OPS). Raises triage.ActionError with a message for the
    page. Returns {ok, op, status, keys, previous} for a status change, like triage.act."""
    if not isinstance(body, dict):
        raise triage.ActionError("send a JSON object")
    op = body.get("op")
    who = triage._clean_text(body.get("who"), 40) or "analyst"
    note = triage._clean_text(body.get("note"), 500)
    if op == "triage":
        return _triage(body, cb, store, who, note)
    if op == "restore":
        return _restore(body, store, who, note)
    if op == "comment":
        return _comment(body, store, who)
    if op == "step":
        return _step(body, store, who)
    if op == "record":
        return _record_review(body, store, who, note)
    raise triage.ActionError("unknown op")


def _keys(raw: object, what: str = "keys") -> list[str]:
    if not isinstance(raw, list) or not raw:
        raise triage.ActionError(f"{what} must be a non-empty list of clusters")
    if len(raw) > MAX_KEYS:
        raise triage.ActionError(f"at most {MAX_KEYS} clusters in one action")
    if not all(valid_key(k) for k in raw):
        raise triage.ActionError("a key is not a cluster (cl:<number>) or an entry of Under attack (ct:<address>)")
    return list(dict.fromkeys(raw))


def _scope(body: dict) -> str | None:
    scope = body.get("scope")
    if scope is None or scope == "":
        return None
    if not isinstance(scope, str) or not SCOPE_RE.fullmatch(scope):
        raise triage.ActionError("scope is a short label of what was selected")
    return scope


def _verdicts(cb: ClusterBoard | None) -> dict[str, str]:
    """key -> verdict of every work object on the board."""
    if cb is None:
        return {}
    out = {t["key"]: target_verdict(t) for t in cb.targets}
    snap = cb.snapshot
    if not snap.empty and "key" in snap.clusters.columns:
        out.update(zip(snap.clusters["key"].to_list(), snap.clusters["verdict"].to_list(), strict=True))
    return out


def _triage(body: dict, cb: ClusterBoard | None, store, who: str, note: str) -> dict:
    status = body.get("status")
    if status not in (*triage.STATUS, "open"):
        raise triage.ActionError("status must be one of: " + ", ".join((*triage.STATUS, "open")))
    owner = triage._clean_text(body.get("owner"), 40) or None
    if status == "investigating" and not owner:
        owner = who
    if status == "escalated" and not owner:
        owner = "L2"
    if status not in ("investigating", "escalated"):
        owner = None
    reason = triage._clean_text(body.get("reason"), 80) or None
    if reason and status in triage.REASONS and reason not in triage.REASONS[status]:
        raise triage.ActionError("unknown reason for " + triage.STATUS[status])
    keys = _keys(body.get("keys"))
    scope = _scope(body)
    if cb is None:
        raise triage.ActionError("the board is not ready yet")
    on_board = _verdicts(cb)
    resolved = []
    for k in keys:
        if k not in on_board and CL_RE.fullmatch(k):       # a cluster the window merged into an older one
            k = f"cl:{store.resolve_episode(int(k[3:]))}"
        if k not in on_board:
            raise triage.ActionError(f"{k} is not on the board any more (it may have changed: refresh)")
        resolved.append(k)
    keys = list(dict.fromkeys(resolved))
    before = store.cluster_triage()
    cols = ("status", "who", "note", "verdict", "owner", "reason")
    previous = [{"key": k, **{c: before[k].get(c) for c in cols}} if k in before else {"key": k, "status": None}
                for k in keys]
    writes = [(k, None if status == "open" else (status, who, note, [], on_board[k], owner, reason),
               (who, f"triage:{status}", k, note, {"verdict": on_board[k], "owner": owner, "reason": reason,
                                                   "scope": scope})) for k in keys]
    group = None
    if len(keys) > 1:
        label = triage._clean_text(body.get("label"), 200) or scope or f"{len(keys)} clusters"
        group = (who, f"clusters:{status}", label, note, {"scope": scope, "keys": keys, "owner": owner,
                                                          "reason": reason})
    store.cluster_triage_many(writes, group)       # one transaction, audit lines labelled clusters
    return {"ok": True, "op": "triage", "status": status, "keys": keys, "previous": previous}


def _restore(body: dict, store, who: str, note: str) -> dict:
    """Undo: put back the states a just-made action replaced (the page sends them back as the action returned them)."""
    rows = body.get("rows")
    if not isinstance(rows, list) or not rows or len(rows) > MAX_KEYS:
        raise triage.ActionError(f"rows must be a list of up to {MAX_KEYS} clusters")
    writes = []
    for r in rows:
        if not isinstance(r, dict) or not valid_key(r.get("key")):
            raise triage.ActionError("each row is an object with the key of a cluster")
        st = r.get("status")
        if st is None:
            cur = None
        elif st in triage.STATUS:
            verdict = r.get("verdict") if r.get("verdict") in ev.VERDICTS else "watch"
            cur = (st, triage._clean_text(r.get("who"), 40) or who, triage._clean_text(r.get("note"), 500), [],
                   verdict, triage._clean_text(r.get("owner"), 40) or None,
                   triage._clean_text(r.get("reason"), 80) or None)
        else:
            raise triage.ActionError("unknown status in a row")
        writes.append((r["key"], cur, (who, "triage:undo", r["key"], note, {"restored": st})))
    keys = [w[0] for w in writes]
    scope = _scope(body)
    group = (who, "clusters:undo", triage._clean_text(body.get("label"), 200) or scope or "clusters", note,
             {"scope": scope, "keys": keys}) if len(keys) > 1 else None
    store.cluster_triage_many(writes, group)
    return {"ok": True, "op": "restore", "keys": keys}


def _comment(body: dict, store, who: str) -> dict:
    """A note on a work object without changing its state: in the audit log and on its open record."""
    key = body.get("key")
    if not valid_key(key):
        raise triage.ActionError("key must be a cluster (cl:<number>) or an entry of Under attack (ct:<address>)")
    text = triage._clean_text(body.get("note"), 1000)
    if not text:
        raise triage.ActionError("write the note")
    store.log(who, "comment", key, text, {}, product=PRODUCT)
    history.note(store, key, who, text, product=PRODUCT)
    return {"ok": True, "op": "comment", "key": key}


def _step(body: dict, store, who: str) -> dict:
    """A next step checked or unchecked on an open record (or one that ended quiet); the audit log and the record's
    own history get a line."""
    try:
        rec = int(body.get("rec"))
    except (TypeError, ValueError):
        raise triage.ActionError("rec must be the number of an open incident") from None
    step = triage._clean_text(body.get("step"), 160)
    if not step:
        raise triage.ActionError("step is required")
    title = triage._clean_text(body.get("title"), 300) or step
    done = body.get("done", True) is not False
    o = store.incident(rec, product=PRODUCT)
    if not o or not history.workable(o):
        raise triage.ActionError("this incident is not open any more: refresh the page")
    key = o.get("ui_key") or str(rec)
    store.set_step(rec, step, done, who, title,
                   (who, "step:done" if done else "step:undone", key, title,
                    {"incident": rec, "step": step}), product=PRODUCT)
    history.event(store, rec, "step", f"{who} {'checked' if done else 'unchecked'}: {title}", product=PRODUCT)
    return {"ok": True, "op": "step", "rec": rec, "step": step, "done": done, "title": title}


def _record_review(body: dict, store, who: str, note: str) -> dict:
    """Seen, closed, taken or escalated on a record that ended with nobody having looked at it; status "open" puts
    it back as not reviewed (undo, release)."""
    try:
        rec = int(body.get("rec"))
    except (TypeError, ValueError):
        raise triage.ActionError("rec must be the number of an incident record") from None
    status = body.get("status")
    if status not in ("ack", *triage.CLOSED, "investigating", "escalated", "open"):
        raise triage.ActionError("status must be one of: ack, " + ", ".join(triage.CLOSED)
                                 + ", investigating, escalated, open")
    owner = triage._clean_text(body.get("owner"), 40) or None
    reason = triage._clean_text(body.get("reason"), 80) or None
    if reason and status in triage.REASONS and reason not in triage.REASONS[status]:
        raise triage.ActionError("unknown reason for " + triage.STATUS[status])
    try:
        r = history.review(store, rec, status, who, note, reason, owner=owner, product=PRODUCT)
    except ValueError as exc:
        raise triage.ActionError(str(exc)) from None
    store.log(who, f"record:{status}", r["ui_key"] or r["label"] or str(rec), note,
              {"incident": rec, "reason": reason, "owner": owner}, product=PRODUCT)
    prev = r["previous"]["outcome"]
    return {"ok": True, "op": "record", "rec": rec, "status": status,
            "previous": "open" if prev in (None, "expired") else prev, "previous_owner": r["previous_owner"]}


# ---- the records -------------------------------------------------------------------------------------------------

def _outcome(st: dict, t: dict | None) -> tuple:
    """(outcome, by, at, note, reason) of a record from the state: what the analyst did, while it holds."""
    if t and (st["handled"] or st["status"] in history.OWNED):
        by = t.get("owner") if st["status"] in history.OWNED and t.get("owner") else t.get("who")
        return st["status"], by, t.get("at"), t.get("note"), t.get("reason")
    return None, None, None, None, None


def _bucket_rows(snap, catalog: rules.Catalog, cids: Sequence[str]) -> dict[str, list[dict]]:
    """The buckets of the given clusters, most alerts first, as playbook.for_cluster reads them: one pass over the
    clusters' alerts, whatever their number."""
    if not cids or snap.empty:
        return {}
    j = (snap.cluster_alerts.filter(pl.col("cluster_id").is_in(pl.Series(list(cids)).implode()))
         .join(snap.alerts.select("alert_id", "Alert Name", "Counterpart IP", "Server Port", "Time", "_w",
                                  "Template Tactic"), on="alert_id"))
    g = (j.group_by("cluster_id", "Alert Name", "Counterpart IP", "Server Port")
         .agg(pl.col("_w").sum().alias("n"), pl.col("Time").min().dt.epoch("ms").alias("first"),
              pl.col("Time").max().dt.epoch("ms").alias("last"), pl.col("Template Tactic").first().alias("tac"))
         .sort(["n", "first", "Alert Name"], descending=[True, False, False]))
    out: dict[str, list[dict]] = {}
    for r in g.iter_rows(named=True):
        name = str(r["Alert Name"])
        out.setdefault(r["cluster_id"], []).append(
            # the base rule on purpose: these rows are grouped by counterpart, so the pair's direction (the client
            # and server sides) is not known here; the Clusters frame itself resolved the variants per bucket
            {"rule": catalog.get(name, r["tac"]), "cp": r["Counterpart IP"], "port": r["Server Port"], "n": r["n"],
             "first": r["first"], "last": r["last"]})
    return out


_WORM = re.compile(r"scanning in (.+)$")


def _worm_hosts(cb: ClusterBoard) -> dict[str, list[str]]:
    """CR-07 text -> the hosts that carry it (the segment's scanning hosts)."""
    out: dict[str, list[str]] = {}
    for actor, cs in cb.chains.items():
        for cr, _m, text in cs:
            if cr == "CR-07":
                out.setdefault(text, []).append(actor)
    return {t: sorted(hs) for t, hs in out.items()}


def chains_of(c: dict, cb: ClusterBoard) -> list[tuple[str, float, str]]:
    """The chain rules of the cluster's host that apply to this cluster: the one whose multiplier it carries (the host's
    newest cluster; every member's for CR-07), not the host's older clusters."""
    return list(cb.chains.get(c["anchor_ip"], ())) if (c.get("chain_bonus") or 1.0) > 1.0 else []


def chains_view(chains: list[tuple[str, float, str]]) -> list[dict]:
    """The chain lines of a card or a cluster's page: {id, title, mult, text}."""
    return [{"id": cr, "title": cluster_chains.CHAINS[cr][0], "mult": m, "text": t} for cr, m, t in chains]


def _cluster_steps(c: dict, rows: list[dict], cb: ClusterBoard, worms: dict, names: dict,
                   overlay: Sequence[dict], crown: bool) -> list[dict]:
    chains = chains_of(c, cb)
    worm = next(((m.group(1) if (m := _WORM.search(t)) else "its segment", worms.get(t, []))
                 for cr, _x, t in chains if cr == "CR-07"), None)
    return playbook.for_cluster(c["anchor_ip"], rows, [cr for cr, _x, _t in chains], c["verdict"], crown, names,
                                overlay, worm=worm)


_COLS = ("key", "cluster_id", "episode_id", "anchor_ip", "cluster_type", "cluster_label", "secondary_types", "start_ms", "end_ms",
         "alert_count", "verdict", "priority", "lead_alert", "highest_phase", "chain_bonus", "critical_host",
         "n_alert_types")


def _reason(c: dict, chains: list[tuple[str, float, str]]) -> str:
    bits = [fmt.plural(c['alert_count'], "alert") + (f", highest phase {c['highest_phase']}" if c.get("highest_phase") else "")]
    bits += [t for _cr, _m, t in chains]
    return "; ".join(bits)


def _cluster_rec(c: dict, cb: ClusterBoard, st: dict, t: dict | None, names: dict, snap) -> dict:
    ids, res = entities.of_ip(c["anchor_ip"], names)
    chains = chains_of(c, cb)
    oc, by, at, note, why = _outcome(st, t)
    fams = [c["cluster_type"], *(c.get("secondary_types") or [])]
    label = c.get("cluster_label") or c["cluster_type"]
    rose = (f"reopened: rose from {playbook.VL.get(st['reopened_from'], st['reopened_from'])} to "
            f"{playbook.VL[c['verdict']]} after close" if st["reopened_from"]
            else "back in the queue: its state was cleared")
    return {"kind": "cluster", "subject": f"cluster:{c['episode_id']}", "label": f"{c['anchor_ip']} · {label}",
            "ui_key": c["key"], "parent": None, "first_ms": c["start_ms"], "last_ms": c["end_ms"],
            "verdict": c["verdict"], "conf": None, "risk": float(c.get("priority") or 0), "stage": None,
            "headline": f"{label} on {c['anchor_ip']}: {fmt.plural(c['alert_count'], 'alert')}", "reason": _reason(c, chains),
            "families": fams, "chains": [cr for cr, _m, _t in chains], "members": [], "members_n": 1,
            "identifiers": ids, "resolution": res, "outcome": oc, "outcome_by": by, "outcome_at": at,
            "outcome_note": note, "outcome_reason": why, "handled_n": int(oc in history.HANDLED),
            "reopen_text": rose, "snap": snap}


def _target_rec(t: dict, st: dict, row: dict | None, names: dict, snap) -> dict:
    ids, res = entities.of_ip(t["ip"], names)
    oc, by, at, note, why = _outcome(st, row)
    n = t["attackers"]
    rose = (f"reopened: rose from {playbook.VL.get(st['reopened_from'], st['reopened_from'])} to "
            f"{playbook.VL[target_verdict(t)]} after close" if st["reopened_from"]
            else "back in the queue: its state was cleared")
    return {"kind": "cluster-target", "subject": f"ip:{t['ip']}", "label": t["ip"], "ui_key": t["key"], "parent": None,
            "first_ms": t["first"], "last_ms": t["last"], "verdict": target_verdict(t), "conf": None,
            "risk": 0.2 if t.get("crown") else 0.05, "stage": None,
            "headline": f"{n} source{'s' if n != 1 else ''} against {t['ip']}: {t['top_rule']}",
            "reason": ("it answered" if t.get("answered") else "it did not answer")
            + ("; a crown jewel" if t.get("crown") else ""), "families": list(t["families"]), "chains": [],
            "members": [], "members_n": 1, "identifiers": ids, "resolution": res, "outcome": oc, "outcome_by": by,
            "outcome_at": at, "outcome_note": note, "outcome_reason": why, "handled_n": int(oc in history.HANDLED),
            "reopen_text": rose, "snap": snap}


def _merge_pass(store, ctri: dict, merged: dict[int, int]) -> None:
    """Every status still under a merged id goes to the episode it merged into (or is dropped, audited, when that one
    has its own). Idempotent and read from the stored merges, so a crash between the merge and the move, or a move
    that failed, is finished by the next pass."""
    moved = False
    for key in [k for k in ctri if CL_RE.fullmatch(k) and int(k[3:]) in merged]:
        try:
            store.move_cluster_triage(key, f"cl:{merged[int(key[3:])]}")
            moved = True
        except Exception:
            log.exception("moving the status of %s failed (retried on the next pass)", key)
    if moved:
        fresh = store.cluster_triage()
        ctri.clear()
        ctri.update(fresh)


def _closing(o: dict, ctri: dict, merged_to: int | None = None) -> tuple[int, dict, list] | None:
    """The update that closes an open record, or None when somebody has it (it ends when they close it)."""
    t = ctri.get(o["ui_key"])
    status = t["status"] if t else None
    if merged_to is not None:
        outcome, end = "merged", "merged"
        why = f"its alerts are part of cl:{merged_to} now, the earlier cluster of the same host"
    else:
        if status in history.OWNED:
            return None
        # a closure the cluster has outgrown (its verdict rose past it: New again) is not an outcome: it expires
        if t and not state(o["verdict_last"], t)["handled"]:
            t, status = None, None
        outcome, end = status or "expired", "quiet"
        why = ("it is not on the board any more: its alerts left the window or its verdict fell to Watch"
               + ("; nobody has looked at it: it stays in the queue under Ended, not reviewed"
                  if not status and o["verdict_peak"] in ("act", "investigate") else ""))
    fields = {"status": "closed", "closed_at": o["last_seen"], "outcome": outcome, "end_reason": end,
              "events": (list(o["events"] or []) + [{"at": o["last_seen"], "kind": "closed", "text": why}])
              [-history.EVENTS_MAX:]}
    if merged_to is None:
        fields.update(outcome_by=(t.get("owner") or t.get("who")) if t else None, outcome_at=t.get("at") if t else None,
                      outcome_note=t.get("note") if t else None, outcome_reason=t.get("reason") if t else None)
    return o["id"], fields, []


def record(cb: ClusterBoard, ctri: dict, store, now: float, grace_s: float = history.GRACE_S, *,
           catalog: rules.Catalog | None = None, names: dict | None = None,
           overlay: Sequence[dict] = ()) -> dict:
    """Bring the Clusters records up to date with the board (after every build and every action; the caller holds
    history._LOCK). A cluster at Review or above with no open record opens one; the ones on the board get
    `last_seen`; a record whose key is gone closes after `grace_s` (quiet), or at once when its episode was merged.
    Under attack entries at Investigate are recorded the same way. Returns {opened, updated, closed}."""
    catalog, names = catalog or rules.Catalog(), names or {}
    merged = store.merged_episodes()
    if merged:
        _merge_pass(store, ctri, merged)
    opened = store.open_incidents(product=PRODUCT)
    by_key = {o["ui_key"]: o for o in opened}
    snap = cb.snapshot
    cls = []
    if not snap.empty and "episode_id" in snap.clusters.columns:
        cls = [c for c in snap.clusters.select([x for x in _COLS if x in snap.clusters.columns]).iter_rows(named=True)
               if c["key"] and CL_RE.fullmatch(c["key"]) and ev.VRANK.get(c["verdict"], 0) >= 1]
    targets = [t for t in cb.targets if target_verdict(t) == "investigate"][:TARGET_RECORDS]
    # an entry that already has an open record keeps it while it is on the board, whatever its verdict or rank now
    listed = {t["key"] for t in targets}
    targets += [t for t in cb.targets if t["key"] in by_key and t["key"] not in listed]
    # the clusters whose snapshot will be taken (a new record, or a verdict above the record's peak): one pass for all
    need = [c["cluster_id"] for c in cls
            if (o := by_key.get(c["key"])) is None or ev.VRANK[c["verdict"]] > ev.VRANK.get(o["verdict_peak"], -1)
            or not o.get("snapshot")]
    rows = _bucket_rows(snap, catalog, need)
    worms = _worm_hosts(cb)
    crown = {c["anchor_ip"]: bool(c.get("critical_host")) for c in cls}
    stamp = {"config_version": store.stamp[0], "profile_day": store.stamp[1], "product": PRODUCT}
    creates, updates, taken = [], [], set()
    recs = []
    for c in cls:
        t = ctri.get(c["key"])

        def snapshot(c=c) -> dict:
            return _cluster_snap(c, rows.get(c["cluster_id"], []), cb, worms, names, overlay, crown[c["anchor_ip"]])
        recs.append(_cluster_rec(c, cb, state(c["verdict"], t), t, names, snapshot))
    for tg in targets:
        t = ctri.get(tg["key"])
        recs.append(_target_rec(tg, state(target_verdict(tg), t), t, names,
                                lambda tg=tg: _target_snap(tg, names, overlay, catalog)))
    for r in recs:
        o = by_key.get(r["ui_key"])
        if o is None:
            fields, members = history._create(r, now)
            creates.append(({**fields, **stamp}, members))
        else:
            taken.add(o["id"])
            iid, fields, members = history._update(o, r, now)
            updates.append((iid, {**fields, **stamp}, members))
    closed = 0
    for o in opened:
        if o["id"] in taken:
            continue
        key = o["ui_key"]
        dead = int(key[3:]) if CL_RE.fullmatch(key or "") and int(key[3:]) in merged else None
        if dead is None and now - o["last_seen"] < grace_s:
            continue
        c = _closing(o, ctri, merged[dead] if dead is not None else None)
        if c:
            updates.append(c)
            closed += 1
    if creates or updates:
        store.apply_incidents(creates, updates)
    return {"opened": len(creates), "updated": len(updates) - closed, "closed": closed}


def _cluster_snap(c: dict, rows: list[dict], cb: ClusterBoard, worms: dict, names: dict, overlay: Sequence[dict],
                  crown: bool) -> dict:
    chains = chains_of(c, cb)
    try:
        steps = _cluster_steps(c, rows, cb, worms, names, overlay, crown)
    except Exception:       # a snapshot without steps is still a snapshot
        log.exception("next steps for the cluster snapshot failed")
        steps = None
    return {"what": "cluster", "key": c["key"], "ip": c["anchor_ip"], "name": names.get(c["anchor_ip"]),
            "verdict": c["verdict"], "priority": c.get("priority"), "type": c["cluster_type"],
            "label": c.get("cluster_label"), "families": [c["cluster_type"], *(c.get("secondary_types") or [])],
            "phase": c.get("highest_phase"), "alerts": c["alert_count"], "first": c["start_ms"], "last": c["end_ms"],
            "crown": crown, "lead": c.get("lead_alert"),
            "chains": [{"id": cr, "title": cluster_chains.CHAINS[cr][0], "text": t} for cr, _m, t in chains],
            "steps": steps,
            "findings": [{"rule": r["rule"].name, "family": r["rule"].family, "cp": r["cp"], "port": r["port"],
                          "n": r["n"], "first": r["first"], "last": r["last"]} for r in rows[:FINDINGS_KEPT]]}


def _target_snap(t: dict, names: dict, overlay: Sequence[dict], catalog: rules.Catalog) -> dict:
    try:
        steps = playbook.for_cluster_target(t["ip"], t, overlay, catalog)
    except Exception:
        log.exception("next steps for the target snapshot failed")
        steps = None
    return {"what": "cluster-target", "key": t["key"], "ip": t["ip"], "name": names.get(t["ip"]),
            "verdict": target_verdict(t), "attackers": t["attackers"], "alerts": t["alerts"], "top_rule": t["top_rule"],
            "families": list(t["families"]), "answered": t["answered"], "crown": t["crown"], "first": t["first"],
            "last": t["last"], "steps": steps}


# ---- what the pages read -----------------------------------------------------------------------------------------

def steps_view(store, steps: list[dict], key: str) -> dict:
    """The steps with what the team checked, kept under the open record of `key` (the shape of Triage's /host)."""
    rec = store.open_incident_by_key(key, PRODUCT)
    return {"list": steps, "rec": rec["id"] if rec else None, "rec_key": rec["ui_key"] if rec else None,
            "done": store.steps(rec["id"], PRODUCT) if rec else {}}


def timeline(store, key: str, limit: int = 60, full: bool = False) -> list[dict]:
    """The analysts' and the service's lines about a work object (audit, product clusters), newest first."""
    out = []
    for a in store.audit(key, limit, full, product=PRODUCT):
        d = a.get("detail") or {}
        text = {**triage.ACTION_WORDS, **ACTION_WORDS}.get(a["action"], a["action"])
        if a["action"] == "triage:investigating" and d.get("owner") and d["owner"] != a["who"]:
            text = f"assigned it to {d['owner']}"
        elif a["action"] == "triage:escalated" and d.get("owner"):
            text = f"escalated it to {d['owner']}"
        elif a["action"] == "triage:undo" and "restored" in d:
            text = f"undid the last action: back to {triage.STATUS.get(d['restored'], d['restored']) if d['restored'] else 'New'}"
        if d.get("reason"):
            text += f" ({d['reason']})"
        out.append({"at": a["at"], "who": a["who"], "action": a["action"], "text": text, "note": a.get("note") or "",
                    "detail": d, "verified": a.get("verified")})
    return out


def cluster_view(cb: ClusterBoard, d: dict, store, ctri: dict, catalog: rules.Catalog, names: dict,
                 overlay: Sequence[dict], params) -> dict:
    """What a cluster's page adds to clusters.detail: its state, next steps with what the team checked, the ticket
    priority, and its history. `d` is clusters.detail's answer."""
    c = d["cluster"]
    key = c["key"]
    snap = cb.snapshot
    row = snap.clusters.filter(pl.col("key") == key).row(0, named=True)
    rows = _bucket_rows(snap, catalog, [row["cluster_id"]]).get(row["cluster_id"], [])
    crown = bool(row.get("critical_host"))
    chains = chains_of(row, cb)
    steps = _cluster_steps(row, rows, cb, _worm_hosts(cb), names, overlay, crown)
    return {"kind": "cluster", "state": state_row(c["verdict"], ctri.get(key)),
            "steps": steps_view(store, steps, key),
            "chains": chains_view(chains),
            "priority": playbook.priority(c["verdict"], crown, [cr for cr, _m, _t in chains], params),
            "timeline": timeline(store, key)}


def target_view(cb: ClusterBoard, key: str, store, ctri: dict, catalog: rules.Catalog, names: dict,
                overlay: Sequence[dict], params) -> dict | None:
    """The page of an Under attack entry: the lane row, its state, next steps, priority and history."""
    row = next((t for t in cb.targets if t["key"] == key), None)
    if row is None:
        return None
    v = target_verdict(row)
    return {"kind": "target", "target": {**row, "verdict": v, "name": names.get(row["ip"])},
            "state": state_row(v, ctri.get(key)),
            "steps": steps_view(store, playbook.for_cluster_target(row["ip"], row, overlay, catalog), key),
            "priority": playbook.priority(v, row.get("crown"), (), params), "timeline": timeline(store, key)}


def item(store, iid: int, ctri: dict | None = None) -> dict | None:
    """One Clusters record for its page (history-item): the row, the snapshot, the events, what the cluster is
    now. A Triage record is not found."""
    o = store.incident(iid, product=PRODUCT)
    if not o:
        return None
    ctri = ctri or {}
    key = o["ui_key"]
    return {**history._row(o), "reason": o["reason"], "chains": o["chains"], "identifiers": o["identifiers"],
            "resolution": o["resolution"], "snapshot": o["snapshot"], "snapshot_at": o["snapshot_at"],
            "events": o["events"], "outcome_note": o["outcome_note"],
            "state": state_row(o["verdict_last"], ctri.get(key)), "live": o["status"] == "open"}


def record_steps(store, d: dict) -> dict:
    """The next steps of a record for its page, with what the team checked (the steps are kept in the snapshot)."""
    snap = d.get("snapshot") or {}
    return {"list": snap.get("steps") or [],
            "rec": d["id"] if (d["status"] == "open" or d.get("end_reason") == "quiet") else None,
            "done": store.steps(d["id"], PRODUCT)}
