"""Read-only Sycope client: login, run one NQL over the alerts stream, page through the result.

Stdlib only, like the recorder's sycope_import. A session cookie is kept; a 401 logs in again once.
"""

from __future__ import annotations

import http.cookiejar
import json
import ssl
import sys
import time
import urllib.error
import urllib.request
from collections.abc import Iterator

# The alert fields the clustering reads, and what the detail views show. Everything else in a row
# (the definition's own metrics) is dropped while the page is parsed, to keep memory flat.
CLASSIC_FIELDS = ("id", "timestamp", "alertName", "alertSeverity", "alertMitreTactic", "alertMitreTechnique",
                  "alertMitreId", "alertRuleType", "alertRuleId", "alertDefId", "clientIp", "serverIp", "serverPort",
                  "clientLocation", "serverLocation", "clientFunction", "serverFunction")
# v0.2, what the evidence model reads on top: how far over its threshold the alert went, bytes each way (an
# "upload" alert on a download is not exfiltration), who the counterpart is (ASN, country), and the targets of
# aggregated alerts (a horizontal scan lists the hosts it touched, the chain rules follow them). v1.4: protocolName
# (TCP, UDP, ICMP; ~92% of the lab's alerts carry it), what a silence rule's protocol is matched against.
EXTRA_FIELDS = ("alertFlagThresholdLevel", "sumClientBytes", "sumServerBytes", "serverAsName", "serverCountry",
                "clientAsName", "clientCountry", "serverIps", "serverPorts", "_uniqueServerIps", "_countSessions",
                "protocolName")
FIELDS = CLASSIC_FIELDS + EXTRA_FIELDS

PAGE = 20000
RESULT_CAP = 100000  # Sycope 3.x: a pipeline job keeps at most this many records (measured on the lab instance)


class SycopeError(Exception):
    """Not configured, unreachable, login refused or an NQL error; the message says which."""


_UNIQUE = frozenset({"id", "serverIps"})


def _cell(v, field: str = ""):
    """One field as kept in memory. 150,000 alerts a day repeat the same names, IPs and severities: interned
    strings are stored once. Lookups (location, function) come as lists and are kept as one string. Unique values
    (alert ids, target lists) are never interned: on Python 3.12 interned strings are immortal, and a day of
    backfill would pin a million ids."""
    if isinstance(v, list):
        v = ", ".join(str(x) for x in v if x not in (None, ""))
        return sys.intern(v) if v else None
    if isinstance(v, str):
        return sys.intern(v) if len(v) <= 64 and field not in _UNIQUE else v
    return v


def _iso(epoch: float) -> str:
    return "@" + time.strftime("%Y-%m-%dT%H:%M:%S+00:00", time.gmtime(epoch))


class Sycope:
    def __init__(self, base: str, user: str, password: str, verify: bool = True, timeout: int = 120) -> None:
        if not (base and user and password):
            raise SycopeError("Sycope is not configured: set SC_SYCOPE_URL, SC_SYCOPE_USER, SC_SYCOPE_PASSWORD")
        self.base = base.rstrip("/")
        self._user, self._password, self._timeout = user, password, timeout
        ctx = ssl.create_default_context()
        if not verify:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        self._opener = urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()),
            urllib.request.HTTPSHandler(context=ctx))
        self._logged_in = False

    def _post(self, path: str, body: dict):
        req = urllib.request.Request(f"{self.base}/npm/api/v1/{path}", data=json.dumps(body).encode(),
                                     headers={"Content-Type": "application/json", "Accept": "application/json"})
        try:
            with self._opener.open(req, timeout=self._timeout) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            if exc.code == 401:
                raise
            raise SycopeError(f"Sycope answered HTTP {exc.code} to {path.split('/')[0]}") from exc
        except (urllib.error.URLError, OSError, ValueError) as exc:
            hint = (" (set SC_SYCOPE_VERIFY_TLS=false for a self-signed certificate)"
                    if "CERTIFICATE" in str(exc).upper() else "")
            raise SycopeError(f"cannot reach Sycope: {getattr(exc, 'reason', exc)}{hint}") from exc

    def login(self) -> None:
        try:
            ans = self._post("login", {"username": self._user, "password": self._password})
        except urllib.error.HTTPError as exc:
            raise SycopeError(f"login refused (HTTP {exc.code})") from exc
        if not isinstance(ans, dict) or ans.get("status") != 200:
            raise SycopeError(f"login refused: {ans.get('message') if isinstance(ans, dict) else ans}")
        self._logged_in = True

    def _call(self, path: str, body: dict):
        if not self._logged_in:
            self.login()
        try:
            return self._post(path, body)
        except urllib.error.HTTPError:  # 401: the session expired
            self.login()
            try:
                return self._post(path, body)
            except urllib.error.HTTPError as exc:
                raise SycopeError(f"Sycope answered HTTP {exc.code} after a fresh login") from exc

    def get_json(self, path: str):
        """GET {base}/npm/api/v1/{path} as JSON (e.g. a Passthrough of another tool), with the session."""
        if not self._logged_in:
            self.login()
        for attempt in (1, 2):
            req = urllib.request.Request(f"{self.base}/npm/api/v1/{path}", headers={"Accept": "application/json"})
            try:
                with self._opener.open(req, timeout=30) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as exc:
                if exc.code == 401 and attempt == 1:
                    self.login()
                    continue
                raise SycopeError(f"Sycope answered HTTP {exc.code} to {path.split('?')[0]}") from exc
            except (urllib.error.URLError, OSError, ValueError) as exc:
                raise SycopeError(f"cannot reach Sycope: {getattr(exc, 'reason', exc)}") from exc
        return None

    def call_action(self, destination: str, def_id: str, alert_id: str, timestamp: int) -> dict:
        """Ask Sycope to send one stored alert to a REST destination (its postAlert action), as an operator
        would from the alert's menu."""
        body = {"externalSystem": "REST", "instanceName": destination, "actionName": "postAlert",
                "parameters": {"alertDefId": def_id, "alertId": alert_id, "timestamp": timestamp}}
        return self._call("external-systems/system-actions/callAction", body)

    def rows(self, start: float, end: float, nql: str, limit: int = 50) -> list[dict]:
        """The first `limit` records of a query as Sycope sends them (any stream, raw or aggregated), for a view
        shown on demand."""
        run = self._call("pipeline/run", {"startTime": _iso(start), "endTime": _iso(end), "nql": nql,
                                          "fsActive": False, "waitTime": 30000, "limit": limit})
        if not isinstance(run, dict) or "jobId" not in run:
            msg = run.get("message") if isinstance(run, dict) else str(run)[:200]
            raise SycopeError(f"NQL refused: {msg}")
        page = self._call(f"pipeline/{run['jobId']}/data", {"limit": limit, "offset": 0})
        return [r for r in ((page or {}).get("data") or []) if isinstance(r, dict)][:limit]

    def query_rows(self, start: float, end: float, nql: str) -> tuple[list[dict], int]:
        """Every record of one query (any stream, raw or aggregated) as the dicts Sycope sends, and the total it
        reports. Sycope keeps at most RESULT_CAP records of a job: a total at the cap means the answer is cut and
        the caller asks a smaller window."""
        run = self._call("pipeline/run", {"startTime": _iso(start), "endTime": _iso(end), "nql": nql,
                                          "fsActive": False, "waitTime": 60000, "limit": PAGE})
        if not isinstance(run, dict) or "jobId" not in run:
            msg = run.get("message") if isinstance(run, dict) else str(run)[:200]
            raise SycopeError(f"NQL refused: {msg}")
        total = int((run.get("data") or {}).get("total") or 0)
        out: list[dict] = []
        while len(out) < total:
            page = self._call(f"pipeline/{run['jobId']}/data", {"limit": PAGE, "offset": len(out)})
            rows = [r for r in ((page or {}).get("data") or []) if isinstance(r, dict)]
            if not rows:
                break
            out.extend(rows)
        return out, total

    def alerts(self, start: float, end: float, nql: str = 'src stream="alerts"', chunk: int = 3600) -> list[tuple]:
        """Every alert with `start <= timestamp < end`, as tuples in FIELDS order (pages() as one list)."""
        return [r for page in self.pages(start, end, nql, chunk) for r in page]

    def pages(self, start: float, end: float, nql: str = 'src stream="alerts"',
              chunk: int = 3600) -> Iterator[list[tuple]]:
        """The alerts of alerts() one Sycope page at a time (PAGE records at most), so a caller never holds a whole
        day (2M alerts) at once.

        Asked in windows of `chunk` seconds: Sycope stops a job at RESULT_CAP records (it then answers with the
        oldest ones only), so a window whose total reaches the cap is split in half before any page of it is read.
        """
        t = start
        while t < end:
            yield from self._window(t, min(end, t + chunk), nql)
            t += chunk

    def _window(self, start: float, end: float, nql: str) -> Iterator[list[tuple]]:
        run = self._call("pipeline/run", {"startTime": _iso(start), "endTime": _iso(end), "nql": nql,
                                          "fsActive": False, "waitTime": 60000, "limit": PAGE})
        if not isinstance(run, dict) or "jobId" not in run:
            msg = run.get("message") if isinstance(run, dict) else str(run)[:200]
            raise SycopeError(f"NQL refused: {msg}")
        total = int((run.get("data") or {}).get("total") or 0)
        if total >= RESULT_CAP and end - start > 60:
            mid = start + (end - start) / 2
            yield from self._window(start, mid, nql)
            yield from self._window(mid, end, nql)
            return
        offset = 0
        while offset < total:
            page = self._call(f"pipeline/{run['jobId']}/data", {"limit": PAGE, "offset": offset})
            rows = (page or {}).get("data") or []
            if not rows:
                break
            offset += len(rows)
            yield [tuple(_cell(r.get(f), f) for f in FIELDS) for r in rows if isinstance(r, dict)]
