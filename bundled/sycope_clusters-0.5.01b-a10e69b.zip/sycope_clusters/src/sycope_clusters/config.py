"""Settings from the environment (SC_*). Every field has a line in HELP, shown on the System page."""

from __future__ import annotations

import os
from dataclasses import dataclass, fields
from pathlib import Path


def _bool(v: str) -> bool:
    return v.strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Settings:
    sycope_url: str = ""
    sycope_user: str = ""
    sycope_password: str = ""
    sycope_verify_tls: bool = True
    sycope_ui_url: str = ""
    nql: str = 'src stream="alerts"'
    retention_hours: int = 24
    poll_seconds: int = 60
    overlap_seconds: int = 900
    fetch_chunk_seconds: int = 3600
    delta_seconds: int = 3600
    min_alerts: int = 2
    critical_hosts_file: str = ""
    base_href: str = ""
    default_range: str = "6h"
    state_dir: str = ""
    scoring_edit: bool = False
    debug_models: bool = False
    clusters_compare: bool = False
    hostnames_file: str = ""
    reverse_dns: bool = True
    recorder_passthrough: str = ""
    recorder_destination: str = ""
    internal_nets: str = ""
    location_internal: bool = True
    history_days: int = 14
    triage_edit: bool = False
    rules_file: str = ""
    stage_order: str = "stage"
    campaign_min: int = 5
    incident_days: int = 180
    unreviewed_days: int = 14
    chain_days: int = 3
    networks_file: str = ""
    lookup_names: str = "hosts & subnets"
    lookup_refresh_seconds: int = 900
    silenced_lookup: str = ""
    exception_approval: bool = False
    ti_pivots: str = ""
    require_verified_user: bool = False
    flow_aggregate: bool = True
    memory_mb: int = 2048
    raw_per_host: int = 200
    classic_max_alerts: int = 300000
    webhook_url: str = ""
    webhook_secret: str = ""
    webhook_verify_tls: bool = True

    @property
    def critical_hosts_path(self) -> Path | None:
        return Path(self.critical_hosts_file) if self.critical_hosts_file else None

    @property
    def db_path(self) -> Path | None:
        return Path(self.state_dir) / "clusters.db" if self.state_dir else None

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> Settings:
        env = os.environ if env is None else env
        kw: dict = {}
        for f in fields(cls):
            raw = env.get(f"SC_{f.name.upper()}")
            if raw is None or raw == "":
                continue
            kw[f.name] = _bool(raw) if f.type in ("bool", bool) else int(raw) if f.type in ("int", int) else raw
        return cls(**kw)


HELP = {
    "sycope_url": "Sycope the alerts are read from, e.g. https://sycope.example (API /npm/api/v1).",
    "sycope_user": "Sycope account; a read-only one is enough (login + NQL on the alerts stream).",
    "sycope_password": "Its password. Only in the environment, never shown.",
    "sycope_verify_tls": "false for a self-signed Sycope certificate.",
    "sycope_ui_url": "Sycope address for links from a cluster back to Sycope (empty = the Sycope address above).",
    "nql": "Query that selects the alerts to cluster. Narrow it to drop a rule type, e.g. "
           "src stream=\"alerts\" | where alertRuleType = \"Security\".",
    "retention_hours": "How much alert history is kept in memory and clustered (hours).",
    "poll_seconds": "How often new alerts are read from Sycope.",
    "overlap_seconds": "Each poll asks again for this much before the newest alert seen (late alerts).",
    "fetch_chunk_seconds": "Window of one Sycope query; a window over 100,000 alerts is split by itself.",
    "delta_seconds": "Gap that ends a cluster: alerts of one anchor IP no more than this apart chain (default 1 h). "
                     "Clusters chain hourly findings: values under 3600 act as 3600.",
    "min_alerts": "Chains with fewer alerts are not clusters (default 2).",
    "critical_hosts_file": "JSON with \"critical_hosts\": [ip, ...]: +6000 to the score of a crown jewel (+3000 or +5000 in the stricter presets).",
    "base_href": "Address the pages are opened at through Sycope Passthrough, e.g. "
                 "https://sycope.example/npm/api/v1/passthrough/clusters (links then stay on it).",
    "default_range": "Time range the live page opens with: 15m, 1h, 6h, 12h or 24h.",
    "state_dir": "Writable directory for the saved scoring model (scoring.json). Empty = the model is not kept.",
    "scoring_edit": "true lets the Scoring page save a model (it changes everyone's board). Off by default.",
    "debug_models": "true: admins also see the reference scoring models and their blend on a Clusters card (for "
                    "comparing the models). Off by default; nobody else ever sees them.",
    "clusters_compare": "true: Clusters keeps its own verdict, priority and quadrant (for comparing the boards on the "
                        "lab). Off by default.",
    "hostnames_file": "CSV ip,name (no header) with names shown next to IPs; they win over reverse DNS.",
    "reverse_dns": "Look up a PTR name for each host on the board (cached for a day).",
    "recorder_passthrough": "Name of the Sycope Passthrough of a Sycope Traffic Recorder, e.g. recorder: the cluster "
                            "shows the PCAP of each of its alerts the recorder has.",
    "recorder_destination": "Name of the Sycope REST destination that sends alerts to that recorder (postAlert): "
                            "turns on the PCAP button, which asks Sycope to send one alert to it. Empty = off.",
    "internal_nets": "Your own networks besides the private ranges, comma separated CIDRs (public DMZ ranges, NAT "
                     "pools). An IP in them is a host the triage scores; any other IP is external.",
    "location_internal": "true: an IP Sycope gives a location (Network > Locations) counts as internal too.",
    "history_days": "Days of alert history read from Sycope on start (backfill). The state database keeps at least "
                    "35 days as they come in; the triage reads them to tell new behaviour from what a host does "
                    "every day.",
    "triage_edit": "true lets analysts acknowledge hosts, mark false positives and add exceptions on the "
                   "Triage page (stored in the state directory). Off = read-only triage.",
    "stage_order": "Order inside a verdict: stage (default: the confirmed kill-chain stage first, then risk; a "
                   "a confirmed Objectives or command channel is always above Lateral, as on the 14 expert-ranked reference cases: Spearman "
                   "0.84) or risk (confidence x impact only: 0.29).",
    "campaign_min": "Fewest hosts of one network segment at Investigate or above, with the same kind of intrusion, "
                    "that can make a campaign (default 5); the number must also be improbable for the segment's size.",
    "incident_days": "Days a closed incident stays in the incident history (default 180).",
    "unreviewed_days": "Days an incident that reached Act now or Investigate, went quiet and ended with nobody having "
                       "looked at it stays in the queue under Ended, not reviewed (default 14).",
    "chain_days": "Days back a two-step chain rule looks for its first step in the stored history: credential "
                  "attack, then lateral movement (CR-08) up to 2 days, scanning, then exploitation (CR-09) up to this "
                  "many (default 3, as in the architecture: 48 h and 72 h). 1 = only the 24 h window.",
    "networks_file": "CSV cidr,name[,role] naming your networks (VLAN-HR, DMZ-PROD); shown next to hosts and searchable.",
    "lookup_names": "Sycope subnet lookups (Configuration > Lookups) that say which addresses are yours and name them, "
                    "comma separated. Their privacy column (Private/Internal or Public/External) decides "
                    "internal or external before the settings and the private ranges do; location, function, "
                    "service, business unit and severity are kept per network. Default, also when set empty: "
                    "hosts & subnets. A name that matches no lookup is skipped with a warning in the log, so "
                    "naming one that does not exist reads none.",
    "lookup_refresh_seconds": "How often those lookups are read again from Sycope (default 900). A failed read keeps "
                              "the last good one.",
    "silenced_lookup": "Name of one Sycope lookup (subnet or csvFile; for a csvFile the cidr/ip column, else the first "
                       "one; with several names only the first is read) whose addresses and networks the triage treats as silenced hosts, read-only: they show next to the exceptions "
                       "as 'sycope-lookup' and are never stored here. Read every lookup_refresh_seconds. Empty = none.",
    "exception_approval": "true: an exception an analyst adds waits until an admin (ROLE_ADMIN in Sycope) approves it; "
                          "admins add theirs directly. Admin means a pass Sycope confirmed (see require_verified_user), "
                          "never what the page says. Whatever this says, an exception added by someone Sycope has not "
                          "confirmed is only a proposal that a confirmed user approves; one for a credential, exfiltration "
                          "or C2 family or any threat-list match needs a second confirmed admin; one covering more than "
                          "1,000 alerts a day or 20 hosts needs an admin.",
    "require_verified_user": "true: actions only from a user Sycope confirmed (the page proves who is signed in once a "
                             "session: it writes a code into the user's own Sycope preferences and the service finds it "
                             "in Sycope's audit log). false (default): an unconfirmed name is still recorded, without "
                             "the check mark. Needs the service's Sycope account to read the audit log and users.",
    "flow_aggregate": "true (default): once an hour the service asks Sycope's netflow stream two small aggregate "
                      "questions (traffic per internal service, and per internal host towards the outside) and keeps "
                      "the sums; the triage learns from them what is normal for a host. false: no flow queries.",
    "memory_mb": "Memory budget of the service in MB (default 2048): the alert window (alerts are kept as hourly "
                 "findings) plus what the scoring holds, two boards and two histories while the next ones are built. "
                 "Above 80 % the window thins itself in steps (shorter per-host alert lists, then class D findings "
                 "as counts, then class C target lists); class A and B findings are never thinned. Back below 60 % "
                 "it stops thinning new alerts. The estimate is on the System page.",
    "raw_per_host": "Newest raw alerts kept per host for its page and the PCAP links (default 200; 20 when the "
                    "window is thinned). Counts and scoring use every alert whatever this is.",
    "classic_max_alerts": "Ignored since 1.1: the Clusters board is built from the hourly findings and has no alert "
                          "limit. Still read to decide when a backfill day is fetched as Sycope's aggregate "
                          "(default 300000).",
    "ti_pivots": "Lookups for outside addresses, 'Name|https://...{ip}' separated by ';', e.g. "
                 "VirusTotal|https://www.virustotal.com/gui/ip-address/{ip}. Each link sends the address to that "
                 "service: leave empty unless your policy allows it.",
    "webhook_url": "Address that receives incident events as JSON POSTs: incident.new, incident.raised, "
                   "incident.status, sla.breached, actnow.unowned (SLA limits: Configuration > Parameters, sla.*). "
                   "Empty = no webhook. Sent from a queue with retries; a failure is in the audit log and in Health.",
    "webhook_secret": "Optional. When set, every webhook body is signed: header X-SC-Signature = sha256= and the "
                      "HMAC-SHA256 of the body as hex. Only in the environment, never shown.",
    "webhook_verify_tls": "false for a webhook receiver with a self-signed certificate.",
    "rules_file": "JSON with overrides of the rule catalog: {\"rules\": {\"Alert name\": {\"family\": \"CL-05\", "
                  "\"class\": \"B\", \"stage\": 2, \"subject\": \"client\"}}}. Empty = the built-in catalog.",
}
