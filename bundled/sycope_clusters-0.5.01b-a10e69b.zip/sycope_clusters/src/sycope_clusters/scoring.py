"""The ranking model the board uses: alert_cluster's formula with every number a parameter, and presets.

The engine's own columns (maciej_score, pawel_score) are never changed; this module adds `score`, `priority`
and `verdict` from the cluster features and a model the operator can edit on the Scoring page.

    stage term     = stage × P × m(severity)            (strict: stage × P, and m(severity) × B inside the band)
    critical host  = crown_jewel × C
    alert types    = min(Σ max severity per type × S, S_cap)
    progression    = min(progression × G, G_cap)
    score          = (stage term + the rest) × chain bonus  (strict: the rest is capped at P − 1)
    priority 0-100 = score / full × 100

`severity_source` says whose severity m() reads: "cluster" = the highest severity anywhere in the cluster (what
alert_cluster's code does), "stage" = each alert type's own severity at its own stage, best product wins (what
Maciej's notes ask: "max z iloczynu max_mitre_phase × criticality").
"""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field, fields, replace
from pathlib import Path

import polars as pl

SEVERITIES = ("Info", "Low", "Medium", "High", "Critical")
WEIGHT_SEV = {1: "Info", 2: "Low", 3: "Medium", 4: "High", 5: "Critical"}


@dataclass(frozen=True)
class Model:
    preset: str = "alert_cluster"
    stage_points: float = 10000          # P
    severity_source: str = "cluster"     # cluster | stage
    multipliers: dict = field(default_factory=lambda: {"Info": 0.1, "Low": 0.5, "Medium": 0.6, "High": 0.8,
                                                       "Critical": 1.0})
    strict: bool = False                 # no cluster ever outranks one of a later stage
    severity_band: float = 0             # B: strict only, severity points inside the stage band
    crown_jewel: float = 6000            # C
    per_type: float = 200                # S
    per_type_cap: float = 0              # 0 = no cap
    progression: float = 1500            # G
    progression_cap: float = 0
    full: float = 40000                  # the score that reads as priority 100
    act: float = 80
    investigate: float = 60
    review: float = 35

    def verdict(self, priority: float) -> str:
        return ("act" if priority >= self.act else "investigate" if priority >= self.investigate
                else "review" if priority >= self.review else "watch")


PRESETS: dict[str, dict] = {
    "alert_cluster": {"label": "Severity-weighted",
                      "help": "The stage is scaled by the highest severity anywhere in the cluster. A Critical alert of an early "
                              "stage lifts a Medium alert of a late stage.",
                      "model": {}},
    "maciej_note": {"label": "Per-alert product",
                    "help": "Same weights, but the stage is scaled by the severity of the alert that is in that stage "
                            "(best stage × severity product wins). An early Critical no longer lifts a late Medium. "
                            "Severity can still outrank a stage: Lateral × Critical (20000) > Objectives × Medium (18000).",
                    "model": {"severity_source": "stage"}},
    "strict": {"label": "Strict",
               "help": "Every stage owns a band of 10000 points and nothing leaves it: a later stage always ranks "
                       "higher. Severity (up to 6000), crown jewel (3000), alert types and progression order clusters inside the "
                       "band. Priority reads as the stage: Objectives 75-100, Lateral 50-75, Foothold 25-50, Recon 0-25; "
                       "Act now = Objectives with High or Critical, or Objectives on a crown jewel.",
               "model": {"severity_source": "stage", "strict": True, "severity_band": 6000, "crown_jewel": 3000,
                         "per_type": 100, "per_type_cap": 1000, "progression": 500, "progression_cap": 500,
                         "act": 90, "investigate": 88, "review": 50}},
    "pawel": {"label": "Stage-isolated",
              "help": "Stage × 10000 with no severity multiplier, crown jewel +5000, Σ severity × 30 capped at 1999, "
                      "progression × 999 capped at 999. The caps keep every stage isolated.",
              "model": {"multipliers": {s: 1.0 for s in SEVERITIES}, "strict": True, "severity_band": 0,
                        "crown_jewel": 5000, "per_type": 30, "per_type_cap": 1999, "progression": 999,
                        "progression_cap": 999, "act": 90, "investigate": 78, "review": 50}},
}


DEFAULT_PRESET = "maciej_note"   # what the service ranks by when nothing is saved (Model() itself stays the raw code values)


# What a preset is called outside the saved file and the code: the pages and the JSON they fetch use these ids.
WIRE = {"alert_cluster": "severity_weighted", "maciej_note": "per_alert", "strict": "strict", "pawel": "stage_isolated"}
_UNWIRE = {v: k for k, v in WIRE.items()}


def wire(name: str) -> str:
    return WIRE.get(name, name)


def public(m: Model) -> dict:
    """The model as the pages and their JSON get it (the preset under its public id)."""
    return {**asdict(m), "preset": wire(m.preset)}


def preset(name: str) -> Model:
    name = _UNWIRE.get(name, name)
    p = PRESETS.get(name) or PRESETS["alert_cluster"]
    return replace(Model(), preset=name if name in PRESETS else "alert_cluster", **p["model"])


class ModelError(ValueError):
    pass


_LIMITS = {"stage_points": (100, 1e7), "severity_band": (0, 1e7), "crown_jewel": (0, 1e7), "per_type": (0, 1e6),
           "per_type_cap": (0, 1e7), "progression": (0, 1e7), "progression_cap": (0, 1e7), "full": (1, 1e8),
           "act": (0, 100), "investigate": (0, 100), "review": (0, 100)}


def from_dict(d: dict) -> Model:
    """A validated model from an untrusted dict (the Scoring page's form). Raises ModelError."""
    if not isinstance(d, dict):
        raise ModelError("the model must be a JSON object")
    known = {f.name for f in fields(Model)}
    extra = set(d) - known
    if extra:
        raise ModelError(f"unknown fields: {', '.join(sorted(extra))}")
    base = preset(str(d.get("preset") or DEFAULT_PRESET))   # either id
    kw: dict = {}
    for name, (lo, hi) in _LIMITS.items():
        if name in d:
            try:
                v = float(d[name])
            except (TypeError, ValueError):
                raise ModelError(f"{name} must be a number") from None
            if not math.isfinite(v) or not lo <= v <= hi:
                raise ModelError(f"{name} must be between {lo:g} and {hi:g}")
            kw[name] = v
    if "severity_source" in d:
        if d["severity_source"] not in ("cluster", "stage"):
            raise ModelError("severity_source must be cluster or stage")
        kw["severity_source"] = d["severity_source"]
    if "strict" in d:
        if not isinstance(d["strict"], bool):
            raise ModelError("strict must be true or false")
        kw["strict"] = d["strict"]
    if "multipliers" in d:
        m = d["multipliers"]
        if not isinstance(m, dict) or set(m) != set(SEVERITIES):
            raise ModelError("multipliers needs exactly: " + ", ".join(SEVERITIES))
        try:
            mm = {s: float(m[s]) for s in SEVERITIES}
        except (TypeError, ValueError):
            raise ModelError("multipliers must be numbers") from None
        if any(not 0 <= v <= 10 for v in mm.values()):
            raise ModelError("multipliers must be between 0 and 10")
        kw["multipliers"] = mm
    if "preset" in d:
        kw["preset"] = _UNWIRE.get(str(d["preset"]), str(d["preset"]))[:40]
    model = replace(base, **kw)
    if not model.act >= model.investigate >= model.review:
        raise ModelError("the verdict bounds must go down: act ≥ investigate ≥ review")
    return model


def load(path: Path | None) -> Model:
    if not path or not path.exists():
        return preset(DEFAULT_PRESET)
    try:
        return from_dict(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, ValueError):  # a broken file never stops the board: back to the default model
        return preset(DEFAULT_PRESET)


def migrate(model: Model) -> Model | None:
    """The model a saved alert_cluster one becomes (the other edits are kept), or None when there is nothing to do.
    Run once per state directory by Live: the Clusters board moved its default to maciej_note."""
    if model.preset != "alert_cluster":
        return None
    return replace(model, preset="maciej_note", severity_source="stage")


def save(path: Path, model: Model) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(asdict(model), indent=2), encoding="utf-8")
    tmp.replace(path)


# ---- applying a model ------------------------------------------------------------------------------------

def _stage_term(m: Model, stage: int, sev_max: str | None, stage_sev: list) -> tuple[float, float, str]:
    """(stage term, severity-in-band term, a readable expression)."""
    mult = m.multipliers
    if m.severity_source == "stage" and stage_sev:
        best = max(stage_sev, key=lambda ps: (ps[0] * mult.get(WEIGHT_SEV.get(ps[1], ""), 0), ps[0]))
        st, sev = best[0], WEIGHT_SEV.get(best[1])
    else:
        st, sev = stage, sev_max
    k = mult.get(sev, 0.0)
    if m.strict:
        return stage * m.stage_points, k * m.severity_band, f"{stage} × {m.stage_points:g}|{k} × {m.severity_band:g} ({sev})"
    return st * m.stage_points * k, 0.0, f"{st} × {m.stage_points:g} × {k} ({sev}{', stage ' + str(st) if st != stage else ''})"


def terms(m: Model, c: dict) -> dict:
    phaseless = c.get("stage_idx") is None
    stage = int(c.get("stage_idx") if c.get("stage_idx") is not None else 0)
    stage_sev = c.get("stage_sev") or []
    t_stage, t_band, expr = _stage_term(m, stage, c.get("severity_max"), stage_sev)
    crit = int(c.get("critical_host") or 0)
    sigma = float(c.get("sigma_sev") or 0)
    prog = float(c.get("killchain_progression_score") or 0)
    t_type = sigma * m.per_type
    t_type = min(t_type, m.per_type_cap) if m.per_type_cap else t_type
    t_prog = prog * m.progression
    t_prog = min(t_prog, m.progression_cap) if m.progression_cap else t_prog
    rest = t_band + crit * m.crown_jewel + t_type + t_prog
    capped = m.strict and rest > m.stage_points - 1
    rest_cut = 0.0
    if m.strict:
        rest_cut = min(rest, m.stage_points - 1) - rest
        rest = rest + rest_cut
    bonus = float(c.get("chain_bonus") or 1.0)
    score = (t_stage + rest) * bonus
    if m.strict:
        e1, e2 = expr.split("|")
        rows = [("stage (band floor)", e1, t_stage), ("severity inside the stage", e2, t_band)]
    else:
        rows = [("stage", expr, t_stage)]
    rows += [("crown jewel", f"{crit} × {m.crown_jewel:g}", crit * m.crown_jewel),
             ("alert types (Σ max severity)", f"{sigma:g} × {m.per_type:g}" + (f", cap {m.per_type_cap:g}" if m.per_type_cap else ""), t_type),
             ("kill-chain progression", f"{prog:.3f} × {m.progression:g}" + (f", cap {m.progression_cap:g}" if m.progression_cap else ""), t_prog)]
    if capped:      # the rows add up to the subtotal: the cut that keeps the cluster inside its stage is a row too
        rows.append(("kept inside the stage", f"terms after the stage capped at {m.stage_points - 1:g}", rest_cut))
    raw = round(score / m.full * 100)
    pr = max(0.0, min(100.0, raw))
    return {"subtotal": round(t_stage + rest, 1), "raw_priority": raw,
            "rows": [{"term": a, "expr": b, "value": round(v, 1)} for a, b, v in rows], "score": round(score, 1),
            "capped": capped, "chain_bonus": bonus, "priority": pr,
            # a cluster of phase-less rules cannot rise above Watch whatever its priority (spec 4.2.2)
            "verdict": "watch" if phaseless else m.verdict(pr)}


def apply(clusters: pl.DataFrame, m: Model) -> pl.DataFrame:
    """Add score, priority and verdict (replacing earlier ones)."""
    if clusters.is_empty():
        return clusters
    cols = ["stage_idx", "stage_sev", "severity_max", "critical_host", "sigma_sev", "killchain_progression_score",
            "chain_bonus"]
    out = [terms(m, r) for r in clusters.select(cols).iter_rows(named=True)]
    base = clusters.drop([c for c in ("score", "priority", "verdict") if c in clusters.columns])
    return base.with_columns(pl.Series("score", [o["score"] for o in out], dtype=pl.Float64),
                             pl.Series("priority", [o["priority"] for o in out], dtype=pl.Float64),
                             pl.Series("verdict", [o["verdict"] for o in out], dtype=pl.Utf8))


def stage_jumps(clusters: pl.DataFrame) -> int:
    """Clusters that outrank at least one cluster of a later stage (0 = stages fully isolated)."""
    if clusters.is_empty():
        return 0
    jumps = 0
    by = clusters.group_by("stage_idx").agg(pl.col("score").min().alias("lo"), pl.col("score").alias("all")).sort("stage_idx")
    rows = list(by.iter_rows(named=True))
    for i, r in enumerate(rows):
        later_min = min((x["lo"] for x in rows[i + 1:]), default=math.inf)
        jumps += sum(1 for s in r["all"] if s > later_min)
    return jumps
