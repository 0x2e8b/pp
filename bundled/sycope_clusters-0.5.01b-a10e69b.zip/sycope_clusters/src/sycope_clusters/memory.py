"""What the service remembers about each host, read from the store before every board (W-2).

Three things the scoring cannot get from the 24 h window or the stored alert days:

    habit days      the days a host sat in an incident that peaked at Investigate or Act now and ended with nobody
                    deciding. A host that does the same thing every day while nobody looks at it has not shown that
                    it is normal, so those days do not teach habit (evidence.History.novelty leaves them out). Days of
                    benign / false-positive closures still count: somebody decided.
    recurrence      how many times in the last days an incident of the host (Review or above) ended without a decision
                    (evidence.score_entity adds bits at `recurrence.min1` and `recurrence.min2`).
    hysteresis      what the verdict log, the analysts' actions and the 72 h clock say about a host that fell from
                    Act now (evidence.apply_hold).

Everything is a function of the store and of `now`: a restart gives the same Memory. The one thing the log cannot
tell is when a host last showed evidence at Review or above while it was held (the verdict log writes only moves that
touch Act now or Investigate), so that clock is a small JSON document in the store's meta table, written here.

"Ended without a decision" is end_reason quiet with no closure as tp, benign, fp or resolved: a record marked seen,
taken or escalated that then went quiet is still undecided. Merged and regrouped records never count.
"""

from __future__ import annotations

import bisect
import json
import logging
from collections import defaultdict
from collections.abc import Mapping
from datetime import UTC, datetime, timedelta

from sycope_clusters import entities
from sycope_clusters import evidence as ev
from sycope_clusters.params import FACTORY, Params

log = logging.getLogger(__name__)

CLOCK_KEY = "hysteresis_clock"
CLOSED = ("tp", "benign", "fp", "resolved")      # an analyst closed it: a decision
HABIT_PEAKS = ("act", "investigate")
RECURRENCE_PEAKS = ("act", "investigate", "review")
LOOKBACK_DAYS = 30            # the incident rows read: far enough for the comparable days after a holiday
CLOCK_WRITE_S = 300           # a clock entry is rewritten at most this often
MAX_SPAN_DAYS = 31


def hosts_of(rec: dict) -> list[str]:
    """The addresses an incident record is about: its subject (a host) and its members."""
    keys = list(rec.get("members") or [])
    if rec.get("kind") == "entity":
        keys.append(rec["subject"])
    out = []
    for k in keys:
        kind, value = entities.parse(k)
        if kind == "ip" and value:
            out.append(value)
    return sorted(set(out))


def _days(start: float, end: float) -> set[str]:
    """The UTC days from `start` to `end` (epoch seconds), the way the stored alert days are named."""
    first = datetime.fromtimestamp(start, UTC).date()
    last = datetime.fromtimestamp(max(start, end), UTC).date()
    n = min(MAX_SPAN_DAYS, (last - first).days)
    return {(first + timedelta(days=i)).isoformat() for i in range(n + 1)}


def ended_undecided(rec: dict) -> bool:
    """Went quiet and nobody decided: no closure as tp, benign, fp or resolved. Marked seen, taken or escalated
    records are not decisions. Merged, regrouped and excepted records ended for another reason and never count."""
    return rec["status"] == "closed" and rec["end_reason"] == "quiet" and rec["outcome"] not in CLOSED


def load_clock(store) -> dict:
    try:
        d = json.loads(store.meta(CLOCK_KEY) or "{}")
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


class Facts:
    """What the stored incidents and statuses say, reduced once per store generation and board day (build caches it):
    the days each host sat in an incident nobody decided, the ends of its undecided incidents (for the recurrence
    count) and when an analyst last acted on it."""
    __slots__ = ("analyst", "ended", "undecided")

    def __init__(self) -> None:
        self.undecided: dict[str, frozenset] = {}
        self.ended: list[tuple[float, str]] = []      # (closed_at, host), oldest first: one per host of a recurring record
        self.analyst: dict[str, float] = {}


def _facts(store, since: float, product: str) -> Facts:
    out = Facts()
    undecided: dict[str, set] = defaultdict(set)
    for rec in store.decision_facts(since, product):
        hosts = hosts_of(rec)
        if not hosts:
            continue
        if ended_undecided(rec):
            if rec["verdict_peak"] in HABIT_PEAKS:
                days = _days(rec["opened_at"], rec["closed_at"] or rec["last_seen"])
                for h in hosts:
                    undecided[h] |= days
            if (rec["verdict_peak"] in RECURRENCE_PEAKS and rec["parent"] is None
                    and rec["kind"] in ("entity", "group", "campaign") and rec["closed_at"]):
                out.ended.extend((rec["closed_at"], h) for h in hosts)
        if (rec["outcome"] in CLOSED or rec["outcome"] == "excepted") and rec["outcome_at"]:
            # (an excepted closure carries the moment the exception began to cover all the host's evidence)
            for h in hosts:
                out.analyst[h] = max(out.analyst.get(h, 0.0), rec["outcome_at"])
    for ip, t in store.triage().items():
        if t.get("at"):
            out.analyst[ip] = max(out.analyst.get(ip, 0.0), t["at"])
    out.undecided = {h: frozenset(d) for h, d in undecided.items()}
    out.ended.sort()
    return out


class Holds(Mapping):
    """host -> Hold, made on demand: the board asks for the hosts it has, not for every host the log ever saw. The same
    rule as ever (see build): a host has a hold when the clock knows it, or when the verdicts shown in the step
    window reach Investigate, or when an analyst acted on it since its verdict last changed (a release, so the clock
    is not armed again)."""

    def __init__(self, win, clock: dict, analyst: dict, now: float, p: Params) -> None:
        self._win, self._clock, self._analyst, self._now = win, clock, analyst, now
        self._since = now - p["hysteresis.step_h"] * 3600
        self._step_s = p["hysteresis.step_h"] * 3600
        self._made: dict[str, ev.Hold | None] = {}

    def _make(self, ip: str) -> ev.Hold | None:
        win, c = self._win, self._clock.get(ip)
        in_log = ip in win.last
        if not in_log and c is None:
            return None
        a = self._analyst.get(ip, 0.0)
        changed = win.changed.get(ip) or 0.0
        trail = win.trail(ip, self._since) if in_log else ()
        shown = max((r for t, r in trail if t > a), default=-1)
        act = float((c or {}).get("act") or 0)
        if act and self._now - act < self._step_s:
            shown = max(shown, ev.VRANK["act"])       # the clock saw it Act now within the step
        released = bool(a and a > changed and in_log)
        if shown < ev.VRANK["investigate"] and c is None and not released:
            return None                               # nothing to hold it at
        return ev.Hold(changed_at=changed, analyst_at=a, shown=shown, armed=c is not None and a <= act, act_at=act,
                       evid_at=float((c or {}).get("evid") or 0), trail=trail)

    def __getitem__(self, ip: str) -> ev.Hold:
        if ip not in self._made:
            self._made[ip] = self._make(ip)
        h = self._made[ip]
        if h is None:
            raise KeyError(ip)
        return h

    def __iter__(self):
        for ip in sorted({*self._win.last, *self._clock}):
            if ip in self:
                yield ip

    def __len__(self) -> int:
        return sum(1 for _ in self)

    def __contains__(self, ip: object) -> bool:
        try:
            self[ip]
        except KeyError:
            return False
        return True


def _day_start(now: float) -> float:
    return now - now % 86400


def build(store, now: float, p: Params = FACTORY, *, product: str = "triage") -> ev.Memory:
    """The Memory of the board at `now`. The reduction of the stored incidents, statuses and verdict log is cached in
    the store until the next write that can change it (Store.decision_gen) and for the board's UTC day: the same
    store, day and time give the same Memory. What depends on `now` alone (the recurrence window, the step window of
    the hysteresis, the 72 h clock) is worked out here from the cached facts, on demand."""
    day = _day_start(now)
    lookback = max(LOOKBACK_DAYS, p["recurrence.days"])
    gen = store.decision_gen
    facts = store.memoized(("facts", product, day, lookback), gen, lambda: _facts(store, day - lookback * 86400, product))
    step_s = p["hysteresis.step_h"] * 3600
    win = store.verdict_window(day - step_s, product)
    recent = now - p["recurrence.days"] * 86400
    recurring: dict[str, int] = defaultdict(int)
    for _t, h in facts.ended[bisect.bisect_left(facts.ended, (recent, "")):]:
        recurring[h] += 1
    return ev.Memory(undecided=facts.undecided, recurring=dict(recurring),
                     holds=Holds(win, load_clock(store), facts.analyst, now, p))


def update_clock(store, board: ev.Board, memory: ev.Memory, now: float, p: Params = FACTORY) -> None:
    """Keep the 72 h clock of the hosts that were Act now: armed when a host is Act now on the evidence, its last
    evidence at Review or above noted while it lasts, dropped when an analyst has acted or 72 h passed with nothing
    above Watch. Written at most every CLOCK_WRITE_S per host, and only when something changed."""
    old = load_clock(store)
    new = {ip: dict(c) for ip, c in old.items()}
    hold_s = p["hysteresis.act_hold_h"] * 3600
    for ip, e in board.entities.items():
        raw = ev.VRANK.get(e.raw_verdict or e.verdict, 0)
        c = new.get(ip)
        h = memory.holds.get(ip)
        if h is not None and max(h.analyst_at, e.excepted_at) > h.changed_at:
            new.pop(ip, None)    # an analyst has acted (or an exception took the evidence): the hold is over (an Act now
            continue             # after a new change arms it again)
        if raw >= ev.VRANK["act"]:
            if c is None or now - c.get("evid", 0) >= CLOCK_WRITE_S:
                new[ip] = {"act": now, "evid": now}
        elif c is not None:
            if raw >= ev.VRANK["review"]:
                if now - c.get("evid", 0) >= CLOCK_WRITE_S:
                    c["evid"] = now
            elif now - c.get("evid", 0) >= hold_s:
                del new[ip]
    for ip in list(new):
        if ip not in board.entities and now - new[ip].get("evid", 0) >= hold_s:
            del new[ip]
    if new != old:
        store.meta(CLOCK_KEY, json.dumps(new, sort_keys=True, separators=(",", ":")))
