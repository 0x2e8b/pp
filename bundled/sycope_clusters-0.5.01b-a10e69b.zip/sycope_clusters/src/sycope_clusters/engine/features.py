"""Per-cluster feature computation: severity, MITRE, killchain, diversity, burstiness."""

import json
import math
from collections.abc import Container
from datetime import datetime, timezone
from pathlib import Path

import polars as pl

from .clusters_def import (
    DEFAULT_DETECTION_CONFIDENCE,
    DETECTION_CONFIDENCE,
    TACTIC_WEIGHTS,
)
from .mitre import PHASE_NAMES, TACTIC_PHASE, progression_score

# Kill-chain phase name -> index (Recon=0 .. Objectives=3)
PHASE_INDEX: dict[str, int] = {name: i for i, name in enumerate(PHASE_NAMES)}

# Severity multiplier used by Maciej's model (math2.md)
SEVERITY_MULTIPLIER: dict[str, float] = {
    "Info": 0.1,
    "Low": 0.5,
    "Medium": 0.6,
    "High": 0.8,
    "Critical": 1.0,
}

SEVERITY_WEIGHTS: dict[str, int] = {
    "Critical": 5,
    "High": 4,
    "Medium": 3,
    "Low": 2,
    "Info": 1,
}
WEIGHT_TO_SEVERITY: dict[int, str] = {v: k for k, v in SEVERITY_WEIGHTS.items()}


def _join(
    cluster_alerts: pl.DataFrame, alerts: pl.DataFrame, *cols: str
) -> pl.DataFrame:
    return cluster_alerts.join(alerts.select("alert_id", *cols), on="alert_id")


def _wcols(alerts: pl.DataFrame, *cols: str) -> list[str]:
    # deviation from alert_cluster: a `_w` column (one row stands for that many alerts, a finding bucket) is
    # carried along; the counting features below weight by it. Without it every row counts once, as before.
    return [*cols, *(["_w"] if "_w" in alerts.columns else [])]


def add_severity_features(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
) -> pl.DataFrame:
    j = _join(cluster_alerts, alerts, *_wcols(alerts, "Alert Severity"))
    weight = pl.col("Alert Severity").replace_strict(
        SEVERITY_WEIGHTS, default=0, return_dtype=pl.Int64
    )
    if "_w" in j.columns:     # deviation from alert_cluster: counts, sum and mean over alerts, not rows
        w = pl.col("_w")

        def count(sev: str) -> pl.Expr:
            return ((pl.col("Alert Severity") == sev).cast(pl.Int64) * w).sum()

        total, mean = (weight * w).sum(), (weight * w).sum() / w.sum()
    else:
        def count(sev: str) -> pl.Expr:
            return (pl.col("Alert Severity") == sev).sum()

        total, mean = weight.sum(), weight.mean()
    sev = (
        j.group_by("cluster_id")
        .agg(
            weight.max().alias("max_w"),
            total.alias("severity_score_sum"),
            mean.alias("severity_score_mean"),
            count("Critical").alias("sev_critical"),
            count("High").alias("sev_high"),
            count("Medium").alias("sev_medium"),
            count("Low").alias("sev_low"),
            count("Info").alias("sev_info"),
        )
        .with_columns(
            pl.col("max_w")
            .replace_strict(WEIGHT_TO_SEVERITY, default=None, return_dtype=pl.Utf8)
            .alias("severity_max")
        )
        .drop("max_w")
    )
    return clusters.join(sev, on="cluster_id", how="left")


def add_mitre_features(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
) -> pl.DataFrame:
    j = _join(cluster_alerts, alerts, "Mitre Tactic", "Mitre Technique")
    mit = j.group_by("cluster_id").agg(
        pl.col("Mitre Tactic").n_unique().alias("n_tactics"),
        pl.col("Mitre Technique").n_unique().alias("n_techniques"),
        pl.col("Mitre Tactic").unique().sort().alias("tactics"),
        pl.col("Mitre Technique").unique().sort().alias("techniques"),
    )
    return clusters.join(mit, on="cluster_id", how="left")


def add_killchain_score(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
) -> pl.DataFrame:
    j = (
        _join(cluster_alerts, alerts, "Mitre Tactic", "Time")
        .with_columns(
            pl.col("Mitre Tactic")
            .replace_strict(TACTIC_PHASE, default=None, return_dtype=pl.Int32)
            .alias("phase_idx")
        )
        .filter(pl.col("phase_idx").is_not_null())
        # sycope_clusters: alert_id breaks ties. alert_cluster sorts by Time only and polars' sort is not
        # stable, so alerts of the same minute came in a random order and the score changed between runs.
        .sort("cluster_id", "Time", "alert_id")
    )
    per_cluster = j.group_by("cluster_id", maintain_order=True).agg(
        pl.col("phase_idx").alias("phase_indices"),
        pl.col("phase_idx").max().alias("_max_phase"),
    )
    phase_lookup = dict(enumerate(PHASE_NAMES))
    scored = per_cluster.with_columns(
        pl.col("phase_indices")
        .map_elements(
            lambda s: progression_score(s.to_list()), return_dtype=pl.Float64
        )
        .alias("killchain_progression_score"),
        pl.col("_max_phase")
        .replace_strict(phase_lookup, default=None, return_dtype=pl.Utf8)
        .alias("highest_phase"),
    ).select("cluster_id", "killchain_progression_score", "highest_phase")
    return clusters.join(scored, on="cluster_id", how="left")


def _shannon_entropy_bits(names: list[str], weights: list[int] | None = None) -> float:
    if not names:
        return 0.0
    counts: dict[str, int] = {}
    for i, n in enumerate(names):     # deviation from alert_cluster: a row can stand for several alerts
        counts[n] = counts.get(n, 0) + (weights[i] if weights else 1)
    total = sum(counts.values())
    h = 0.0
    for c in counts.values():
        p = c / total
        if p > 0.0:
            h -= p * math.log2(p)
    return h


def add_diversity_features(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
) -> pl.DataFrame:
    j = _join(cluster_alerts, alerts, *_wcols(alerts, "Alert Name"))
    weighted = "_w" in j.columns
    aggs = [pl.col("Alert Name").n_unique().alias("n_alert_types"), pl.col("Alert Name").alias("_names")]
    if weighted:
        aggs.append(pl.col("_w").alias("_ws"))
        entropy = pl.struct("_names", "_ws").map_elements(
            lambda r: _shannon_entropy_bits(r["_names"], r["_ws"]), return_dtype=pl.Float64)
    else:
        entropy = pl.col("_names").map_elements(
            lambda s: _shannon_entropy_bits(s.to_list()), return_dtype=pl.Float64)
    div = (
        j.group_by("cluster_id")
        .agg(*aggs)
        .with_columns(entropy.alias("alert_type_entropy"))
        .drop("_names", *(["_ws"] if weighted else []))
    )
    return clusters.join(div, on="cluster_id", how="left")


def add_threat_certainty_scores(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
    now: datetime | None = None,
) -> pl.DataFrame:
    """Compute Impact Score (0-100) and Certainty Score (0-100) per cluster.

    Impact Score = severity_mean_normalized * tactic_weight * recency_boost
    Certainty Score = detection_confidence * volume_factor * diversity_factor
    Both clamped to [0, 100].
    """
    if now is None:
        # Use last alert time in dataset as reference to avoid datetime.now() issues.
        now = alerts["Time"].max().replace(tzinfo=timezone.utc)

    now_ts = now.timestamp() * 1000  # milliseconds

    needed_cols = _wcols(alerts, "alert_id", "Alert Severity", "Mitre Tactic", "Time")
    rule_type_col = "Rule Type" if "Rule Type" in alerts.columns else None
    if rule_type_col:
        needed_cols.append(rule_type_col)

    j = cluster_alerts.join(alerts.select(*needed_cols), on="alert_id", how="left")

    # Per cluster: gather what we need for scoring.
    sev_w = pl.col("Alert Severity").replace_strict(SEVERITY_WEIGHTS, default=0, return_dtype=pl.Float64)
    if "_w" in j.columns:     # deviation from alert_cluster: the mean and the volume count alerts, not rows
        sev_mean, volume = (sev_w * pl.col("_w")).sum() / pl.col("_w").sum(), pl.col("_w").sum()
    else:
        sev_mean, volume = sev_w.mean(), pl.len()
    agg_exprs = [
        sev_mean.alias("_sev_mean"),
        pl.col("Mitre Tactic").drop_nulls().alias("_tactics"),
        pl.col("Time").max().alias("_last_alert_time"),
        volume.alias("_alert_count"),
    ]
    weighted_type = bool(rule_type_col) and "_w" in j.columns
    if rule_type_col and not weighted_type:
        agg_exprs.append(pl.col(rule_type_col).mode().first().alias("_rule_type"))

    per_cluster = j.group_by("cluster_id").agg(agg_exprs)
    if weighted_type:
        # deviation from alert_cluster: the most common rule type counts alerts (the weights), not rows
        top = (j.group_by("cluster_id", rule_type_col).agg(pl.col("_w").sum().alias("_n"))
               .sort(["cluster_id", "_n", rule_type_col], descending=[False, True, False])
               .unique("cluster_id", keep="first", maintain_order=True)
               .select("cluster_id", pl.col(rule_type_col).cast(pl.Utf8).alias("_rule_type")))
        per_cluster = per_cluster.join(top, on="cluster_id", how="left")

    scores = []
    for row in per_cluster.iter_rows(named=True):
        # --- Impact Score ---
        # Base: severity mean normalized to 0-100 (Critical=100, High=80, Med=60, Low=40, Info=20)
        sev_norm = (row["_sev_mean"] / 5.0) * 100.0

        tactics = row["_tactics"] if row["_tactics"] else []
        # tactic_weight additive bonus: max(weights)-1.0 added as up to +30 pts
        tactic_w = max((TACTIC_WEIGHTS.get(t, 0.8) for t in tactics), default=0.8)
        tactic_bonus = (tactic_w - 1.0) * 30.0  # e.g. Exfil: +15, C2: +9, Recon: -6

        last_ms = row["_last_alert_time"]
        if last_ms is not None:
            last_ts = last_ms.timestamp() if hasattr(last_ms, "timestamp") else float(last_ms) / 1000
            now_sec = now_ts / 1000
            age_h = (now_sec - last_ts) / 3600
        else:
            age_h = 999.0
        if age_h < 4:
            recency_bonus = 10.0
        elif age_h < 24:
            recency_bonus = 5.0
        elif age_h < 72:
            recency_bonus = 0.0
        else:
            recency_bonus = -10.0

        threat = min(100.0, max(0.0, sev_norm + tactic_bonus + recency_bonus))

        # --- Certainty Score ---
        rule_type = row.get("_rule_type") or "Security"
        base_conf = DETECTION_CONFIDENCE.get(rule_type, DEFAULT_DETECTION_CONFIDENCE)

        n = row["_alert_count"]
        # volume: log scale, +10 per order of magnitude, max +25
        volume_bonus = min(25.0, math.log1p(n) * 4.0)

        n_unique_tactics = len(set(tactics)) if tactics else 0
        if n_unique_tactics >= 3:
            diversity_bonus = 15.0
        elif n_unique_tactics == 2:
            diversity_bonus = 8.0
        else:
            diversity_bonus = 0.0

        certainty = min(100.0, max(0.0, base_conf + volume_bonus + diversity_bonus))

        scores.append({
            "cluster_id": row["cluster_id"],
            "impact_score": round(threat, 1),
            "certainty_score": round(certainty, 1),
        })

    scores_df = pl.DataFrame(scores, schema={
        "cluster_id": pl.Utf8,
        "impact_score": pl.Float64,
        "certainty_score": pl.Float64,
    })
    return clusters.join(scores_df, on="cluster_id", how="left")


def _load_critical_config(config_path: Path | None) -> tuple[set[str], dict]:
    """Load critical-host list and chain-rule map from JSON. Missing file = empty."""
    if config_path is None:
        config_path = Path(__file__).parent / "critical_hosts.json"
    if not config_path.exists():
        return set(), {}
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    return set(cfg.get("critical_hosts", [])), cfg.get("chain_rules", {})


def add_threat_score(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
    config_path: Path | None = None,
    critical: Container[str] | None = None,
) -> pl.DataFrame:
    """Compute Pawel + Maciej scoring models and the blended Threat Score.

    Both models (math2.md / math3.md) share these components per cluster:
      - phase_idx        : highest_phase mapped to 0..3
      - critical_host    : 1 if anchor_ip in critical_hosts.json else 0
      - sigma_sev        : sum of max-severity-weight per unique alert type
      - progression      : killchain_progression_score (null -> 0)
      - sev_mult         : severity_max mapped to Maciej's multiplier

    Pawel  = phase*1e4 + crit*5000 + min(sigma_sev*30,1999) + min(prog*999,999)
    Maciej = phase*1e4*sev_mult + crit*6000 + sigma_sev*200 + prog*1500

    chain_bonus (multiplier) is a v2 slot - in v1 every cluster gets 1.0,
    so phase isolation holds (no context jumps a lower phase over Impact).

    Both raw models are min-max normalized to 0-100 across the cluster set,
    then averaged: threat_score = (pawel_norm + maciej_norm) / 2.
    Adds columns: sigma_sev, critical_host, chain_bonus, pawel_score,
    maciej_score, pawel_norm, maciej_norm, threat_score.
    """
    critical_hosts, chain_rules = _load_critical_config(config_path)
    if critical is not None:     # the caller's crown jewels (the triage database) replace the file's list
        critical_hosts = critical

    # sigma_sev = sum over unique alert types of that type's max severity weight
    j = _join(cluster_alerts, alerts, "Alert Name", "Alert Severity")
    sev_w = pl.col("Alert Severity").replace_strict(
        SEVERITY_WEIGHTS, default=0, return_dtype=pl.Int64
    )
    sigma = (
        j.with_columns(sev_w.alias("_sw"))
        .group_by("cluster_id", "Alert Name")
        .agg(pl.col("_sw").max().alias("_type_max"))
        .group_by("cluster_id")
        .agg(pl.col("_type_max").sum().alias("sigma_sev"))
    )

    work = clusters.join(sigma, on="cluster_id", how="left").with_columns(
        pl.col("sigma_sev").fill_null(0),
    )

    rows = []
    for r in work.iter_rows(named=True):
        phase_idx = PHASE_INDEX.get(r["highest_phase"], 0)
        crit = 1 if r["anchor_ip"] in critical_hosts else 0
        sigma_sev = float(r["sigma_sev"] or 0)
        prog = float(r["killchain_progression_score"] or 0.0)
        sev_mult = SEVERITY_MULTIPLIER.get(r["severity_max"], 0.0)

        # v1: chain_bonus always 1.0 (slot reserved for CR-01..09 multipliers).
        rule = chain_rules.get(r["anchor_ip"])
        chain_bonus = float(rule["bonus"]) if rule else 1.0

        pawel = (
            phase_idx * 10000
            + crit * 5000
            + min(sigma_sev * 30, 1999)
            + min(prog * 999, 999)
        ) * chain_bonus

        maciej = (
            phase_idx * 10000 * sev_mult
            + crit * 6000
            + sigma_sev * 200
            + prog * 1500
        ) * chain_bonus

        rows.append({
            "cluster_id": r["cluster_id"],
            "critical_host": crit,
            "chain_bonus": chain_bonus,
            "pawel_score": round(pawel, 1),
            "maciej_score": round(maciej, 1),
        })

    scores = pl.DataFrame(rows, schema={
        "cluster_id": pl.Utf8,
        "critical_host": pl.Int64,
        "chain_bonus": pl.Float64,
        "pawel_score": pl.Float64,
        "maciej_score": pl.Float64,
    })

    def _norm(col: str) -> pl.Expr:
        lo = pl.col(col).min()
        hi = pl.col(col).max()
        return (
            pl.when(hi == lo)
            .then(pl.lit(0.0))
            .otherwise((pl.col(col) - lo) / (hi - lo) * 100.0)
        )

    scores = scores.with_columns(
        _norm("pawel_score").alias("pawel_norm"),
        _norm("maciej_score").alias("maciej_norm"),
    ).with_columns(
        ((pl.col("pawel_norm") + pl.col("maciej_norm")) / 2.0)
        .round(1)
        .alias("threat_score"),
        pl.col("pawel_norm").round(1),
        pl.col("maciej_norm").round(1),
    )

    return clusters.join(scores, on="cluster_id", how="left")


def add_burstiness_features(
    clusters: pl.DataFrame,
    cluster_alerts: pl.DataFrame,
    alerts: pl.DataFrame,
) -> pl.DataFrame:
    j = _join(cluster_alerts, alerts, "Time").sort("cluster_id", "Time", "alert_id")

    gaps = j.with_columns(
        pl.col("Time").diff().over("cluster_id").dt.total_seconds().alias("gap_s")
    ).filter(pl.col("gap_s").is_not_null())

    gap_stats = gaps.group_by("cluster_id").agg(
        pl.col("gap_s").mean().alias("mean_gap_s"),
        pl.col("gap_s").max().alias("max_gap_s"),
        pl.col("gap_s").std(ddof=0).alias("std_gap_s"),
    ).with_columns(
        pl.when((pl.col("mean_gap_s") + pl.col("std_gap_s")) == 0)
        .then(None)
        .otherwise(
            (pl.col("std_gap_s") - pl.col("mean_gap_s"))
            / (pl.col("std_gap_s") + pl.col("mean_gap_s"))
        )
        .alias("burstiness")
    )

    # Peak alerts-per-minute: at each alert time, count alerts in the
    # preceding 60s window within the same cluster; take the cluster max.
    peak = (
        j.rolling(index_column="Time", period="1m", group_by="cluster_id")
        .agg(pl.len().alias("window_count"))
        .group_by("cluster_id")
        .agg(pl.col("window_count").max().alias("alerts_per_minute_peak"))
    )

    bf = gap_stats.join(peak, on="cluster_id", how="left")
    return clusters.join(bf, on="cluster_id", how="left")
