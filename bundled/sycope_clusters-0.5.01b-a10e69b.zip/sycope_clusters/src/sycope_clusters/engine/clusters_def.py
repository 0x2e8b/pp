"""Sycope Security cluster definitions: CL-01..CL-09 semantic mapping.

Maps alert names to cluster types based on the approved 9-cluster architecture.
"""

from sycope_clusters.aliases import extend

# Alert name -> cluster type ID
ALERT_CLUSTER_MAP: dict[str, str] = {
    # CL-01: Threat Intel Contact
    "Suspicious IP - Malicious": "CL-01",
    "Suspicious IP - TOR": "CL-01",
    "Suspicious IP - Proxy": "CL-01",
    "Suspicious IP - Phishing": "CL-01",
    "Suspicious IP - Spam": "CL-01",
    "Suspicious IP - Sycope Community": "CL-01",
    "Suspicious IP - Cryptomining": "CL-01",
    "Suspicious IP - Scanner": "CL-01",
    "Suspicious IP - Open DNS": "CL-01",
    "Suspicious Domain - DNS": "CL-01",
    "Suspicious Domain - HTTP": "CL-01",
    "Suspicious JA3": "CL-01",
    # CL-02: C2 Beacon Pattern
    "Repeated Connection": "CL-02",
    "Small Payload Beaconing": "CL-02",
    "Long-Duration Session": "CL-02",
    "Frequent Short-Lived Connections": "CL-02",
    "IRC Traffic": "CL-02",
    "C2 Polling": "CL-02",
    # CL-03: Non-Standard Communication
    "Suspicious Port - Allowlist": "CL-03",
    "Suspicious Port - Blocklist": "CL-03",
    "Protocol Mixing": "CL-03",
    "Proxy/SOCKS": "CL-03",
    "Cleartext Application": "CL-03",
    # CL-04: Scanning Activity
    "Horizontal Scan": "CL-04",
    "Vertical Scan": "CL-04",
    "High Connection Failure Rate": "CL-04",
    "Multiple Protocols Same Dest": "CL-04",
    "Excessive ICMP": "CL-04",
    "Potential Virus Outbreak": "CL-04",
    "Abnormal flows ratios": "CL-04",
    "Only SYN Client TCP Flag": "CL-04",
    "Only SYN Server TCP Flag": "CL-04",
    # CL-05: Credential Attack
    "Brute Force": "CL-05",
    "Brute Force Attack": "CL-05",
    "RDP Brute Force Slow": "CL-05",
    "SSH Brute Force Slow": "CL-05",
    "SSH Protocol Change": "CL-05",
    "LLMNR/NetBIOS": "CL-05",
    "Unauthorized LLMNR/NetBIOS Activity": "CL-05",
    "Kerberos External": "CL-05",
    "LDAP External": "CL-05",
    "Unauthorized RDP from/to the Internet": "CL-05",
    "Rogue RDP Access": "CL-05",
    # CL-06: Data Exfiltration
    "Large Data Upload": "CL-06",
    "Large Data Upload to External": "CL-06",
    "Abnormal Upload/Download Ratio": "CL-06",
    "Abnormal Upload/Download Ratio1": "CL-06",
    "FTP Exfil": "CL-06",
    "High Data Transfer": "CL-06",
    "High Data Transfer (Int<-> Ext)": "CL-06",
    "High Data Transfer (Int)": "CL-06",
    "Google Drive Upload": "CL-06",
    "Large Google Drive Upload Traffic": "CL-06",
    "SMB External": "CL-06",
    "DNS Transfer Limit": "CL-06",
    # CL-07: Baseline Deviation
    "Unexpected increase in number of bytes": "CL-07",
    "Unexpected decrease in number of bytes": "CL-07",
    "Unexpected increase in BPS": "CL-07",
    "Unexpected decrease in BPS": "CL-07",
    "Unexpected increase in PPS": "CL-07",
    "Unexpected decrease in PPS": "CL-07",
    "Unexpected increase in numbe of packets": "CL-07",
    "Unexpected decrease in number of packets": "CL-07",
    "Abnormal DNS Query Limit": "CL-07",
    "Abnormal DNS Response Limit": "CL-07",
    # CL-08: DDoS / Availability
    "DDoS Attack": "CL-08",
    "DNS Amplification": "CL-08",
    "Protocol Flood": "CL-08",
    "DoS": "CL-08",
    "SYN Flood": "CL-08",
    "DNS Reflection": "CL-08",
    "Botnet via DNS": "CL-08",
    "Botnet Attack via DNS": "CL-08",
    # CL-09: Asset Anomaly
    "Unknown Device": "CL-09",
    "Watch Device": "CL-09",
    "High IP Count": "CL-09",
    "IoT/OT Device Discovered": "CL-09",
    "IoT/OT Discovered": "CL-09",
    "IP Address Conflict": "CL-09",
    "APIPA": "CL-09",
    "Suspicious Host": "CL-09",

    # Compliance / Policy Violations (osobna kategoria, mapujemy tymczasowo)
    "Unauthorized DNS Activity": "COMPLIANCE",
    "Unauthorized DHCP Activity": "COMPLIANCE",
    "After-Hours Traffic": "COMPLIANCE",
    "P2P Activity": "COMPLIANCE",

    # Lateral Movement (przyszłe CL do zdefiniowania)
    "Possible Lateral Movement": "CL-05",
    "Frequent Short-Lived Connections": "CL-02",

    # sycope_clusters: names as the live Sycope (v3.x templates) writes them into the alerts stream,
    # mapped like their older spellings above. Not in alert_cluster; the System page lists any name
    # that still falls to UNKNOWN.
    "Suspicious SSH Protocol Change": "CL-05",
    "Suspicious Protocol Mixing": "CL-03",
    "Suspicious IP - User Lookup": "CL-01",
    "SMB Traffic to External Networks": "CL-06",
    "APIPA address assignment": "CL-09",
    "Unprotected Docker Daemon": "CL-04",
    "Unauthorized LDAP Activity": "COMPLIANCE",
    "Unauthorized NFS Export Data": "COMPLIANCE",

    # Sycope 3.3 templates (0.5.01b), grouped like the nearest rule above
    "Crypto Mining Pool Connection": "CL-02",
    "Web Shell Activity Pattern": "CL-05",
    "Database Port Exposed to Internet": "CL-04",
    "Telnet to External": "CL-03",
    "Email Worm": "CL-05",
    "NetBIOS/SMB Discovery": "CL-04",
    "Possible SPAM activity": "CL-08",
    "Large Size ICMP Packets": "CL-03",
    "Large Size TCP Packets": "CL-07",
    "Large Size UDP Packets": "CL-07",
    "Ingress from High-Risk Countries": "COMPLIANCE",
}
# the official names of the rules above that have a short one (aliases.py)
extend(ALERT_CLUSTER_MAP)

CLUSTER_LABELS: dict[str, str] = {
    "CL-01": "Threat Intel Contact",
    "CL-02": "C2 Beacon Pattern",
    "CL-03": "Non-Standard Communication",
    "CL-04": "Scanning Activity",
    "CL-05": "Credential Attack",
    "CL-06": "Data Exfiltration",
    "CL-07": "Baseline Deviation",
    "CL-08": "DDoS / Availability",
    "CL-09": "Asset Anomaly",
    "UNKNOWN": "Unclassified",
    "COMPLIANCE": "Policy Violation",
}

# Colors per cluster type for the HTML report
CLUSTER_COLORS: dict[str, str] = {
    "CL-01": "#7b2d8b",   # purple - threat intel
    "CL-02": "#c1121f",   # dark red - C2
    "CL-03": "#e07b00",   # orange - non-standard comms
    "CL-04": "#457b9d",   # steel blue - scanning
    "CL-05": "#e63946",   # red - credential attacks
    "CL-06": "#2d6a4f",   # dark green - exfiltration
    "CL-07": "#8d99ae",   # grey-blue - baseline
    "CL-08": "#1d3557",   # navy - DDoS
    "CL-09": "#606c38",   # olive - asset anomaly
    "UNKNOWN": "#bdbdbd",  # grey
    "COMPLIANCE": "#5c6bc0",  # indigo - policy violations
}

# Tactic weights for Threat Score calculation
TACTIC_WEIGHTS: dict[str, float] = {
    "Exfiltration": 1.5,
    "Command and Control": 1.3,
    "Lateral Movement": 1.3,
    "Credential Access": 1.2,
    "Initial Access": 1.0,
    "Execution": 1.0,
    "Persistence": 1.0,
    "Privilege Escalation": 1.0,
    "Defense Evasion": 0.9,
    "Discovery": 0.8,
    "Collection": 0.8,
    "Reconnaissance": 0.7,
    "Resource Development": 0.7,
    "Impact": 1.1,
}

# Base detection confidence per rule type
DETECTION_CONFIDENCE: dict[str, float] = {
    "Security": 70.0,
    "Anomaly": 50.0,
    "Threshold": 60.0,
    "Compliance": 80.0,
}

DEFAULT_DETECTION_CONFIDENCE = 60.0
