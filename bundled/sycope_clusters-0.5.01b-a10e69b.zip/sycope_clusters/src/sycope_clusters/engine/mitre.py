"""MITRE ATT&CK tactic → kill-chain phase mapping and progression scoring."""

# deviation from alert_cluster: the phases follow the Unified Kill Chain in four stages (Recon, Foothold, Lateral,
# Objectives) and Command and Control is a Foothold tactic (phase 1): a beacon proves a foothold, not an objective.
# alert_cluster has C2 in its phase 3 and calls the phases Pre-intrusion, Foothold, Maneuver, Impact.
TACTIC_PHASE: dict[str, int] = {
    # 0: Recon
    "Reconnaissance": 0,
    "Resource Development": 0,
    # 1: Foothold
    "Initial Access": 1,
    "Execution": 1,
    "Persistence": 1,
    "Privilege Escalation": 1,
    "Command and Control": 1,
    # 2: Lateral
    "Defense Evasion": 2,
    "Credential Access": 2,
    "Discovery": 2,
    "Lateral Movement": 2,
    "Collection": 2,
    # 3: Objectives
    "Exfiltration": 3,
    "Impact": 3,
}

PHASE_NAMES: list[str] = ["Recon", "Foothold", "Lateral", "Objectives"]


def progression_score(phase_indices_in_time_order: list[int]) -> float | None:
    """Fraction of ordered alert pairs (i before j in time) for which
    `phase_i <= phase_j`.

    Range [0, 1]; 1 = perfectly forward-ordered, ~0.5 = random, 0 = reversed.
    Ties (same phase repeated) count as concordant so repeats don't penalize.
    Returns None if fewer than 2 distinct phase indices are present.
    """
    indices = phase_indices_in_time_order
    if len(set(indices)) < 2:
        return None
    # Same count as the pairwise loop of alert_cluster/mitre.py, in one pass: phases are 0..3, so for each
    # alert j the earlier alerts i with phase_i <= phase_j are a prefix sum of the phase counts seen so far.
    # The O(n^2) loop took minutes on a live brute-force cluster of 60k alerts.
    n = len(indices)
    seen = [0] * (max(indices) + 1)
    concordant = 0
    for p in indices:
        concordant += sum(seen[: p + 1])
        seen[p] += 1
    return concordant / (n * (n - 1) // 2)
