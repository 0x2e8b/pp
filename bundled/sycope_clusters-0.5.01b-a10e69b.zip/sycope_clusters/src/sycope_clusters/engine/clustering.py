"""Per-anchor-IP, time-chained cluster builder.

A cluster is a chain of alerts that all mention the same anchor IP
(in either `Client IP` or `Server IP`) with consecutive alerts no more
than `dt` apart. Clusters are *not* merged transitively across anchors,
so the same alert can appear in multiple clusters (one per IP it mentions).
"""

from datetime import timedelta

import polars as pl

from .clusters_def import ALERT_CLUSTER_MAP, CLUSTER_LABELS


def _assign_cluster_type(alert_names: list[str]) -> tuple[str, str, list[str]]:
    """Return (cluster_type, cluster_label, secondary_types) for a list of alert names."""
    counts: dict[str, int] = {}
    for name in alert_names:
        ct = ALERT_CLUSTER_MAP.get(name, "UNKNOWN")
        counts[ct] = counts.get(ct, 0) + 1
    if not counts:
        return "UNKNOWN", CLUSTER_LABELS["UNKNOWN"], []
    dominant = max(counts, key=lambda k: counts[k])
    secondary = sorted(k for k in counts if k != dominant)
    return dominant, CLUSTER_LABELS.get(dominant, dominant), secondary


def build_clusters(
    df: pl.DataFrame,
    dt: timedelta = timedelta(hours=1),
    min_alerts: int = 2,
    anchor_cols: tuple[str, ...] = ("Client IP", "Server IP"),
    related: bool = True,
) -> tuple[pl.DataFrame, pl.DataFrame, pl.DataFrame]:
    """Return `(clusters, cluster_alerts, cluster_related_ips)`.

    - `clusters`: one row per cluster with `cluster_id, anchor_ip,
      start_time, end_time, duration_s, alert_count`.
    - `cluster_alerts`: long table `cluster_id, alert_id` linking each
      cluster to the underlying alert rows in `df`.
    - `cluster_related_ips`: long table `cluster_id, ip, occurrence_count`
      of every non-anchor IP appearing in the cluster's alerts.

    # deviation from alert_cluster: `anchor_cols` names the columns whose IPs anchor a cluster (default: both, as
    # before; sycope_clusters passes ("Actor IP",) so a victim gets none), and when `df` has a `_w` column (one row
    # stands for that many alerts: a finding bucket) `alert_count` and `min_alerts` count the weights. `related=False`
    # returns an empty related-IPs table: sycope_clusters lists a cluster's counterparts from its own frame, and at
    # 2M alerts the table costs about 180 MB of working memory.
    """
    dt_seconds = dt.total_seconds()

    # 1) IP <-> alert long table (one row per distinct IP per alert).
    weighted = "_w" in df.columns
    w = ["_w"] if weighted else []
    if len(anchor_cols) == 1:
        # deviation from alert_cluster: one anchor column gives one IP per alert, so the unpivot and the unique are
        # no-ops; skipping them saves about 180 MB of working memory on 1.2M rows
        ip_long = (
            df.select("alert_id", "Time", pl.col(anchor_cols[0]).alias("ip"), *w)
            .filter(pl.col("ip").is_not_null())
            .sort("ip", "Time")
        )
    else:
        ip_long = (
            df.select("alert_id", "Time", *anchor_cols, *w)
            .unpivot(
                index=["alert_id", "Time", *w],
                on=list(anchor_cols),
                variable_name="role",
                value_name="ip",
            )
            .filter(pl.col("ip").is_not_null())
            .unique(subset=["alert_id", "ip"])
            .drop("role")
            .sort("ip", "Time")
        )

    # 2) Per-IP chain detection: new chain whenever gap > dt.
    ip_long = (
        ip_long.with_columns(
            pl.col("Time").diff().over("ip").dt.total_seconds().alias("gap_s")
        )
        .with_columns(
            (pl.col("gap_s").is_null() | (pl.col("gap_s") > dt_seconds)).alias(
                "new_chain"
            )
        )
        .with_columns(
            pl.col("new_chain").cast(pl.Int32).cum_sum().over("ip").alias("chain_idx")
        )
    )

    # 3) Aggregate per (ip, chain_idx).
    chains = ip_long.group_by("ip", "chain_idx").agg(
        pl.col("alert_id").alias("alert_ids"),
        pl.col("Time").min().alias("start_time"),
        pl.col("Time").max().alias("end_time"),
        (pl.col("_w").sum() if weighted else pl.len()).alias("alert_count"),
    )

    # 4) Keep chains with enough alerts; assign stable cluster ids.
    clusters_base = (
        chains.filter(pl.col("alert_count") >= min_alerts)
        .sort("start_time", "ip")
        .with_row_index("idx")
        .with_columns(
            ("C_" + pl.col("idx").cast(pl.Utf8).str.zfill(6)).alias("cluster_id"),
            (pl.col("end_time") - pl.col("start_time"))
            .dt.total_seconds()
            .alias("duration_s"),
            pl.col("ip").alias("anchor_ip"),
        )
    )

    clusters = clusters_base.select(
        "cluster_id",
        "anchor_ip",
        "start_time",
        "end_time",
        "duration_s",
        "alert_count",
    )

    cluster_alerts = (
        clusters_base.select("cluster_id", "alert_ids")
        .explode("alert_ids")
        .rename({"alert_ids": "alert_id"})
    )

    # Assign semantic cluster types based on alert names.
    alert_names_by_cluster = (
        cluster_alerts
        .join(df.select("alert_id", "Alert Name"), on="alert_id", how="left")
        .group_by("cluster_id")
        .agg(pl.col("Alert Name").drop_nulls().alias("alert_names"))
    )

    type_rows = []
    for row in alert_names_by_cluster.iter_rows(named=True):
        ct, label, secondary = _assign_cluster_type(row["alert_names"])
        type_rows.append({
            "cluster_id": row["cluster_id"],
            "cluster_type": ct,
            "cluster_label": label,
            "secondary_types": secondary,
        })

    type_df = pl.DataFrame(
        type_rows,
        schema={
            "cluster_id": pl.Utf8,
            "cluster_type": pl.Utf8,
            "cluster_label": pl.Utf8,
            "secondary_types": pl.List(pl.Utf8),
        },
    )
    clusters = clusters.join(type_df, on="cluster_id", how="left")

    # 5) Related IPs: every non-anchor IP in the cluster's alerts.
    if not related:
        empty = pl.DataFrame(schema={"cluster_id": pl.Utf8, "ip": pl.Utf8, "occurrence_count": pl.UInt32})
        return clusters, cluster_alerts, empty
    anchor_lookup = clusters_base.select("cluster_id", "anchor_ip")
    cluster_related_ips = (
        cluster_alerts.join(anchor_lookup, on="cluster_id")
        .join(df.select("alert_id", "Client IP", "Server IP"), on="alert_id")
        .unpivot(
            index=["cluster_id", "anchor_ip"],
            on=["Client IP", "Server IP"],
            variable_name="role",
            value_name="ip",
        )
        .filter(pl.col("ip").is_not_null())
        .filter(pl.col("ip") != pl.col("anchor_ip"))
        .group_by("cluster_id", "ip")
        .len()
        .rename({"len": "occurrence_count"})
        .sort("cluster_id", "occurrence_count", descending=[False, True])
    )

    return clusters, cluster_alerts, cluster_related_ips
