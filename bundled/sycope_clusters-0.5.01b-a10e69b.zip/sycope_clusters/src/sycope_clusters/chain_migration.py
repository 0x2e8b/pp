"""One-time renumbering of the chain rules in the state database (0.5.01b).

The chain rule ids were renumbered so that the number is the display order, CR-01 the most severe. A state database
written by an earlier release holds the old ids in many places (incident chains and snapshots, story keys, step ids,
audit lines, the stored configuration). `run` rewrites them once, at Store open, guarded by the `meta` key
`chain_ids` = "2"; the rewrite is not idempotent (CR-01 -> CR-05 -> ...), so the guard is what keeps it single.

The old numbering was the same in Triage and Clusters except for CR-05: in Triage it was the 24 h full kill chain
(now CR-02), in Clusters the 168 h one (now CR-03). Rows of the Clusters product and the cluster_* tables use the
Clusters map, everything else the Triage map. The old Clusters CR-06 (worm propagation) is CR-07 in both.

A rewrite is a single pass over the text with a lookup, never one replace after another. Lists that are kept in id
order (a chain list, a story key joined with "+", a sorted fingerprint) are put in the new id order again.
"""

from __future__ import annotations

import json
import re
import sqlite3

TRIAGE = {"01": "05", "02": "01", "03": "08", "04": "09", "05": "02", "05w": "03", "06": "07", "07": "04", "08": "10"}
CLUSTERS = {**TRIAGE, "05": "03"}
_ID = re.compile(r"(?<![A-Za-z0-9])(CR-|cr)(\d\d)(w?)(?![A-Za-z0-9])")
_CR_ONLY = re.compile(r"CR-\d\d")
# the titles as of 0.5.01b: a stored chain object gets the title of its new id; old titles in stored text are renamed
TITLES = {"CR-01": "Data theft in progress", "CR-02": "Full kill chain (24 h)", "CR-03": "Full kill chain (7 days)",
          "CR-04": "Staged exfiltration", "CR-05": "Confirmed C2", "CR-06": "Compromised, then calling home",
          "CR-07": "Worm propagation", "CR-08": "Credential theft, then lateral movement",
          "CR-09": "Recon, then exploitation", "CR-10": "Persistent channel"}
_WEEK = re.compile(r"Kill chain across the week")
_FULL = re.compile(r"Full kill chain(?! \()")    # the old title of CR-05: 24 h in Triage, 7 days in Clusters
_PLUS_RUN = re.compile(r"(?<![A-Za-z0-9])C[LR]-\d\d(?:\+C[LR]-\d\d)+(?![A-Za-z0-9])")


def _sub(text: str, m: dict[str, str]) -> str:
    def one(mo: re.Match) -> str:
        new = m.get(mo.group(2) + mo.group(3))
        return mo.group(0) if new is None else mo.group(1) + new
    out = _ID.sub(one, text)
    out = _WEEK.sub(TITLES["CR-03"], out)
    out = _FULL.sub(TITLES["CR-03"] if m.get("05") == "03" else TITLES["CR-02"], out)
    if out != text:     # a story key lists its families and chains in id order
        out = _PLUS_RUN.sub(lambda mo: "+".join(sorted(mo.group(0).split("+"))), out)
    return out


def text(s: str | None, m: dict[str, str]) -> str | None:
    return _sub(s, m) if isinstance(s, str) and s else s


def value(o: object, m: dict[str, str]) -> object:
    """A JSON value with every chain id (in strings and in object keys) renumbered, and the lists that are kept in id
    order sorted again."""
    if isinstance(o, str):
        return _sub(o, m)
    if isinstance(o, dict):
        d = {_sub(k, m): value(v, m) for k, v in o.items()}
        if isinstance(d.get("id"), str) and d["id"] in TITLES and isinstance(d.get("title"), str):
            d["title"] = TITLES[d["id"]]
        return d
    if isinstance(o, list):
        new = [value(x, m) for x in o]
        if new == o:
            return o
        if o and all(isinstance(x, str) for x in o):
            if all(_CR_ONLY.fullmatch(x) for x in new) or o == sorted(o):
                return sorted(new)        # a chain list, or a sorted fingerprint of families and chains
        elif o and all(isinstance(x, dict) and isinstance(x.get("id"), str) and _CR_ONLY.fullmatch(x["id"])
                       for x in new):
            return sorted(new, key=lambda x: x["id"])
        elif o and all(isinstance(x, (list, tuple)) and x and isinstance(x[0], str) and _CR_ONLY.fullmatch(x[0])
                       for x in new):
            return sorted(new, key=lambda x: x[0])
        return new
    return o


def cell(s: str | None, m: dict[str, str], is_json: bool = False) -> str | None:
    """A stored cell renumbered: JSON when it parses as an object or a list, plain text otherwise."""
    if not isinstance(s, str) or not s:
        return s
    if is_json or s[:1] in "[{":
        try:
            o = json.loads(s)
        except ValueError:
            return _sub(s, m)
        if isinstance(o, (dict, list)):
            return json.dumps(value(o, m))
    return _sub(s, m)


# table -> its columns that can hold a chain id or a step id, as text or as JSON
_TABLES = {
    "incidents": ("subject label ui_key parent headline reason families chains identifiers resolution snapshot events "
                  "search outcome_note outcome_reason end_reason"),
    "verdict_log": "ip reason detail",
    "audit": "target note detail",
    "triage": "ip note fingerprint verdict owner reason",
    "exceptions": "rule actor reason decision_note",
    "cluster_triage": "key note reason owner",
}


def run(db: sqlite3.Connection) -> bool:
    """Renumber what the database holds, once. True when it ran. Call it with the connection in autocommit mode and
    the lock held; everything, the guard included, is one transaction."""
    if db.execute("SELECT v FROM meta WHERE k = 'chain_ids'").fetchone():
        return False
    have = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}

    def cols(table: str) -> set[str]:
        return {r[1] for r in db.execute(f"PRAGMA table_info({table})")}

    db.execute("BEGIN")
    try:
        product: dict[int, str] = {}
        if "incidents" in have:
            product = {i: p for i, p in db.execute("SELECT id, product FROM incidents") if p == "clusters"}
        for table, names in _TABLES.items():
            if table not in have:
                continue
            c = cols(table)
            use = [n for n in names.split() if n in c]
            if not use:
                continue
            clusters_table = table == "cluster_triage"
            sel = ", ".join(use) + (", product" if "product" in c else "")
            for row in db.execute(f"SELECT rowid, {sel} FROM {table}").fetchall():
                m = CLUSTERS if clusters_table or (len(row) > len(use) + 1 and row[-1] == "clusters") else TRIAGE
                new = [cell(v, m, n in ("families", "chains", "identifiers", "resolution", "snapshot", "events",
                                        "detail", "fingerprint")) for n, v in zip(use, row[1:1 + len(use)])]
                if new != list(row[1:1 + len(use)]):
                    db.execute(f"UPDATE {table} SET " + ", ".join(f"{n} = ?" for n in use) + " WHERE rowid = ?",
                               (*new, row[0]))
        for table, key, idcol in (("incident_steps", "step title", "incident_id"),
                                  ("incident_members", "entity", "incident_id")):
            if table not in have:
                continue
            use = key.split()
            for row in db.execute(f"SELECT rowid, {idcol}, {', '.join(use)} FROM {table}").fetchall():
                m = CLUSTERS if row[1] in product else TRIAGE
                new = [text(v, m) for v in row[2:]]
                if new != list(row[2:]):
                    db.execute(f"UPDATE {table} SET " + ", ".join(f"{n} = ?" for n in use) + " WHERE rowid = ?",
                               (*new, row[0]))
        if "config_versions" in have:
            for vid, body, note in db.execute("SELECT id, body, note FROM config_versions").fetchall():
                nb, nn = cell(body, TRIAGE, True), text(note, TRIAGE)
                if (nb, nn) != (body, note):
                    db.execute("UPDATE config_versions SET body = ?, note = ? WHERE id = ?", (nb, nn, vid))
        db.execute("INSERT OR REPLACE INTO meta VALUES ('chain_ids', '2')")
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
    return True
