"""What each Sycope alert means to the triage: its family, how much it proves, which kill-chain stage it can
confirm, and whose behaviour it describes.

The MITRE tactic of a template is a reporting tag ("this could be C2"), not proof that an attack got that far:
on the lab, "Suspicious Port - Allowlist" (tag C2) fires on 28% of all hosts and "IoT/OT Device Discovered"
(asset inventory) is tagged C2 too. So the stage a rule can confirm comes from this table, which the product
owns; the template tag is kept for MITRE coverage only. An alert name missing here falls back to its tactic as
weak evidence (class C) and is listed on the System page.

Classes (bits of evidence an alert of the rule can carry at most, before rarity and novelty cap it):
    A  indicator match (threat intel, known-bad JA3)      5
    B  attack behaviour (scan, brute force, lateral, ...)  3
    C  weak or ambiguous signal (anomaly, odd port)        1.5
    D  hygiene, asset or policy finding                    0   (never threat; goes to Hygiene)

Subject (whose finding it is):
    client  the client acts (default: scans, brute force, beacons, uploads)
    server  the server is the subject (a rogue DHCP server, an exposed Docker daemon, a discovered OT device)
    ti      threat intel: the internal side of a contact with a listed IP; inbound contacts make it a target
"""

from __future__ import annotations

import json
import threading
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path

from sycope_clusters import attack_map
from sycope_clusters.aliases import ALIASES
from sycope_clusters.params import factory

CLASS_BITS = {c: factory(f"class_bits.{c}") for c in "ABCD"}   # the factory values of the parameter registry
# The Unified Kill Chain in four stages (letters R F L O): a beacon or a listed C2 address proves a foothold, not an
# objective; Objectives are data out and floods. "Impact" is not a stage name (it is ATT&CK tactic TA0040).
STAGES = ("Recon", "Foothold", "Lateral", "Objectives")
STAGE_LETTERS = "".join(s[0] for s in STAGES)
OBJECTIVES = len(STAGES) - 1
# Threat-intel rules whose listed address is a command-and-control infrastructure (they moved from stage 3 to 1 with
# the beacons); Phishing is an initial-access lure and was always stage 1. They are the factory value of the `c2` flag
# of a rule, which an administrator can set on any threat-intel rule (the config plane's catalog field `c2`). With the
# CL-02 and CL-03 families they make a finding "C2-type": the evidence that kept its Act now / Investigate verdict
# when C2 left the top stage (see Rule.c2_type and evidence.verdict).
_C2_TI_SHORT = {"Suspicious IP - Malicious", "Suspicious IP - Sycope Community", "Suspicious IP - Cryptomining",
                "Suspicious Domain - DNS", "Suspicious Domain - HTTP", "Suspicious JA3", "Botnet via DNS",
                "Botnet Attack via DNS"}
C2_TI = frozenset(_C2_TI_SHORT | {o for o, s in ALIASES.items() if s in _C2_TI_SHORT})

# family -> (label, one line for the analyst, colour on the dark background)
FAMILIES: dict[str, tuple[str, str, str]] = {
    "CL-01": ("Threat intel contact", "Talks to an IP or domain on a threat list", "#b45bd6"),
    "CL-02": ("C2 channel", "Beacons, long sessions and IRC: a persistent channel out, like malware calling home", "#ff5d5d"),
    "CL-03": ("Covert channel", "TOR, proxies, protocol tricks: traffic that hides what it is", "#ff8f6b"),
    "CL-04": ("Scanning / discovery", "Maps the network: many hosts or many ports", "#4aa3ff"),
    "CL-05": ("Credential attack", "Brute force and other attempts to get credentials", "#ff4f79"),
    "CL-06": ("Data exfiltration", "Large uploads out of the network", "#3ecf72"),
    "CL-07": ("Traffic anomaly", "Unusual volume or timing; weak alone", "#97a1ba"),
    "CL-08": ("DDoS / flood", "Floods and amplification", "#00bff8"),
    "CL-09": ("Asset change", "New, unknown or misconfigured devices", "#b5c25a"),
    "CL-10": ("Lateral movement", "Spreads to other internal hosts over admin protocols", "#ffb020"),
    "CL-11": ("Remote access / exposure", "RDP or an exposed service reached across the internet edge", "#e88cff"),
    "CL-12": ("Internal staging", "Collects large amounts of data from internal hosts", "#2fc0a0"),
    "HYG": ("Port & protocol hygiene", "Cleartext protocols and ports outside the allowlist", "#8c9eff"),
    "POL": ("Policy violation", "Unauthorized services and traffic the policy forbids", "#7c86b8"),
    "UNK": ("Unclassified", "Alert name not in the rule catalog", "#808297"),
}


DIRECTIONS = ("inbound", "outbound", "internal")
VARIANT_FIELDS = ("family", "cls", "stage", "subject", "kind", "ti", "technique", "tactic")
# The fields a variant may change that do not reclassify the finding: an inbound variant of the others needs the internal
# server to have answered (see Rule.for_direction), these two are what the analyst reads and are shown whenever the
# direction is known.
ATTACK_FIELDS = ("technique", "tactic")


@dataclass(frozen=True)
class Variant:
    """What a rule means in one direction across the internet edge: only the fields it changes (`over`, a sorted
    tuple of (field, value), so a stage of None is a real override). A later field (technique, tactic) is one more
    pair, nothing else changes."""
    over: tuple = ()

    @classmethod
    def of(klass, **kw) -> Variant:
        return klass(tuple(sorted(kw.items())))

    def as_dict(self) -> dict:
        return dict(self.over)


@dataclass(frozen=True)
class Rule:
    name: str
    family: str
    cls: str
    stage: int | None
    subject: str = "client"
    kind: str = ""          # drives the narrative and the checks: ti, beacon, covert, scan, brute, cred, lateral,
    #                         remote, exfil, staging, anomaly, dos, asset, policy, port
    ti: str = ""            # threat-intel category shown to the analyst (Malicious, TOR, Phishing...)
    known: bool = True      # False = fell back to the template tactic
    rule_id: str = ""       # the template's alertRuleId when the template sheet names one
    variants: tuple = ()    # ((direction, Variant), ...): the rule across the internet edge (see for_direction)
    direction: str = ""     # the direction this rule was resolved for, "" when it is the base rule
    technique: str = ""     # our ATT&CK technique id for this rule (this direction), "" = none (see attack_map.py)
    tactic: str = ""        # its ATT&CK tactic name; with no technique it is a command-and-control address contact
    reclassified: bool = False   # resolved through a variant that changes family, class, stage, subject or kind (an
    #                         exposure, SMB going out): the finding says so; a variant of technique and tactic alone does not
    c2: bool = False        # a threat-intel rule whose listed address is a command-and-control one (CL-01 only; the
    #                         CL-02 and CL-03 families are C2-type by their family, see c2_type)

    @property
    def key(self) -> str:
        """The rule's identity in priors.json and the learned norms: its template id, else its name."""
        return self.rule_id or self.name

    @property
    def bits(self) -> float:
        return CLASS_BITS[self.cls]

    @property
    def hygiene(self) -> bool:
        return self.cls == "D"

    @property
    def c2_type(self) -> bool:
        """A command-and-control finding: a beacon, a covert channel or a contact with a listed C2 address (a threat
        intel rule marked `c2`; the mark counts only while the rule is in the threat-intel family)."""
        return self.family in ("CL-02", "CL-03") or (self.c2 and self.family == "CL-01")

    @property
    def attack(self) -> str:
        """The ATT&CK reading of this rule in its direction, for the analyst (attack_map.label)."""
        return attack_map.label(self.tactic, self.technique, self._why_none())

    @property
    def attack_key(self) -> str:
        """The same reading as one text for a frame column (attack_map.read_key)."""
        return attack_map.key(self.tactic, self.technique, self._why_none())

    def _why_none(self) -> str:
        return attack_map.why_none(known=self.known, family=self.family, cls=self.cls, kind=self.kind)

    def for_direction(self, direction: str, answered: bool = True) -> Rule:
        """The rule as it reads for a pair seen in `direction` (inbound, outbound or internal): the base rule with
        that variant's fields, the same name. A direction without a variant gives the rule itself. `answered` False
        (an inbound pair the internal server never answered): a variant that reclassifies the finding (an exposure)
        does not apply and the base rule stays, with no ATT&CK reading since nothing was exposed; a variant that
        only sets the technique and tactic applies, they describe what the outside host did."""
        return _variant(self, direction, answered)


@lru_cache(maxsize=4096)
def _variant(rule: Rule, direction: str, answered: bool = True) -> Rule:
    for d, v in rule.variants:
        if d == direction:
            over = v.as_dict()
            if not answered and any(k not in ATTACK_FIELDS for k in over):
                return replace(rule, technique="", tactic="")
            return replace(rule, variants=(), direction=d, reclassified=any(k not in ATTACK_FIELDS for k in over),
                           **over)
    return rule


def catalog_key(rule: Rule) -> str:
    """The key a rule has in priors.json and the learned norms: its template id when known, else its name."""
    return rule.key


def stored_rule(catalog: Catalog, name: str, rule_id: str | None = None) -> Rule:
    """The rule a stored day_findings row belongs to: by its name when the catalog knows the name, else by its template
    id (a template renamed in Sycope). Live ids differ from the template sheet, so an id alone can name another rule;
    a renamed template that also arrives with a colliding live id still lands on the wrong rule (the catalog view
    shows the live ids)."""
    return catalog.get(name, None, rule_id or None)


def _r(name, family, cls, stage, subject="client", kind="", ti=""):
    return Rule(name, family, cls, stage, subject, kind, ti)


_CATALOG = [
    # CL-01 threat intel: the listed IP is the bad side
    _r("Suspicious IP - Malicious", "CL-01", "A", 1, "ti", "ti", "Malicious"),
    _r("Suspicious IP - Sycope Community", "CL-01", "A", 1, "ti", "ti", "Sycope Community"),
    _r("Suspicious IP - Cryptomining", "CL-01", "A", 1, "ti", "ti", "Cryptomining"),
    _r("Suspicious IP - Phishing", "CL-01", "A", 1, "ti", "ti", "Phishing"),
    _r("Suspicious Domain - DNS", "CL-01", "A", 1, "ti", "ti", "Malicious domain"),
    _r("Suspicious Domain - HTTP", "CL-01", "A", 1, "ti", "ti", "Malicious domain"),
    _r("Suspicious JA3", "CL-01", "A", 1, "ti", "ti", "Known-bad TLS client"),
    _r("Botnet via DNS", "CL-01", "B", 1, "client", "ti", "Botnet domain"),
    _r("Botnet Attack via DNS", "CL-01", "B", 1, "client", "ti", "Botnet domain"),
    _r("Suspicious IP - Spam", "CL-01", "C", None, "ti", "ti", "Spam"),
    _r("Suspicious IP - Scanner", "CL-04", "C", 0, "ti", "ti", "Internet scanner"),
    _r("Suspicious IP - User Lookup", "CL-01", "C", None, "ti", "ti", "Customer list"),
    _r("Suspicious IP - Open DNS", "POL", "C", None, "ti", "policy", "Open resolver"),
    # CL-02 C2 beacons
    _r("Repeated Connection", "CL-02", "B", 1, kind="beacon"),
    _r("C2 Polling", "CL-02", "B", 1, kind="beacon"),
    _r("Small Payload Beaconing", "CL-02", "B", 1, kind="beacon"),
    _r("IRC Traffic", "CL-02", "B", 1, kind="beacon"),
    _r("Long-Duration Session", "CL-02", "C", 1, kind="beacon"),
    # CL-03 covert channels
    _r("Suspicious IP - TOR", "CL-03", "B", 1, "ti", "ti", "TOR"),
    _r("Suspicious IP - Proxy", "CL-03", "B", 1, "ti", "ti", "Anonymous proxy"),
    _r("Protocol Mixing", "CL-03", "B", 1, kind="covert"),
    _r("Suspicious Protocol Mixing", "CL-03", "B", 1, kind="covert"),
    _r("Proxy/SOCKS", "CL-03", "B", 1, kind="covert"),
    _r("Suspicious Port - Blocklist", "CL-03", "B", 1, kind="covert"),
    # SSH on a protocol other than TCP, twice in 10 minutes between one pair: an odd protocol and port pairing (T1571),
    # not a credential attack and not a man in the middle (the 1.1.2 mapping, CL-05 and T1557); weak alone
    _r("SSH Protocol Change", "CL-03", "C", 1, kind="covert"),
    _r("Suspicious SSH Protocol Change", "CL-03", "C", 1, kind="covert"),
    # CL-04 scanning
    _r("Horizontal Scan", "CL-04", "B", 2, kind="scan"),
    _r("Vertical Scan", "CL-04", "B", 2, kind="scan"),
    _r("Potential Virus Outbreak", "CL-04", "B", 2, kind="scan"),
    _r("High Connection Failure Rate", "CL-04", "C", 2, kind="scan"),
    _r("Multiple Protocols Same Dest", "CL-04", "C", 2, kind="scan"),
    _r("Excessive ICMP", "CL-04", "C", 2, kind="scan"),
    _r("Abnormal flows ratios", "CL-04", "C", 2, kind="scan"),
    _r("Only SYN Client TCP Flag", "CL-04", "C", 2, kind="scan"),
    _r("Only SYN Server TCP Flag", "CL-04", "C", 2, kind="scan"),
    # CL-05 credentials
    _r("Brute Force", "CL-05", "B", 2, kind="brute"),
    _r("Brute Force Attack", "CL-05", "B", 2, kind="brute"),
    _r("RDP Brute Force Slow", "CL-05", "B", 2, kind="brute"),
    _r("SSH Brute Force Slow", "CL-05", "B", 2, kind="brute"),
    _r("Kerberos External", "CL-05", "B", 2, kind="cred"),
    _r("LDAP External", "CL-05", "B", 2, kind="cred"),
    _r("LLMNR/NetBIOS", "CL-05", "C", 2, kind="cred"),
    _r("Unauthorized LLMNR/NetBIOS Activity", "CL-05", "C", 2, kind="cred"),
    # CL-10 lateral movement (was folded into CL-05: then CR-08 credential -> lateral could not be evaluated)
    _r("Possible Lateral Movement", "CL-10", "B", 2, kind="lateral"),
    _r("Rogue RDP Access", "CL-10", "B", 2, kind="lateral"),
    _r("Suspicious Host", "CL-10", "B", 2, kind="lateral"),
    # CL-11 remote access across the edge (outbound: the client acts; inbound: the internal server is exposed)
    _r("Unauthorized RDP from/to the Internet", "CL-11", "B", 2, kind="remote"),
    # CL-06 exfiltration: needs the upload to dominate, else it is a download anomaly (see evidence.py)
    _r("Large Data Upload", "CL-06", "B", 3, kind="exfil"),
    _r("Large Data Upload to External", "CL-06", "B", 3, kind="exfil"),
    _r("Abnormal Upload/Download Ratio", "CL-06", "B", 3, kind="exfil"),
    _r("Abnormal Upload/Download Ratio1", "CL-06", "B", 3, kind="exfil"),
    _r("FTP Exfil", "CL-06", "B", 3, kind="exfil"),
    _r("DNS Transfer Limit", "CL-06", "B", 3, kind="exfil"),
    _r("High Data Transfer", "CL-06", "C", 3, kind="exfil"),
    _r("High Data Transfer (Int<-> Ext)", "CL-06", "C", 3, kind="exfil"),
    _r("Google Drive Upload", "CL-06", "C", 3, kind="exfil"),
    _r("Large Google Drive Upload Traffic", "CL-06", "C", 3, kind="exfil"),
    _r("SMB External", "CL-06", "C", 3, kind="exfil"),
    _r("SMB Traffic to External Networks", "CL-06", "C", 3, kind="exfil"),
    # CL-12 internal staging
    _r("High Data Transfer (Int)", "CL-12", "C", 2, kind="staging"),
    _r("Data Staging Detection", "CL-12", "B", 2, kind="staging"),
    # CL-07 anomalies: weak, no stage
    _r("Unexpected increase in number of bytes", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected decrease in number of bytes", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected increase in BPS", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected decrease in BPS", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected increase in PPS", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected decrease in PPS", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected increase in numbe of packets", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected increase in number of packets", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected decrease in number of packets", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected increase in number of flows", "CL-07", "C", None, kind="anomaly"),
    _r("Unexpected decrease in number of flows", "CL-07", "C", None, kind="anomaly"),
    _r("Abnormal DNS Query Limit", "CL-07", "C", None, kind="anomaly"),
    _r("Abnormal DNS Response Limit", "CL-07", "C", None, kind="anomaly"),
    _r("After-Hours Traffic", "CL-07", "C", None, kind="anomaly"),
    # 1000 or more TCP sessions shorter than a second in 5 minutes: scanning or churn, not interval regularity
    _r("Frequent Short-Lived Connections", "CL-07", "C", None, kind="anomaly"),
    # CL-08 floods: an internal host sending them is a bot (Impact); received ones go to the target lane
    _r("DDoS Attack", "CL-08", "B", 3, kind="dos"),
    _r("DNS Amplification", "CL-08", "B", 3, kind="dos"),
    _r("DNS Reflection", "CL-08", "B", 3, kind="dos"),
    _r("Protocol Flood", "CL-08", "B", 3, kind="dos"),
    _r("DoS", "CL-08", "B", 3, kind="dos"),
    _r("SYN Flood", "CL-08", "B", 3, kind="dos"),
    # CL-09 asset changes: profile, never threat
    _r("Unknown Device", "CL-09", "D", None, kind="asset"),
    _r("Watch Device", "CL-09", "D", None, kind="asset"),
    _r("High IP Count", "CL-09", "D", None, kind="asset"),
    _r("IoT/OT Device Discovered", "CL-09", "D", None, "server", "asset"),
    _r("IoT/OT Discovered", "CL-09", "D", None, "server", "asset"),
    _r("IP Address Conflict", "CL-09", "D", None, kind="asset"),
    _r("APIPA", "CL-09", "D", None, kind="asset"),
    _r("APIPA address assignment", "CL-09", "D", None, kind="asset"),
    # hygiene
    _r("Suspicious Port - Allowlist", "HYG", "D", None, kind="port"),
    _r("Cleartext Application", "HYG", "D", None, kind="port"),
    # policy violations (the server is usually the unauthorized service)
    _r("Unauthorized DNS Activity", "POL", "D", None, "server", "policy"),
    _r("Unauthorized DHCP Activity", "POL", "D", None, "server", "policy"),
    _r("Unauthorized LDAP Activity", "POL", "D", None, "server", "policy"),
    _r("Unauthorized NFS Export Data", "POL", "D", None, "server", "policy"),
    _r("Unprotected Docker Daemon", "POL", "D", None, "server", "policy"),
    _r("P2P Activity", "POL", "D", None, kind="policy"),
    _r("Unauthorized Internet Access", "POL", "D", None, kind="policy"),
    _r("Cleartext Internal Traffic", "POL", "D", None, kind="policy"),
    _r("Multicast DNS from Internet", "POL", "D", None, "server", "policy"),
    # templates of Sycope 3.3 the catalog did not have (0.5.01b). Weak ones are class C: they add their bits and never
    # make a host Act now alone. A mining-pool port is port-only (the threat-intel variant, Suspicious IP -
    # Cryptomining, stays class A); a web shell or an exposed database port is a finding about the server side.
    _r("Crypto Mining Pool Connection", "CL-02", "C", 3, kind="beacon"),
    _r("Web Shell Activity Pattern", "CL-11", "B", 1, "server", "remote"),
    _r("Database Port Exposed to Internet", "CL-11", "B", 1, "client", "remote"),
    _r("Telnet to External", "CL-03", "C", 1, kind="covert"),
    _r("Email Worm", "CL-10", "C", 2, kind="lateral"),
    _r("NetBIOS/SMB Discovery", "CL-04", "C", 2, kind="scan"),
    # the sending host is the bot (Impact); mail received from outside is no finding about our host
    _r("Possible SPAM activity", "CL-08", "C", 3, kind="dos"),
    _r("Large Size ICMP Packets", "CL-03", "C", 1, kind="covert"),
    _r("Large Size TCP Packets", "CL-07", "C", None, kind="anomaly"),
    _r("Large Size UDP Packets", "CL-07", "C", None, kind="anomaly"),
    _r("Ingress from High-Risk Countries", "POL", "D", None, kind="policy"),
]
# the official names of rules that already have a short one (aliases.py): the same classification
_CATALOG += [replace(r, name=o) for o, s in ALIASES.items() for r in _CATALOG if r.name == s]

# Template name -> its alertRuleId(s), from sycope_alert_templates.xlsx (sheet "Alert Templates", columns "Alert
# Name" and "Rule ID"), for the catalog names that appear there verbatim. The first id is the rule's key; a template
# that exists twice in the sheet has both ids. Ids the sheet gives to two different templates identify neither and
# are left out: Discovery_010 (APIPA address assignment, Unauthorized Internet Access), Discovery_012 (Excessive ICMP
# Requests, Multicast DNS from Internet), Discovery_015 (High Connection Failure Rate, Unprotected Docker Daemon),
# Exfiltration_011 (Abnormal DNS Query Limit, Unexpected increase in BPS).
RULE_IDS: dict[str, tuple[str, ...]] = {
    'Abnormal DNS Response Limit': ('Exfiltration_006',),
    'Abnormal Upload/Download Ratio': ('Exfiltration_023', 'Exfiltration_102'),
    'Abnormal flows ratios': ('Discovery_009',),
    'Botnet Attack via DNS': ('Impact_041',),
    'Brute Force Attack': ('Credential Access_004',),
    'Cleartext Application': ('Command and Control_015',),
    'DDoS Attack': ('Impact_036',),
    'DNS Transfer Limit': ('Exfiltration_003',),
    'Data Staging Detection': ('Collection_003', 'Collection_101'),
    'Frequent Short-Lived Connections': ('Command and Control_040',),
    'High Connection Failure Rate': ('Discovery_101',),
    'High Data Transfer (Int)': ('Exfiltration_028',),
    'High Data Transfer (Int<-> Ext)': ('Exfiltration_029',),
    'Horizontal Scan': ('Reconnaissance_004',),
    'IP Address Conflict': ('Collection_002',),
    'IoT/OT Device Discovered': ('Command and Control_004',),
    'Large Data Upload to External': ('Exfiltration_024', 'Exfiltration_101'),
    'Large Google Drive Upload Traffic': ('Exfiltration_007',),
    'Long-Duration Session': ('Command and Control_045', 'CommandAndControl_101'),
    'P2P Activity': ('Initial Access_008',),
    'Possible Lateral Movement': ('Lateral Movement_008',),
    'Potential Virus Outbreak': ('Discovery_002',),
    'Rogue RDP Access': ('Lateral Movement_003',),
    'SMB Traffic to External Networks': ('Exfiltration_016',),
    'Suspicious Host': ('Lateral Movement_006',),
    'Suspicious IP - Cryptomining': ('Impact_035',),
    'Suspicious IP - Malicious': ('Command and Control_031',),
    'Suspicious IP - Open DNS': ('Command and Control_032',),
    'Suspicious IP - Phishing': ('Initial Access_006',),
    'Suspicious IP - Proxy': ('Command and Control_033',),
    'Suspicious IP - Scanner': ('Discovery_008',),
    'Suspicious IP - Spam': ('Initial Access_007',),
    'Suspicious IP - Sycope Community': ('Command and Control_029',),
    'Suspicious IP - TOR': ('Command and Control_034',),
    'Suspicious Port - Allowlist': ('Command and Control_016',),
    'Suspicious Port - Blocklist': ('Command and Control_011',),
    'Suspicious Protocol Mixing': ('Command and Control_041',),
    'Suspicious SSH Protocol Change': ('Credential Access_007',),
    'Unauthorized DHCP Activity': ('Discovery_022',),
    'Unauthorized DNS Activity': ('Discovery_023',),
    'Unauthorized LDAP Activity': ('Discovery_019',),
    'Unauthorized LLMNR/NetBIOS Activity': ('Credential Access_003',),
    'Unauthorized NFS Export Data': ('Discovery_020',),
    'Unauthorized RDP from/to the Internet': ('Lateral Movement_009',),
    'Unexpected decrease in number of bytes': ('Exfiltration_010',),
    'Unexpected increase in PPS': ('Exfiltration_015',),
    'Unexpected increase in numbe of packets': ('Exfiltration_012',),
    'Unexpected increase in number of bytes': ('Exfiltration_013',),
    'Unexpected increase in number of flows': ('Exfiltration_014',),
    'Vertical Scan': ('Reconnaissance_003',),
    # Sycope 3.3 names (0.5.01b): the official spelling of rules the catalog has under a short name (aliases.py), and
    # the templates the catalog did not have. Excessive ICMP Requests has none: its id Discovery_012 is the sheet's
    # for Multicast DNS from Internet too.
    'Crypto Mining Pool Connection': ('Impact_048', 'Impact_102'),
    'DDoS DNS Amplification Attack': ('Impact_037',),
    'DDoS Protocol Flood': ('Impact_038',),
    'Database Port Exposed to Internet': ('Initial Access_012', 'InitialAccess_101'),
    'DoS Attack': ('Impact_039',),
    'Email Worm': ('Command and Control_035',),
    'FTP Data Exfiltration': ('Exfiltration_025', 'Exfiltration_103'),
    'High IP Count on Device': ('Initial Access_009',),
    'IRC Traffic Detected': ('Command and Control_047', 'CommandAndControl_113'),
    'Ingress from High-Risk Countries': ('Command and Control_039',),
    'Kerberos Traffic to External': ('Credential Access_008', 'CredentialAccess_101'),
    'LDAP to External': ('Credential Access_009', 'CredentialAccess_102'),
    'Large Size ICMP Packets': ('Exfiltration_031',),
    'Large Size TCP Packets': ('Exfiltration_032',),
    'Large Size UDP Packets': ('Exfiltration_033',),
    'Multiple Protocols Same Destination': ('Discovery_014', 'Discovery_102'),
    'NetBIOS/SMB Discovery': ('Discovery_016', 'Discovery_103'),
    'Possible DNS Reflection Attack': ('Impact_047',),
    'Possible SPAM activity': ('Exfiltration_004',),
    'Proxy/SOCKS Traffic Detected': ('Command and Control_048', 'CommandAndControl_116'),
    'RDP Brute Force (Slow)': ('Credential Access_010', 'CredentialAccess_103'),
    'Repeated Connection (C2 Polling)': ('Command and Control_049', 'CommandAndControl_118'),
    'SSH Brute Force (Slow)': ('Credential Access_011', 'CredentialAccess_104'),
    'SYN Flood Attack': ('Impact_040',),
    'Suspicious Domain - Malware via DNS': ('Command and Control_012',),
    'Suspicious Domain - Malware via HTTP': ('Command and Control_013',),
    'Suspicious JA3 Fingerprint': ('Command and Control_014',),
    'Suspicious Small Payload Beaconing': ('Command and Control_046', 'CommandAndControl_105'),
    'Telnet to External': ('Lateral Movement_010', 'LateralMovement_101'),
    'Unknown Device Detected': ('Initial Access_011',),
    'Watch Device Detected': ('Initial Access_010',),
    'Web Shell Activity Pattern': ('Persistence_001', 'Persistence_101'),
}

# Rules that mean something else across the internet edge. Inbound applies only when the internal side answered (the
# exposure is real), outbound when an internal host reaches outside, internal (both sides ours) is the base rule.
# Protocols that must not cross the edge (LDAP, NFS, SMB) are hygiene inside and a finding at the edge.
_EXPOSURE = Variant.of(family="CL-11", cls="B", stage=1, subject="client", kind="exposure")
_VARIANTS: dict[str, tuple] = {
    "Unauthorized LDAP Activity": (
        ("outbound", Variant.of(family="CL-05", cls="B", stage=2, subject="client", kind="cred")),
        ("inbound", _EXPOSURE)),
    "Unauthorized NFS Export Data": (
        ("outbound", Variant.of(family="CL-06", cls="B", stage=3, subject="client", kind="exfil")),
        ("inbound", _EXPOSURE)),
    "SMB External": (("outbound", Variant.of(cls="B", stage=3)), ("inbound", _EXPOSURE)),
    "SMB Traffic to External Networks": (("outbound", Variant.of(cls="B", stage=3)), ("inbound", _EXPOSURE)),
    "Unprotected Docker Daemon": (("inbound", _EXPOSURE),),
    "Unauthorized RDP from/to the Internet": (
        ("inbound", Variant.of(family="CL-11", cls="B", stage=1, kind="remote")),
        ("outbound", Variant.of(family="POL", cls="D", stage=None, kind="policy"))),
    # the same port across the edge reads as the RDP rule does: exposed when answered, a policy finding going out
    "Rogue RDP Access": (
        ("inbound", Variant.of(family="CL-11", cls="B", stage=1, kind="remote")),
        ("outbound", Variant.of(family="POL", cls="D", stage=None, kind="policy"))),
}


def _with_attack(r: Rule, variants: tuple) -> tuple[Rule, tuple]:
    """The rule with its ATT&CK reading from attack_map.MAP, and its variants with the technique and tactic of each
    direction the table gives (a direction the table names and the rule has no variant for gets a variant of those
    two fields alone)."""
    spec = attack_map.MAP.get(r.name, {})
    tactic, technique = spec.get("base", attack_map.NONE)
    over = {d: v.as_dict() for d, v in variants}
    for d in DIRECTIONS:
        if d in spec:
            over.setdefault(d, {}).update(tactic=spec[d][0], technique=spec[d][1])
    return (replace(r, tactic=tactic, technique=technique),
            tuple((d, Variant.of(**over[d])) for d in DIRECTIONS if d in over))


def _factory_rule(r: Rule) -> Rule:
    if r.name in RULE_IDS:
        r = replace(r, rule_id=RULE_IDS[r.name][0])
    r = replace(r, c2=r.name in C2_TI or r.family in ("CL-02", "CL-03"))
    r, variants = _with_attack(r, _VARIANTS.get(r.name, ()))
    return replace(r, variants=variants) if variants else r


CATALOG: dict[str, Rule] = {r.name: _factory_rule(r) for r in _CATALOG}


def _duplicate_names(names) -> dict[str, str]:
    """Names that are another catalog name with a digit run glued to the end ("Abnormal Upload/Download Ratio1" beside
    "Abnormal Upload/Download Ratio"): the second is a copy of the template, shown under the first one's name."""
    have = set(names)
    out = {}
    for n in have:
        base = n.rstrip("0123456789")
        if base != n and base in have:
            out[n] = base
    return out


DISPLAY_NAMES: dict[str, str] = _duplicate_names(CATALOG)


def display_name(name: str) -> str:
    """The rule name as the analyst reads it (the raw name goes in a tooltip). Only a real duplicate is cleaned:
    "Suspicious JA3" keeps its 3."""
    return DISPLAY_NAMES.get(name, name)

# Template tactic -> fallback family and the stage it would claim (shown as suspected only: class C).
_TACTIC_FALLBACK = {
    "Reconnaissance": ("CL-04", 0, "scan"), "Resource Development": ("CL-04", 0, "scan"),
    "Initial Access": ("CL-01", 1, ""), "Execution": ("CL-07", 1, ""), "Persistence": ("CL-02", 1, "beacon"),
    "Privilege Escalation": ("CL-05", 1, "cred"), "Defense Evasion": ("CL-03", 2, "covert"),
    "Credential Access": ("CL-05", 2, "cred"), "Discovery": ("CL-04", 2, "scan"),
    "Lateral Movement": ("CL-10", 2, "lateral"), "Collection": ("CL-12", 2, "staging"),
    "Command and Control": ("CL-02", 1, "beacon"), "Exfiltration": ("CL-06", 3, "exfil"),
    "Impact": ("CL-08", 3, "dos"),
}


def entry_errors(o: dict) -> list[str]:
    """What is wrong with the values of one catalog entry (family, class, stage, subject, kind, ti, technique, tactic,
    c2); the messages
    do not name the rule. The configuration's validation and the Catalog both use it, so they agree."""
    errs = []
    if "family" in o and not (isinstance(o["family"], str) and o["family"] in FAMILIES):
        errs.append(f"family must be one of {', '.join(FAMILIES)}")
    for f in ("class", "cls"):
        if f in o and not (isinstance(o[f], str) and o[f] in CLASS_BITS):
            errs.append(f"{f} must be one of {', '.join(CLASS_BITS)}")
    if "stage" in o and not (o["stage"] is None or (isinstance(o["stage"], int) and not isinstance(o["stage"], bool)
                                                     and o["stage"] in (0, 1, 2, 3))):
        errs.append("stage must be 0, 1, 2, 3 or null")
    if "subject" in o and not (isinstance(o["subject"], str) and o["subject"] in ("client", "server", "ti")):
        errs.append("subject must be client, server or ti")
    for f in ("kind", "ti"):
        if f in o and not isinstance(o[f], str):
            errs.append(f"{f} must be text")
    if "technique" in o and not (isinstance(o["technique"], str)
                                 and (o["technique"] == "" or attack_map.ID_FORMAT.match(o["technique"]))):
        errs.append("technique must be an ATT&CK id such as T1133 or T1021.001, or empty for none")
    if "tactic" in o and not (isinstance(o["tactic"], str) and (o["tactic"] == "" or o["tactic"] in attack_map.TACTICS)):
        errs.append(f"tactic must be one of {', '.join(attack_map.TACTICS)}, or empty for none")
    if "c2" in o and not isinstance(o["c2"], bool):
        errs.append("c2 must be true or false")
    if "variants" in o:
        vs = o["variants"]
        if not isinstance(vs, dict):
            errs.append("variants must be an object of inbound, outbound or internal entries")
        else:
            for d in sorted(vs, key=str):
                if d not in DIRECTIONS:
                    errs.append(f"variants: direction must be one of {', '.join(DIRECTIONS)}")
                elif not isinstance(vs[d], dict):
                    errs.append(f"variants {d}: must be an object")
                else:
                    errs += [f"variants {d}: {m}" for m in entry_errors(
                        {k: v for k, v in vs[d].items() if k != "variants"})]
                    errs += [f"variants {d}: unknown field {k}" for k in sorted(set(vs[d]) - {*VARIANT_FIELDS, "class"})]
    return errs


def _factory_ids() -> dict[str, str]:
    """Template id -> name of the factory rule that owns it."""
    ids: dict[str, str] = {}
    for name, r in CATALOG.items():
        if r.rule_id:
            ids.setdefault(r.rule_id, name)
    for name in CATALOG:
        for rid in RULE_IDS.get(name, ()):
            ids.setdefault(rid, name)
    return ids


LIVE_IDS_KEPT = 8      # other template ids remembered per catalog entry (for the catalog view)


class Catalog:
    """The rule table plus two layers of overrides, with a memo for names seen live. `overrides` is the operator's
    SC_RULES_FILE (source "env"), `admin` the active configuration's catalog (source "admin"); the admin's entry
    for a rule replaces the file's. An entry is keyed by the template's id or by the rule's name; an id the template
    sheet gives a factory rule names that rule. An alert is matched by its name first, then by its template id
    (alertRuleId), so a renamed template keeps its entry. An entry whose values are not allowed is ignored, and the
    layer below it stays in force."""

    def __init__(self, overrides: dict[str, dict] | None = None, admin: dict[str, dict] | None = None) -> None:
        self.rules = dict(CATALOG)
        self._src: dict[str, str] = {}
        factory_ids = _factory_ids()
        applied: dict[str, dict] = {}
        for src, layer in (("env", overrides), ("admin", admin)):
            entries: dict[str, dict] = {}
            for key in sorted(layer or {}, key=str):
                o = layer[key]
                if isinstance(o, dict) and not entry_errors(o):
                    entries[factory_ids.get(key) or key] = o
            for name, o in entries.items():
                base = CATALOG.get(name) or Rule(name, "UNK", "C", None)
                kw = {k: o[k] for k in ("family", "cls", "stage", "subject", "kind", "ti", "technique", "tactic", "c2")
                      if k in o}
                if "class" in o:
                    kw["cls"] = o["class"]
                if isinstance(o.get("rule_id"), str):
                    kw["rule_id"] = o["rule_id"].strip()
                if "variants" in o:     # the operator's variants replace the shipped ones ({} clears them)
                    kw["variants"] = tuple((d, Variant.of(**{("cls" if k == "class" else k): v
                                                             for k, v in o["variants"][d].items()}))
                                           for d in DIRECTIONS if d in o["variants"])
                self.rules[name] = replace(base, **kw, known=True)
                self._src[name] = src
                applied[name] = o
        # template id -> entry: an operator's id first, then each entry's own, then the sheet's other ids, then the
        # key of an entry that no factory rule owns (the admin named an unknown rule by its id or name)
        self.by_id: dict[str, str] = {}
        given = [n for n, o in applied.items() if isinstance(o.get("rule_id"), str)]
        for name in (*given, *self.rules):
            if self.rules[name].rule_id:
                self.by_id.setdefault(self.rules[name].rule_id, name)
        for rid, name in factory_ids.items():
            self.by_id.setdefault(rid, name)
        for name in self._src:
            if name not in CATALOG:
                self.by_id.setdefault(name, name)
        self._ids_of: dict[str, frozenset[str]] = {}       # entry -> the template ids the catalog knows it by
        for rid, name in self.by_id.items():
            self._ids_of[name] = self._ids_of.get(name, frozenset()) | {rid}
        self._live: dict[str, set[str]] = {}               # entry -> other ids its alerts arrived with
        self._lock = threading.Lock()
        self._memo: dict[tuple, Rule] = {}
        self._seen: dict[str, int] = {}

    def get(self, name: str | None, tactic: str | None = None, rule_id: str | None = None) -> Rule:
        """The rule of an alert: by its own name when the catalog (any layer) has it, by its template id only when
        the name is unknown (a template renamed in Sycope), else a fallback from its tactic. The name comes first
        because Sycope numbers its templates differently from the template sheet RULE_IDS comes from: on the lab,
        Cleartext Application (hygiene) arrives as Command and Control_041, the sheet's id of Suspicious Protocol
        Mixing (CL-03, stage 3), so matching the id first made hygiene and policy findings C2."""
        rule = self.rules.get(name) if name else None
        if rule is not None:
            if rule_id and rule_id not in self._ids_of.get(name, ()):
                self._note_live_id(name, rule_id)
            return rule
        if rule_id:
            hit = self.by_id.get(rule_id)
            if hit is not None:
                return self.rules[hit]
        key = (name, tactic)
        hit = self._memo.get(key)
        if hit is None:
            fam, stage, kind = _TACTIC_FALLBACK.get(tactic or "", ("UNK", None, ""))
            hit = Rule(name or "?", fam, "C", stage, "client", kind, "", known=False)
            with self._lock:
                hit = self._memo.setdefault(key, hit)
        return hit

    def _note_live_id(self, name: str, rule_id: str) -> None:
        ids = self._live.get(name)
        if ids is not None and (rule_id in ids or len(ids) >= LIVE_IDS_KEPT):
            return
        with self._lock:
            self._live.setdefault(name, set()).add(rule_id)

    def live_ids(self) -> dict[str, list[str]]:
        """Entry name -> the template ids its alerts arrived with that the catalog does not know it by (Sycope numbers
        templates differently from the sheet RULE_IDS comes from). Seen since this catalog was built; a copy."""
        with self._lock:
            return {n: sorted(ids) for n, ids in sorted(self._live.items())}

    def source(self, key: str) -> str:
        """Where the rule behind `key` (its template id or its name) comes from: factory, env (SC_RULES_FILE), admin,
        or fallback (not in the catalog: scored from its tactic as class C)."""
        name = self.by_id.get(key, key)
        if name not in self.rules:
            return "fallback"
        return self._src.get(name, "factory")

    def rows(self) -> list[dict]:
        """Every rule known (factory, SC_RULES_FILE and the administrator's), sorted by key: {"key", "name",
        "rule_id", "family", "class", "stage", "subject", "kind", "ti", "technique", "tactic", "c2", "attack" (our
        ATT&CK reading as text), "variants" ({direction: the fields it changes}), "source"}."""
        out = [{"key": r.key, "name": name, "rule_id": r.rule_id, "family": r.family, "class": r.cls,
                "stage": r.stage, "subject": r.subject, "kind": r.kind, "ti": r.ti, "technique": r.technique,
                "tactic": r.tactic, "c2": r.c2, "attack": r.attack,
                "variants": {d: {("class" if k == "cls" else k): v for k, v in x.as_dict().items()}
                             for d, x in r.variants}, "source": self._src.get(name, "factory")} for name, r in self.rules.items()]
        return sorted(out, key=lambda x: (x["key"], x["name"]))

    def seen(self, key: str, n: int) -> None:
        """How many alerts of the rule `key` the last build counted. Only rules that fell back are kept: they are
        the queue an admin works through. The count is the last window's, not a running total."""
        if key not in self.rules and key not in self.by_id:
            with self._lock:
                self._seen[key] = int(n)

    def unknown(self) -> list[str]:
        with self._lock:
            return sorted({r.name for r in self._memo.values()})

    def unknown_rows(self) -> list[dict]:
        """The rules that fell back to their tactic, most alerts first: {"key", "name", "tactic", "seen"}. A copy,
        safe to read while the poller builds."""
        with self._lock:
            memo, seen = sorted(self._memo, key=lambda k: (str(k[0]), str(k[1]))), dict(self._seen)
        rows: dict[str, dict] = {}
        for name, tactic in memo:
            key = name or "?"
            rows.setdefault(key, {"key": key, "name": key, "tactic": tactic, "seen": seen.get(key, 0)})
        return sorted(rows.values(), key=lambda r: (-r["seen"], r["key"]))


def read_overrides(path: str | None) -> dict[str, dict]:
    """The overrides of a JSON file {"rules": {"Alert name": {"family": "CL-05", "class": "B", "stage": 2,
    "subject": "client"}}}. A missing or broken file means no overrides."""
    if not path:
        return {}
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    rules = data.get("rules") if isinstance(data, dict) else None
    return rules if isinstance(rules, dict) else {}


def load(path: str | None) -> Catalog:
    """The catalog with the overrides of a JSON file (see read_overrides)."""
    return Catalog(read_overrides(path))
