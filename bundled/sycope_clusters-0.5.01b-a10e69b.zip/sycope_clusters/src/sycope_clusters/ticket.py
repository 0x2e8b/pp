"""The ticket text of an incident: the plain-text summary a person pastes into a ticket, chat or e-mail ("Copy as
ticket"), and the `ticket` field of an outbound webhook (notify.py).

One builder, here. The pages no longer assemble the text in JavaScript: /host, /story and /campaign carry it as `ticket`
and the button copies that, so the copy and the webhook cannot drift apart. It reads the same detail payloads the pages
read (triage.host_detail, story_detail, campaign_detail, with `steps` and `priority` added by the route).

Times are in the configured UTC offset (`calendar.utc_offset_min`) and always carry the date (YYYY-MM-DD HH:MM): a ticket
is read later, unlike a list on screen. Links to this service are relative unless SC_BASE_HREF is set (the Passthrough address); the page
turns a relative one into an absolute one when it copies.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta, timezone
from urllib.parse import quote

from sycope_clusters import fmt
from sycope_clusters.rules import FAMILIES, STAGES, display_name

VL = {"act": "Act now", "investigate": "Investigate", "review": "Review", "watch": "Watch"}
STW = {"investigating": "In progress", "escalated": "Escalated", "ack": "Seen", "tp": "Closed: true positive",
       "benign": "Closed: benign", "fp": "Closed: false positive", "resolved": "Resolved"}
_IPRE = re.compile(r"^[0-9A-Fa-f:.]{2,45}$")
_NAMERE = re.compile(r'^[^"\\]{1,200}$')
DASH = "-"
DOT = "·"


@dataclass(frozen=True)
class Ctx:
    """What the text depends on besides the incident: `now` and the offset (the times), the Sycope address for links
    into Sycope ("" = none) and the address the pages are opened at ("" = relative links)."""
    now: float = 0.0
    offset_min: int = 0
    sycope_ui: str = ""
    base: str = ""

    def link(self, rel: str) -> str:
        return f"{self.base.rstrip('/')}/{rel}" if self.base else rel


# ---- formatting ---------------------------------------------------------------------------------------------------

def pc(x) -> str:
    """A confidence as a percentage ("<1%" under one, "99%" from 99.5)."""
    if x is None:
        return ""
    return ("99" if x >= 0.995 else "<1" if 0 < x < 0.01 else str(int(x * 100 + 0.5))) + "%"


num = fmt.num


def raw_name(rule: str) -> str:
    """The rule name for a ticket: cleaned, with Sycope's own name kept when it differs (an analyst searches Sycope by it)."""
    clean = display_name(rule)
    return clean if clean == rule else f"{clean} (Sycope: {rule})"


def fam(k: str) -> str:
    return FAMILIES.get(k, (k,))[0]


hp = fmt.plural


def ltime(ms, ctx: Ctx) -> str:
    """A time in a ticket: always the full date, YYYY-MM-DD HH:MM, in the configured offset (a ticket is read later;
    "today" on its own would be ambiguous)."""
    return fmt.tm(ms / 1000, 0, ctx.offset_min, "dt")


def span(first, last, ctx: Ctx) -> str:
    """"start - end" for a span of a minute or more (the end is a time of day when the span is under a day), else the
    one time."""
    a = ltime(first, ctx)
    if last is None or last - first <= 60000:
        return a
    if last - first < 86400000:
        b = datetime.fromtimestamp(last / 1000 + ctx.offset_min * 60, UTC).strftime("%H:%M")
    else:
        b = ltime(last, ctx)
    return f"{a} {DASH} {b}"


def zone(ctx: Ctx) -> str:
    return fmt.zone(ctx.offset_min)


def _table(head: list[str], rows: list[list]) -> str:
    last = len(head) - 1
    w = [min(42, max([len(h), *(len(str(r[i] if r[i] is not None else "")) for r in rows)])) for i, h in enumerate(head)]
    out = []
    for r in [head, *rows]:
        cells = []
        for i, c in enumerate(r):
            c = str(c if c is not None else "")
            cells.append(c[:100] if i == last else c[:42].ljust(w[i]))
        out.append("  ".join(cells).rstrip())
    return "\n".join(out)


def _steps(st: dict | None, lines: list[str], ctx: Ctx) -> None:
    lst = (st or {}).get("list") or []
    done = (st or {}).get("done") or {}
    acts = [s for s in lst if s.get("kind") == "act"]
    rest = [s for s in lst if s.get("kind") != "act"]
    if acts:
        lines += ["", "RECOMMENDED ACTIONS (once a check confirms the attack)"]
        lines += [f"{i}. {s['title']}" for i, s in enumerate(acts, 1)]
    if rest:
        lines += ["", "WHAT TO CHECK"]
        for s in rest:
            d = done.get(s.get("id")) or {}
            ok = bool(d.get("done"))
            lines.append(f"[{'x' if ok else ' '}] {s['title']}"
                         + (f" (checked by {d.get('who')}, {ltime(d['at'] * 1000, ctx)})" if ok else ""))


def _links(lines: list[str], items: list[tuple[str, str]]) -> None:
    ok = [x for x in items if x[1]]
    if ok:
        lines += ["", "LINKS", *(f"{k}: {v}" for k, v in ok)]


def _iso_off(ms: float, off_min: int) -> str:
    d = datetime.fromtimestamp(ms / 1000, timezone(timedelta(minutes=off_min)))
    sign, o = ("+" if off_min >= 0 else "-"), abs(off_min)
    return d.strftime("%Y-%m-%dT%H:%M:%S") + f"{sign}{o // 60:02d}:{o % 60:02d}"


def _gq(source: str, nql: str, frm: float, to: float, ctx: Ctx) -> str:
    gq = {"query": {"source": source, "nql": nql, "advanced": False},
          "timerange": {"from": _iso_off(frm, ctx.offset_min), "to": _iso_off(to, ctx.offset_min), "roundTo": "minute"}}
    return quote(json.dumps(gq, separators=(",", ":")), safe="-_.!~*'()")


def raw_url(nql: str, frm: float, to: float, ctx: Ctx) -> str:
    return f"{ctx.sycope_ui}/panel/raw-data/list?source=netflow&gq={_gq('netflow', nql, frm, to, ctx)}&direction=-1&groupType=all"


def alerts_url(nql: str, frm: float, to: float, ctx: Ctx) -> str:
    return f"{ctx.sycope_ui}/panel/alerts?source=alerts&gq={_gq('alerts', nql, frm, to, ctx)}"


def host_rel(ip: str) -> str:
    return "incident?ip=" + quote(ip, safe="-_.!~*'()")


def story_rel(key: str) -> str:
    return "incident?story=" + quote(key, safe="-_.!~*'()")


def campaign_rel(net: str) -> str:
    return "incident?campaign=" + quote(net, safe="-_.!~*'()")


def history_rel(iid: int) -> str:
    return f"incident?history={iid}"


def _owner(t: dict | None) -> str | None:
    if t and not t.get("changed") and t.get("status") in ("investigating", "escalated") and t.get("owner"):
        return t["owner"]
    return None


# ---- a host ---------------------------------------------------------------------------------------------------------

def host_text(D: dict, ctx: Ctx) -> str:
    """The ticket of a host page payload (triage.host_detail with `steps` and `priority`)."""
    a, t = D.get("actor"), D.get("triage")
    P = D.get("priority") or ("P4", "Review", "")
    ip = D["ip"]
    L = [f"[{P[0]}] " + (a["headline"] if a else f"Host {ip}"),
         f"Host: {ip}" + (f" ({D['name']})" if D.get("name") else "") + (f" {DOT} {D['net']}" if D.get("net") else "")
         + (f" {DOT} crown jewel" if D.get("crown") else ""),
         f"Priority: {P[0]} ({P[1]})" + (f" {DOT} confidence {pc(a['conf'])}" if a else "")
         + f" {DOT} from Sycope Security Triage"]
    if a:
        L.append(f"Why: {a['reason']}")
    if t and not t.get("changed"):
        L.append(f"Status: {STW.get(t['status'], t['status'])}" + (f", {_owner(t)}" if _owner(t) else "")
                 + f" {DOT} set by {t.get('who') or '?'} {ltime(t['at'] * 1000, ctx)}"
                 + (f" ({t['reason']})" if t.get("reason") else ""))
    _steps(D.get("steps"), L, ctx)
    if a:
        rows = [[f.get("client") or "-", f.get("server") or "-", f.get("port") or "-", raw_name(f["rule"]),
                 span(f["first"], f["last"], ctx), f.get("asn") or ""]
                for f in [f for f in a["trace"] if f["counted"] or f["bits"] >= 1][:15]]
        if rows:
            L += ["", f"INDICATORS (times {zone(ctx)})",
                  _table(["Client", "Server", "Port", "Alert", "When", "Network"], rows)]
        ext: dict[str, str] = {}
        for f in a["trace"]:
            if f.get("cp") and f.get("asn") and f["bits"] >= 1 and f["cp"] not in ext:
                ext[f["cp"]] = f["asn"] + (f", {f['ti']}" if f.get("ti") else "")
        if ext:
            L += ["", "OUTSIDE ADDRESSES", *(f"- {k} ({v})" for k, v in list(ext.items())[:10])]
    tg = D.get("target")
    if tg:
        L.append(f"Also targeted by {hp(tg.get('attackers_total', 0), 'host')}"
                 + (f" (threat intel: {', '.join(tg['ti'])})" if tg.get("ti") else ""))
    notes = [x for x in (D.get("timeline") or []) if x.get("kind") == "action" and x.get("note")
             and not str(x.get("action") or "").startswith("step:")][:6]
    if notes:
        L += ["", "NOTES", *(f"- {ltime(x['at'] * 1000, ctx)} {x['who']}: {x['note']}" for x in notes)]
    link = [("Incident page", ctx.link(host_rel(ip)))]
    if ctx.sycope_ui and a and _IPRE.match(ip):
        link += [("Alerts in Sycope", alerts_url(f'clientIp = "{ip}" or serverIp = "{ip}"', a["first"] - 60000,
                                                 a["last"] + 120000, ctx)),
                 ("Flows in Sycope", raw_url(f'clientIp = "{ip}"', a["first"] - 300000, a["last"] + 60000, ctx))]
    _links(L, link)
    if a:
        L += ["", "-- Technical appendix (for the security team) --", f"Verdict {VL[a['verdict']]}: {a['reason']}"]
        for s in a["narrative"]:
            L.append(f"- {ltime(s['t'], ctx)}  {s['text']}  [{s['label']}"
                     + (f", {STAGES[s['stage']]}" if s.get("stage") is not None else "")
                     + f", {num(s['bits'], 1)} bits" + (", new" if s.get("new") else "") + "]"
                     + (f" ({s['note']})" if s.get("note") else ""))
        if a["background"]:
            L.append("Background: " + "; ".join(f"{raw_name(b['rule'])} x{b['n']}" for b in a["background"][:3]))
        L.append(f"Evidence {num(a['E'], 1)} bits = "
                 + " + ".join(f"{num(f['bits'], 1)} {f['label']}" for f in a["families"])
                 + (" + chains " + ", ".join(c["id"] for c in a["chains"]) if a["chains"] else "")
                 + f" -> confidence {pc(a['conf'])}, risk {num(a['risk'], 3)}")
        L.append(f"Window: {ltime(a['first'], ctx)} - {ltime(a['last'], ctx)} {DOT} {hp(a['alerts'], 'alert')} {DOT} "
                 f"{hp(a['findings'], 'finding')}")
    return "\n".join(L)


# ---- a group of hosts or a campaign ---------------------------------------------------------------------------------

def group_text(D: dict, camp: bool, ctx: Ctx) -> str:
    """The ticket of a story (group incident) or a campaign payload (triage.story_detail / campaign_detail with
    `steps` and `priority`)."""
    hs = D["hosts"] if camp else D["members"]
    P = D.get("priority") or ("P4", "Review", "")
    L = [f"[{P[0]}] " + (D["title"] if camp else f"Incident: {D['title']}") + f" {DOT} {hp(D['count'], 'host')}",
         (f"Priority: {P[0]} ({P[1]}) {DOT} confidence up to {pc(D['conf'])} {DOT} {num(D['open'])} open, "
          f"{num(D['handled'])} handled {DOT} from Sycope Security Triage"),
         ("Families: " if camp else "Pattern: ") + ", ".join(fam(k) for k in D["families"])
         + (" " + DOT + " chain rules: " + "; ".join(c["title"] for c in D["chain_words"])
            if D.get("chain_words") else ""),
         f"Window: {ltime(D['first'], ctx)} - {ltime(D['last'], ctx)} ({zone(ctx)})"]
    _steps(D.get("steps"), L, ctx)
    L += ["", f"HOSTS ({num(len(hs))})",
          _table(["Host", "Name", "Verdict", "Confidence", "What happened"],
                 [[m["ip"], m.get("name") or "", VL.get(m["verdict"], m["verdict"]), pc(m.get("conf")),
                   str(m.get("path") or m.get("headline") or "")[:70]] for m in hs[:40]])]
    if len(hs) > 40:
        L.append(f"... and {num(len(hs) - 40)} more on the incident page")
    if not camp and D.get("common_targets"):
        L += ["", "MOST HIT COUNTERPARTS", ", ".join(f"{t[0]} x{t[1]}" for t in D["common_targets"])]
    if not camp and D.get("outside"):
        L += ["", "OUTSIDE ADDRESSES"]
        for o in D["outside"]:
            L.append(f"- {o['ip']} ({hp(o['hosts'], 'host')}" + (f", {o['asn']}" if o.get("asn") else "")
                     + (", " + ", ".join(o["ti"]) if o.get("ti") else "") + ")")
    _links(L, [("Incident page", ctx.link(campaign_rel(D["net"]) if camp else story_rel(D["key"])))])
    return "\n".join(L)


# ---- a record that is no longer on the board -------------------------------------------------------------------------

def record_text(o: dict, ctx: Ctx, priority: tuple | None = None) -> str:
    """The ticket of a stored incident record (history), for an incident the board no longer shows: what it was at its
    peak, from the snapshot kept with it. Shorter than a live ticket: no indicators table."""
    snap = o.get("snapshot") or {}
    P = priority or ("P4", VL.get(o.get("verdict_peak"), ""), "")
    label = o.get("label") or o.get("subject") or ""
    L = [f"[{P[0]}] " + (o.get("headline") or label),
         f"Incident: {label} ({o.get('subject')})" + (f" {DOT} {hp(o['members_n'], 'host')}" if o.get("kind") != "entity"
                                                      and o.get("members_n") else ""),
         (f"Priority: {P[0]} ({P[1]}) {DOT} peak verdict {VL.get(o.get('verdict_peak'), o.get('verdict_peak'))}"
          f" {DOT} from Sycope Security Triage")]
    if o.get("reason"):
        L.append(f"Why: {o['reason']}")
    if o.get("outcome") and o["outcome"] not in ("expired", "merged", "excepted") and o.get("outcome_at"):
        L.append(f"Status: {STW.get(o['outcome'], o['outcome'])}" + f" {DOT} set by {o.get('outcome_by') or '?'} "
                 + ltime(o["outcome_at"] * 1000, ctx))
    if o.get("first_ms") and o.get("last_ms"):
        L.append(f"Window: {ltime(o['first_ms'], ctx)} - {ltime(o['last_ms'], ctx)} ({zone(ctx)})")
    _steps({"list": snap.get("steps") or [], "done": {}}, L, ctx)
    _links(L, [("Incident page", ctx.link(history_rel(o["id"])))])
    return "\n".join(L)
