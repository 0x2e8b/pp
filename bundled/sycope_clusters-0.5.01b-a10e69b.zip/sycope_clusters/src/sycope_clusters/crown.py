"""Crown jewels in the triage database (spec 7.3, D38, D45) and the silenced hosts of a Sycope lookup.

An entity is `ip:<address>` or `subnet:<cidr>` (entities.py style); a subnet covers every address inside it. Three
sources feed the set the board scores with:

    manual / suggestion   rows an admin added, or accepted from the profile's candidates (table `crown`)
    file                  `critical_hosts_file`, imported once; a host removed since stays removed
    sycope-lookup         lookup entries whose severity is critical or high (read-only, never stored); the most
                          specific entry that names a severity answers, so a /32 marked low is not a crown jewel
                          inside a critical /24

`effective` gives entity -> source with bare addresses and networks as keys; `CrownSet` is what `evidence.build`
asks ("is this IP a crown jewel"). A suggestion's answer is kept with the evidence text it was given on: a rejected
one stays quiet until that text changes, an accepted "role" one is read by profile.learn.
"""

from __future__ import annotations

import ipaddress
import json
import time
from pathlib import Path

from sycope_clusters import profile as prof_mod
from sycope_clusters.addresses import AddressBook, Entry
from sycope_clusters.store import Store

LOOKUP = "sycope-lookup"
SEVERITIES = frozenset({"critical", "high"})
ANSWERS = ("accept", "reject")


def normalize(entity: str) -> tuple[str, str]:
    """(kind, canonical value) of `ip:<address>` or `subnet:<cidr>`; ValueError for anything else."""
    kind, _, value = (entity or "").partition(":")
    value = value.strip()
    try:
        if kind == "ip":
            return kind, str(ipaddress.ip_address(value))
        if kind == "subnet":
            return kind, str(ipaddress.ip_network(value, strict=False))
    except ValueError:
        pass
    raise ValueError(f"{entity!r} is not ip:<address> or subnet:<cidr>")


def canonical(entity: str) -> str:
    kind, value = normalize(entity)
    return f"{kind}:{value}"


def _key(net: ipaddress.IPv4Network | ipaddress.IPv6Network) -> str:
    return str(net.network_address) if net.num_addresses == 1 else str(net)


def add(store: Store, entity: str, who: str, reason: str, *, source: str = "manual", at: float | None = None) -> str:
    """An admin's crown jewel (or one accepted from a suggestion); a removed one comes back. The canonical entity."""
    ent = canonical(entity)
    store.crown_put(ent, source, reason, who, time.time() if at is None else at)
    store.log(who, "crown:add", ent, reason, {"source": source})
    return ent


def remove(store: Store, entity: str, who: str, reason: str = "", *, at: float | None = None) -> bool:
    """Take a crown jewel off the list (the row stays, so a replay and the file import know). False: not there."""
    ent = canonical(entity)
    done = store.crown_remove(ent, who, time.time() if at is None else at)
    if done:
        store.log(who, "crown:remove", ent, reason)
    return done


def import_file(store: Store, path: Path | None) -> int:
    """Take `critical_hosts_file` into the table once: entries with source "file", skipped when the entity already
    has a row (even a removed one). How many were added; a missing or unreadable file adds nothing."""
    if not path:
        return 0
    try:
        hosts = json.loads(Path(path).read_text(encoding="utf-8")).get("critical_hosts", [])
    except (OSError, ValueError, AttributeError):
        return 0
    now, n = time.time(), 0
    for h in hosts if isinstance(hosts, list) else []:
        try:
            ent = canonical(f"ip:{h}")
        except ValueError:
            continue
        if store.crown_import(ent, "file", "critical_hosts_file", "file", now):
            n += 1
    if n:
        store.log("file", "crown:import", str(path), f"{n} hosts from critical_hosts_file")
    return n


def effective(store: Store, book: AddressBook, at: float | None = None) -> dict[str, str]:
    """address or network -> source, for the crown jewels in force: the table's, then the lookup's. With `at`, the
    table as it stood then (every interval, closed ones too); the lookup is whatever `book` holds."""
    out: dict[str, str] = {}
    for r in store.crown_rows():
        if r["active"] and (at is None or r["at"] <= at):
            out[normalize(r["entity"])[1]] = r["source"] or "manual"
    if at is not None:
        for h in store.crown_history():
            if h["added_at"] <= at < h["removed_at"]:
                out.setdefault(normalize(h["entity"])[1], h["source"] or "manual")
    for e in book.entries:
        if e.severity.strip().lower() in SEVERITIES:
            out.setdefault(_key(e.net), e.source or LOOKUP)
    return dict(sorted(out.items()))


class CrownSet:
    """Answers `ip in crown_set` for the board: the most specific network or address of `effective` that covers the
    IP. A lookup source stands only while the book's most specific severity for the IP is still critical or high."""

    def __init__(self, eff: dict[str, str], book: AddressBook) -> None:
        self.eff, self.book = dict(eff), book
        self._by: dict[int, dict[int, dict[int, tuple[str, str]]]] = {4: {}, 6: {}}
        for k in sorted(self.eff):
            net = ipaddress.ip_network(k, strict=False)
            self._by[net.version].setdefault(net.prefixlen, {})[int(net.network_address)] = (k, self.eff[k])
        bits = {4: 32, 6: 128}
        self._plans = {v: [(plen, ((1 << plen) - 1) << (bits[v] - plen)) for plen in sorted(by, reverse=True)]
                       for v, by in self._by.items()}
        self._memo: dict[str, str | None] = {}

    def source(self, ip: str | None) -> str | None:
        if not ip:
            return None
        if ip not in self._memo:
            self._memo[ip] = self._find(ip)
        return self._memo[ip]

    def _find(self, ip: str) -> str | None:
        try:
            a = ipaddress.ip_address(ip)
        except ValueError:
            return None
        n = int(a)
        for plen, mask in self._plans[a.version]:
            hit = self._by[a.version][plen].get(n & mask)
            if hit is None:
                continue
            if hit[1] == LOOKUP and self.book.field(ip, "severity").strip().lower() not in SEVERITIES:
                continue
            return hit[1]
        return None

    def __contains__(self, ip: object) -> bool:
        return isinstance(ip, str) and self.source(ip) is not None

    def __iter__(self):
        return iter(sorted(self.eff))

    def __len__(self) -> int:
        return len(self.eff)

    def __bool__(self) -> bool:
        return True


def is_crown(eff: dict[str, str], book: AddressBook, ip: str) -> str | None:
    """The source that makes the IP a crown jewel, or None."""
    return CrownSet(eff, book).source(ip)


def candidates(profile: prof_mod.Profile, book: AddressBook, store: Store) -> list[dict]:
    """The profile's crown jewel candidates (directory, database, file servers, the busiest server of a segment)
    that are not crown jewels yet and not answered: a rejected one returns when its evidence text changed."""
    have = CrownSet(effective(store, book), book)
    todo = prof_mod.unanswered([s for s in profile.suggestions if s["kind"] == "crown"], store.answers())
    return [{"key": s["key"], "subject": s["subject"], "reason": s["reason"]}
            for s in todo if s["subject"] not in have]


def answer(store: Store, key: str, answer: str, who: str, reason: str = "") -> None:
    """Record accept or reject for a suggestion key ("crown:<ip>", "role:<role>:<ip>", "internal-ip:<ip>"). The
    evidence key it is answered on (profile.evidence_key) comes from the suggestion in the profile in use, or from
    the earlier answer when the suggestion left the list; a key that names neither is refused, as is a malformed
    one. Accepting a crown candidate adds it with source "suggestion"; accepting a role is read by the next
    profile.learn. Answering again replaces the answer. `reason` (the admin's own words, optional) goes into the audit
    line's note; without it the note is the suggestion's evidence text."""
    if answer not in ANSWERS:
        raise ValueError("answer must be accept or reject")
    kind, _, subject = prof_mod.parse_key(key)
    body = store.profile()
    sug = next((s for s in (body or {}).get("suggestions", []) if s.get("key") == key), None)
    if sug is not None:
        evidence, note = prof_mod.evidence_key(sug), sug["reason"]
    elif key in (prior := store.answers()):
        evidence, note = prior[key]["evidence"], ""
    else:
        raise ValueError(f"no such suggestion: {key}")
    now = time.time()
    store.answer_put(key, answer, who, now, evidence)
    store.log(who, f"suggestion:{answer}", key, reason or note, {"evidence": evidence, "suggested": note})
    if kind == "crown" and answer == "accept":
        add(store, f"subnet:{subject}" if "/" in subject else f"ip:{subject}", who,
            reason or note or "accepted suggestion",
            source="suggestion", at=now)


# ---- silenced hosts from a Sycope lookup (D45) ----------------------------------------------------------------

def silenced_from_lookup(entries: list[Entry]) -> list[dict]:
    """Read-only host exceptions for the addresses and networks of a lookup, shaped like store.exceptions() rows:
    id "lk:<cidr>", actor the address or the CIDR. Merged at build time, never stored."""
    seen: dict[str, ipaddress.IPv4Network | ipaddress.IPv6Network] = {}
    for e in entries:
        seen.setdefault(str(e.net), e.net)
    out = []
    for cidr, net in sorted(seen.items(), key=lambda kv: (kv[1].version, int(kv[1].network_address), kv[1].prefixlen)):
        out.append({"id": f"lk:{cidr}", "kind": "host", "rule": "*", "server": None, "port": None,
                    "actor": _key(net), "reason": "listed in the Sycope silenced-hosts lookup", "who": LOOKUP,
                    "created": 0.0, "expires": None, "active": 1, "removed_by": None, "removed_at": None,
                    "pending": 0, "days": None, "expired": False, "source": LOOKUP,
                    "src": _key(net), "dst": None, "proto": None, "win_days": None, "win_from": None,
                    "win_to": None, "edited_by": None, "edited_at": None, "pruned_alerts": 0})
    return out
