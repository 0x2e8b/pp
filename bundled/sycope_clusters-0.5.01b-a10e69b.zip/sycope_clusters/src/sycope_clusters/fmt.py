"""One way to write a number, a time, a plural and an "a/an", in Python (text the server writes) and in JavaScript
(both pages). The two are written to give the same text for the same input; tests/test_fmt.py runs the JavaScript in
node against the Python on fixed inputs.

    number   thousands separator "," (1,234,567 and 1,234.50), never a space
    time     today "HH:MM", any other day "YYYY-MM-DD HH:MM" (tm); "hm" = the time of day only, "dt" = always with the date, "full" = with seconds
             (tooltips, exports). Every time on the pages is in the zone the viewer chose with the UTC | Local switch in the
             top bar (localStorage "sc-tz", "utc" or "local", missing = "local"): UTC, or the browser's own zone read
             per timestamp (so DST is right). "Today" is the day in that zone. Text the server writes (ticket, digest,
             webhook) and CSV exports do not follow the switch: the text is in the configured UTC offset
             (`calendar.utc_offset_min`; the pages get it as window.SC_OFF, JS confOff()), exports are UTC.
             Relative times ("5 min ago") live in tooltips only.
    plural   "1 host", "2 hosts", "1,200 hosts"  (plural(n, "host"), plural(n, "address", "addresses"))
    article  "a host", "an IP", "an unknown address"  (article / with_article)

Python: num, tm, zone, plural, article, with_article.  JavaScript (FMT_JS): num, tm, rng, zoneLbl, tzMode, offMin, confOff, tzPaint, hp, an, wa, p2.
"""
from __future__ import annotations

import re
from datetime import UTC, datetime
from decimal import ROUND_HALF_UP, Decimal


def num(v, d: int = 0) -> str:
    """1234567 -> "1,234,567"; with `d` decimals 1234.5 -> "1,234.50". None -> "" (the page shows its own null)."""
    if v is None:
        return ""
    q = Decimal(float(v)).quantize(Decimal(1).scaleb(-d), rounding=ROUND_HALF_UP)       # as JavaScript's toFixed rounds
    return f"{q:,.{d}f}"


def _local(epoch: float, offset_min: int) -> datetime:
    return datetime.fromtimestamp(epoch + offset_min * 60, UTC)


def tm(epoch: float | None, now: float, offset_min: int = 0, f: str = "") -> str:
    """A time of day today (the day of `now`), else date and time; `f` "hm" is the time of day alone, "dt" always has the date, "full" adds seconds."""
    if epoch is None:
        return ""
    t = _local(epoch, offset_min)
    if f == "hm":
        return t.strftime("%H:%M")
    if f == "full":
        return t.strftime("%Y-%m-%d %H:%M:%S")
    if f == "dt":
        return t.strftime("%Y-%m-%d %H:%M")
    return t.strftime("%H:%M" if t.date() == _local(now, offset_min).date() else "%Y-%m-%d %H:%M")


def zone(offset_min: int) -> str:
    """The configured zone as text: "UTC", "UTC+02:00"."""
    return "UTC" if offset_min == 0 else f"UTC{'+' if offset_min > 0 else '-'}{abs(offset_min) // 60:02d}:{abs(offset_min) % 60:02d}"


TZ_TIP = "Times on these pages: UTC or your browser's time zone. CSV exports are always UTC."


def tz_switch() -> str:
    """The top bar's UTC | Local switch and the zone label (FMT_JS tzPaint marks the pressed option and fills the label)."""
    return (f'<span class="mut tz tzsw" id="tz" title="{TZ_TIP.replace(chr(39), "&#39;")}"><span class="tzseg" role="group" '
            'aria-label="Time zone of the times on this page"><button type="button" class="tzb" data-tz="utc" '
            'aria-pressed="false">UTC</button><button type="button" class="tzb" data-tz="local" aria-pressed="true">Local</button>'
            '</span><span class="tzl" id="tzname"></span></span>')


def plural(n: int, word: str, pl: str | None = None) -> str:
    """"1 host", "2 hosts", "1,200 hosts"."""
    return f"{n:,} " + (word if n == 1 else (pl or word + "s"))


# "a" or "an" follows the sound, not the letter. Words that start with a vowel letter but a consonant sound take "a"
# (a user, a unique), words that start with a silent h take "an" (an hour). An acronym is read letter by letter: "an IP",
# "an SSH", "an HTTP", but "a TCP", "a DNS".
_A_VOWEL = re.compile(r"^(uni(?!n|d|m)|use|usu|uti|uk|eu|one|once|ubiq|ural)", re.IGNORECASE)
_AN_CONS = re.compile(r"^(hour|honest|honou?r|heir)", re.IGNORECASE)
_LETTER_VOWEL = "AEFHILMNORSX"


def article(word: str) -> str:
    """"a" or "an" for the word that follows it."""
    w = (word or "").strip()
    if not w:
        return "a"
    if len(w) > 1 and w.isupper() and w.isalpha():
        return "an" if w[0] in _LETTER_VOWEL else "a"
    if _AN_CONS.match(w):
        return "an"
    if _A_VOWEL.match(w):
        return "a"
    return "an" if w[0].lower() in "aeiou" else "a"


def with_article(word: str) -> str:
    return f"{article(word)} {word}"


FMT_JS = r"""function p2(n){return (n<10?"0":"")+n}
function num(v,d){if(v==null)return nul();var x=(+v).toFixed(d||0),i=x.indexOf("."),w=i<0?x:x.slice(0,i);return w.replace(/\B(?=(\d{3})+(?!\d))/g,",")+(i<0?"":x.slice(i))}
// the display zone is the viewer's: "utc" (0) or "local" (the browser's own, taken per timestamp so DST is right), kept in
// localStorage "sc-tz" (missing or invalid = local); the switch reloads the page, so the choice is read once.
// confOff() is the configured calendar zone (calendar.utc_offset_min, page variable SC_OFF): not for display.
var TZM=null;
function tzMode(){if(TZM===null){var v="";try{v=localStorage.getItem("sc-tz")||""}catch(x){}TZM=v==="utc"?"utc":"local"}return TZM}
function confOff(){return typeof window!=="undefined"&&window&&window.SC_OFF!=null?+window.SC_OFF:0}
function offMin(ms){if(tzMode()==="utc")return 0;var o=-new Date(ms==null?Date.now():ms).getTimezoneOffset();return isNaN(o)?0:o}
function lc(ms){return new Date(ms+offMin(ms)*60000)}
function ymdOf(d){return d.getUTCFullYear()+"-"+p2(d.getUTCMonth()+1)+"-"+p2(d.getUTCDate())}
function tm(ms,f,now){if(ms==null)return nul();var d=lc(ms),h=p2(d.getUTCHours())+":"+p2(d.getUTCMinutes()),ymd=ymdOf(d);
  if(f==="hm")return h;if(f==="full")return ymd+" "+h+":"+p2(d.getUTCSeconds());if(f==="dt")return ymd+" "+h;
  return ymd===ymdOf(lc(now==null?Date.now():now))?h:ymd+" "+h}
function rng(a,b,now){if(a==null)return nul();if(b==null||b===a)return tm(a,"",now);
  return tm(a,"",now)+" – "+(ymdOf(lc(a))===ymdOf(lc(b))?tm(b,"hm"):tm(b,"",now))}
function zoneLbl(ms){var m=offMin(ms),a=Math.abs(m);return m===0?"UTC":"UTC"+(m>0?"+":"-")+p2(Math.floor(a/60))+":"+p2(a%60)}
function tzLabel(){return tzMode()==="utc"?"UTC":"Local ("+zoneLbl()+")"}
// the top bar switch (markup from fmt.tz_switch): the pressed option, the zone label, the click that stores the choice and reloads
function tzPaint(){if(typeof document==="undefined"||!document)return;var el=document.getElementById("tz");if(!el)return;
  var m=tzMode(),bs=el.querySelectorAll("button[data-tz]"),l=document.getElementById("tzname"),i;
  for(i=0;i<bs.length;i++)bs[i].setAttribute("aria-pressed",bs[i].getAttribute("data-tz")===m?"true":"false");
  if(l)l.textContent=tzLabel();
  el.onclick=function(e){var b=e.target&&e.target.closest?e.target.closest("button[data-tz]"):null;if(!b)return;var v=b.getAttribute("data-tz");if(v===tzMode())return;
    try{localStorage.setItem("sc-tz",v)}catch(x){}location.reload()}}
function hp(n,w,pl){return num(n)+" "+(n===1?w:(pl||w+"s"))}
function an(w){w=String(w||"").trim();if(!w)return "a";
  if(w.length>1&&/^[A-Z]+$/.test(w))return "AEFHILMNORSX".indexOf(w.charAt(0))>=0?"an":"a";
  if(/^(hour|honest|honou?r|heir)/i.test(w))return "an";
  if(/^(uni(?!n|d|m)|use|usu|uti|uk|eu|one|once|ubiq|ural)/i.test(w))return "a";
  return /^[aeiou]/i.test(w)?"an":"a"}
function wa(w){return an(w)+" "+w}
// ---- times: the viewer's zone, said once in the top bar and in every tooltip; relative times only in tooltips ----
function fullTime(ms){return ms==null?"":tm(ms,"full")+" "+zoneLbl(ms)}
function ago(ms){if(ms==null)return "";var now=typeof S!=="undefined"&&S&&S.data&&S.data.now?S.data.now*1000:Date.now(),s=Math.max(0,Math.round((now-ms)/1000));
  if(s<90)return "just now";if(s<3600)return Math.round(s/60)+" min ago";if(s<86400)return Math.round(s/3600)+" h ago";return Math.round(s/86400)+" d ago"}
function at(ms){if(ms==null)return nul();return '<span title="'+esc(ago(ms)+" · "+fullTime(ms))+'">'+tm(ms)+'</span>'}
"""

# The times the server writes as <time class="ts" data-e="epoch" data-f="hm|full|">: the same JavaScript formatter as the
# pages (FMT_JS, so the same zone and format), run over every tag. The page sets window.SC_OFF (the configured zone, see pages._page).
TIME_TAG_JS = (
    "<script>(function(){function nul(){return \"\"}function esc(v){return String(v)}" + FMT_JS
    + 'document.querySelectorAll("time.ts").forEach(function(t){var ms=+t.dataset.e*1000,f=t.dataset.f;'
    't.textContent=tm(ms,f==="hm"||f==="full"?f:"");t.title=fullTime(ms)});'
    'tzPaint()})();</script>'
)
