"""Shared infrastructure by address: the fallback for the shared-cloud deduction when the alerts carry no ASN.

`data/shared_infra.json` lists prefixes (CDN edges, public DNS, large clouds) with the provider and where the range
is published; an entry marked "approximate" is a wide block the provider shares with others. An admin can add
networks with the `shared_infra_extra` parameter. Pure lookups, no state."""

from __future__ import annotations

import ipaddress
import json
from functools import lru_cache
from pathlib import Path

DATA = Path(__file__).resolve().parent / "data" / "shared_infra.json"


@lru_cache(maxsize=1)
def shipped() -> tuple[tuple, ...]:
    """(network, provider, approximate) of the shipped list, narrowest prefix first. Empty when unreadable."""
    try:
        rows = json.loads(DATA.read_text(encoding="utf-8"))
        out = [(ipaddress.ip_network(r["prefix"]), str(r["provider"]), bool(r.get("approximate"))) for r in rows]
    except (OSError, ValueError, KeyError, TypeError):
        return ()
    return tuple(sorted(out, key=lambda t: (-t[0].prefixlen, str(t[0]))))


@lru_cache(maxsize=256)
def _extra(nets: tuple[str, ...]) -> tuple:
    out = []
    for c in nets:
        try:
            out.append((ipaddress.ip_network(c.strip()), "your list", False))
        except ValueError:
            continue
    return tuple(out)


def provider(ip: str | None, extra: tuple[str, ...] | list[str] = ()) -> str | None:
    """The provider label of the shared network `ip` belongs to ("Microsoft, approximate" for a wide block), else
    None. The admin's networks come first and are labelled "your list"."""
    if not ip:
        return None
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return None
    for net, prov, approx in (*_extra(tuple(extra)), *shipped()):
        if a.version == net.version and a in net:
            return f"{prov}, approximate" if approx else prov
    return None
