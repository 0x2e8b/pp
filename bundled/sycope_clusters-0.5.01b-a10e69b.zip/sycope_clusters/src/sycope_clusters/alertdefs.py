"""Sycope's own alert definitions, as the list the silence dialog's Alert picker offers.

Verified on the lab Sycope (2026-11-06, GET only): `GET alert-defs?offset=N&limit=100` answers {"data": [...]}; a page
shorter than the limit is the last. Each definition has alertName, active (bool), ruleType (SECURITY, VISIBILITY,
PERFORMANCE), mitreTactic, ruleId and id. 173 definitions on the lab, 0.2 s. Inactive ones are mostly "[TEMPLATE] ..."
copies, and a name can repeat across definitions: the list is by name (a silence rule matches by name), a name is
active when any of its definitions is. Templates ("[TEMPLATE] ...") are left out: customers never see them as alerts,
they only create rules from them (Pawel, 2026-11-06).
"""

from __future__ import annotations

import logging
import time

from sycope_clusters.sycope import SycopeError

log = logging.getLogger("sycope_clusters.alertdefs")

PAGE = 100
MAX_PAGES = 200           # a runaway guard: 20,000 definitions
TEMPLATE = "[TEMPLATE]"   # template definitions: not alerts a customer sees, left out of the list


def read(client) -> list[dict]:
    """Every alert definition of Sycope, one row per alert name: {name, active, type, tactic}, by name."""
    get = getattr(client, "get_json", None)
    if get is None:
        raise SycopeError("no Sycope connection to read them with")
    by: dict[str, dict] = {}
    for page in range(MAX_PAGES):
        ans = get(f"alert-defs?offset={page * PAGE}&limit={PAGE}")
        data = ans.get("data") if isinstance(ans, dict) else None
        if not isinstance(data, list):
            raise SycopeError("Sycope answered the alert definitions in an unexpected shape")
        for d in data:
            name = str(d.get("alertName") or "").strip() if isinstance(d, dict) else ""
            if not name or name.upper().startswith(TEMPLATE):
                continue
            active = d.get("active") is True
            t = {"name": name, "active": active, "type": str(d.get("ruleType") or ""),
                 "tactic": str(d.get("mitreTactic") or "")}
            old = by.get(name)
            if old is None:
                by[name] = t
            elif active and not old["active"]:
                by[name] = {**t, "tactic": t["tactic"] or old["tactic"]}   # the active definition speaks for the name
            elif not old["tactic"] and t["tactic"]:
                old["tactic"] = t["tactic"]
        if len(data) < PAGE:
            break
    return sorted(by.values(), key=lambda t: (t["name"].lower(), t["name"]))


class AlertDefCache:
    """The definitions, read again every `refresh_s` seconds by the poll (with the Lookups); the last good read is
    kept when Sycope fails, and `error` says why the last try did."""

    def __init__(self, refresh_s: int = 900) -> None:
        self.refresh_s = refresh_s
        self.defs: list[dict] = []
        self.error = "not read yet"
        self.read_at = 0.0
        self._tried: float | None = None

    def get(self, client, now: float | None = None) -> list[dict]:
        now = time.time() if now is None else now
        if client is not None and (self._tried is None or now - self._tried >= self.refresh_s):
            self._tried = now
            try:
                got = read(client)
            except SycopeError as exc:
                self.error = str(exc)
            except Exception as exc:  # a changed answer shape must not stop the board
                log.exception("alert definitions read failed")
                self.error = f"{type(exc).__name__}: {exc}"
            else:
                self.defs, self.error, self.read_at = got, "", now
        return self.defs

    def view(self, family_of) -> dict:
        """The route's answer: the definitions (with our family when the catalog knows the name), when they were
        read (epoch seconds, 0 = never) and the error of the last try, "" when it worked."""
        return {"defs": [{**d, "family": family_of(d["name"])} for d in self.defs], "read_at": self.read_at,
                "error": self.error}
