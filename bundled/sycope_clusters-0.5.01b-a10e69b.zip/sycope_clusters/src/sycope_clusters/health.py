"""Health: what the system knows about its inputs and what it lacks (spec 8.3, 8.5).

Per poll the fill rate of every alert field the scoring reads is measured (`fill_rates`). A field that is nearly
absent turns the terms that need it off, explicitly (`disabled_terms`): the scoring skips the term, writes a
"missing data" line into the trace of every finding it touches (evidence.build `disabled=`) and Health says so.
Nothing here raises: a missing field degrades the verdict, never the service.

`summary(live)` is the data of the Health card on the System page (Task 14 adds a JSON route and the admin page).
Keys:

    fields           field -> fill rate 0..1 of the last rebuild's window (see fill_rates for what 1.0 means)
    disabled         [{"term", "needs", "text"}] the terms turned off now
    profile_days     comparable days the learned profile looks at; dormant_days: days it found far quieter than usual
    norm_conf        {"share", "volume_hosts", "volume_low", "volume_median"}: confidence of the learned shares and
                     of the per-host volume norms (low = under 0.5)
    unknown_rules    [{"key", "name", "tactic", "seen"}] alert names the rule catalog does not know
    unmapped_hosts   acting internal hosts that no Sycope Lookup row covers
    suggestions      how many profile suggestions wait for an answer (int)
    mem_mb, mem_budget_mb, degrade_level   the service's memory estimate, its budget, how far the window was thinned
    rebuild_s        seconds the last board took; poll_lag_s: seconds since the last good poll (None: never)
    last_backup      time of the newest backup file (None: none); config_version, modified: the active
                     configuration and whether it differs from the factory
    lookup_error, flowagg_error   why the last Lookup read / netflow aggregate failed ("" = fine)

Carried keys:

    unknown_privacy, bad_cidr   lookup rows with an unreadable privacy value / network
    flow_coverage    {day: hours of netflow aggregated} for the stored flow days
    flow_error       the same as flowagg_error
    config_error     break-glass file and stored-version problems (Live.config_error)
    profile_frozen   whether an admin froze the profile
    poll_wait_s      seconds until the next poll; above SC_POLL_SECONDS while Sycope keeps failing (backoff)
    overlay_warnings playbook overlay edits that name a step this release does not have
    config_import_leftover   `config-import.json.applying-*` files (a crash between rename and publish)
    restored         what the start-up database check did, as text; None when nothing was wrong
    silence_spikes   [{"id", "alerts", "usual", "text"}] silence rules that hide a spike now (silence.spike); each is a warning
    silenced_alerts  alerts of the window some rule took; silence_rules: the silence rules in force
    past_error       why learning the past (profile and History) failed last ("" = fine): the board then scores on
                     the priors or the last good past, and it is tried again later
    webhook          the outbound webhook (notify.py): on, queued, delivered, failed, dropped, last_ok_at, last_error,
                     last_error_at, last_drop_at; the warnings say "the last delivery failed at ..." and a queue overflow
    suggestions_old  how many of those have waited longer than health.suggestion_days (first seen day kept in meta)
    utc_offset_min, browser_offset_min, tz_warning   the configured calendar offset, the browser's (the ?tz= of
                     /health-data; None when not sent) and the warning when they differ
    provisional      the board is scored on the priors while the service learns the past (no incidents written)
    warnings         one plain sentence per thing an admin should look at: operational errors, missing fields with what
                     they cost (DEPENDS), netflow days with gaps, a calendar offset that differs from the browser's,
                     suggestions left waiting, configuration problems
"""

from __future__ import annotations

import ipaddress
import json
import sqlite3
import statistics
import time
from collections import Counter
from pathlib import Path

from sycope_clusters import backup, playbook
from sycope_clusters import profile as prof_mod
from sycope_clusters.evidence import local_time
from sycope_clusters.sycope import FIELDS

READ = ("sumClientBytes", "sumServerBytes", "serverAsName", "clientAsName", "serverCountry", "clientLocation",
        "serverLocation", "clientFunction", "serverFunction", "serverIps", "alertFlagThresholdLevel", "alertRuleId")
FLOOR = 0.05            # a field filled in less than this share of the rows that should have it is missing
MIN_ROWS = 20           # fewer rows say nothing about a field
_IX = {f: FIELDS.index(f) for f in (*READ, "alertName", "alertMitreTactic", "_uniqueServerIps", "clientIp", "serverIp")}
_BYTES = ("sumClientBytes", "sumServerBytes")
# Sycope enriches only global addresses with an ASN and a country (a private-to-private alert has none to give): these
# fields are measured on the rows whose own side is a global address, the side the field describes
_GLOBAL_SIDE = {"serverAsName": "serverIp", "serverCountry": "serverIp", "clientAsName": "clientIp"}


_ABSENT = (None, "", ())


def _count(v) -> float:
    try:
        return float(v or 0)
    except (TypeError, ValueError):
        return 0.0


def _is_global(ip, memo: dict) -> bool:
    if not ip:
        return False
    v = memo.get(ip)
    if v is None:
        try:
            v = memo[ip] = ipaddress.ip_address(str(ip).strip()).is_global
        except ValueError:
            v = memo[ip] = False
    return v


def fill_rates(rows: list[tuple], catalog=None, min_rows: int = MIN_ROWS) -> dict[str, float]:
    """The share of rows (alerts or buckets, FIELDS order) that carry each field the scoring reads: present means
    not None, not empty text, not an empty target list (a 0 is a value). 0.0 for all fields when there are no rows.
    A field only some alerts can carry is counted among those: the byte counts among the upload rules' alerts (with
    a catalog) and the target list among the scan alerts of class A and B that touched more than one server (with a
    catalog; without one, among any alert that did). A field with fewer than `min_rows` alerts that should carry it
    is not judged: it reads 1.0, as does a field nobody needs. The ASN and country fields are counted among the rows
    whose own side (server for serverAsName and serverCountry, client for clientAsName) is a global address: Sycope
    gives a private address none, and ~95% of a typical site's alerts are private to private. When one ASN side is
    not judged (too few global rows) it reads the other's rate: the two stand for one question."""
    if not rows:
        return dict.fromkeys(READ, 0.0)
    have, need = Counter(), Counter()
    kinds: dict[tuple, tuple] = {}
    i_name, i_tac, i_rid, i_uniq = (_IX[k] for k in ("alertName", "alertMitreTactic", "alertRuleId",
                                                     "_uniqueServerIps"))
    glob: dict = {}
    side = {f: _IX[ip] for f, ip in _GLOBAL_SIDE.items()}
    for r in rows:
        exfil, scan = True, True
        if catalog is not None:
            key = (r[i_name], r[i_tac], r[i_rid])
            kc = kinds.get(key)
            if kc is None:
                rule = catalog.get(*key)
                kc = kinds[key] = (rule.kind == "exfil", rule.kind == "scan" and rule.cls in ("A", "B"))
            exfil, scan = kc
        listed = scan and _count(r[i_uniq]) > 1
        for f in READ:
            if f in _BYTES and not exfil or f == "serverIps" and not listed:
                continue
            if f in side and not _is_global(r[side[f]], glob):
                continue
            need[f] += 1
            if r[_IX[f]] not in _ABSENT:
                have[f] += 1
    out = {f: (have[f] / need[f] if need[f] >= min_rows and need[f] else 1.0) for f in READ}
    judged = [f for f in ("serverAsName", "clientAsName") if need[f] >= min_rows and need[f]]
    if len(judged) == 1:
        out["clientAsName" if judged[0] == "serverAsName" else "serverAsName"] = out[judged[0]]
    return out


def disabled_terms(rates: dict[str, float], floor: float = FLOOR) -> list[dict]:
    """The scoring terms a missing field turns off: {"term", "needs" (the fields below the floor), "text"}. A field
    absent from `rates` counts as present, so an empty dict (too few rows to say) disables nothing. The scoring
    reads the upload bytes (sumClientBytes) only; a one-direction exporter without sumServerBytes keeps exfil
    volume on."""
    def low(*names: str) -> list[str]:
        return [n for n in names if rates.get(n, 1.0) < floor]

    out = []
    if m := low("sumClientBytes"):
        out.append({"term": "exfil_volume", "needs": m,
                    "text": "no byte counts in the alerts: exfil volume cannot confirm exfiltration (Objectives), an upload stays "
                            "suspected"})
    asn = ("serverAsName", "clientAsName")
    if len(m := low(*asn)) == len(asn):
        out.append({"term": "shared_cloud", "needs": m,
                    "text": "no ASN in the alerts: no shared-cloud deduction for intel and beacon matches"})
    if m := low("serverIps"):
        out.append({"term": "same_host", "needs": m,
                    "text": "no target lists in the alerts: CR-09 same-host link off, a scan is not tied to the host "
                            "attacked next by the hosts it listed"})
    return out


# The dependency matrix: the alert fields (any of a group may carry it; the best of them counts) -> what uses them ->
# what it costs when they are missing. Health warns when a group is filled in less than `health.fill_warn`.
DEPENDS = (
    (("sumClientBytes",), "byte counts", "exfil volume cannot confirm exfiltration (Objectives), so an upload stays suspected"),
    (("sumServerBytes",), "download byte counts",
     "an upload cannot be told from a download: big downloads may read as exfiltration"),
    (("serverAsName", "clientAsName"), "ASN",
     "the shared-cloud deduction is off, expect false positives on CDN and cloud addresses"),
    (("serverCountry", "clientLocation", "serverLocation"), "location",
     "countries and locations are missing next to addresses and in the context of a host"),
    (("clientFunction", "serverFunction"), "host function",
     "roles (resolver, scanner, server) are learned from less data, so their lowering weakens"),
    (("serverIps",), "target lists",
     "the CR-09 same-host link is off, a scan is not tied to the host attacked next by the hosts it listed"),
    (("alertFlagThresholdLevel",), "threshold level", "the evidence added for a crossed threshold is missing"),
    (("alertRuleId",), "rule ids", "rules are recognised by name only, a renamed rule is read as unknown"),
)
_LABEL = {"ASN": "No ASN in alerts", "host function": "Your Sycope lookup assigns no host functions"}


def dependency_warnings(rates: dict[str, float], disabled: list[dict], warn_below: float = 0.5) -> list[str]:
    """One sentence per field group under `warn_below` (and per disabled term no group explains), with the cost."""
    out, covered = [], set()
    for fields, what, cost in DEPENDS:
        seen = [rates[f] for f in fields if f in rates]
        if not seen:
            continue
        fill = max(seen)
        if fill >= warn_below:
            continue
        covered.update(fields)
        head = _LABEL.get(what, f"Few {what} in alerts" if fill else f"No {what} in alerts")
        if what == "host function":    # not a data problem: the lookup the customer keeps decides it
            head = ("Your Sycope lookup assigns host functions to few hosts" if fill else _LABEL[what])
            out.append(f"{head} ({fill * 100:.0f}% of alerts carry one): roles (resolver, scanner, server) are learned "
                       f"from netflow instead, which needs more days; fill the function column of the lookup to speed "
                       f"that up")
            continue
        if what == "ASN":
            cost = ("the shared-cloud deduction is off (the prefix list is used instead), expect false positives on "
                    "cloud addresses outside it" if fill < FLOOR else
                    f"the shared-cloud deduction applies only to the {fill * 100:.0f}% of alerts that carry an ASN")
        out.append(f"{head} ({fill * 100:.0f}% filled): {cost}")
    for t in disabled:
        if not set(t["needs"]) & covered:
            out.append(f"{t['term'].replace('_', ' ').capitalize()} is off: {t['text']}")
    return out


def utc_label(minutes: int) -> str:
    sign = "+" if minutes >= 0 else "-"
    h, m = divmod(abs(int(minutes)), 60)
    return f"UTC{sign}{h}" + (f":{m:02d}" if m else "")


def offset_warning(configured: int, browser: int | None) -> str | None:
    if browser is None or int(configured) == int(browser):
        return None
    return (f"Weekday and weekend learning uses {utc_label(configured)} but your browser is {utc_label(browser)}: "
            f"days are cut at the wrong hour and holidays can land on the wrong weekday")


def coverage_warning(coverage: dict[str, int], today: str, hours_min: float = 0.9, last: int = 7) -> str | None:
    """The stored days (the newest `last`, today's still running excluded) with netflow in fewer than `hours_min` of
    their 24 hours, named."""
    days = [d for d in sorted(coverage) if d < today][-last:]
    bad = [f"{d} ({coverage[d]}/24 h)" for d in days if coverage[d] < hours_min * 24]
    if not bad:
        return None
    return (f"Netflow is incomplete on {', '.join(bad)}: the volume norms and the exfil and scan checks for those "
            f"days rest on partial data")


def _norm_conf(live) -> dict:
    prof = live.profile
    out = {"share": None, "volume_hosts": 0, "volume_low": 0, "volume_median": None}
    if prof is None:
        return out
    a_share = prof.alphas.get("share", live.priors.alpha_share if live.priors else 4.0)
    out["share"] = round(prof_mod._conf(prof.population.get(prof_mod.ALL, 0), a_share), 3)
    a_vol = prof.alphas.get("volume", 5.0)
    conf = sorted(prof_mod._conf(n, a_vol) for k, n in prof.norm_n.items() if k.startswith("host:"))
    out["volume_hosts"] = len(conf)
    out["volume_low"] = sum(1 for c in conf if c < 0.5)
    out["volume_median"] = round(statistics.median(conf), 3) if conf else None
    return out


def _unmapped(live) -> int:
    """Acting internal hosts of the last board that no lookup row covers."""
    src, b = live._scored, live.board
    if src is None or b is None:
        return 0
    book = src.book
    return sum(1 for ip in b.entities if book.internal(ip) and book.entry(ip) is None)


def _leftover(live) -> list[str]:
    d = live.settings.state_dir
    if not d:
        return []
    try:
        return sorted(p.name for p in Path(d).glob("config-import.json.applying-*"))
    except OSError:
        return []


def summary(live, now: float | None = None, browser_offset: int | None = None) -> dict:
    now = time.time() if now is None else now
    s, store = live.settings, live.store
    prof = live.profile
    stats = live.window.stats() if live.window is not None else {"mem_bytes": 0, "level": 0}
    last_ok = live.last_ok_at
    backups_dir = live.backup_dir
    newest = backup.latest(backups_dir) if backups_dir else None
    try:
        last_backup = newest.stat().st_mtime if newest else None
    except OSError:
        last_backup = None
    days = store.flow_days()[-14:]
    overlay = playbook.overlay_warnings(live.playbook_overlay)
    leftover = _leftover(live)
    waiting = prof_mod.waiting(prof.suggestions, store.answers()) if prof is not None else []
    suggestions = len(waiting)
    old_sugg = _old_suggestions(live, waiting, now)
    cfg = live.config
    body = {
        "fields": dict(live.fill),
        "disabled": [dict(t) for t in live.disabled],
        "profile_days": len(prof.days) if prof is not None else 0,
        "dormant_days": len(prof.calendar.dormant) if prof is not None else 0,
        "norm_conf": _norm_conf(live),
        "unknown_rules": live.catalog.unknown_rows() if live.catalog is not None else [],
        "unmapped_hosts": _unmapped(live),
        "suggestions": suggestions,
        "mem_mb": round((live.mem_bytes() if live.window is not None else 0) / 2**20, 1),
        "mem_budget_mb": s.memory_mb,
        "degrade_level": stats["level"],
        "rebuild_s": live.board.took_s if live.board is not None else None,
        "poll_lag_s": round(now - last_ok, 1) if last_ok else None,
        "last_backup": last_backup,
        "config_version": live.config_version,
        "modified": any(cfg.get(k) for k in ("params", "catalog", "playbook", "internal")),
        "lookup_error": live._lookups.error if live._lookups is not None else "",
        "flowagg_error": live.flow_error,
        "unknown_privacy": live.unknown_privacy,
        "bad_cidr": live._lookups.bad_cidr if live._lookups is not None else 0,
        "flow_coverage": {d: store.flow_coverage(d) for d in days},
        "flow_error": live.flow_error,
        "config_error": live.config_error,
        "profile_frozen": store.meta("profile_frozen") == "1",
        "poll_wait_s": live.wait_s,
        "overlay_warnings": overlay,
        "config_import_leftover": leftover,
        "restored": live.restore_note or None,
        "past_error": live.past_error,
        "provisional": live.provisional,
        "suggestions_old": old_sugg,
        "webhook": live.notifier.status() if live.notifier is not None else {"on": False},
        "utc_offset_min": int(live.params["calendar.utc_offset_min"]),
        "browser_offset_min": browser_offset,
        "tz_warning": offset_warning(int(live.params["calendar.utc_offset_min"]), browser_offset),
        "fill_warn": live.params["health.fill_warn"],
        "silence_spikes": list(getattr(live, "silence_spikes", {}).values()),
        "silenced_alerts": getattr(live, "silenced_alerts", 0),
        "silence_rules": sum(1 for x in store.exceptions() if x["kind"] == "silence"),
        "today": time.strftime("%Y-%m-%d", time.gmtime(now)),
        "now": now,
    }
    body["warnings"] = _warnings(live, body)
    body.pop("today")
    body.pop("now")
    body["config_warnings"] = _config_warnings(body)      # the part of `warnings` that is about the configuration
    return body


def stamp_suggestions(store, suggestions: list[dict], today: str) -> None:
    """Keep the first UTC day each waiting suggestion was seen (meta "suggestion_seen": key -> day; the profile does
    not date its suggestions). Called where the profile is learned, not from a page, on every path that learns it. A suggestion that is answered is
    forgotten, so one that comes back starts fresh. Never raises: a database that cannot be written loses the date,
    not the service."""
    try:
        waiting = prof_mod.waiting(suggestions, store.answers())
        try:
            seen = json.loads(store.meta("suggestion_seen") or "{}")
        except ValueError:
            seen = {}
        new = {s["key"]: seen.get(s["key"], today) for s in sorted(waiting, key=lambda s: s["key"])}
        if new != seen:
            store.meta("suggestion_seen", json.dumps(new, sort_keys=True))
    except (sqlite3.Error, OSError, KeyError, TypeError):
        pass


def _old_suggestions(live, waiting: list[dict], now: float) -> int:
    """How many of the waiting suggestions were first seen more than `health.suggestion_days` ago (read only)."""
    store = live.store
    if store is None or not waiting:
        return 0
    try:
        seen = json.loads(store.meta("suggestion_seen") or "{}")
    except (sqlite3.Error, OSError, ValueError):
        return 0
    limit = time.strftime("%Y-%m-%d", time.gmtime(now - live.params["health.suggestion_days"] * 86400))
    return sum(1 for s in waiting if seen.get(s["key"], "9999") < limit)


def _config_warnings(b: dict) -> list[str]:
    """The warnings about the configuration (an invalid active version, a half-applied break-glass file, playbook
    edits that point nowhere): for admins; /system keeps the operational ones for everyone."""
    out = [f"Configuration: {b['config_error']}"] if b["config_error"] else []
    out += [f"{name} is left in the state directory: a break-glass import stopped half way; check the active "
            f"configuration, then delete or rename the file" for name in b["config_import_leftover"]]
    return out + [f"Playbook overlay: {w}" for w in b["overlay_warnings"]]


def _webhook_warnings(w: dict, offset_min: int, now: float) -> list[str]:
    """The outbound webhook: a delivery that failed after its retries and was not followed by a good one, and events
    dropped because the queue was full."""
    out = []
    if w.get("url_error"):
        out.append(w["url_error"])
    if w.get("last_error_at") and (w.get("last_ok_at") or 0) < w["last_error_at"]:
        out.append(f"The last webhook delivery failed at {local_time(w['last_error_at'], now, offset_min)} "
                   f"({w['last_error']}); {w['failed']} failed in all. The audit log has each one")
    if w.get("dropped") and (w.get("last_ok_at") or 0) < (w.get("last_drop_at") or 0):
        out.append(f"The webhook queue overflowed: {w['dropped']} events were dropped (the receiver is slow or down); "
                   f"the last one at {local_time(w['last_drop_at'], now, offset_min)}")
    return out


def _warnings(live, b: dict) -> list[str]:
    out = []
    if b["restored"]:
        out.append(b["restored"])
    if live.backup_error:
        out.append(f"The daily backup failed: {live.backup_error}")
    if b["lookup_error"]:
        out.append(f"The Sycope Lookups could not be read (the last good read is used): {b['lookup_error']}")
    if b["flowagg_error"]:
        out.append(f"The netflow aggregate failed (it tries again): {b['flowagg_error']}")
    if b["past_error"]:
        out.append(f"Learning the stored days failed (the board scores without them until a retry works): "
                   f"{b['past_error']}")
    out += _config_warnings(b)
    P = live.params
    out += dependency_warnings(b["fields"], b["disabled"], P["health.fill_warn"])
    if w := coverage_warning(b["flow_coverage"], b["today"], P["health.coverage_min"]):
        out.append(w)
    if b["tz_warning"]:
        out.append(b["tz_warning"])
    out += _webhook_warnings(b["webhook"], b["utc_offset_min"], b["now"])
    out += [f"{x['text']}. It still silences; see Silence rules in Noise & tuning" for x in b.get("silence_spikes", ())]
    if b["suggestions_old"]:
        out.append(f"{b['suggestions_old']} of {b['suggestions']} configuration suggestions have waited more than "
                   f"{int(P['health.suggestion_days'])} days for an answer: accept or reject them in the "
                   f"Configuration tab")
    if b["unknown_privacy"]:
        out.append(f"{b['unknown_privacy']} lookup rows have a privacy value that is neither Private nor Public")
    if b["bad_cidr"]:
        out.append(f"{b['bad_cidr']} lookup rows have a network that cannot be read")
    if b["poll_wait_s"] > live.settings.poll_seconds:
        out.append(f"Sycope is not answering: the next poll waits {b['poll_wait_s']:.0f} s")
    return out
