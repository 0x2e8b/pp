"""Who an incident is about.

An entity is `<kind>:<value>`. Today the triage resolves every host to its IP, names it from the hostnames file or
reverse DNS, and groups hosts by pattern (a story) or by network (a campaign). The other kinds are what the stored
records take already: an incident about a hostname from Sycope's asset discovery, a user from AD (TrueID) or a device
from DHCP needs a resolver that fills them, not a new schema.

    kind     example                      comes from                                  resolution confidence
    ip       ip:10.88.2.54                the alert's client or server                ip_only       40
    host     host:ws-0123.corp.local      asset discovery, DNS, the hostnames file    (with the IP)
    mac      mac:00:1a:2b:3c:4d:5e        DHCP                                        dhcp          80
    user     user:CORP\\jkowalski          AD / TrueID logons                          ad            95
    subnet   subnet:10.88.0.0/16          a campaign's network
    pattern  pattern:investigate:CR-09    hosts that show the same pattern (a story)

Every record keeps the identifiers it knew at the time ({"ip": [...], "host": [...], "user": [...]}) so a search by
any of them finds the incident, and the resolution that named the subject (method and confidence), so an analyst can
tell an IP-only incident from one tied to a user.
"""

from __future__ import annotations

import csv
import ipaddress
from pathlib import Path

from sycope_clusters.addresses import Entry

KINDS = {"ip": "IP", "host": "Host", "mac": "MAC", "user": "User", "subnet": "Subnet", "asset": "Asset",
         "pattern": "Pattern", "cluster": "Cluster"}
# how sure the subject is the same thing over time (Entity Resolution: IP-only < MAC < DHCP < AD)
RESOLUTION = {"ip_only": 40, "mac": 70, "dhcp": 80, "ad": 95}


def key(kind: str, value: str) -> str:
    if kind not in KINDS:
        raise ValueError(f"unknown entity kind {kind!r}")
    return f"{kind}:{value}"


def parse(k: str) -> tuple[str, str]:
    kind, _, value = (k or "").partition(":")
    return (kind, value) if kind in KINDS and value else ("", k or "")


def label(k: str) -> str:
    kind, value = parse(k)
    return f"{KINDS.get(kind, '?')} {value}" if kind else value


class Networks:
    """Names of the operator's networks, from a CSV `cidr,name[,role]` (SC_NETWORKS_FILE): the most specific match
    names an IP ("VLAN-HR", "DMZ-PROD"). Cheap context until asset discovery and AD are connected."""

    def __init__(self, rows: list[tuple] | None = None) -> None:
        self.rows = sorted(rows or [], key=lambda r: -r[0].prefixlen)
        self._cache: dict[str, str | None] = {}

    @classmethod
    def load(cls, path: str | Path | None) -> Networks:
        rows = []
        if path and Path(path).is_file():
            with Path(path).open(encoding="utf-8", newline="") as f:
                for row in csv.reader(f):
                    if len(row) < 2 or row[0].strip().startswith("#"):
                        continue
                    try:
                        net = ipaddress.ip_network(row[0].strip(), strict=False)
                    except ValueError:
                        continue
                    name = row[1].strip()[:60]
                    role = row[2].strip()[:60] if len(row) > 2 else ""
                    if name:
                        rows.append((net, name, role))
        return cls(rows)

    def entries(self) -> list[Entry]:
        """The rows as address entries (source "file"): name and role (as function), no privacy."""
        return [Entry(net, name=n, function=r, source="file") for net, n, r in self.rows]

    def name(self, ip: str | None) -> str | None:
        if not ip or not self.rows:
            return None
        if ip not in self._cache:
            try:
                addr = ipaddress.ip_address(ip)
            except ValueError:
                self._cache[ip] = None
                return None
            self._cache[ip] = next((n + (f" ({r})" if r else "") for net, n, r in self.rows
                                    if addr.version == net.version and addr in net), None)
        return self._cache[ip]


def of_ip(ip: str, names: dict | None = None, locs: dict | None = None,
          nets: dict | None = None) -> tuple[dict, dict]:
    """The identifiers and the resolution of a host known by its IP (the only resolver today)."""
    ids: dict[str, list[str]] = {"ip": [ip]}
    name = (names or {}).get(ip)
    if name:
        ids["host"] = [name]
    loc = (locs or {}).get(ip)
    if loc:
        ids["location"] = [loc]
    net = (nets or {}).get(ip)
    if net:
        ids["network"] = [net]
    return ids, {"method": "ip_only", "confidence": RESOLUTION["ip_only"]}


def merge(a: dict | None, b: dict | None, cap: int = 50) -> dict:
    """Union of two identifier maps, kind by kind, order kept."""
    out: dict[str, list[str]] = {}
    for src in (a or {}, b or {}):
        for kind, values in src.items():
            seen = out.setdefault(kind, [])
            for v in values:
                if v not in seen and len(seen) < cap:
                    seen.append(v)
    return out
