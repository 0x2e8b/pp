# Sycope triage and clusters (sycope_clusters) v0.5.01b

Security triage on top of Sycope alerts. Every minute the service reads new alerts from Sycope's `alerts` stream (NQL
over the REST API, read-only), keeps the last 24 h in memory, and turns them into a short queue of incidents for an
analyst: one host, a host attacked from outside, a group of hosts with the same pattern, or a campaign in one network,
ranked by evidence, with the reason in words, the next steps to check and the math term by term. Past days are read
into a small SQLite database, so the triage knows what each host does every day (novelty) and what most hosts do
(rarity). The pages look like Sycope and are meant to be opened through Sycope Passthrough. The product name on the pages is
**Security Triage** (top bar "Sycope | Security Triage"); the package and the service stay `sycope_clusters`, and the
Passthrough entry stays `clusters`.

1.0 adapts to the customer's network by itself: it learns what is normal here (rarity of each rule, upload volumes
per host and role, host roles, network segments, the work calendar, the team's rhythm) from the stored days and an
hourly netflow aggregate, and an admin can change in the GUI what a team reasonably wants to change, with preview,
versions and rollback. Learning computes norms only; it never silences anything, never marks a crown jewel and never
moves a verdict threshold. Every number the math uses says where it comes from: factory, learned (from how much
data), admin or a deployment setting.

1.1 added **Security Clusters** beside Triage: the same alerts grouped Maciej's way (see below). The top bar of both
products has a switch. From 1.2 the second page is **Episodes** by default and the Clusters board (its own verdict and
priority) is a comparison mode, `SC_CLUSTERS_COMPARE=true`; see "What 1.2 changes".

## What 1.2 changes (fixes for the CISO audit of 1.1.2)

Triage is the one verdict engine of the product; everything else shows its verdict and status, never its own.

- **Stages**: Recon, Foothold, Lateral, Objectives (letters R F L O). A command channel is a Foothold (it still weighs
  and ranks like Objectives, so a missed one is never left in Review). Reasons say "confirmed" only at high confidence
  (`wording.conf_high`), else "<Stage>-stage signal". Rule mapping is direction-aware (inbound, outbound, internal), the
  ATT&CK technique and tactic come from the product's own table (`attack_map.py`), none is better than a wrong one.
- **Episodes** replace the Clusters verdict in the default mode: the time-chained alerts of a host, with the Triage
  verdict and status of that host and a link to its incident. No priority, status or action of their own. Compare mode
  (`SC_CLUSTERS_COMPARE=true`) keeps the 1.1.2 Clusters behaviour with the audit's fixes; `SC_DEBUG_MODELS=true` adds the
  reference models to its card for admins.
- **Memory** (`memory.py`): habit is learned only from days someone decided (an incident that ended unreviewed does not
  teach "this is normal"), recurrence adds bits for a host whose incidents keep ending undecided, hysteresis keeps a host
  that was Act now at Investigate for 72 h unless an analyst acts, and a verdict falls one level per 24 h. An exception
  that covers a host's evidence counts as that action (an incident whose evidence it covers entirely closes as
  Excepted and leaves the SLA queue), an analyst's action protects the host whatever its age (only what the service
  showed after it counts), and the reads behind all this are cached until the store changes (a board rebuild with no
  decision written since the last one costs milliseconds, not seconds, on a large history).
- **Weak signals stay suspected**: a class C finding (a weak or ambiguous signal) adds its bits but is never severe,
  never a command-and-control leg of CR-01, CR-02 or CR-05 and never a step of a chain rule. One High "Suspicious SSH
  Protocol Change" alone is Review, as in 1.1.2; on the replay boards five hosts that reached "Full kill chain" through
  that rule fall from Act now to Investigate (`docs/mitre-mapping-1.2.md`).
- **Workflow**: SLA per incident (Act now 30 min / 4 h, Investigate 4 h / 24 h) with a queue column, breach and unowned
  events, an outbound webhook (below), the ticket text written by the service, the Digest with week over week, MTTA, MTTR
  and Act now per day.
- **Exceptions**: credential, exfiltration, C2 and threat-list matches need a second confirmed person; one that would hide
  many alerts or hosts needs an admin; the proposer's identity must have been confirmed.
- **Silence rules (1.4)**: the exceptions with precise fields: alert name, source, destination (IP or CIDR, v4 or v6),
  port or range, protocol (TCP, UDP, ICMP from Sycope's `protocolName`) and a time window (weekdays, `HH:MM-HH:MM`, may
  cross midnight, in the calendar offset). Started from an alert line on a host page, with a preview of what it hides.
  Guard rails: a name alone is refused (tune the rule in Sycope), a time window needs a source or destination, expiry 1-90
  days, a second person for a network wider than /24 (IPv6 /64), a big preview or a protected family. Per rule: hits today,
  in 7 days and in total, last hit, hosts, a 14-day bar chart and an hourly hit log (kept 90 days) in Noise & tuning; the
  audit gets the first hit per host, edits, extensions, expiries and spikes. A rule whose last hour exceeds
  `silence.spike_x` (10) times its usual hour and `silence.spike_min` (50) alerts keeps silencing and is reported in Health,
  the bell and the audit. Silenced findings stay on the host page under Silenced; the Simple view shows only "N alerts
  silenced" in the queue footer. The older service / host-rule / host exceptions are rules in the same table (same id,
  author, reason, expiry, approval) and the old API bodies still work.
- **Wording and units**: one date format (`HH:MM` today, else `YYYY-MM-DD HH:MM`, in the configured offset), `,` for
  thousands, every count with its noun, confidence as low / medium / high with the percentage in a tooltip, host names and
  roles with their source in a tooltip, health warnings that say what the missing data costs.
- **Acceptance test**: `tests/test_purple_team.py` (scan, brute force, lateral movement, then an upload above the exfil
  bar on one host, asserted at every step).

### New environment settings

| Setting | Default | Meaning |
|---|---|---|
| `SC_CLUSTERS_COMPARE` | false | true: `/clusters` is the 1.1.2 Clusters board with its own verdict and priority (for comparing the boards on a lab); false: Episodes, no verdict of its own |
| `SC_DEBUG_MODELS` | false | true: an admin also sees the reference scoring models and their blend on the Clusters card (compare mode only); nobody else ever does |
| `SC_WEBHOOK_URL` | empty | incident events as JSON POSTs (`incident.new`, `incident.raised`, `incident.status`, `sla.breached`, `actnow.unowned`) from a queue of 500, three retries (2, 8 and 30 s), failures in the audit log and on Health |
| `SC_WEBHOOK_SECRET` | empty | signs each body: `X-SC-Signature: sha256=<HMAC-SHA256 hex>`; the signature has no timestamp, a receiver that must refuse replays checks `event_id` and `at` in the body |
| `SC_WEBHOOK_VERIFY_TLS` | true | false for a receiver with a self-signed certificate |

`SC_BASE_HREF` decides the `link` of an incident in a webhook event and in the ticket text: absolute when it is set
(`https://<sycope>/npm/api/v1/passthrough/clusters`), otherwise relative to wherever the pages are opened, which a
receiver cannot follow. Set it before turning the webhook on. All five are passed through `compose.yaml` and listed in
`.env.example`.

### New parameters (Configuration, parameters; draft and publish like every other number)

| Parameter | Default | Meaning |
|---|---|---|
| `wording.conf_low`, `wording.conf_high` | 0.2, 0.6 | where confidence is called low, medium, high; "confirmed" in a reason needs high |
| `recurrence.days`, `.min1`, `.bits1`, `.min2`, `.bits2` | 14, 3, 1.0, 5, 2.0 | incidents of a host (Review or above) that ended undecided within the window; bits added at the two counts |
| `hysteresis.step_h`, `hysteresis.act_hold_h` | 24, 72 | a verdict falls at most one level per `step_h`; a host that was Act now stays at least Investigate for `act_hold_h` with nothing above Watch (an analyst's action, or an exception covering its evidence, ends both) |
| `sla.act.ack_min`, `sla.act.handle_h`, `sla.investigate.ack_h`, `sla.investigate.handle_h`, `sla.unowned_min` | 30, 4, 4, 24, 30 | first action and close or escalate, per peak verdict; minutes an Act now incident may stay unowned |
| `exception.big_alerts`, `exception.big_hosts` | 1000, 20 | an exception that would hide more than this many alerts (24 h) or hosts needs an admin |
| `edge_forbidden_rules` | SMB External, SMB Traffic to External Networks, Unauthorized NFS Export Data | protocols that must not cross the internet edge: going out they weigh whatever the volume |
| `shared_infra_extra` | empty | networks (CIDR) added to the shipped shared-infrastructure list, used when the alerts carry no ASN |
| `health.fill_warn`, `health.coverage_min`, `health.suggestion_days` | 0.5, 0.9, 7 | Health warns for a field filled in under this share, a stored netflow day under this share of its hours, a suggestion waiting this many days |

`verdict.impact_conf` and `verdict.crown_stage_conf` kept their ids and values; they now read "command channel or
Objectives" and "crown jewel at Lateral".

### Version 0.5.01b: chain rules renumbered

Product is still an internal beta, so the chain rule ids were renumbered to read in severity order (no suffixes, no
gaps): old Triage CR-02 -> CR-01, CR-05 -> CR-02, the 7-day kill chain (the suffixed one) -> CR-03, CR-07 -> CR-04, CR-01 -> CR-05, CR-03 -> CR-08,
CR-04 -> CR-09, CR-08 -> CR-10; Clusters CR-02 -> CR-01, CR-05 -> CR-03, CR-01 -> CR-05, CR-06 (worm) -> CR-07,
CR-03 -> CR-08, CR-04 -> CR-09. CR-06 is new. At the first start the state database is rewritten once (incident
chains, snapshots, story keys, step ids, audit lines, configuration versions: parameters `chain.CR-..`, `act_chains`,
`p1_chains`, playbook edits), guarded by the `meta` key `chain_ids` = 2 (`chain_migration.py`). A
`config-import.json` written before the upgrade still carries the old ids and must be renumbered by hand.

The rule catalog also knows the official Sycope 3.3 template names now: 22 aliases of the short names (SYN Flood Attack
is SYN Flood, `aliases.py`, one dict that every name-keyed table takes its alias rows from) and 11 templates it did not
have (Crypto Mining Pool Connection, Web Shell Activity Pattern, Database Port Exposed to Internet, Telnet to External,
Email Worm, NetBIOS/SMB Discovery, Possible SPAM activity, Large Size ICMP/TCP/UDP Packets, Ingress from High-Risk
Countries). A template the customer renamed is still recognised by its template id. On the System page an alert name
the catalog does not know is a link that opens the Rule catalog card with its classify dialog (admins), where "Classify
like..." copies the classification of a known rule into the form.

### Upgrading to 1.4

The state DB migrates in place at the first start, additively: nine columns on `exceptions` (`src`, `dst`, `proto`,
`win_days`, `win_from`, `win_to`, `edited_by`, `edited_at`, `pruned_alerts`; `dst` is filled from `server` of a service
and `src` from `actor` of a host-rule or host exception) and two tables, `silence_hits` and `silence_hosts`. Nothing is
dropped. Going back to 1.3 leaves the extra columns and tables unused; silence rules (kind `silence`) are then ignored by
1.3, so their alerts count again. Alerts now carry `protocolName` in the window buckets (one more field read from Sycope;
the past days' aggregates do not need it).

### Upgrading from 1.1.2, and going back

The state DB migrates in place at the first start, additively and idempotently: three columns on `incidents` (`peak_n`,
`peak_at`, `reopened_at`: the size at the peak, when the peak verdict was reached for the SLA clock, when new evidence
last lifted an analyst's status) and two on `exceptions` (`second`, `verified`), and three indexes (`verdict_log(at)`,
`incidents(closed_at)`, `incidents(outcome_at)`). Nothing is dropped or rewritten, with one exception to "only
additive": a proposal that was pending under 1.1.2 gets `verified = 1` from its own audit line when Sycope had
confirmed its proposer at the time. A pending proposal whose proposer was not confirmed stays unverified: for a
protected family (credential, exfiltration, C2, threat intelligence, a whole host) it cannot be approved ("needs two
confirmed people"), so reject it and have a confirmed person propose it again. The
hysteresis clock is one JSON row in `meta` (`hysteresis_clock`), written by 1.2 only. Stored scoring presets keep their
internal ids (the neutral ones exist only on the wire).

**Back up the state DB before deploy; rollback = restore that backup and run `release-1.1.2`.** Stop the service
cleanly and copy it, for example
`docker compose stop app && docker compose run --rm --no-deps --entrypoint cp app /state/clusters.db /state/clusters.db.bak-1.1.2`
(the service also keeps a daily copy in `/state/backups`). To go back: stop the service, put the build `release-1.1.2`
in place and copy the backup over the live file,
`docker compose stop app && docker compose run --rm --no-deps --entrypoint cp app /state/clusters.db.bak-1.1.2 /state/clusters.db`.
**Everything done under 1.2 after the backup is lost on restore**: statuses, incident records, exceptions added or
approved, notes, audit lines and configuration versions published in 1.2.

Checked on a temporary `release-1.1.2` worktree: **1.1.2 opens a DB written by 1.2**. The extra columns are ignored,
incidents, history, exceptions (with `second` and `verified`), digest and System page load, and the board is built. What
does not carry over is a configuration version published in 1.2 with any of the new parameters above: 1.1.2 rejects it
("unknown parameter ...", the log and Health say the version is not valid and not used), does not use it and falls back to the
last good version or the factory values. Going back without the restore therefore also means publishing the setup you
want again in 1.1.2 (Versions > roll back to a version made before the upgrade). The 1.2 hold clock, SLA clocks and
recurrence are simply not read by 1.1.2. The restore is still the clean way back, because it also removes 1.2 records
whose wording 1.1.2 does not know.

## Pages

| Path | What |
|---|---|
| `/` | **Triage**: every section is a card with a folding header (the state is remembered per browser); the first card holds the funnel (alerts → findings → busy services → incidents (hosts) → to act on) and the actions, the queue is a card of its own. The queue is a table of incidents in sections per verdict, each row marked Host, Target, Group · N or Campaign · N, in a table styled like Sycope's (header band, row lines, severity-style verdict badges, **compact** one-line rows). Columns: Verdict, Incident (what happened, IPs and ports in monospace), Kill chain (the four stages confirmed vs suspected, with **R F L O** above the blocks), Scope, Confidence, Last activity, Status and owner, and the row actions in a cell of their own (Take, Seen and Close… show on the row under the mouse and do not cover the status). The sticky toolbar holds the day summary ("15 incidents (1 289 hosts) · 1 act now · 2 investigate", the full funnel in its tooltip), the who-has-it chips (Mine, Unassigned, Escalated), sorting inside each verdict, search, density and **Action ▾** for one action on all ticked incidents, plus Pause updates. A click is a quick look in a resizable side panel; Open › opens the incident in a new tab; **⋯** or a **right click** opens a menu of what works for that row, address or alert line (state changes, flows and alerts in Sycope, copy; Shift + right click gives the browser's menu). Lookups of outside addresses (`SC_TI_PIVOTS`) sit under one **Check externally ▾** button. Hosts someone took that went quiet stay at the end (**Taken, now quiet**). Tabs in three groups with outline icons and counts only where they mean something: the work (Queue, **Under attack**, **External**), the tuning (**Noise & tuning**: busy services, suggestions from the team's closures, exceptions and those waiting for approval; **Hygiene**) and the records (**History**, **Audit**); for a confirmed admin also **Configuration** (below). While the profile is still learning a line above the tabs says "Profile: N/14 days". The alert lines and the earlier incidents start folded |
| top bar | one **search** for everything (incidents, hosts with alerts, targets, outside addresses, history), the analyst's name (from the Sycope login), a **UTC | Local** switch for the times on the pages (per browser, `localStorage` key `sc-tz`, default Local = the browser's zone with DST; text the service writes uses `calendar.utc_offset_min`, CSV exports are always UTC), **?** for help |
| `/incident` | one incident on its own page, breadcrumb and Previous / Next in the queue's order, each part a card whose header folds it (remembered in the browser; Alerts, Earlier incidents, Why / the math and Where it talked start folded): `?ip=` a host or a target (summary with the actions, **next steps**, attack path, what happened, alert lines, where it talked (flows from Sycope), last days, history, earlier incidents, the math folded), `?story=` a group (next steps, what connects the hosts, scope, filters over its hosts, actions on all, the shown or the ticked hosts), `?campaign=` a network segment (its incidents and hosts), `?history=` a record of the incident history (an incident that ended unreviewed can be taken, escalated, seen or closed there, with the next steps from its peak) |
| `/help` | the whole help on one page; the **?** opens the part for the view on screen in a side panel (as Sycope does), with annotated screenshots (31, the ⋯ and right-click menu and the Configuration tab among them) |
| `/digest` | the last 24 h in words for the security manager, printable |
| `/clusters`, `/scoring`, `/system` | **Episodes** by default (the time-chained alerts of each host with Triage's verdict and status, no verdict of its own); with `SC_CLUSTERS_COMPARE=true` **Security Clusters** (below); the Clusters scoring page (presets, `maciej_note` by default) with the rule catalog; the feed, the board, stored days, settings and the **Health** card. `/classic` redirects to `clusters` |
| `/board`, `/host?ip=`, `/story?key=`, `/campaign?net=`, `/lane?name=`, `/audit` (CSV too), `/history` (CSV too, `hours=` for a shift), `/whoami`, `/history-item?id=`, `/search?q=`, `/handover?hours=`, `/flows?c=&s=&port=&from=&to=&mode=raw\|client\|server`, `/exception-preview`, `/helpdoc`, `/helpimg?n=` | JSON (and the help's pictures) |
| `/config`, `/config-version?id=`, `/config-export?id=`, `/config-preview?draft=`, `/profile` (`?history=<param>`), `/exceptions`, `/crown`, `/catalog`, `/health-data`, `/replay?day=&config=&profile=` | JSON for the Configuration tab, admin pass only (403 otherwise) |
| `/action` | POST (SC_TRIAGE_EDIT=true): triage state of a host or of hosts named one by one (op `triage`, `hosts`), undo (`restore`), notes (`comment`), next steps (`step`), exceptions (`exception-add`, `exception-remove`, `exception-decide`), ended incidents (`record`). Admin ops (`config:draft`, `config:publish`, `config:rollback`, `config:import`, `exception:expire`, `profile:override`, `profile:internal`, `profile:freeze`, `crown:add`, `crown:remove`, `suggestion:answer`, `catalog:set`) need a verified admin pass and work whatever SC_TRIAGE_EDIT says |
| `/healthz` | liveness, no auth |

## Security Clusters (clusters.py, cluster_work.py, engine/)

In 1.2 this is the compare mode (`SC_CLUSTERS_COMPARE=true`). By default `/clusters` shows **Episodes** (`episodes.py`):
the same time-chained alerts per host with the kill-chain stages they reached, the host's Triage verdict and status
and a link to its Triage incident, and no verdict, priority or action of its own. Everything below describes the compare mode.

Clusters is the other answer to "how should the Security Module show alerts", on `/clusters`, so management can compare
it with Triage on the same live data. It is Maciej's approach, kept recognisable: alerts of one **actor host** are
chained in time (gap under 1 h) into a **cluster**, one time episode of one host. The kill-chain **phase**
(Recon, Foothold, Lateral, Objectives) comes from the rule catalog (`rules.py`), not from the template's MITRE tactic;
rules of the families CL-07, CL-08, CL-09, HYG, POL and class D rules set no phase, and a cluster made only of them
cannot rise above Watch. The score is Maciej's (`maciej_note` preset: severity per alert type at its own stage, best
product wins; `alert_cluster` stays selectable on `/scoring`, and a saved `alert_cluster` model is migrated once).
**Chain rules** CR-01, CR-03, CR-05, CR-07, CR-08 and CR-09 are score multipliers (x1.4..x2.5), read across a host's clusters and, for the longer
windows, the stored days; a card and a table row show one line, "Chains ×1.8" and a chip per matched rule (the one that set the multiplier filled; the tooltip says "Confirmed C2 (CR-05) across 3 clusters"). CR-07 groups hosts by their /24 (/64), or by a lookup entry when that is a /24 or narrower. **Memory badges** say whether
the lead rule set was seen on that host before (New / Recurring Nd) with a 7-day heatmap, and a host that repeats the
same rule set on 3 of the last 6 days is folded under Chronic (display only, the score is untouched). Hosts that are
only the target of others' alerts sit in an **Under attack** lane and outside addresses in an **External** lane, never
as host cards. Views: Threat Board, Table, Timeline, Impact x Certainty.

Work layer: the same as Triage. Take, Seen, Close... with a reason, notes, playbook next steps, exceptions, bulk actions,
Undo, the audit log, the verified Sycope user, handover and Ended, not reviewed, all through `POST /action` with
`"product": "clusters"` (no new POST path, so no Passthrough rule change). The work object is the cluster, with a stable
episode id (`cl:<id>`) that survives the window moving; a closed cluster that rises above the verdict it had at close
shows again as New. Status spaces are separate: closing a host in Clusters does not close it in Triage, and the other
way round. Exceptions and crown jewels are shared.

Differences from Triage: no evidence bits, rarity or novelty, no stories (groups) and no campaigns, no adaptive profile
or Configuration tab. The only things shared with Triage are the ingest window, the rule catalog, networks and lookups,
crown jewels and exceptions, the store, identity, audit and playbook machinery. A Triage config change cannot move a
Clusters verdict. Clusters reads the hourly finding buckets of the window (exact first/last time in ms), which gives the
same episode boundaries as the raw alerts; burstiness and the certainty volume factor are computed from bucket counts.

Sizing and limits of Clusters:

- At the worst-case synthetic load (2M alerts/day, 50k hosts, 14 stored days) 1.1 peaked at about 2.23-2.32 GB RSS on
  macOS (1.0: about 2.03 GB). The 2.5 GB container (`SC_MEMORY_MB` 2560) still holds, with about 200 MB headroom.
  For sites near 2M alerts/day run a **3 GB** container (`SC_MEMORY_MB` 3072).
- **Lean mode**: Clusters compares the service's memory estimate plus 3x the last full Clusters board against 55 % of
  `SC_MEMORY_MB`. Above that it drops the hygiene findings (HYG, POL, CL-09: no phase, most of a big window) from the
  board; they would only extend chains and counts. The page says so, and lean ends when the same figure is back under
  40 %. At sites near 2M alerts/day lean is the normal state, so Clusters there leaves out HYG/POL/CL-09 findings.
  Clusters has its own switch and never thins Triage's window.
- `SC_DELTA_SECONDS` below 3600 acts as 3600 (Clusters chains hourly findings; a warning is logged).
- `SC_CLASSIC_MAX_ALERTS` is ignored by Clusters, which has no off switch any more.
- Upgrade from 1.0.0: the DB migrates in place at the first start (two new tables, `cluster_triage` and
  `cluster_episodes`, and a `product` column on `incidents`, `audit` and `verdict_log`; nothing is dropped). Triage rows
  keep `product = 'triage'`. Back up `clusters.db` first, with the service stopped cleanly:
  `docker compose stop app && docker compose run --rm --no-deps --entrypoint cp app /state/clusters.db /state/clusters.db.bak-1.0.0`.
  Rollback: the 1.0.0 build (`main` fcff795) with `/state/clusters.db.bak-1.0.0` copied back to `/state/clusters.db`;
  Triage and Clusters work done under 1.1 is lost. A plain downgrade without the copy is not safe: 1.0 has no product
  filter, so Clusters records would show in Triage History and Handover, and 1.0's recorder would close them.

## Triage model (src/sycope_clusters/evidence.py, rules.py)

The MITRE tactic of a template is a reporting tag, not proof: on the lab, "Suspicious Port - Allowlist" (tag C2) fires
on 28% of all hosts, so with tag-based stages two thirds of all clusters "reached the last stage". Here each rule has a
product-owned entry in `rules.py`: family (CL-01..CL-12, port hygiene, policy), class A-D (indicator, attack
behaviour, weak signal, hygiene), the kill-chain stage it can confirm, and whose behaviour it describes.

```
finding  = one rule between one host and one counterpart (and port) in the window      ~19 alerts per finding
bits     = min(class + severity + threshold level, rarity, habit) - deductions
           rarity = log2(1 / p), p = (k + alpha * p0) / (n + alpha): host-days with the signature over acting
                    host-days on comparable days, shrunk toward the shipped prior p0 (peer group: the host's role)
           habit  = log2((D + 2) / (d + 1)) when the host had the rule on d of the last D non-dormant days
           deductions: shared cloud/CDN counterpart (external only) for intel and beacons; "uploads" that are
           downloads become traffic anomalies; an upload confirms Objectives only at max(10 MB floor, the host's or its
           role's q99), +1 bit at 10x and +2 at 100x that norm; a DNS resolver relaying its clients
evidence = sum over families of the strongest finding (only one weak signal counts) + progression + chain rules
confidence = 1 / (1 + 2^-(evidence - 8)), risk = confidence x impact of the confirmed stage (crown jewel x 1.5)
```

What is learned, daily from the stored days (never from today) and the hourly netflow aggregate: rarity shares per
rule, counterpart and port; upload and answer volume norms per host and role; host roles (resolver, directory,
database, file, web, mail, proxy, IoT/OT, workstation; Sycope's lookup function first); segments (Sycope subnet
lookup first, else learned /24 and /64 merged up to 8 active hosts); the calendar (off days and dormant days such as
holidays); the team's rhythm (shift gap from the audit, 24/7 when the team acts in 20 of 24 hours). Host-days of
hosts in open or true-positive incidents are left out of the norms, a learned value moves at most x2 a day, a host's
volume norm never exceeds 4x its role's, and a threat-intel finding keeps at least 2 bits of rarity. Roles that would
only lower evidence (scanner, backup server, monitoring poller) and public addresses that look like yours are
suggestions an admin accepts. Class bits, CONFIRM, PRIOR, IMPACT, chain bonuses and the verdict table are never
learned: an admin can change them, and the profile then shows "modified".

Chain rules add bits. The number is the display order, CR-01 the most severe; the same ids are used in Triage and
Clusters, and a rule one view does not have leaves a gap there.

| Rule | Name | Bits (Triage) | View |
|---|---|---|---|
| CR-01 | Data theft in progress: command channel and a large upload | 4.0 | Triage, Clusters (x2.0) |
| CR-02 | Full kill chain (24 h): three of scanning, credentials or lateral, command channel, exfiltration | 4.0 | Triage |
| CR-03 | Full kill chain (7 days): three of the four groups within the last 7 days (stored days) | 3.0 | Triage, Clusters (168 h window, x2.5) |
| CR-04 | Staged exfiltration: data collected internally, then uploaded out | 3.0 | Triage |
| CR-05 | Confirmed C2: threat-intel contact and a beacon or covert channel | 3.0 | Triage, Clusters (x1.8) |
| CR-06 | Compromised, then calling home: attacked over credentials or lateral movement by another host, then its own command channel starts | 3.0 | Triage |
| CR-07 | Worm propagation: scanning on 3 or more hosts of one segment | - | Clusters (x1.8) |
| CR-08 | Credential theft, then lateral movement | 2.0 (+1 same hosts) | Triage, Clusters (x1.6) |
| CR-09 | Recon, then exploitation | 1.5 (+1.5 same hosts) | Triage, Clusters (x1.4) |
| CR-10 | Persistent channel: the same command or intel contact on 5 of the last 7 days (stored days) | 1.0 | Triage |

CR-08 and CR-09 add more when the second step hits a host the first one touched. CR-06 reads the credential and lateral
findings of other hosts (confirmed, not class C) that name the host as their counterpart or target, and needs the
host's own command channel to start after the first of them; it makes a ticket P1 but does not force Act now.

The verdict is a decision table (Act now / Investigate / Review / Watch) with the matching line as the reason.

Incidents: a **host** that acts; a **target**, a host attacked across the edge (RDP, brute force, credentials, a scan)
or by a listed address that answered and does not act itself (Review; Investigate when it answered 1 MB or more, is a
crown jewel, or the source is listed); a **group**, hosts with the same verdict and pattern, split when its hosts went
after different targets (connected through the counterparts of their confirmed evidence, two or more parts of 3+ hosts
and a tenth of the group, each named by the counterpart that ties it); a **campaign**, more hosts of one segment at
Investigate or above with the same intrusion families than chance explains for its size (P(X >= k | Binomial(N, b))
< 1e-4 with b the learned daily share of such hosts, and k >= 5), holding the groups and hosts that mostly sit in it,
so a host counts once. Inside a verdict,
incidents quiet for 6 h or more sort lower within their stage.

## Working an incident (triage.py, playbook.py)

Statuses: New, In progress (an owner: take it or assign it), Escalated (to L2 or a named team), Seen (out of the queue
until it shows something new), Closed as true positive, benign or false positive with a reason from a short list and,
at Act now and Investigate, a note. Every action returns what it replaced: the toast offers Undo.
An Act now or Investigate incident that goes quiet before anyone looked moves to **Ended, not reviewed** (between
the live Investigate and Review) for `SC_UNREVIEWED_DAYS` (14) and can be taken, escalated, seen or closed there. Notes on a host, a
group or a campaign go into the audit log and the incident's history. Group actions apply to all hosts, the hosts a
filter shows, or the ticked ones; the dialog states the scope and how many are at Act now.

**Next steps** are built from the incident's own evidence (playbook.py): its chain rules first, then its strongest
families, then the context (crown jewel, recorded packets). A step is a check (Sycope flows or alerts of the exact
pair and time, readable in the page), an ask (EDR, auth logs, the owner) or an action (containment); a ticked step is
kept on the incident record with the analyst and the time. **Copy as ticket** gives IT a priority P1-P4, the recommended
actions, the checklist, indicators and links, the math in an appendix.

Ticket priority (`priority()` in playbook.py): **P1** = Act now on a crown jewel, or Act now with a chain that already
means a compromise (`P1_CHAINS`: Confirmed C2, Data theft in progress, Full kill chain, Staged exfiltration, Compromised then
calling home and, since 0.5.4, Credential theft, then lateral movement, CR-08); **P2** = Act now otherwise, or Investigate on a crown jewel;
**P3** = Investigate; **P4** = Review (Watch). `P1_CHAINS` is `ACT_CHAINS` (evidence.py) plus CR-06 and CR-08 and is separate
from it: `ACT_CHAINS` drives the verdict, so CR-06 or CR-08 alone do not force Act now, they only raise the ticket.
The P tag's tooltip says what would raise the priority one level, and the P1 reason names the chain ("Act now with
Credential theft, then lateral movement"). **Copy as handover** (History; by default since the team was last here: the last action before a
pause of the learned shift gap, 6 h until 14 days of audit exist; 24/7 teams get 8 h) lists what opened, what the team did, what is still open and who has it, and the notes. CSV exports (Audit, History) are
named `sycope-security-triage-audit-<date>.csv` and `sycope-security-triage-incidents-<date>.csv`.

## Incident history and entities (src/sycope_clusters/history.py, entities.py)

Each incident gets a record from the moment it enters the queue: peak verdict and its reason, a snapshot of the
evidence at the peak, the analysts' outcome (with the reason), the checked steps and the events (opened, escalated,
handled, noted, reopened, closed). A record closes 15 minutes after the board forgets it: expired without action, merged
into a group, or with the outcome the analysts gave it; one an analyst holds (In progress, Escalated) never closes by
itself. Group incidents are matched by their hosts, not by their key. Numbers count like the queue: an incident inside a
campaign is part of it. Records are kept `SC_INCIDENT_DAYS` days (180).

The subject of a record is an entity `<kind>:<value>`: `ip:10.88.2.54`, `pattern:investigate:CR-09`,
`subnet:10.88.0.0/16` today; `host:` (asset discovery, DNS), `user:` (AD / TrueID) and `mac:` (DHCP) are in the
schema with the identifiers and the resolution method and confidence, waiting for those resolvers. `SC_NETWORKS_FILE`
names networks (CSV `cidr,name[,role]`).

## Configuration (admins; confplane.py, admin.py, confui.py)

One tab **Configuration**, shown only to a user whose pass Sycope confirmed as ROLE_ADMIN (identity.py); the page
cannot claim it. Cards: Health of the configuration, Profile (learned values with source, n, norm confidence, last
change; override, freeze, suggestions to accept or reject with a reason), Crown jewels (manual, Sycope lookup, the old
file imported once, suggested candidates), Silenced (every exception, bulk expire, the read-only lookup list), Scoring
(the non-learnable numbers next to their factory value), Playbooks (edit, hide, move or add steps as an overlay on
the factory steps; "factory step changed, review" after an upgrade), Rule catalog (all rules seen, unknown ones to
classify) and Versions.

Every edit is a draft: **Preview** re-scores today's window with it and lists the incidents whose verdict changes,
**Publish** makes it version N (audited, the board is scored again), **Rollback** publishes an earlier version as a
new one. A version exports as JSON (schema-versioned) and imports through the same validation and preview: unknown
keys and values outside the bounds are rejected, never clamped. An invalid stored config never loads; the last good
version stays. Verdicts, incident records and audit lines carry the config version and profile day, and the replay
(`/replay?day=&config=&profile=`) scores a stored day again with recorded versions (days stored before 1.0 lack
severity, threshold, ASN and targets and replay only approximately). Only one preview or replay runs at a time (409 while one
runs) and one that would not fit in `SC_MEMORY_MB` is refused (503).

**Break-glass** (no admin can sign in): put a config JSON (as exported) at `state/config-import.json` and restart.
At start it is validated like an import, renamed to `config-import.json.applying-<ts>`, published as a new version
by "file" and renamed to `.applied-<ts>`. An invalid file stays where it is, the active version stays and Health
says why. A leftover `.applying-*` file (a crash in between) is reported on Health.

**Health**: the System page has a Health card for everyone (fill rate of each alert field Sycope sends, scoring terms
switched off for missing data, profile depth and norm confidence, unknown rules, hosts without a lookup row, lookup
errors, memory against the budget and the thinning level, last rebuild, whether the stored days are still being
learned, poll lag, last backup, netflow coverage per day). The admin's Health card in the Configuration tab adds the
active version, modified vs factory, config errors, playbook edits that point nowhere and waiting suggestions.

## Help (helpdoc.py, guide.py, tools/help_shots.py)

The help text lives in `helpdoc.py`: one part per view, each with figures whose numbered marks are CSS selectors.
`tools/help_shots.py` opens a running instance (the local preview `tools/preview_server.py` with fixture data), puts each view in the state the text
describes, draws the numbered boxes and writes `src/sycope_clusters/help/<figure>.webp`:

```bash
uv run python tools/preview_server.py 8791 > /tmp/preview.log &      # fixture data, never a real Sycope
grep '^passes ' /tmp/preview.log | sed 's/^passes //' > /tmp/passes.json
SC_PREVIEW_PASSES=/tmp/passes.json uv run --with playwright --with pillow python tools/help_shots.py http://127.0.0.1:8791/ [figure ...]
```

A mark that is not found stops the run. Regenerate after a UI change that moves a marked element.

## Run

```bash
uv sync && uv run pytest -q && uv run ruff check .
cp .env.example .env    # fill in
mkdir -p config && echo '{"critical_hosts": []}' > config/critical_hosts.json
docker compose up -d --build
```

The app listens only inside the compose network; Caddy publishes HTTPS on `SC_PORT` (8444) with Basic auth, an IP
allowlist, GET everywhere and POST only to `/scoring-model`, `/pcap-request` and `/action`. The state volume holds
`clusters.db` (history, triage, steps, exceptions, audit, config versions, profile snapshots, crown jewels, flow
aggregates), `scoring.json`, `identity.key` and `backups/` (a daily online SQLite backup, 7 kept; a corrupt DB at
start is restored from the newest good one and Health says so).

### Sizing

| Load | Container memory | `SC_MEMORY_MB` |
|---|---|---|
| lab (~150k alerts/day) | 2 GB | 2048 (default) |
| ~2M alerts/day, ~50k hosts | **2.5 GB** (3 GB near the top of that range, see Security Clusters) | **2560** (3072) |

At the worst-case synthetic load (2M alerts/day from 50k hosts, 14 stored days) the service peaks at about 2.0 GB
before any preview (1.1 with Clusters: about 2.3 GB); a lab-like mix at that volume about 1.6 GB. 2 GB is the minimum: at worst-case load the window
then stays thinned (class D and C detail first, class A and B never) and previews and replays are refused (503) as
they would not fit. Over 80 % of the budget the window thins itself; Health shows the level. Above ~50k hosts run
several instances. Rebuild at 2M/day is 6-10 s on an M3 (allow about 2x on a 4 vCPU VM); the first board after a
start is provisional for ~25 s at that scale (scored on priors, no incident records) while the stored days are
learned. `compose.yaml` sets no memory limit; set one (`mem_limit`) to match `SC_MEMORY_MB`.

### Upgrade from 0.6.x

The DB migrates in place at the first start (new tables and columns; nothing is dropped). Back it up first, as for
earlier releases, to `/state/clusters.db.bak-0.6.1` in the state volume, with the service stopped cleanly:
`docker compose stop app && docker compose run --rm --no-deps --entrypoint cp app /state/clusters.db /state/clusters.db.bak-0.6.1`. Every 0.6 `SC_*` setting
keeps working and shows as source "env" for its parameter; the crown jewels file is imported once into the DB.
Remove `SC_CAMPAIGN_MIN=20` from `.env` if it is there (the 0.6 default): it would put a fixed floor of 20 hosts
under 1.0's segment-size test (`compose.yaml` no longer sets it). Rollback: the 0.6.1 build (`main` 5238082) with
`/state/clusters.db.bak-0.6.1` copied back to `/state/clusters.db`.

Optional settings of v0.5: `SC_NETWORKS_FILE`, `SC_INCIDENT_DAYS`, `SC_EXCEPTION_APPROVAL` (analysts propose
exceptions, an admin approves; with it off, an exception from someone Sycope has not confirmed is only a proposal a confirmed user approves,
credential, exfiltration, C2 and threat-list exceptions need a second confirmed admin, and one covering over 1,000 alerts
a day or 20 hosts needs an admin; every exception has a reason and lasts 1, 7,
30 or at most 90 days), `SC_TI_PIVOTS` (lookup links for outside addresses, `Name|https://...{ip};...`; empty
by default because each link sends the address out), `SC_REQUIRE_VERIFIED_USER` (0.5.1: actions only from a user
Sycope confirmed).

Settings of 0.6 and 1.0 (all optional; the System page explains each):

| Setting | Default | What |
|---|---|---|
| `SC_UNREVIEWED_DAYS` | 14 | how long an incident that ended unreviewed stays under Ended, not reviewed; also when such a host returns to the population norms (never if it peaked at Act now) |
| `SC_CHAIN_DAYS` | 3 | days back CR-08 (up to 2) and CR-09 look for their first step in the stored days; 1 = only the 24 h window |
| `SC_CAMPAIGN_MIN` | 5 | fewest hosts that can make a campaign (env layer of `campaign_k_min`); the count must also be improbable for the segment |
| `SC_LOOKUP_NAMES` | `hosts & subnets` | Sycope subnet lookups read for internal/external (privacy column), names, location, function, service, severity; empty = the default; a name that matches no lookup is skipped (a warning in the log), so to read none, name one that does not exist |
| `SC_LOOKUP_REFRESH_SECONDS` | 900 | how often they are read again; a failed read keeps the last good one; a change is audited as "sycope-lookup" |
| `SC_SILENCED_LOOKUP` | empty | one Sycope lookup whose addresses are silenced hosts, read-only |
| `SC_FLOW_AGGREGATE` | true | hourly aggregate of the netflow stream on the last complete hour (2 small queries per hour), for volume norms and roles; false = no flow queries |
| `SC_MEMORY_MB` | 2048 | memory budget of the whole service; see Sizing |
| `SC_POLARS_RUNTIME` | auto | build argument, read at `docker compose build`: `auto` adds polars' compat runtime when the CPU of the building host lacks AVX2/FMA/BMI2 (a VM with a generic CPU type, e.g. Proxmox kvm64 or x86-64-v2-AES, where the default runtime crashes and the app answers 502); `compat` always, `default` never. The compat runtime is slower; with a CPU type `host` or `x86-64-v3` it is not needed. Build on the host that runs the image |
| `SC_RAW_PER_HOST` | 200 | newest raw alerts kept per host for its page and PCAP links (20 when thinned) |
| `SC_CLASSIC_MAX_ALERTS` | 300000 | ignored by Clusters (it has no off switch any more); still read by the decision to build the flow backfill aggregate |
| `SC_WEBHOOK_URL` | empty | receives incident events (`incident.new`, `incident.raised`, `incident.status`, `sla.breached`, `actnow.unowned`) as JSON POSTs; queue, 3 retries, failures in the audit log and Health |
| `SC_WEBHOOK_SECRET` | empty | signs each body: header `X-SC-Signature: sha256=<HMAC-SHA256 hex>` |
| `SC_WEBHOOK_VERIFY_TLS` | true | false for a receiver with a self-signed certificate |
| `SC_CLUSTERS_COMPARE` | false | true: `/clusters` is the 1.1.2 Clusters board with its own verdict and priority, for comparing the boards on a lab; false: Episodes |
| `SC_DEBUG_MODELS` | false | true: an admin also sees the reference scoring models on the Clusters card (compare mode only) |

Sycope Lookups (D43) win over `SC_INTERNAL_NETS`, `SC_NETWORKS_FILE` and `SC_HOSTNAMES_FILE`, which stay as
fallbacks. The flow aggregate is hourly, not daily, because Sycope may keep raw netflow only a few hours (2.5 h on the
lab); distinct client counts are the hourly maximum, a lower bound. The service's Sycope account also needs to read
lookups (config-elements) and the netflow stream.

## Sycope Passthrough

Settings > Integrations > Passthrough, name `clusters`: URL `https://<SC_PUBLIC_HOST>:8444`, SSL verify off, Basic
auth with `BASIC_AUTH_USER` and its password, access rules `GET ^/([A-Za-z0-9_-]+)?/?$` and
`POST ^/(scoring-model|pcap-request|action)$`. Set `SC_BASE_HREF=https://<sycope>/npm/api/v1/passthrough/clusters`
so links stay on the Passthrough. Every route is one path segment (the help's pictures too: `/helpimg?n=`).

Under the Passthrough the page asks Sycope who is signed in (`/npm/api/v1/logged-user`) and lists Sycope's users for
Assign. The flows come from Sycope's netflow stream through the service's own login; the recorder's buffer depth from
the recorder's `/system` JSON through its Passthrough.

## Who acts, confirmed by Sycope (identity.py)

The Passthrough passes on neither the user nor the session: it drops the browser's `Cookie` header (a `Set-Cookie`
reaches the browser, so a cookie never comes back), custom `X-` headers do pass, and Sycope's session cookie is
HttpOnly. Sycope does log every change a user makes to their own preferences (stream `auditMessages`, with the user and
what was written). Once a shift:

1. `GET /whoami` gives a claim (kept by the page) and its proof (an HMAC of the claim with the service's key,
   `<state>/identity.key`);
2. the page writes the proof into the signed-in user's own preferences (`PUT /npm/api/v1/user-preferences?merge=true`,
   key `sc-triage-proof`): only that user's session can;
3. `GET /whoami` with the claim (`X-SC-Claim`) finds the line in Sycope's audit log (it shows up about 6.5 s after the write), takes
   the user from it and the roles from `/npm/api/v1/user/<name>`, and answers with a pass signed for 8 hours;
4. every action carries the pass (`X-SC-Pass`): the name and the admin role come from it, whatever the page says.

The audit log marks each line: confirmed by Sycope (a ✓ on the page, `yes` in the CSV) or not. Without a pass the
action is still recorded under the name the page gave, unless `SC_REQUIRE_VERIFIED_USER=true`, and it is never an
admin's (approving exceptions needs a confirmed admin). The service's Sycope account must be able to read the audit
log (Audit Log: view) and users.

## Limits

- One process: the last 24 h of alerts in memory as hourly findings plus a ring of raw alerts per host (a restart
  reads them again; at 2M alerts/day the first poll takes about a minute). Past days live in the state database;
  the first start reads `SC_HISTORY_DAYS` days from Sycope in the background, aggregated by Sycope.
- Chain rules with order and target continuity look at the 24 h window; the weekly ones (CR-03, CR-10) only know
  which families and channels a host had per day.
- The constants of the evidence model (class bits, prior, thresholds) and the shipped priors come from the lab and
  four synthetic customers (school, bank, factory, cloud shop); recalibrate with real customer data. The campaign
  base-rate prior is `investigate_rate` 0.01 (the lab's 0.6 incidents gave 0.044): before any scored day a campaign
  in a segment of 200 active hosts needs 10 hosts at Investigate or above (22 with 0.044); a smaller worm shows as
  separate Act now hosts until the profile has scored days.
- The persistent-channel rule CR-10 needs a contact outside your networks (daily OT and monitoring polls
  habituate): an internal C2 relay relies on rarity and novelty.
- An incident record stores the config version current when it was last scored, not the one it was created with.
- The campaign quick look still scrolls sideways inside the side panel at 1280 px wide (+147 px) and 1440 px (+25 px);
  0.5.2 was worse (+182 / +61).
- Not built (backlog): an ITSM "Create ticket" with status sync (Copy as ticket is a text for now).
- Who acts is confirmed through a side door: the check depends on Sycope logging preference changes with what was
  written. If a Sycope version stops doing that, the check fails openly (no ✓) and actions fall back to the page's
  name (or are refused with `SC_REQUIRE_VERIFIED_USER`). The clean fix is the Passthrough passing the signed-in user
  on to the service itself.
