#!/usr/bin/env bash
# Launcher for the recorder installer (tools/install/wizard.py). See that file for the options.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
command -v python3 >/dev/null 2>&1 || { echo "python3 is required: apt-get install -y python3" >&2; exit 2; }
exec python3 "$here/wizard.py" "$@"
